package com.example.model

enum class Department(val displayName: String, val description: String) {
    CEO("Executive (CEO)", "High-level strategy, compliance, finance & facility oversight"),
    WORKSHOP("Workshop & Casket Crafting", "Casket fabrication, timber woodwork, satin lining & brass fittings (Bama Branch)"),
    DRIVERS("Drivers & Fleet Logistics", "Hearse drivers, transfer vehicles, cortege transport & 24/7 service (Stationed at Bama Branch)"),
    OPERATORS("Operators Department", "Gravesite setup, lowering gear, church trolleys, red carpets, stunchions & 24/7 grounds assistance (Stationed at Bama Branch)"),
    SALES_MARKETING("Sales & Marketing", "Business Development (Sale), family consultations, package & casket bookings"),
    ADMINISTRATION("Administration & Accounts", "Paperwork, billing, statutory documentation and accounts")
}

enum class StaffRole(val title: String, val description: String) {
    MANAGING_DIRECTOR_CEO(
        title = "Managing Director / CEO",
        description = "High-level strategy, executive leadership, compliance and overall management"
    ),
    WORKSHOP_WORKER(
        title = "Workshop Craftsman",
        description = "Casket fabrication, wood crafting, luxury lining, and hardware assembly"
    ),
    DRIVER(
        title = "Fleet Driver",
        description = "Hearse cortege escort, deceased transfer & 24/7 road logistics (Stationed at Bama Branch)"
    ),
    OPERATOR(
        title = "Operator / Grounds Assistant",
        description = "Gravesite equipment setup, lowering gear, church trolleys, stunchions & red carpet (Stationed at Bama Branch)"
    ),
    SALES_MARKETING(
        title = "Business Development (Sale)",
        description = "Family consultation, package bookings, casket sales & pre-need care (5% casket commission)"
    ),
    ADMINISTRATIVE_STAFF(
        title = "Administrative Staff",
        description = "Manages paperwork, billing, statutory compliance, and records"
    ),
    FUNERAL_DIRECTOR(
        title = "Funeral Director",
        description = "Directs funeral services and coordinates family arrangements"
    ),
    MORTUARY_TECH(
        title = "Mortuary Technician & Embalmer",
        description = "Embalming, body preservation and dignified preparation"
    ),
    FLEET_OPERATOR(
        title = "Hearse & Fleet Logistics",
        description = "Dignified hearse transport and mortuary transit operations"
    ),
    CASKET_ARTISAN(
        title = "Casket Craftsman",
        description = "Casket fabrication, luxury lining, and brass hardware fitting"
    ),
    CHAPEL_COORDINATOR(
        title = "Chapel & Vigil Coordinator",
        description = "Chapel viewings, sound/hymns setup, and memorial decor"
    ),
    ACCOUNTS_OFFICER(
        title = "Accounts & Cashier",
        description = "Invoicing, inventory audits, and payroll tracking"
    ),
    INVENTORY_MANAGER(
        title = "Inventory Manager",
        description = "Workshop casket inventory, branch allocations, stock intake & price updates"
    ),
    OPERATIONS_ADMIN(
        title = "Operations Administrator",
        description = "Main Admin with full roster access and wallet disbursements"
    )
}

data class StaffAccount(
    val id: String,
    val fullName: String,
    val email: String,
    val phone: String,
    val role: StaffRole,
    val department: Department = Department.SALES_MARKETING,
    val password: String = "", // Legacy field kept empty when hashed
    val nationalId: String,
    val branch: String,
    val assignedVehicle: String? = null,
    val isActive: Boolean = true,
    val avatarColor: Long = 0xFF0284C7,
    val joinedDate: String = "15 Jan 2025",
    val defaultMpesaNumber: String = "",
    val defaultBankDetails: String = "",
    val isBiometricEnabled: Boolean = true,
    val baseSalaryKes: Double = 45000.0,
    val allowanceKes: Double = 10000.0,
    val commissionRatePercent: Double = 5.0,
    val notes: String = "",
    val transportFeeKes: Double = 0.0,
    val dailyWageKes: Double = 0.0,
    val totalBreakageDeductionsKes: Double = 0.0,
    val passwordHash: String = "",
    val mustRotatePassword: Boolean = false
)

enum class ActivityCategory(val label: String) {
    CASE_HANDLING("Case Intake & Family Care"),
    EMBALMING_PREPARATION("Ceremonial Setup & Florals"),
    FLEET_TRANSPORT("Hearse & Fleet Logistics"),
    CASKET_FITTING("Casket Assembly & Fitting"),
    CHAPEL_SERVICE("Chapel & Vigil Service"),
    GRAVESITE_SETUP("Gravesite & Lowering Gear"),
    ADMIN_INVENTORY("Stock & Administrative Duty"),
    SALES_CONSULTATION("Sales & Family Counseling"),
    WORKSHOP_PRODUCTION("Workshop Casket Crafting"),
    OPERATOR_SETUP("Operators Setup & Grounds Duty")
}

enum class FuneralArrangementStage(val label: String, val description: String) {
    INTAKE_MORTUARY("Arrangement Intake & Planning", "Family consultation, statutory permits & scheduling"),
    FAMILY_PLANNING("Casket Choice & Program Planning", "Casket selection, program schedule & floral tributes"),
    CASKET_FLORALS("Casket, Lining & Florals", "Hardware, brass plate & flower wreaths"),
    FLEET_CORTEGE("Hearse & Fleet Escort", "Cortege motorcade, route logistics & flags"),
    CHAPEL_VIGIL("Church / Chapel Vigil Service", "Sound equipment, bier trolley & hymn sheets"),
    GRAVESITE_LOWERING("Gravesite & Lowering Gear", "Hydraulic lowering gear, red carpet & canopy"),
    DEBRIEF_COMPLETION("Post-Burial Debrief & Returns", "Sanitization, gear check-in & family sign-off")
}

enum class TaskPriority(val label: String, val colorHex: Long) {
    NORMAL("Normal", 0xFF2563EB),
    HIGH("High Priority", 0xFFD97706),
    URGENT("Urgent Immediate", 0xFFDC2626)
}

enum class ActivityStatus(val label: String) {
    SCHEDULED("Scheduled"),
    IN_PROGRESS("In Progress"),
    IN_TRANSIT("In Transit"),
    ON_HOLD("On Hold"),
    COMPLETED("Completed"),
    VERIFIED_BY_ADMIN("Verified")
}

enum class TimelineViewMode(val label: String) {
    TIMELINE("Timeline View"),
    CARDS("Card List")
}

enum class AlertFilterCategory(val label: String) {
    ALL("All Alerts"),
    SHIFT("Shift Alerts"),
    TASK("Task & Ops"),
    UNREAD("Unread Only")
}

data class StaffActivity(
    val id: String,
    val staffId: String,
    val staffName: String,
    val department: Department = Department.WORKSHOP,
    val category: ActivityCategory,
    val title: String,
    val caseReference: String,
    val clientFamily: String,
    val location: String,
    val date: String,
    val time: String,
    val durationMinutes: Int,
    val status: ActivityStatus,
    val notes: String = "",
    val allowanceEarned: Double = 0.0,
    val verifiedByAdmin: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val arrangementStage: FuneralArrangementStage = FuneralArrangementStage.FAMILY_PLANNING,
    val priority: TaskPriority = TaskPriority.NORMAL,
    val assignedVehicle: String? = null,
    val assignedEquipment: String? = null,
    val checklistItems: List<String> = emptyList(),
    val completedChecklistItems: List<String> = emptyList(),
    val startedTimestamp: Long? = null,
    val completedTimestamp: Long? = null,
    val elapsedMinutesLogged: Int = 0
)

enum class TransactionType(val label: String, val isCredit: Boolean) {
    SALARY_BASE("Monthly Salary / Retainer", true),
    ACTIVITY_ALLOWANCE("Case Activity Allowance", true),
    OVERTIME_BONUS("Night Vigil & Weekend Overtime", true),
    COMMISSION("5% Casket Commission", true),
    PERFORMANCE_INCENTIVE("Performance Incentive Bonus", true),
    EXPENSE_REIMBURSEMENT("Field Expense Reimbursement", true),
    PER_DIEM("Transport & Meal Stipend", true),
    PAYOUT_WITHDRAWAL("Wallet Cash Withdrawal", false),
    ADMIN_ADJUSTMENT("Admin Manual Credit", true),
    BREAKAGE_DEDUCTION("Breakage Cost Deduction", false),
    OPERATOR_TRANSPORT_FEE("Operator Transport Fee", true),
    OPERATOR_DAILY_WAGE("Operator Daily Wage", true)
}

enum class IncentiveCategory(val label: String, val badgeColorHex: Long) {
    TARGET_MILESTONE("Target Milestone Achieved", 0xFF2563EB),
    CASE_EXCELLENCE("Arrangement Excellence", 0xFF10B981),
    CASKET_COMMISSION("5% Casket Commission", 0xFFD97706),
    ON_TIME_CORTEGE("Flawless Motorcade Escort", 0xFF7C3AED),
    MORTUARY_QA("Mortuary Preservation QA", 0xFF0D9488),
    CLIENT_PRAISE("Family Commendation", 0xFFE11D48),
    AFTER_HOURS_READINESS("24/7 Emergency Readiness", 0xFF475569)
}

data class PerformanceIncentive(
    val id: String,
    val staffId: String,
    val staffName: String,
    val department: Department,
    val category: IncentiveCategory,
    val title: String,
    val amount: Double,
    val date: String,
    val caseReference: String? = null,
    val awardedBy: String,
    val rationale: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class ExpenseCategory(val label: String, val badgeColorHex: Long) {
    FUEL_TOLLS("Hearse Fuel & Road Tolls", 0xFF2563EB),
    POLICE_ESCORT_FACILITATION("Police Escort Facilitation", 0xFF7C3AED),
    EMBALMING_PPE_SUPPLIES("Embalming Chemicals & PPE", 0xFF0D9488),
    CHURCH_SOUND_CONSUMABLES("Vigil Batteries & Guest Books", 0xFFD97706),
    HEARSE_WASH_FLORALS("Hearse Detailing & Ribbons", 0xFF10B981),
    CREW_MEALS_STIPEND("Night Vigil Crew Stipend", 0xFFF59E0B),
    EMERGENCY_REPAIR("Emergency On-Road Repair", 0xFFDC2626)
}

enum class ExpenseStatus(val label: String) {
    PENDING_APPROVAL("Pending Approval"),
    APPROVED_REIMBURSED("Approved & Reimbursed"),
    REJECTED("Rejected")
}

data class StaffExpenseClaim(
    val id: String,
    val staffId: String,
    val staffName: String,
    val department: Department,
    val category: ExpenseCategory,
    val title: String,
    val amount: Double,
    val date: String,
    val caseReference: String,
    val receiptNumber: String,
    val vehiclePlate: String? = null,
    val status: ExpenseStatus = ExpenseStatus.PENDING_APPROVAL,
    val notes: String = "",
    val reimbursementMethod: String? = null,
    val authorizedBy: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

enum class PaymentStatus(val label: String) {
    DISBURSED("Disbursed / Paid"),
    PENDING_APPROVAL("Pending Admin Approval"),
    PROCESSING("Processing Transfer"),
    REJECTED("Rejected")
}

data class WalletTransaction(
    val id: String,
    val staffId: String,
    val type: TransactionType,
    val title: String,
    val referenceNumber: String,
    val amount: Double,
    val date: String,
    val status: PaymentStatus,
    val notes: String = "",
    val payoutMethod: String? = null,
    val payoutDestination: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class StaffWalletSummary(
    val staffId: String,
    val availableBalance: Double,
    val totalEarned: Double,
    val totalWithdrawn: Double,
    val pendingPayouts: Double,
    val casketCommissionTotal: Double = 0.0,
    val breakageDeductionsTotal: Double = 0.0,
    val servicePayoutsTotal: Double = 0.0,
    val pendingServicePayoutsTotal: Double = 0.0
)

enum class IntegrationPlatform(
    val id: String,
    val displayName: String,
    val provider: String,
    val category: String,
    val badgeColorHex: Long,
    val description: String,
    val primaryFeatures: List<String>
) {
    ZOHO_ONE(
        id = "zoho_one",
        displayName = "Zoho One",
        provider = "Zoho Corporation",
        category = "ERP & Finance Ledger",
        badgeColorHex = 0xFFDC2626,
        description = "Enterprise ERP syncing Books, Staff Payroll Ledger, Stock Inventory & Statutory Compliance",
        primaryFeatures = listOf("Zoho Books Invoicing", "Zoho Payroll Payouts", "Inventory Multi-Warehouse", "Zoho Sign Burial Permits")
    ),
    FRESHSALES(
        id = "freshsales",
        displayName = "Freshsales",
        provider = "Freshworks CRM",
        category = "Sales & Family Intake CRM",
        badgeColorHex = 0xFF0284C7,
        description = "Client Family relationship management, casket booking pipeline & sales agent commission tracking",
        primaryFeatures = listOf("Family Intake Pipeline", "5% Casket Commission Deals", "WhatsApp/Call Logging", "Sales Rep Target Tracking")
    ),
    ZURI_PLATFORM(
        id = "zuri_platform",
        displayName = "Zuri Platform (Safaricom M-PESA)",
        provider = "Safaricom PLC / Zuri Gateway",
        category = "Safaricom Payment Gateway & Collections",
        badgeColorHex = 0xFF10B981,
        description = "Safaricom payments integration platform powering M-PESA Daraja C2B/B2C, Lipa Na M-PESA Till/Paybill (889420) reconciliation, instant staff disbursements & funeral billing collections",
        primaryFeatures = listOf(
            "Lipa Na M-PESA Paybill (889420) & Till Collections",
            "Instant M-PESA B2C Payouts & Staff Disbursements",
            "Daraja API Real-time STK Push & Webhook Callbacks",
            "Automated Safaricom Bank Reconciliation & Statements"
        )
    ),
    HUBSPOT(
        id = "hubspot",
        displayName = "HubSpot",
        provider = "HubSpot Inc",
        category = "Inbound CRM & Service Desk",
        badgeColorHex = 0xFFEA580C,
        description = "Family support ticketing, memorial tribute landing pages & customer satisfaction CSAT surveys",
        primaryFeatures = listOf("Family Service Tickets", "Memorial Tribute Notices", "Post-Burial Feedback", "Automated Condolence Email/SMS")
    )
}

enum class SyncStatus(val label: String) {
    ACTIVE_CONNECTED("Active & Connected"),
    SYNCING("Syncing in Progress..."),
    SYNC_PAUSED("Paused"),
    ERROR("Sync Warning")
}

data class PlatformIntegrationConfig(
    val platform: IntegrationPlatform,
    val isEnabled: Boolean = true,
    val status: SyncStatus = SyncStatus.ACTIVE_CONNECTED,
    val apiEndpoint: String,
    val organizationId: String,
    val lastSyncTime: String,
    val syncedRecordsCount: Int,
    val webhookActive: Boolean = true,
    val autoSyncIntervalMinutes: Int = 15,
    val pendingQueueCount: Int = 0
)

data class IntegrationSyncLog(
    val id: String,
    val platform: IntegrationPlatform,
    val actionType: String,
    val recordSummary: String,
    val entityType: String,
    val timestamp: String,
    val status: String = "Success (200 OK)",
    val itemsProcessed: Int = 1
)

enum class MainAppTab(val label: String) {
    STAFF_OPERATIONS("Overview"),
    AI_ASSISTANT("Gemini AI"),
    KRA_PORTAL("KRA iTax & eTIMS"),
    ADMIN_CONSOLE("Admin"),
    ORDERS_PAYMENTS("Order & Pay"),
    ORDER_DASHBOARD("Order Dashboard"),
    CASKET_SELECTION("Casket Order"),
    THERMAL_POS("Thermal POS"),
    INVENTORY_MANAGEMENT("Inventory Mgmt"),
    STAFF_WALLET("Staff Wallet"),
    CRM_INTEGRATIONS("CRM & Cloud"),
    ROSTER_CALENDAR("Roster Shifts"),
    FLEET_TRACKING("Fleet GPS Map"),
    WORKSHOP_PRODUCTION("Live Workshop"),
    COSTINGS_AND_PRICING("Costings & BOM"),
    COST_ANALYTICS("Cost Analytics"),
    BURIAL_SCHEDULING("Burial Scheduler"),
    DAILY_REPORT("Daily Report"),
    DAILY_LOG("Daily Log"),
    STOCK_MOVEMENT("Stock Movement"),
    BRANCH_BOARDS("Status Boards"),
    VENDOR_MANAGEMENT("Vendor Mgmt"),
    BRANCHES_FLEET("Branches & Fleet"),
    COMMUNICATION_3CX("3CX Comms"),
    BULK_SMS("Bulk SMS"),
    SALES_SERVICES("Sales Services"),
    MANAGEMENT_STRUCTURE("Management"),
    REMOTE_SURVEILLANCE("Surveillance"),
    SERVICES("Services"), // Backwards compatibility alias
    MEMORIALS("Memorials")
}

enum class NavTab(val label: String) {
    OVERVIEW("Overview"),
    ACTIVITIES("Duties"),
    WALLET("Staff Payment Wallet"),
    ROSTER("Roster Shifts"),
    REMOTE_SURVEILLANCE("Surveillance"),
    WORKSHOP_PRODUCTION("Live Workshop"),
    COSTINGS_PRICING("Costings & BOM"),
    INVENTORY_MANAGEMENT("Inventory Mgmt"),
    BURIAL_SCHEDULING("Burial Scheduler"),
    DAILY_REPORT("Daily Report"),
    ACCOUNTS_FINANCE("Accounts & Finance"),
    COMPANY_ASSETS("Company Assets"),
    LEAVE_MANAGEMENT("Leave Management"),
    COMMUNICATION_3CX("3CX Comms"),
    BULK_SMS("Bulk SMS"),
    CRM_INTEGRATIONS("CRM & Cloud"),
    ADMIN_CONSOLE("Admin Console"),
    PROFILE("Settings & Profile")
}

// Live Fleet GPS & Telemetry Models for Google Maps Tracking
data class FleetLocationPoint(
    val latitude: Double,
    val longitude: Double,
    val label: String = ""
)

data class FleetGpsVehicle(
    val registration: String,
    val model: String,
    val driverName: String,
    val driverPhone: String,
    val latitude: Double,
    val longitude: Double,
    val speedKmh: Int,
    val headingDegrees: Float,
    val statusLabel: String,
    val isMoving: Boolean,
    val fuelPercent: Int,
    val engineRunning: Boolean,
    val activeCaseRef: String,
    val destination: String,
    val eta: String,
    val currentStreet: String,
    val lastPingSecondsAgo: Int = 14,
    val routeBreadcrumbs: List<FleetLocationPoint> = emptyList()
)

// Geofencing & Auto-Checkin Models
data class GeofenceZone(
    val id: String,
    val name: String,
    val type: String, // "Morgue Intake", "Headquarters Depot", "Church/Chapel", "Cemetery/Gravesite", "Branch Office"
    val latitude: Double,
    val longitude: Double,
    val radiusMeters: Double = 350.0,
    val colorHex: Long = 0xFF2563EB
)

data class GeofenceCheckinEvent(
    val id: String,
    val vehicleReg: String,
    val driverName: String,
    val zoneName: String,
    val eventType: String, // "ENTERED", "EXITED", "ON_SITE_ACTIVE"
    val caseReference: String,
    val timestamp: String,
    val statusSummary: String
)

// Hearse Fleet Pre-Trip Inspection Checklist
data class FleetInspectionRecord(
    val id: String,
    val vehicleReg: String,
    val inspectorDriverName: String,
    val date: String,
    val time: String,
    val odometerKm: Int,
    val deckRollersAndClampLocks: Boolean = true,
    val hydraulicLiftOperating: Boolean = true,
    val ceremonialFlagsAndRibbons: Boolean = true,
    val engineOilAndCoolantOk: Boolean = true,
    val tirePressureAndTreadOk: Boolean = true,
    val interiorSanitizedAndVelvetClean: Boolean = true,
    val ceremonialUniformAndGlovesReady: Boolean = true,
    val overallStatus: String = "Passed - Certified Ready for Cortege",
    val notes: String = ""
)

// Fuel Log Book Record
data class FleetFuelLogRecord(
    val id: String,
    val vehicleReg: String,
    val driverName: String,
    val stationName: String, // e.g. "Shell Siaya", "TotalEnergies Bondo"
    val date: String,
    val odometerKm: Int,
    val litersPumped: Double,
    val pricePerLiterKes: Double,
    val totalAmountKes: Double,
    val receiptOrMpesaRef: String,
    val fuelCardNumber: String = "JABIMA-PETRO-042",
    val calculatedEfficiencyKmPerL: Double = 9.8,
    val notes: String = ""
)

// Instant M-PESA B2C Payout Result
data class MpesaB2cReceipt(
    val transactionId: String, // e.g. QHX81920LA
    val recipientName: String,
    val recipientPhone: String,
    val staffId: String,
    val amountKes: Double,
    val disbursementCategory: String, // "Activity Allowance", "Overtime", "Commission", "Salary"
    val date: String,
    val time: String,
    val status: String = "Success (Completed)",
    val b2cUtilityAccount: String = "889420 - Jabima Payroll",
    val safaricomSmsText: String
)

// Casket Selection & Exchange Models
data class CasketItem(
    val id: String,
    val name: String,
    val woodType: String,
    val finish: String,
    val interiorLining: String,
    val tier: String,
    val priceKes: Double,
    val priceUsd: Double,
    val inStock: Boolean = true,
    val stockCount: Int = 5,
    val features: List<String> = emptyList()
)

enum class CasketReturnType(val label: String) {
    RETURN_INWARD("Return Inward (Client Returning Casket)"),
    RETURN_OUTWARD("Return Outward (Exchange / Replacement Dispatch)")
}

data class CasketExchangeRecord(
    val id: String,
    val clientFamily: String,
    val caseReference: String,
    val originalCasketName: String,
    val originalCasketPrice: Double,
    val newCasketName: String,
    val newCasketPrice: Double,
    val returnType: CasketReturnType,
    val priceDifferenceKes: Double, // positive = client pays top-up, negative = refund
    val reason: String,
    val conditionAssessment: String,
    val branch: String,
    val processedByStaffName: String,
    val date: String,
    val status: String = "Approved"
)

// Authorized Sales Services (14 items exclusively sold by Business Development / Sales & Admin)
data class SalesServiceItem(
    val id: String,
    val name: String,
    val priceKes: Double,
    val category: String,
    val description: String,
    val unit: String = "Per Event",
    val earnsCommission: Boolean = false // Only caskets earn 5% commission!
)

data class PriceEditItem(
    val id: String,
    val name: String,
    val currentPriceKes: Double,
    val isCasket: Boolean,
    val currentStock: Int = 0,
    val category: String = "Standard",
    val description: String = ""
)

enum class StockCategory(val label: String, val badgeColorHex: Long) {
    CASKET("Caskets & Coffins", 0xFF0284C7),
    MORTUARY_CHEMICALS("Mortuary & Chemicals", 0xFF0D9488),
    BURIAL_APPAREL("Burial Apparel & Veils", 0xFF7C3AED),
    CEREMONIAL_EQUIPMENT("Ceremonial Equipment & Gear", 0xFFD97706),
    CHAPEL_VIGIL("Chapel & Vigil Supplies", 0xFF2563EB),
    BRASS_HARDWARE("Brass Handles & Fittings", 0xFFB45309),
    FLEET_SPARES("Hearse & Fleet Spares", 0xFF475569)
}

data class StockUploadItem(
    val id: String,
    val name: String,
    val category: StockCategory,
    val sku: String,
    val description: String,
    val quantity: Int,
    val reorderThreshold: Int = 3,
    val costPriceKes: Double,
    val sellingPriceKes: Double,
    val branchWarehouse: String,
    val supplierName: String = "Internal Workshop / Consignment",
    val invoiceOrBatchNumber: String = "BATCH-2026-001",
    val dateUploaded: String = "05 Oct 2026",
    val uploadedByStaffName: String = "Fredrick Hayoyo (CEO)"
)

data class PriceUpdateRecord(
    val id: String,
    val itemId: String,
    val itemName: String,
    val itemType: String, // "Casket", "Sales Service", "POS Item"
    val previousPriceKes: Double,
    val newPriceKes: Double,
    val updatedByStaffName: String,
    val dateUpdated: String,
    val notes: String = ""
)

// Customer Order & Payment Models
data class CustomerOrderRecord(
    val orderId: String,
    val clientName: String,
    val clientPhone: String,
    val deceasedName: String,
    val selectedPackage: String,
    val selectedCasket: String,
    val selectedAddons: List<String>,
    val totalAmountKes: Double,
    val totalAmountUsd: Double,
    val paymentMethod: String, // "M-PESA" or "BANK_TRANSFER"
    val paymentTerms: String, // "Full payment" or "Lipa pole pole Option (2 installments)"
    val paymentStatus: String, // "Confirmed", "Installment 1 Received", "Pending"
    val referenceCode: String,
    val orderDate: String,
    val branch: String,
    val salesAgentName: String,
    val commissionEarnedKes: Double // 5% of casket price if sold by sales agent
)

// Company Assets Control Models
enum class CustodyStatus(val label: String) {
    IN_DEPOT("In Depot"),
    CHECKED_OUT("Checked Out for Burial"),
    MISSING_FLAGGED("Missing / Flagged"),
    DAMAGED("Damaged on Return")
}

data class CompanyAsset(
    val id: String,
    val name: String,
    val category: String, // "Fleet", "Lowering Gear", "Trolley", "Cold Room", "Carpets & Stunchions", "Workshop Machinery"
    val registrationOrTag: String,
    val branchAssigned: String,
    val condition: String, // "Operational", "Service Due", "In Use", "Under Maintenance"
    val lastInspected: String,
    val custodianStaffName: String,
    val qrTagCode: String = "JFD-AST-$id",
    val custodyStatus: CustodyStatus = CustodyStatus.IN_DEPOT,
    val checkedOutCaseRef: String? = null
)

data class AssetCustodyLog(
    val id: String,
    val assetId: String,
    val assetName: String,
    val qrTagCode: String,
    val custodyStatus: CustodyStatus,
    val caseReference: String,
    val staffId: String,
    val staffName: String,
    val branch: String,
    val conditionNotes: String,
    val timestamp: String,
    val breakageRecordId: String? = null
)

// Leave Management Models
data class LeaveRequest(
    val id: String,
    val staffId: String,
    val staffName: String,
    val department: Department,
    val leaveType: String, // "Annual Leave", "Compassionate / Bereavement", "Sick Leave", "Off-Duty Rest"
    val startDate: String,
    val endDate: String,
    val daysCount: Int,
    val reason: String,
    val status: String = "Pending", // "Pending", "Approved", "Declined"
    val approvedBy: String? = null
)

// 3CX Unified Communication Models
data class VoipExtension(
    val extension: String,
    val departmentOrBranch: String,
    val contactPerson: String,
    val status: String = "Online",
    val directDial: String
)

data class VoipCallLog(
    val id: String,
    val callType: String, // "Inbound", "Outbound", "Missed", "Intercom"
    val contactName: String,
    val numberOrExt: String,
    val durationText: String,
    val timestamp: String,
    val status: String = "Connected HD",
    val recordingAvailable: Boolean = true
)

// Bulk SMS Models
data class BulkSmsMessage(
    val id: String,
    val recipientType: String, // "Client Family", "Staff Department", "All Branches", "Fleet Standby"
    val recipientDetails: String,
    val messageBody: String,
    val timestamp: String,
    val status: String = "Delivered via Safaricom Gateway",
    val senderId: String = "JABIMA_LTD",
    val units: Int = 1
)

data class SmsTemplate(
    val id: String,
    val title: String,
    val category: String,
    val bodyTemplate: String
)

val DEFAULT_SMS_TEMPLATES = listOf(
    SmsTemplate(
        id = "TPL-01",
        title = "Cortege Departure Notice",
        category = "Cortege & Fleet",
        bodyTemplate = "Jabima Funeral Directors Ltd: The cortege for the late [Name] departs Bama Base at 09:00 AM escorted by Fleet [Reg]. 24/7 Hotline: +254793553434."
    ),
    SmsTemplate(
        id = "TPL-02",
        title = "Bereaved Family Case Confirmation",
        category = "Family Care",
        bodyTemplate = "Jabima Funeral: We convey heartfelt condolences to the family of the late [Name]. Case #[Ref] confirmed. Reserved casket & hearse ready. 24/7 Hotline: +254793553434."
    ),
    SmsTemplate(
        id = "TPL-03",
        title = "Night Vigil & Chapel Setup Alert",
        category = "Chapel & Vigils",
        bodyTemplate = "Jabima Operations: Vigil audio, church trolley biers & brass stunchions setup scheduled for 18:00 hrs. All duty crew report on site."
    ),
    SmsTemplate(
        id = "TPL-04",
        title = "Fleet Logistics Standby Alert",
        category = "Emergency Recall",
        bodyTemplate = "Jabima Fleet Alert: 24/7 Dispatch requires hearse standby at Bama Branch base immediately. Contact Central Dispatch Ext 101."
    ),
    SmsTemplate(
        id = "TPL-05",
        title = "Casket Ready for Family Viewing",
        category = "Workshop Crafting",
        bodyTemplate = "Jabima Workshop: Selected custom casket has completed assembly and satin lining at Bama Workshop. Ready for family inspection."
    ),
    SmsTemplate(
        id = "TPL-06",
        title = "Payment Receipt & Lipa Pole Pole",
        category = "Finance & Receipts",
        bodyTemplate = "Jabima Funeral: Payment receipt of KES [Amount] confirmed for Case #[Ref]. Paybill: 889420 / STK +254793553434. Thank you for choosing Jabima."
    )
)

// Stock Movement Models
enum class StockMovementStatus(val label: String) {
    PENDING_AUTHORIZATION("Pending Authorization"),
    AUTHORIZED("Authorized & Approved"),
    IN_TRANSIT("In Transit"),
    DELIVERED("Delivered & Stocked"),
    REJECTED("Rejected")
}

data class StockMovementRecord(
    val id: String,
    val itemName: String,
    val category: String,
    val quantity: Int,
    val sourceBranch: String,
    val destinationBranch: String,
    val requestedByStaffId: String,
    val requestedByStaffName: String,
    val assignedVehicle: String,
    val assignedDriverName: String,
    val requestDate: String,
    val urgency: String,
    val status: StockMovementStatus,
    val authorizedByManagerName: String? = null,
    val authorizationTimestamp: String? = null,
    val notes: String = ""
)

// Branch Status and Information Board Models
data class BranchStatusBoard(
    val branchName: String,
    val operationalStatus: String,
    val activeCasesCount: Int,
    val coldRoomCapacity: Int,
    val coldRoomOccupancy: Int,
    val hearseFleetStationed: List<String>,
    val hearseFleetInTransit: List<String>,
    val onDutyStaffCount: Int,
    val todayCortegeDepartures: Int,
    val pendingStockRequests: Int,
    val contactPhone: String,
    val leadSupervisor: String,
    val activeAdvisories: List<String>
)

// Vendor Management Models
enum class VendorTransactionType(val label: String) {
    PAYMENT_SUBMITTED("Payment Submitted (Expense)"),
    PAYMENT_RECEIVED("Payment Received (Inflow/Rebate)")
}

data class VendorProfile(
    val id: String,
    val vendorName: String,
    val category: String,
    val contactPerson: String,
    val phoneNumber: String,
    val paymentTerms: String,
    val bankOrMpesaDetails: String,
    val totalPaidSubmitted: Double,
    val totalReceivedRebates: Double,
    val pendingBalanceDue: Double
)

data class VendorTransaction(
    val id: String,
    val vendorId: String,
    val vendorName: String,
    val transactionType: VendorTransactionType,
    val amount: Double,
    val description: String,
    val invoiceNumber: String,
    val date: String,
    val paymentMethod: String,
    val mpesaOrBankRef: String,
    val authorizedBy: String,
    val status: String = "Completed"
)

// Visual Calendar Staff Shift Models
enum class ShiftPeriod(val label: String, val badgeColorHex: Long) {
    ACTIVE("Active Shifts", 0xFF10B981),
    UPCOMING("Upcoming Shifts", 0xFF2563EB),
    PAST("Past Shifts", 0xFF64748B)
}

data class StaffShiftSchedule(
    val id: String,
    val staffId: String,
    val staffName: String,
    val department: Department,
    val assignedBranch: String,
    val shiftType: String,
    val dayOfWeek: String,
    val dateFormatted: String,
    val availabilityStatus: String,
    val hearseAssigned: String? = null,
    val notes: String = "",
    val shiftPeriod: ShiftPeriod = ShiftPeriod.ACTIVE,
    val startTime: String = "08:00",
    val endTime: String = "17:00",
    val equipmentAssigned: String? = null,
    val caseReference: String? = null,
    val familyName: String? = null,
    val destination: String? = null,
    val supervisorName: String = "Fredrick Hayoyo (CEO)",
    val hoursLogged: Double = 8.0,
    val checkInStatus: String = "On-Site Active",
    val completionNotes: String? = null
)

// Thermal POS Models
enum class PosCategory(val label: String) {
    ALL("All Products"),
    CASKETS("Caskets & Coffins"),
    FLEET("Hearse & Transport"),
    MORTUARY("Preservation & Care"),
    CHAPEL("Chapel & Vigils"),
    FLORALS("Memorial Florals & Books")
}

data class PosItem(
    val id: String,
    val name: String,
    val category: PosCategory,
    val price: Double,
    val description: String,
    val sku: String,
    val inStock: Boolean = true
)

data class PosCartItem(
    val item: PosItem,
    val quantity: Int = 1
)

data class PosReceipt(
    val receiptNumber: String,
    val date: String,
    val time: String,
    val customerFamily: String,
    val caseReference: String,
    val cashierStaffId: String,
    val cashierStaffName: String,
    val items: List<PosCartItem>,
    val subtotal: Double,
    val taxVat: Double,
    val totalAmount: Double,
    val paymentMethod: String,
    val mpesaRef: String? = null,
    val etrNumber: String = "ETR-2026-99381",
    val paymentTerms: String = "Full payment",
    val mpesaStkNumber: String = "+254793553434",
    val branch: String = "Siaya Referal"
)

val JABIMA_BRANCHES = listOf(
    "Bama Branch",
    "Bondo Branch",
    "Got Agulu",
    "Matibabu",
    "Rangala",
    "Siaya Main",
    "Siaya Referal",
    "Ukwala",
    "Uradi"
)

val JABIMA_FLEET = listOf(
    "KDG 705Y",
    "KCL 703C",
    "KBR 104R",
    "KDH 172H",
    "KDY 211L",
    "KCT 871D"
)

const val MPESA_STK_NUMBER = "+254793553434"
const val MPESA_PAYBILL_NUMBER = "889420"
const val BANK_SWIFT_CODE = "SCBLKENX"
const val BANK_ACCOUNT_NAME = "Jabima Funeral Directors Ltd"
const val BANK_NAME = "Standard Chartered Bank"
const val BANK_ACCOUNT_NUMBER = "01029384700"

val PAYMENT_TERMS = listOf(
    "Full payment",
    "Lipa pole pole Option (2 installments)"
)

// ==========================================
// 16 MANDATORY CASKET TYPES (Vertically aligned in Stock by Branch)
// ==========================================
val JABIMA_CASKET_TYPES = listOf(
    "Dragon",
    "Dumu Mayai",
    "English Coffin",
    "Executive",
    "Giraffe Flat",
    "Half Glass",
    "Half Glass Dome",
    "Kids",
    "Kupa",
    "Mini Executive",
    "Modern High Roof",
    "Reagan",
    "Saitoti",
    "Simple",
    "Tonny",
    "VIP"
)

data class CasketStockByBranchRow(
    val casketType: String,
    val branchStockMap: Map<String, Int>, // Branch Name -> stock quantity
    val priceKes: Double
) {
    val totalStock: Int get() = branchStockMap.values.sum()
}

// Dashboard Daily Financial and Production KPIs
data class DashboardDailyKpis(
    val totalMaterialCostsToday: Double = 84500.0,
    val finishedProductsToday: Int = 8,
    val productsInProduction: Int = 14,
    val totalSalesToday: Double = 420000.0,
    val totalStaffEarnings: Double = 65000.0,
    val totalPaymentsToday: Double = 380000.0
)

// ==========================================
// LIVE WORKSHOP & 4 PRODUCTION STAGES
// ==========================================
enum class WorkshopProductionStage(
    val stageNumber: Int,
    val title: String,
    val defaultPercentage: Int,
    val colorHex: Long,
    val description: String
) {
    FRAME_AND_ASSEMBLY(
        stageNumber = 1,
        title = "Frame and Assembly",
        defaultPercentage = 25,
        colorHex = 0xFF2563EB,
        description = "Timber woodwork, jointing, framing and structural casket assembly"
    ),
    SANDING_AND_PAINTING(
        stageNumber = 2,
        title = "Sanding and Painting",
        defaultPercentage = 50,
        colorHex = 0xFFD97706,
        description = "Sanding surfaces, primer coat, polyurethane spraying and gloss polishing"
    ),
    CLOTH_LINING_AND_FINAL_ASSEMBLY(
        stageNumber = 3,
        title = "Cloth Lining and Final Assembly",
        defaultPercentage = 75,
        colorHex = 0xFF7C3AED,
        description = "Quilted satin lining, foam padding, edge lace, and brass handle mounting"
    ),
    GLASS_FITTING(
        stageNumber = 4,
        title = "Glass Fitting",
        defaultPercentage = 100,
        colorHex = 0xFF059669,
        description = "Tempered viewing glass installation, dome seal, airtight latches & QA inspection"
    )
}

data class WorkshopMaterialAllocation(
    val materialId: String,
    val materialName: String,
    val quantity: Int,
    val unit: String,
    val unitCostKes: Double,
    val totalCostKes: Double,
    val allocatedDate: String,
    val allocatedBy: String
)

data class WorkshopProductionItem(
    val id: String,
    val casketType: String,
    val woodType: String = "Hardwood Mahogany",
    val currentStage: WorkshopProductionStage,
    val percentageDone: Int,
    val assignedCraftsmanId: String,
    val assignedCraftsmanName: String,
    val isDoneForDay: Boolean = false,
    val isCompleted: Boolean = false,
    val startedDate: String,
    val targetCompletionDate: String,
    val branch: String = "Bama Branch (Workshop Base)",
    val notes: String = "",
    val sellingPriceKes: Double = 95000.0,
    val materialCostKes: Double = 0.0,
    val laborCostKes: Double = 0.0,
    val finishingCostKes: Double = 0.0,
    val allocatedMaterials: List<WorkshopMaterialAllocation> = emptyList(),
    val isCustomDesign: Boolean = false,
    val qrTagCode: String = "JFD-CSK-$id",
    val autoBomDeductedStages: List<String> = emptyList()
) {
    val totalProductionCostKes: Double get() = materialCostKes + laborCostKes + finishingCostKes
    val profitMarginKes: Double get() = sellingPriceKes - totalProductionCostKes
}

data class LiveWorkshopSummary(
    val itemsInProductionCount: Int,
    val doneForDayCount: Int,
    val totalDoneCount: Int
)

// ==========================================
// INVENTORY MANAGEMENT MODELS
// ==========================================
data class MaterialCategory(
    val id: String,
    val name: String,
    val description: String,
    val unitOfMeasure: String,
    val lowStockThreshold: Int = 10,
    val itemCount: Int = 0,
    val totalValuationKes: Double = 0.0
)

data class InventoryMaterialItem(
    val id: String,
    val name: String,
    val categoryId: String,
    val categoryName: String,
    val quantity: Int,
    val unit: String,
    val unitCostKes: Double,
    val minThreshold: Int,
    val branchWarehouse: String = "Bama Branch",
    val status: String = "IN_STOCK"
) {
    val totalValueKes: Double get() = quantity * unitCostKes
    val isLowStock: Boolean get() = quantity in 1..minThreshold
    val isOutOfStock: Boolean get() = quantity == 0
}

data class InventoryOverviewKpis(
    val totalMaterialsValueKes: Double,
    val totalMaterialTypesCount: Int,
    val totalFinishedProductsCount: Int,
    val lowStockCount: Int,
    val outOfStockCount: Int,
    val pendingProductRequestsCount: Int
)

data class ProductItem(
    val id: String,
    val name: String,
    val category: String,
    val casketType: String? = null,
    val stockCount: Int,
    val costPriceKes: Double,
    val sellingPriceKes: Double,
    val branchWarehouse: String,
    val dateAdded: String,
    val addedBy: String
)

// ==========================================
// DAILY REPORT TAB MODELS
// ==========================================
data class StaffDailyReport(
    val id: String,
    val staffId: String,
    val staffName: String,
    val role: StaffRole,
    val department: Department,
    val branch: String,
    val date: String,
    val submissionTime: String,
    val tasksDoneCount: Int,
    val tasksSummary: List<String>,
    val materialsUsedSummary: String = "",
    val hoursLogged: Double = 8.0,
    val notes: String = "",
    val isSubmitted: Boolean = true
)

data class DailyReportSummary(
    val totalReportsSubmittedCount: Int,
    val totalStaffCount: Int,
    val totalTasksDoneCount: Int,
    val unsubmittedStaffList: List<StaffAccount>
)

// ==========================================
// DYNAMIC BURIAL SCHEDULING & ROSTER SYNC
// ==========================================
data class BurialServiceTiming(
    val stage: FuneralArrangementStage,
    val timeFormatted: String,
    val venue: String,
    val assignedStaffIds: List<String>,
    val assignedStaffNames: List<String>,
    val assignedHearseReg: String? = null,
    val reminderSent: Boolean = false,
    val lastReminderTime: String? = null
)

enum class FamilyCortegeMilestone(
    val stepNumber: Int,
    val label: String,
    val familySmsNotice: String
) {
    PREPARATION_COMPLETE(
        stepNumber = 1,
        label = "Preparation Complete",
        familySmsNotice = "Dignified preparation, dressing & casket readiness completed at Jabima Funeral Home."
    ),
    HEARSE_DISPATCHED(
        stepNumber = 2,
        label = "Hearse Dispatched",
        familySmsNotice = "Our ceremonial hearse & cortege escort has departed en route."
    ),
    CHAPEL_ARRIVAL(
        stepNumber = 3,
        label = "Chapel Arrival",
        familySmsNotice = "The cortege has safely arrived at the church / chapel venue."
    ),
    GRAVESIDE(
        stepNumber = 4,
        label = "Graveside",
        familySmsNotice = "Cortege & lowering crew have arrived at the gravesite for final rites."
    )
}

data class BurialScheduleEvent(
    val id: String,
    val caseReference: String,
    val deceasedName: String,
    val familyRepresentative: String,
    val familyPhone: String,
    val burialDate: String,
    val casketModel: String,
    val churchVenue: String,
    val gravesiteLocation: String,
    val assignedHearseReg: String,
    val assignedDriverName: String,
    val assignedOperators: List<String>,
    val assignedDirector: String,
    val timings: List<BurialServiceTiming>,
    val status: String = "Confirmed & Roster Synced",
    val isRosterSynced: Boolean = true,
    val currentMilestone: FamilyCortegeMilestone = FamilyCortegeMilestone.PREPARATION_COMPLETE,
    val milestoneUpdatedAt: String = "Ready for dispatch",
    val etimsReceiptRef: String = "ETIMS-2026-$caseReference"
)

data class ServiceReminderLog(
    val id: String,
    val burialScheduleId: String,
    val deceasedName: String,
    val serviceStage: String,
    val timing: String,
    val recipients: List<String>,
    val messageText: String,
    val timestamp: String,
    val channel: String = "SMS & In-App Notification (Safaricom Gateway)"
)

enum class ExcelDatasetType(
    val title: String,
    val subtitle: String,
    val shortCode: String,
    val columnsSummary: String
) {
    INVENTORY_STOCK(
        title = "Inventory & Caskets",
        subtitle = "Caskets, chemicals, burial suits, lowering gear, spare parts",
        shortCode = "STK",
        columnsSummary = "SKU, Name, Category, Description, Qty, Cost KES, Price KES, Branch, Supplier"
    ),
    BURIAL_SCHEDULES(
        title = "Burial Schedules",
        subtitle = "Deceased cases, family contacts, church & gravesite venues, hearses",
        shortCode = "BRL",
        columnsSummary = "Case Ref, Deceased, Family Rep, Phone, Date, Casket, Church, Venue, Hearse, Director"
    ),
    CUSTOMER_ORDERS(
        title = "Customer Orders",
        subtitle = "Client funeral bookings, packages, contract sums & deposit payments",
        shortCode = "ORD",
        columnsSummary = "Order ID, Client Name, Phone, Deceased, Package, Total KES, Paid KES, Status, Branch"
    ),
    STAFF_ACCOUNTS(
        title = "Staff & Personnel",
        subtitle = "Employee accounts, operational roles, phone directory & salary bases",
        shortCode = "STF",
        columnsSummary = "Staff ID, Full Name, Department, Role, Phone, National ID, Branch, Salary KES"
    ),
    FLEET_VEHICLES(
        title = "Fleet & Vehicles",
        subtitle = "Hearses, cortege vans, ambulances, assigned drivers & telemetry",
        shortCode = "FLT",
        columnsSummary = "Plate Reg, Model, Type, Driver, Phone, Fuel %, Station Branch, Status"
    ),
    WORKSHOP_JOBS(
        title = "Workshop Jobs",
        subtitle = "Production queue, casket models, craftsmen & target dates",
        shortCode = "WRK",
        columnsSummary = "Job ID, Casket Model, Wood Type, Craftsman, Stage, Progress %, Target Date, Branch"
    )
}

// ==========================================
// ADMIN-EDITABLE PACKAGES, ADDONS, BREAKAGES, OPERATOR WAGES, UPGRADES & ALERTS
// ==========================================
data class OrderPackageItem(
    val id: String,
    val name: String,
    val priceKes: Double,
    val priceUsd: Double,
    val defaultCasket: String,
    val description: String,
    val inclusions: List<String>
)

data class OrderAddonItem(
    val id: String,
    val name: String,
    val priceKes: Double,
    val category: String
)

data class StaffBreakageRecord(
    val id: String,
    val staffId: String,
    val staffName: String,
    val department: Department,
    val itemBroken: String,
    val description: String,
    val breakageCostKes: Double,
    val date: String,
    val loggedBy: String,
    val isDeducted: Boolean = false,
    val walletTransactionId: String? = null
)

data class OperatorWageAllocation(
    val id: String,
    val staffId: String,
    val staffName: String,
    val branch: String,
    val transportFeeKes: Double,
    val dailyWageKes: Double,
    val totalPaidKes: Double,
    val dutyAssignment: String,
    val date: String,
    val allocatedBy: String,
    val isDisbursed: Boolean = false
)

data class StoreUpgradeDowngradeRecord(
    val id: String,
    val storeCategory: String, // "Raw Material", "Finished Product", "Uploaded Stock", "Casket Catalog"
    val itemId: String,
    val itemName: String,
    val actionType: String, // "UPGRADE" or "DOWNGRADE"
    val unitCostDeltaKes: Double,
    val quantity: Int,
    val totalCostDeltaKes: Double,
    val reason: String,
    val date: String,
    val processedBy: String
)

data class StaffAlertNotification(
    val id: String,
    val recipientStaffId: String,
    val recipientName: String,
    val title: String,
    val message: String,
    val category: String, // "SHIFT_ALERT", "TASK_ASSIGNED", "ROLE_REASSIGNED", "TASK_PRICED", "BREAKAGE_DEDUCTION", "OPERATOR_WAGE", "MARGIN_GUARD"
    val timestamp: String,
    val isRead: Boolean = false,
    val relatedEntityId: String? = null,
    val priority: TaskPriority = TaskPriority.NORMAL,
    val shiftId: String? = null,
    val scheduledTimeLabel: String? = null,
    val smsDispatched: Boolean = false,
    val branch: String? = null,
    val acknowledgedAt: String? = null
)

// ==========================================
// BOM MARGIN GUARD, SHIFT HANDOVERS, STATUTORY PAYROLL & OFFLINE SYNC QUEUE
// ==========================================
enum class MarginStatus(val label: String) {
    HEALTHY("Healthy Margin"),
    LOW_MARGIN("Low Margin Warning"),
    BELOW_COST("Below Production Cost")
}

data class MarginEvaluation(
    val sellingPriceKes: Double,
    val totalCostKes: Double,
    val profitKes: Double,
    val marginPercent: Double,
    val status: MarginStatus,
    val warningMessage: String?
)

data class ShiftVehicleHandover(
    val id: String,
    val vehicleReg: String,
    val branch: String,
    val outgoingStaffId: String,
    val outgoingStaffName: String,
    val incomingStaffId: String,
    val incomingStaffName: String,
    val fuelPercent: Int,
    val odometerKm: Int,
    val loweringGearCount: Int,
    val churchTrolleyOk: Boolean,
    val velvetDeckClean: Boolean,
    val spareTireAndJackOk: Boolean,
    val conditionNotes: String,
    val outgoingBiometricSigned: Boolean,
    val incomingBiometricSigned: Boolean,
    val timestamp: String
)

data class KenyanStatutoryBreakdown(
    val grossPayKes: Double,
    val shifDeductionKes: Double,
    val nssfDeductionKes: Double,
    val housingLevyKes: Double,
    val taxablePayKes: Double,
    val grossPayeKes: Double,
    val personalReliefKes: Double,
    val netPayeKes: Double,
    val totalStatutoryDeductionsKes: Double,
    val netTakeHomeBeforeBreakageKes: Double
)

enum class OfflineActionType(val label: String) {
    CUSTODY_SCAN("QR Custody Scan"),
    CORTEGE_MILESTONE("Cortege Milestone"),
    SHIFT_HANDOVER("Shift Handover"),
    FIELD_CHECKIN("Rural Field Check-In"),
    CASH_PAYMENT("Field Cash Collection"),
    SHIFT_ATTENDANCE("Shift Attendance QR Scan"),
    LEAVE_REQUEST("Time-Off / Leave Application")
}

data class OfflineQueuedAction(
    val id: String,
    val actionType: OfflineActionType,
    val title: String,
    val summary: String,
    val payloadJson: String,
    val createdAtLabel: String,
    val staffName: String,
    val synced: Boolean = false
)

enum class ShiftAttendanceAction(val label: String) {
    CHECK_IN("Shift Check-In"),
    CHECK_OUT("Shift Check-Out")
}

data class ShiftAttendanceRecord(
    val id: String,
    val staffId: String,
    val staffName: String,
    val roleTitle: String,
    val department: Department,
    val branch: String,
    val scannedQrPayload: String,
    val shiftId: String? = null,
    val shiftWindowLabel: String,
    val action: ShiftAttendanceAction,
    val checkpointLocation: String,
    val verifiedByStaffId: String,
    val verifiedByName: String,
    val timestampFormatted: String,
    val dateFormatted: String,
    val notes: String = "",
    val timestampMillis: Long = System.currentTimeMillis()
)

// ==========================================
// CASE PAPERWORK & PERMIT CLOUD VAULT MODELS
// ==========================================
enum class CaseDocumentType(val label: String) {
    BURIAL_PERMIT("Burial Permit"),
    MORTUARY_RELEASE("Mortuary Release Form"),
    POLICE_NOTIFICATION("Police / O.B. Notification"),
    PAYMENT_SLIP("Bank / M-PESA Deposit Slip"),
    CASKET_QC_PHOTO("Casket Dispatch QC Photo"),
    ID_VERIFICATION("Next-of-Kin ID Verification")
}

data class CaseDocumentRecord(
    val id: String,
    val caseReference: String,
    val deceasedName: String,
    val documentType: CaseDocumentType,
    val title: String,
    val notes: String = "",
    val fileName: String = "",
    val mimeType: String = "image/jpeg",
    val thumbnailBase64: String = "",
    val uploadedByStaffId: String,
    val uploadedByStaffName: String,
    val uploadedAt: String,
    val verifiedByAdmin: Boolean = false,
    val timestampMillis: Long = System.currentTimeMillis()
)





