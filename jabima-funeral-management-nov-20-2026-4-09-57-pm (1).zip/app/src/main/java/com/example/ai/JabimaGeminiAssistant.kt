package com.example.ai

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.BurialScheduleEvent
import com.example.model.CasketItem
import com.example.model.CustomerOrderRecord
import com.example.model.FleetGpsVehicle
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.StaffAlertNotification
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import com.google.gson.Gson

private const val TAG = "JabimaGeminiVM"
private const val DEFAULT_MODEL_NAME = "gemini-3.8-flash"
private const val AI_TIMEOUT_MS = 60_000L

sealed interface GeminiUiState {
    data object Idle : GeminiUiState
    data object Loading : GeminiUiState
    data class Streaming(val text: String) : GeminiUiState
    data class Success(val text: String) : GeminiUiState
    data class Error(val message: String) : GeminiUiState
}

enum class GeminiWorkflowPreset(
    val id: String,
    val title: String,
    val subtitle: String,
    val isStructuredMode: Boolean = false
) {
    BEREAVEMENT_NOTICE(
        id = "bereavement_notice",
        title = "Bereavement Notice & Eulogy",
        subtitle = "Draft dignified family SMS notice & funeral service program"
    ),
    SHIFT_HANDOVER(
        id = "shift_handover",
        title = "24/7 Shift Handover Brief",
        subtitle = "Summarize active duties, fleet readiness & branch alerts"
    ),
    CASKET_ADVISOR(
        id = "casket_advisor",
        title = "Casket & Package Advisor",
        subtitle = "Recommend burial packages & caskets in KES/USD from stock"
    ),
    STRUCTURED_CARE_PLAN(
        id = "structured_care_plan",
        title = "Structured Burial Action Plan",
        subtitle = "Generate structured JSON checklist, roles & budget allocation",
        isStructuredMode = true
    )
}

data class GeminiChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val isStreaming: Boolean = false
)

data class StructuredCarePlan(
    val planTitle: String,
    val prioritySummary: String,
    val estimatedBudgetKes: Int,
    val checklistSteps: List<String>,
    val assignedRoles: List<String>,
    val recommendedSmsNotice: String
)

data class JabimaLiveOperationsSnapshot(
    val staffName: String,
    val staffRole: String,
    val staffBranch: String,
    val activeDutiesCount: Int,
    val topActivitiesSummary: String,
    val upcomingBurialsSummary: String,
    val casketsSummary: String,
    val fleetSummary: String,
    val unreadAlertsCount: Int,
    val latestClientOrderSummary: String
)

object JabimaPromptContextBuilder {

    fun buildSnapshot(
        currentAccount: StaffAccount?,
        activities: List<StaffActivity>,
        burials: List<BurialScheduleEvent>,
        caskets: List<CasketItem>,
        fleet: List<FleetGpsVehicle>,
        orders: List<CustomerOrderRecord>,
        alerts: List<StaffAlertNotification>
    ): JabimaLiveOperationsSnapshot {
        val topActs = activities.take(5).joinToString("; ") {
            "${it.title} (${it.caseReference}, ${it.status.label}, ${it.location})"
        }.ifBlank { "No active tasks queued" }

        val upcomingBurials = burials.take(4).joinToString("; ") {
            "${it.deceasedName} (${it.caseReference}, ${it.burialDate}, ${it.gravesiteLocation}, Hearse=${it.assignedHearseReg})"
        }.ifBlank { "No upcoming burials scheduled" }

        val casketList = caskets.take(6).joinToString("; ") {
            "${it.name}: KES ${it.priceKes.toInt()} (${it.stockCount} in stock, ${it.woodType})"
        }.ifBlank { "Standard catalog" }

        val fleetInfo = fleet.take(5).joinToString("; ") {
            "${it.registration} (${it.model}, ${it.statusLabel}, driver=${it.driverName})"
        }.ifBlank { "Fleet standby" }

        val latestOrder = orders.firstOrNull()?.let {
            "Order #${it.orderId} for ${it.clientName} (Deceased: ${it.deceasedName}, Package: ${it.selectedPackage}, Casket: ${it.selectedCasket}, KES ${it.totalAmountKes.toInt()}, Status: ${it.paymentStatus})"
        } ?: "No active orders selected"

        return JabimaLiveOperationsSnapshot(
            staffName = currentAccount?.fullName ?: "Jabima Staff",
            staffRole = currentAccount?.role?.title ?: "Operations Staff",
            staffBranch = currentAccount?.branch ?: "Bama Branch",
            activeDutiesCount = activities.size,
            topActivitiesSummary = topActs,
            upcomingBurialsSummary = upcomingBurials,
            casketsSummary = casketList,
            fleetSummary = fleetInfo,
            unreadAlertsCount = alerts.count { !it.isRead },
            latestClientOrderSummary = latestOrder
        )
    }

    fun buildPresetPrompt(
        preset: GeminiWorkflowPreset,
        snapshot: JabimaLiveOperationsSnapshot,
        customDetails: String = ""
    ): String {
        val extra = if (customDetails.isNotBlank()) "\nAdditional staff notes: $customDetails" else ""
        val contextBlock = """
            Organization: Jabima Funeral Directors Ltd (Care • Dignity • Respect)
            Staff User: ${snapshot.staffName} (${snapshot.staffRole}, ${snapshot.staffBranch})
            Live Duties (${snapshot.activeDutiesCount} total): ${snapshot.topActivitiesSummary}
            Upcoming Burials: ${snapshot.upcomingBurialsSummary}
            Casket Catalog Snapshot: ${snapshot.casketsSummary}
            Hearse Fleet Telemetry: ${snapshot.fleetSummary}
            Unread Shift Alerts: ${snapshot.unreadAlertsCount}
            Latest Client Order: ${snapshot.latestClientOrderSummary}
        """.trimIndent()

        return when (preset) {
            GeminiWorkflowPreset.BEREAVEMENT_NOTICE -> """
                Using Jabima Funeral Directors' operational context below, draft:
                1. A compassionate, dignified short bereavement announcement (under 320 characters) suitable for Bulk SMS.
                2. A structured Funeral Service Order of Events & Tribute outline for the family.
                $extra

                $contextBlock
            """.trimIndent()

            GeminiWorkflowPreset.SHIFT_HANDOVER -> """
                Generate a concise 24/7 Shift Handover Briefing for the incoming Jabima branch supervisor at ${snapshot.staffBranch}.
                Highlight pending duties, hearse fleet readiness, upcoming burials, and urgent unread alerts (${snapshot.unreadAlertsCount}).
                Use clear bullet sections: Immediate Priorities, Fleet & Hearse Status, Upcoming Cortege Schedule, and Compliance/Safety Reminders.
                $extra

                $contextBlock
            """.trimIndent()

            GeminiWorkflowPreset.CASKET_ADVISOR -> """
                Act as a compassionate Jabima Funeral Care Advisor. Based on our current casket inventory and pricing in KES below, recommend 3 clear tier options (Essential, Standard Executive, Dignified VIP) with transparent KES estimates and guidance for the family.
                $extra

                $contextBlock
            """.trimIndent()

            GeminiWorkflowPreset.STRUCTURED_CARE_PLAN -> """
                Create a complete, actionable funeral coordination plan tailored to the live branch order and burial schedule below. Ensure realistic KES budget allocation, clear role assignments (Driver, Mortician, Sales Agent, Branch Lead), and a ready-to-send family SMS notice.
                $extra

                $contextBlock
            """.trimIndent()
        }
    }

    fun buildChatPrompt(
        userMessage: String,
        snapshot: JabimaLiveOperationsSnapshot
    ): String = """
        [Context: Staff=${snapshot.staffName} (${snapshot.staffRole}) at ${snapshot.staffBranch} | Unread Alerts=${snapshot.unreadAlertsCount} | Burials: ${snapshot.upcomingBurialsSummary} | Latest Order: ${snapshot.latestClientOrderSummary}]
        User Question: $userMessage
    """.trimIndent()

    private val gson = Gson()

    fun parseStructuredCarePlan(jsonString: String): StructuredCarePlan {
        val parsed = gson.fromJson(jsonString, StructuredCarePlan::class.java)
            ?: throw IllegalStateException("Unable to parse structured care plan JSON.")
        require(parsed.planTitle.isNotBlank()) { "Structured care plan missing planTitle." }
        return parsed.copy(
            checklistSteps = parsed.checklistSteps.orEmpty(),
            assignedRoles = parsed.assignedRoles.orEmpty(),
            recommendedSmsNotice = parsed.recommendedSmsNotice.orEmpty()
        )
    }
}

interface JabimaAiGateway {
    fun generateChatStream(
        history: List<Pair<Boolean, String>>,
        prompt: String
    ): Flow<String>

    suspend fun generateStructuredPlanJson(prompt: String): String?
}

class FirebaseAiGateway : JabimaAiGateway {
    private val systemPrompt = content("system") {
        text(
            "You are the Jabima Funeral Directors Ltd AI Operations Copilot. " +
                "Respond with empathy, cultural sensitivity for East African/Kenyan bereavement traditions, " +
                "operational precision, and concise practical steps. Use KES for Kenyan Shilling pricing."
        )
    }

    private val chatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = DEFAULT_MODEL_NAME,
            systemInstruction = systemPrompt
        )
    }

    private val carePlanSchema = Schema.obj(
        properties = mapOf(
            "planTitle" to Schema.string(description = "Concise title of the funeral coordination plan"),
            "prioritySummary" to Schema.string(description = "Executive priority summary for the shift lead"),
            "estimatedBudgetKes" to Schema.integer(description = "Estimated total package budget in Kenyan Shillings (KES)"),
            "checklistSteps" to Schema.array(
                items = Schema.string(),
                description = "Sequential step-by-step operational checklist items"
            ),
            "assignedRoles" to Schema.array(
                items = Schema.string(),
                description = "Staff roles assigned to execute steps"
            ),
            "recommendedSmsNotice" to Schema.string(description = "Short compassionate family notification SMS under 300 characters")
        ),
        optionalProperties = listOf("recommendedSmsNotice")
    )

    private val structuredModel by lazy {
        Firebase.ai.generativeModel(
            modelName = DEFAULT_MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = carePlanSchema
            },
            systemInstruction = systemPrompt
        )
    }

    override fun generateChatStream(
        history: List<Pair<Boolean, String>>,
        prompt: String
    ): Flow<String> {
        val mappedHistory: List<Content> = history.map { (isUser, text) ->
            content(if (isUser) "user" else "model") { text(text) }
        }
        val chat = chatModel.startChat(history = mappedHistory)
        return chat.sendMessageStream(prompt).mapNotNull { chunk -> chunk.text }
    }

    override suspend fun generateStructuredPlanJson(prompt: String): String? {
        return structuredModel.generateContent(prompt).text
    }
}

class JabimaGeminiViewModel(
    private val aiGateway: JabimaAiGateway = FirebaseAiGateway(),
    private val errorLogger: (String, Throwable) -> Unit = { msg, err -> Log.e(TAG, msg, err) }
) : ViewModel() {

    private val _uiState = MutableStateFlow<GeminiUiState>(GeminiUiState.Idle)
    val uiState: StateFlow<GeminiUiState> = _uiState.asStateFlow()

    private val _messages = MutableStateFlow<List<GeminiChatMessage>>(emptyList())
    val messages: StateFlow<List<GeminiChatMessage>> = _messages.asStateFlow()

    private val _structuredPlan = MutableStateFlow<StructuredCarePlan?>(null)
    val structuredPlan: StateFlow<StructuredCarePlan?> = _structuredPlan.asStateFlow()

    private val _isStructuredMode = MutableStateFlow(false)
    val isStructuredMode: StateFlow<Boolean> = _isStructuredMode.asStateFlow()

    private var lastRetryAction: (() -> Unit)? = null

    fun setStructuredMode(enabled: Boolean) {
        _isStructuredMode.value = enabled
    }

    fun sendStreamingPrompt(
        displayPrompt: String,
        fullContextPrompt: String = displayPrompt
    ) {
        if (displayPrompt.isBlank()) return
        lastRetryAction = { sendStreamingPrompt(displayPrompt, fullContextPrompt) }
        _isStructuredMode.value = false

        val priorHistory = _messages.value
            .filter { !it.isStreaming && it.text.isNotBlank() }
            .map { it.isUser to it.text }

        val userMsgId = "usr-${System.currentTimeMillis()}"
        val modelMsgId = "mod-${System.currentTimeMillis() + 1}"

        _messages.value = _messages.value +
            GeminiChatMessage(id = userMsgId, isUser = true, text = displayPrompt) +
            GeminiChatMessage(id = modelMsgId, isUser = false, text = "", isStreaming = true)

        viewModelScope.launch {
            _uiState.value = GeminiUiState.Loading
            val accumulated = StringBuilder()
            try {
                withTimeout(AI_TIMEOUT_MS) {
                    aiGateway.generateChatStream(priorHistory, fullContextPrompt).collect { chunkText ->
                        accumulated.append(chunkText)
                        val latest = accumulated.toString()
                        _uiState.value = GeminiUiState.Streaming(latest)
                        _messages.value = _messages.value.map { msg ->
                            if (msg.id == modelMsgId) msg.copy(text = latest, isStreaming = true) else msg
                        }
                    }
                }
                val finalText = accumulated.toString()
                if (finalText.isNotBlank()) {
                    _messages.value = _messages.value.map { msg ->
                        if (msg.id == modelMsgId) msg.copy(text = finalText, isStreaming = false) else msg
                    }
                    _uiState.value = GeminiUiState.Success(finalText)
                } else {
                    _messages.value = _messages.value.filterNot { it.id == modelMsgId }
                    _uiState.value = GeminiUiState.Error("Gemini returned an empty response. Please try again.")
                }
            } catch (e: TimeoutCancellationException) {
                errorLogger("Gemini streaming timed out", e)
                _messages.value = _messages.value.filterNot { it.id == modelMsgId }
                _uiState.value = GeminiUiState.Error("Request timed out after 60 seconds. Check your connection and retry.")
            } catch (e: CancellationException) {
                // Preserve cooperative coroutine cancellation
                throw e
            } catch (e: Exception) {
                errorLogger("Firebase AI streaming generation failed", e)
                _messages.value = _messages.value.filterNot { it.id == modelMsgId }
                _uiState.value = GeminiUiState.Error(e.localizedMessage ?: "Gemini generation failed.")
            }
        }
    }

    fun generateStructuredCarePlan(prompt: String) {
        lastRetryAction = { generateStructuredCarePlan(prompt) }
        _isStructuredMode.value = true

        viewModelScope.launch {
            _uiState.value = GeminiUiState.Loading
            try {
                val jsonString = withTimeout(AI_TIMEOUT_MS) {
                    aiGateway.generateStructuredPlanJson(prompt)
                }
                if (jsonString.isNullOrBlank()) {
                    _uiState.value = GeminiUiState.Error("Gemini returned an empty care plan response.")
                    return@launch
                }
                val parsed = JabimaPromptContextBuilder.parseStructuredCarePlan(jsonString)
                _structuredPlan.value = parsed
                _uiState.value = GeminiUiState.Success(parsed.planTitle)
            } catch (e: TimeoutCancellationException) {
                errorLogger("Structured plan generation timed out", e)
                _uiState.value = GeminiUiState.Error("Structured plan timed out after 60 seconds. Please retry.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                errorLogger("Failed to generate or parse structured care plan", e)
                _uiState.value = GeminiUiState.Error(e.localizedMessage ?: "Failed to generate structured plan.")
            }
        }
    }

    fun retryLastRequest() {
        lastRetryAction?.invoke()
    }

    fun clearSession() {
        _messages.value = emptyList()
        _structuredPlan.value = null
        _uiState.value = GeminiUiState.Idle
    }
}
