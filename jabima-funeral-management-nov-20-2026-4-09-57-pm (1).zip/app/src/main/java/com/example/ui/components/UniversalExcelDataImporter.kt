package com.example.ui.components

import com.example.model.BurialScheduleEvent
import com.example.model.BurialServiceTiming
import com.example.model.CustomerOrderRecord
import com.example.model.Department
import com.example.model.ExcelDatasetType
import com.example.model.FleetGpsVehicle
import com.example.model.FuneralArrangementStage
import com.example.model.JABIMA_BRANCHES
import com.example.model.StaffAccount
import com.example.model.StaffRole
import com.example.model.StockCategory
import com.example.model.StockUploadItem
import com.example.model.WorkshopProductionItem
import com.example.model.WorkshopProductionStage
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipInputStream

object UniversalExcelDataImporter {

    /**
     * Extracts raw 2D grid rows from either an .xlsx OpenXML stream or a .csv/.tsv stream.
     */
    fun extractRawRows(
        inputStream: InputStream,
        fileName: String
    ): List<List<String>> {
        val isXlsx = fileName.endsWith(".xlsx", ignoreCase = true) || isZipStream(inputStream)
        return if (isXlsx) {
            extractXlsxRows(inputStream)
        } else {
            extractDelimitedTextRows(inputStream)
        }
    }

    /**
     * Extracts raw 2D grid rows from pasted text (tab or comma separated).
     */
    fun extractRawRowsFromText(text: String): List<List<String>> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()

        val delimiter = if (lines.first().contains("\t")) "\t" else if (lines.first().contains(",")) "," else ";"
        return lines.map { parseLineWithQuotes(it, delimiter) }
    }

    // =========================================================================
    // 1. INVENTORY & CASKET STOCK MAPPERS
    // =========================================================================
    fun parseStockItems(
        rawRows: List<List<String>>,
        uploadedBy: String = "Fredrick Hayoyo (CEO)"
    ): List<StockUploadItem> {
        val dataRows = stripHeaderRowIfPresent(rawRows, listOf("sku", "name", "category", "qty", "price", "cost"))
        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

        return dataRows.mapNotNull { row ->
            if (row.all { it.isBlank() }) return@mapNotNull null
            val name = row.getOrNull(1)?.trim().orEmpty().ifBlank { row.getOrNull(0)?.trim().orEmpty() }
            if (name.isBlank()) return@mapNotNull null

            val sku = row.getOrNull(0)?.trim()?.ifBlank { "SKU-" + (1000..9999).random() } ?: ("SKU-" + (1000..9999).random())
            val categoryStr = row.getOrNull(2)?.trim().orEmpty()
            val desc = row.getOrNull(3)?.trim().orEmpty().ifBlank { "Standard consignment inventory" }
            val qty = row.getOrNull(4)?.replace(",", "")?.trim()?.toIntOrNull() ?: 1
            val threshold = row.getOrNull(5)?.replace(",", "")?.trim()?.toIntOrNull() ?: 2
            val cost = row.getOrNull(6)?.replace(",", "")?.replace("KES", "")?.trim()?.toDoubleOrNull() ?: 0.0
            val selling = row.getOrNull(7)?.replace(",", "")?.replace("KES", "")?.trim()?.toDoubleOrNull() ?: (cost * 1.5).coerceAtLeast(15000.0)
            val branch = row.getOrNull(8)?.trim().orEmpty().ifBlank { "Bama Branch" }
            val supplier = row.getOrNull(9)?.trim().orEmpty().ifBlank { "Excel Consignment Vendor" }
            val invoice = row.getOrNull(10)?.trim().orEmpty().ifBlank { "INV-XL-" + (100..999).random() }

            val cleanCategory = resolveStockCategory(categoryStr, name)
            val cleanBranch = matchBranch(branch)

            StockUploadItem(
                id = "XL-STK-" + UUID.randomUUID().toString().take(6).uppercase(),
                name = name,
                category = cleanCategory,
                sku = sku,
                description = desc,
                quantity = qty.coerceAtLeast(1),
                reorderThreshold = threshold.coerceAtLeast(1),
                costPriceKes = cost,
                sellingPriceKes = selling,
                branchWarehouse = cleanBranch,
                supplierName = supplier,
                invoiceOrBatchNumber = invoice,
                dateUploaded = today,
                uploadedByStaffName = uploadedBy
            )
        }
    }

    // =========================================================================
    // 2. BURIAL & FUNERAL SCHEDULES MAPPERS
    // =========================================================================
    fun parseBurialSchedules(rawRows: List<List<String>>): List<BurialScheduleEvent> {
        val dataRows = stripHeaderRowIfPresent(rawRows, listOf("case", "deceased", "family", "date", "casket", "church", "venue", "hearse"))

        return dataRows.mapNotNull { row ->
            if (row.all { it.isBlank() }) return@mapNotNull null
            val deceased = row.getOrNull(1)?.trim().orEmpty().ifBlank { row.getOrNull(0)?.trim().orEmpty() }
            if (deceased.isBlank()) return@mapNotNull null

            val caseRef = row.getOrNull(0)?.trim()?.ifBlank { "JFD-2026-" + (100..999).random() } ?: ("JFD-2026-" + (100..999).random())
            val familyRep = row.getOrNull(2)?.trim().orEmpty().ifBlank { "Family Spokesperson" }
            val phone = row.getOrNull(3)?.trim().orEmpty().ifBlank { "+254 7" + (10..99).random() + " " + (100..999).random() + " " + (100..999).random() }
            val burialDate = row.getOrNull(4)?.trim().orEmpty().ifBlank { "28 Oct 2026" }
            val casket = row.getOrNull(5)?.trim().orEmpty().ifBlank { "Executive Double-Lid Mahogany" }
            val church = row.getOrNull(6)?.trim().orEmpty().ifBlank { "St. Peter's Cathedral Siaya" }
            val gravesite = row.getOrNull(7)?.trim().orEmpty().ifBlank { "Family Homestead, Bama Sub-County" }
            val hearse = row.getOrNull(8)?.trim().orEmpty().ifBlank { "KDG 705Y" }
            val driver = row.getOrNull(9)?.trim().orEmpty().ifBlank { "Victor Owino" }
            val director = row.getOrNull(10)?.trim().orEmpty().ifBlank { "Fredrick Hayoyo (CEO)" }

            val timings = listOf(
                BurialServiceTiming(
                    stage = FuneralArrangementStage.FLEET_CORTEGE,
                    timeFormatted = "07:30",
                    venue = "Hearse Cortege Departure from Bama Mortuary",
                    assignedStaffIds = listOf("DRV-01"),
                    assignedStaffNames = listOf(driver),
                    assignedHearseReg = hearse
                ),
                BurialServiceTiming(
                    stage = FuneralArrangementStage.CHAPEL_VIGIL,
                    timeFormatted = "10:00",
                    venue = "Requiem Mass at $church",
                    assignedStaffIds = listOf("DIR-01"),
                    assignedStaffNames = listOf(director)
                ),
                BurialServiceTiming(
                    stage = FuneralArrangementStage.GRAVESITE_LOWERING,
                    timeFormatted = "13:30",
                    venue = "Gravesite Lowering Ceremony at $gravesite",
                    assignedStaffIds = listOf("OP-01", "OP-02"),
                    assignedStaffNames = listOf("George Onyango", "Peter Omondi")
                )
            )

            BurialScheduleEvent(
                id = "XL-BRL-" + UUID.randomUUID().toString().take(6).uppercase(),
                caseReference = caseRef,
                deceasedName = deceased,
                familyRepresentative = familyRep,
                familyPhone = phone,
                burialDate = burialDate,
                casketModel = casket,
                churchVenue = church,
                gravesiteLocation = gravesite,
                assignedHearseReg = hearse,
                assignedDriverName = driver,
                assignedOperators = listOf("George Onyango", "Peter Omondi"),
                assignedDirector = director,
                timings = timings,
                status = "Confirmed & Roster Synced",
                isRosterSynced = true
            )
        }
    }

    // =========================================================================
    // 3. CUSTOMER ORDERS & PAYMENTS MAPPERS
    // =========================================================================
    fun parseCustomerOrders(rawRows: List<List<String>>): List<CustomerOrderRecord> {
        val dataRows = stripHeaderRowIfPresent(rawRows, listOf("order", "client", "deceased", "package", "amount", "paid", "status", "branch"))
        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

        return dataRows.mapNotNull { row ->
            if (row.all { it.isBlank() }) return@mapNotNull null
            val clientName = row.getOrNull(1)?.trim().orEmpty().ifBlank { row.getOrNull(0)?.trim().orEmpty() }
            if (clientName.isBlank()) return@mapNotNull null

            val orderId = row.getOrNull(0)?.trim()?.ifBlank { "ORD-2026-" + (100..999).random() } ?: ("ORD-2026-" + (100..999).random())
            val clientPhone = row.getOrNull(2)?.trim().orEmpty().ifBlank { "+254 7" + (10..99).random() + " 444 888" }
            val deceased = row.getOrNull(3)?.trim().orEmpty().ifBlank { "The Late Family Beloved" }
            val selectedPackage = row.getOrNull(4)?.trim().orEmpty().ifBlank { "Executive Dignity Package" }
            val casket = row.getOrNull(5)?.trim().orEmpty().ifBlank { "Executive Double-Lid Mahogany Casket" }
            val totalKes = row.getOrNull(6)?.replace(",", "")?.replace("KES", "")?.trim()?.toDoubleOrNull() ?: 165000.0
            val paidKes = row.getOrNull(7)?.replace(",", "")?.replace("KES", "")?.trim()?.toDoubleOrNull() ?: (totalKes * 0.7)
            val paymentMethod = row.getOrNull(8)?.trim().orEmpty().ifBlank { "M-PESA" }
            val status = if (paidKes >= totalKes) "Confirmed" else "Installment 1 Received"
            val branch = matchBranch(row.getOrNull(9)?.trim().orEmpty())
            val agent = row.getOrNull(10)?.trim().orEmpty().ifBlank { "Brian Ochieng (Sales Lead)" }

            CustomerOrderRecord(
                orderId = orderId,
                clientName = clientName,
                clientPhone = clientPhone,
                deceasedName = deceased,
                selectedPackage = selectedPackage,
                selectedCasket = casket,
                selectedAddons = listOf("Hearse VIP Escort", "Hydraulic Lowering Gear", "Tents & Red Carpet"),
                totalAmountKes = totalKes,
                totalAmountUsd = totalKes / 130.0,
                paymentMethod = paymentMethod,
                paymentTerms = if (paidKes >= totalKes) "Full payment" else "Lipa pole pole Option (2 installments)",
                paymentStatus = status,
                referenceCode = "REF-" + UUID.randomUUID().toString().take(6).uppercase(),
                orderDate = today,
                branch = branch,
                salesAgentName = agent,
                commissionEarnedKes = (totalKes * 0.05)
            )
        }
    }

    // =========================================================================
    // 4. STAFF ACCOUNTS & DIRECTORY MAPPERS
    // =========================================================================
    fun parseStaffAccounts(rawRows: List<List<String>>): List<StaffAccount> {
        val dataRows = stripHeaderRowIfPresent(rawRows, listOf("staff", "name", "department", "role", "phone", "id", "salary", "branch"))

        return dataRows.mapNotNull { row ->
            if (row.all { it.isBlank() }) return@mapNotNull null
            val name = row.getOrNull(1)?.trim().orEmpty().ifBlank { row.getOrNull(0)?.trim().orEmpty() }
            if (name.isBlank()) return@mapNotNull null

            val staffId = row.getOrNull(0)?.trim()?.ifBlank { "EMP-" + (100..999).random() } ?: ("EMP-" + (100..999).random())
            val deptStr = row.getOrNull(2)?.trim().orEmpty()
            val roleStr = row.getOrNull(3)?.trim().orEmpty()
            val phone = row.getOrNull(4)?.trim().orEmpty().ifBlank { "+254 7" + (10..99).random() + " 333 777" }
            val email = row.getOrNull(5)?.trim().orEmpty().ifBlank { name.lowercase().replace(" ", ".") + "@jabimafuneral.co.ke" }
            val natId = row.getOrNull(6)?.trim().orEmpty().ifBlank { (20000000..38000000).random().toString() }
            val branch = matchBranch(row.getOrNull(7)?.trim().orEmpty())
            val salary = row.getOrNull(8)?.replace(",", "")?.replace("KES", "")?.trim()?.toDoubleOrNull() ?: 45000.0

            val role = resolveStaffRole(roleStr)
            val dept = resolveDepartment(deptStr, role)

            StaffAccount(
                id = staffId,
                fullName = name,
                email = email,
                phone = phone,
                role = role,
                department = dept,
                password = "Jabima2026!",
                nationalId = natId,
                branch = branch,
                baseSalaryKes = salary,
                allowanceKes = 8000.0,
                commissionRatePercent = 5.0,
                isBiometricEnabled = true,
                isActive = true,
                avatarColor = 0xFF0284C7
            )
        }
    }

    // =========================================================================
    // 5. FLEET & VEHICLE LOGISTICS MAPPERS
    // =========================================================================
    fun parseFleetVehicles(rawRows: List<List<String>>): List<FleetGpsVehicle> {
        val dataRows = stripHeaderRowIfPresent(rawRows, listOf("reg", "plate", "model", "type", "driver", "phone", "fuel", "branch", "status"))

        return dataRows.mapNotNull { row ->
            if (row.all { it.isBlank() }) return@mapNotNull null
            val reg = row.getOrNull(0)?.trim().orEmpty()
            val model = row.getOrNull(1)?.trim().orEmpty()
            if (reg.isBlank() && model.isBlank()) return@mapNotNull null

            val cleanReg = if (reg.isNotBlank()) reg else "KDG " + (100..999).random() + "Y"
            val cleanModel = if (model.isNotBlank()) model else "Mercedes-Benz Executive Hearse"
            val driver = row.getOrNull(2)?.trim().orEmpty().ifBlank { "Victor Owino" }
            val driverPhone = row.getOrNull(3)?.trim().orEmpty().ifBlank { "+254 722 000 111" }
            val fuel = row.getOrNull(4)?.replace("%", "")?.trim()?.toIntOrNull() ?: 85
            val destination = row.getOrNull(5)?.trim().orEmpty().ifBlank { "Bama Branch Base" }
            val status = row.getOrNull(6)?.trim().orEmpty().ifBlank { "Standby & Cleaned" }

            FleetGpsVehicle(
                registration = cleanReg,
                model = cleanModel,
                driverName = driver,
                driverPhone = driverPhone,
                latitude = -0.0620 + ((0..50).random() * 0.001),
                longitude = 34.2880 + ((0..50).random() * 0.001),
                speedKmh = 0,
                headingDegrees = 45f,
                statusLabel = status,
                isMoving = false,
                fuelPercent = fuel.coerceIn(10, 100),
                engineRunning = false,
                activeCaseRef = "JFD-2026-REG",
                destination = destination,
                eta = "On Station",
                currentStreet = "Siaya-Bama Main Highway"
            )
        }
    }

    // =========================================================================
    // 6. WORKSHOP PRODUCTION JOBS MAPPERS
    // =========================================================================
    fun parseWorkshopJobs(rawRows: List<List<String>>): List<WorkshopProductionItem> {
        val dataRows = stripHeaderRowIfPresent(rawRows, listOf("job", "casket", "wood", "craftsman", "stage", "progress", "date", "branch"))
        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

        return dataRows.mapNotNull { row ->
            if (row.all { it.isBlank() }) return@mapNotNull null
            val casket = row.getOrNull(1)?.trim().orEmpty().ifBlank { row.getOrNull(0)?.trim().orEmpty() }
            if (casket.isBlank()) return@mapNotNull null

            val jobId = row.getOrNull(0)?.trim()?.ifBlank { "JOB-2026-" + (100..999).random() } ?: ("JOB-2026-" + (100..999).random())
            val wood = row.getOrNull(2)?.trim().orEmpty().ifBlank { "Solid Hardwood Mahogany" }
            val craftsman = row.getOrNull(3)?.trim().orEmpty().ifBlank { "Vincent Omondi (Lead Artisan)" }
            val stageStr = row.getOrNull(4)?.trim().orEmpty()
            val progress = row.getOrNull(5)?.replace("%", "")?.trim()?.toIntOrNull() ?: 50
            val targetDate = row.getOrNull(6)?.trim().orEmpty().ifBlank { "02 Nov 2026" }
            val branch = matchBranch(row.getOrNull(7)?.trim().orEmpty())

            val stage = resolveWorkshopStage(stageStr)

            WorkshopProductionItem(
                id = jobId,
                casketType = casket,
                woodType = wood,
                currentStage = stage,
                percentageDone = progress.coerceIn(0, 100),
                assignedCraftsmanId = "ART-" + (10..99).random(),
                assignedCraftsmanName = craftsman,
                isDoneForDay = false,
                isCompleted = progress >= 100,
                startedDate = today,
                targetCompletionDate = targetDate,
                branch = branch,
                notes = "Imported from Workshop Microsoft Excel Production Schedule"
            )
        }
    }

    // =========================================================================
    // SAMPLE DATASETS GENERATORS FOR ALL 6 CATEGORIES
    // =========================================================================
    fun getSampleExcelDataForType(type: ExcelDatasetType): List<Any> {
        return when (type) {
            ExcelDatasetType.INVENTORY_STOCK -> ExcelStockHelper.getSampleExcelConsignmentItems()
            ExcelDatasetType.BURIAL_SCHEDULES -> getSampleBurialSchedules()
            ExcelDatasetType.CUSTOMER_ORDERS -> getSampleCustomerOrders()
            ExcelDatasetType.STAFF_ACCOUNTS -> getSampleStaffAccounts()
            ExcelDatasetType.FLEET_VEHICLES -> getSampleFleetVehicles()
            ExcelDatasetType.WORKSHOP_JOBS -> getSampleWorkshopJobs()
        }
    }

    fun getSampleBurialSchedules(): List<BurialScheduleEvent> {
        return listOf(
            BurialScheduleEvent(
                id = "XL-BRL-01",
                caseReference = "JFD-2026-101",
                deceasedName = "Hon. Peter Odhiambo Agutu",
                familyRepresentative = "Mama Grace Atieno (Widow)",
                familyPhone = "+254 722 884 911",
                burialDate = "24 Oct 2026",
                casketModel = "Presidential Glass-Dome Oak Casket",
                churchVenue = "St. Paul's ACK Cathedral, Siaya",
                gravesiteLocation = "Bama Central Homestead, Siaya County",
                assignedHearseReg = "KDG 705Y (Mercedes Limousine Hearse)",
                assignedDriverName = "Victor Owino (Senior Cortege Escort)",
                assignedOperators = listOf("George Onyango", "Peter Omondi"),
                assignedDirector = "Fredrick Hayoyo (CEO)",
                timings = listOf(
                    BurialServiceTiming(FuneralArrangementStage.FLEET_CORTEGE, "07:30", "Hearse Cortege Departure from Bama Morgue", listOf("DRV-01"), listOf("Victor Owino"), "KDG 705Y"),
                    BurialServiceTiming(FuneralArrangementStage.CHAPEL_VIGIL, "10:00", "Requiem Mass at St. Paul's Cathedral", listOf("DIR-01"), listOf("Fredrick Hayoyo (CEO)")),
                    BurialServiceTiming(FuneralArrangementStage.GRAVESITE_LOWERING, "13:30", "Gravesite Lowering Protocol at Bama Homestead", listOf("OP-01", "OP-02"), listOf("George Onyango", "Peter Omondi"))
                ),
                status = "Confirmed & Roster Synced",
                isRosterSynced = true
            ),
            BurialScheduleEvent(
                id = "XL-BRL-02",
                caseReference = "JFD-2026-102",
                deceasedName = "Mzee Clement Omolo Nyandiko",
                familyRepresentative = "Dr. John Nyandiko (Elder Son)",
                familyPhone = "+254 733 445 221",
                burialDate = "25 Oct 2026",
                casketModel = "Imperial Walnut Double-Lid",
                churchVenue = "Bondo Catholic Parish Church",
                gravesiteLocation = "Uradi Village, Bondo Sub-County",
                assignedHearseReg = "KCT 871D (Director Executive Hearse)",
                assignedDriverName = "Fredrick Hayoyo",
                assignedOperators = listOf("Charles Ouma", "Kevin Otieno"),
                assignedDirector = "Nicholas Ouma (Funeral Director)",
                timings = listOf(
                    BurialServiceTiming(FuneralArrangementStage.FLEET_CORTEGE, "08:00", "Cortege Departure from Siaya Referral", listOf("DRV-02"), listOf("Fredrick Hayoyo"), "KCT 871D"),
                    BurialServiceTiming(FuneralArrangementStage.CHAPEL_VIGIL, "10:30", "Requiem Mass at Bondo Catholic Church", listOf("DIR-02"), listOf("Nicholas Ouma")),
                    BurialServiceTiming(FuneralArrangementStage.GRAVESITE_LOWERING, "14:00", "Gravesite Committal at Uradi Homestead", listOf("OP-03", "OP-04"), listOf("Charles Ouma", "Kevin Otieno"))
                ),
                status = "Confirmed & Roster Synced",
                isRosterSynced = true
            ),
            BurialScheduleEvent(
                id = "XL-BRL-03",
                caseReference = "JFD-2026-103",
                deceasedName = "Mama Hellen Awino Oduor",
                familyRepresentative = "Eng. Moses Oduor",
                familyPhone = "+254 710 992 443",
                burialDate = "26 Oct 2026",
                casketModel = "Executive Cedar Gloss Finish",
                churchVenue = "Ukwala SDA Community Church",
                gravesiteLocation = "Ukwala Town Family Compound",
                assignedHearseReg = "KDG 705Y",
                assignedDriverName = "Victor Owino",
                assignedOperators = listOf("George Onyango", "Peter Omondi"),
                assignedDirector = "Fredrick Hayoyo (CEO)",
                timings = listOf(
                    BurialServiceTiming(FuneralArrangementStage.INTAKE_MORTUARY, "07:00", "Arrangement Coordination & Family Briefing", listOf("ADM-01"), listOf("Dennis Ochieng")),
                    BurialServiceTiming(FuneralArrangementStage.FLEET_CORTEGE, "09:30", "Procession through Ukwala Central", listOf("DRV-01"), listOf("Victor Owino"), "KDG 705Y"),
                    BurialServiceTiming(FuneralArrangementStage.GRAVESITE_LOWERING, "12:00", "Funeral Service & Burial Committal", listOf("OP-01", "OP-02"), listOf("George Onyango", "Peter Omondi"))
                ),
                status = "Confirmed & Roster Synced",
                isRosterSynced = true
            ),
            BurialScheduleEvent(
                id = "XL-BRL-04",
                caseReference = "JFD-2026-104",
                deceasedName = "Elder Wilson Juma Okoth",
                familyRepresentative = "Pastor Daniel Okoth",
                familyPhone = "+254 721 667 889",
                burialDate = "27 Oct 2026",
                casketModel = "Modern High Roof White Oak",
                churchVenue = "Matibabu Mission Chapel",
                gravesiteLocation = "Rangala Parish Cemetery",
                assignedHearseReg = "KCA 412X (Transit Escort Van)",
                assignedDriverName = "Collins Otieno",
                assignedOperators = listOf("Charles Ouma", "Kevin Otieno"),
                assignedDirector = "Nicholas Ouma (Funeral Director)",
                timings = listOf(
                    BurialServiceTiming(FuneralArrangementStage.FLEET_CORTEGE, "08:30", "Departure from Matibabu Mortuary", listOf("DRV-03"), listOf("Collins Otieno"), "KCA 412X"),
                    BurialServiceTiming(FuneralArrangementStage.CHAPEL_VIGIL, "11:00", "Chapel Service & Eulogies", listOf("DIR-02"), listOf("Nicholas Ouma")),
                    BurialServiceTiming(FuneralArrangementStage.GRAVESITE_LOWERING, "14:30", "Gravesite Lowering & Tent Protocol", listOf("OP-03", "OP-04"), listOf("Charles Ouma", "Kevin Otieno"))
                ),
                status = "Confirmed & Roster Synced",
                isRosterSynced = true
            )
        )
    }

    fun getSampleCustomerOrders(): List<CustomerOrderRecord> {
        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        return listOf(
            CustomerOrderRecord(
                orderId = "ORD-XL-001",
                clientName = "Senator David Ochieng",
                clientPhone = "+254 722 550 119",
                deceasedName = "Mzee George Ochieng",
                selectedPackage = "Presidential State Honors Package",
                selectedCasket = "Presidential Glass-Dome Oak Casket",
                selectedAddons = listOf("Mercedes Hearse Escort", "Hydraulic Lowering Gear", "PA System & Chapel Vigil"),
                totalAmountKes = 265000.0,
                totalAmountUsd = 2038.0,
                paymentMethod = "BANK_TRANSFER",
                paymentTerms = "Full payment",
                paymentStatus = "Confirmed",
                referenceCode = "KCB-TXN-99481",
                orderDate = today,
                branch = "Bama Branch",
                salesAgentName = "Brian Ochieng (Sales Lead)",
                commissionEarnedKes = 13250.0
            ),
            CustomerOrderRecord(
                orderId = "ORD-XL-002",
                clientName = "Mrs. Beatrice Auma",
                clientPhone = "+254 712 994 330",
                deceasedName = "Mama Judith Akeyo",
                selectedPackage = "Executive Dignity Funeral Package",
                selectedCasket = "Executive Double-Lid Mahogany",
                selectedAddons = listOf("VIP Cortege Van", "Red Carpet & Chrome Stunchions"),
                totalAmountKes = 160000.0,
                totalAmountUsd = 1230.0,
                paymentMethod = "M-PESA",
                paymentTerms = "Lipa pole pole Option (2 installments)",
                paymentStatus = "Installment 1 Received",
                referenceCode = "QA89ZX441P",
                orderDate = today,
                branch = "Siaya Referral (Opposite Morgue)",
                salesAgentName = "Alice Atieno",
                commissionEarnedKes = 8000.0
            ),
            CustomerOrderRecord(
                orderId = "ORD-XL-003",
                clientName = "Col. Richard Mwangi",
                clientPhone = "+254 720 111 884",
                deceasedName = "Capt. Evans Mwangi",
                selectedPackage = "Classic Dignity Package",
                selectedCasket = "Modern High Roof White Walnut",
                selectedAddons = listOf("Hearse Escort", "Lowering Gear"),
                totalAmountKes = 115000.0,
                totalAmountUsd = 884.0,
                paymentMethod = "M-PESA",
                paymentTerms = "Full payment",
                paymentStatus = "Confirmed",
                referenceCode = "RB55NM990K",
                orderDate = today,
                branch = "Bondo",
                salesAgentName = "Brian Ochieng (Sales Lead)",
                commissionEarnedKes = 5750.0
            )
        )
    }

    fun getSampleStaffAccounts(): List<StaffAccount> {
        return listOf(
            StaffAccount(
                id = "EMP-XL-01",
                fullName = "Erick Odhiambo",
                email = "erick.odhiambo@jabimafuneral.co.ke",
                phone = "+254 722 890 123",
                role = StaffRole.DRIVER,
                department = Department.DRIVERS,
                password = "Jabima2026!",
                nationalId = "30192837",
                branch = "Bama Branch",
                baseSalaryKes = 50000.0,
                allowanceKes = 12000.0,
                commissionRatePercent = 2.0,
                isBiometricEnabled = true
            ),
            StaffAccount(
                id = "EMP-XL-02",
                fullName = "Grace Akinyi",
                email = "grace.akinyi@jabimafuneral.co.ke",
                phone = "+254 733 901 234",
                role = StaffRole.SALES_MARKETING,
                department = Department.SALES_MARKETING,
                password = "Jabima2026!",
                nationalId = "29485716",
                branch = "Siaya Referral (Opposite Morgue)",
                baseSalaryKes = 40000.0,
                allowanceKes = 8000.0,
                commissionRatePercent = 5.0,
                isBiometricEnabled = true
            ),
            StaffAccount(
                id = "EMP-XL-03",
                fullName = "Moses Otieno",
                email = "moses.otieno@jabimafuneral.co.ke",
                phone = "+254 711 234 567",
                role = StaffRole.CASKET_ARTISAN,
                department = Department.WORKSHOP,
                password = "Jabima2026!",
                nationalId = "31928374",
                branch = "Bama Branch",
                baseSalaryKes = 45000.0,
                allowanceKes = 10000.0,
                commissionRatePercent = 3.0,
                isBiometricEnabled = true
            )
        )
    }

    fun getSampleFleetVehicles(): List<FleetGpsVehicle> {
        return listOf(
            FleetGpsVehicle(
                registration = "KDG 705Y",
                model = "Mercedes-Benz E250 Executive Limousine Hearse",
                driverName = "Victor Owino (Senior Cortege Escort)",
                driverPhone = "+254 722 000 111",
                latitude = -0.0620,
                longitude = 34.2880,
                speedKmh = 0,
                headingDegrees = 45f,
                statusLabel = "Active on Standby (Bama Station)",
                isMoving = false,
                fuelPercent = 95,
                engineRunning = false,
                activeCaseRef = "JFD-2026-VIP",
                destination = "Bama Branch Central Bay",
                eta = "Stationed",
                currentStreet = "Siaya Main Road"
            ),
            FleetGpsVehicle(
                registration = "KCT 871D",
                model = "Executive Director Hearse Cruiser",
                driverName = "Fredrick Hayoyo (Executive Escort)",
                driverPhone = "+254 793 553 434",
                latitude = -0.0612,
                longitude = 34.2865,
                speedKmh = 0,
                headingDegrees = 90f,
                statusLabel = "Standby & Cleaned",
                isMoving = false,
                fuelPercent = 88,
                engineRunning = false,
                activeCaseRef = "JFD-2026-DIR",
                destination = "Siaya Referral Hospital Morgue",
                eta = "15 mins",
                currentStreet = "Bama Commercial Center"
            ),
            FleetGpsVehicle(
                registration = "KCA 412X",
                model = "Toyota HiAce Dignity Family Cortege Escort Van",
                driverName = "Collins Otieno",
                driverPhone = "+254 712 345 678",
                latitude = -0.0635,
                longitude = 34.2895,
                speedKmh = 25,
                headingDegrees = 180f,
                statusLabel = "En Route with Family Cortege",
                isMoving = true,
                fuelPercent = 75,
                engineRunning = true,
                activeCaseRef = "JFD-2026-092",
                destination = "St. Paul's ACK Cathedral, Siaya",
                eta = "8 mins",
                currentStreet = "Hospital Road"
            )
        )
    }

    fun getSampleWorkshopJobs(): List<WorkshopProductionItem> {
        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        return listOf(
            WorkshopProductionItem(
                id = "JOB-XL-01",
                casketType = "Presidential Glass-Dome Oak Casket",
                woodType = "American White Oak",
                currentStage = WorkshopProductionStage.GLASS_FITTING,
                percentageDone = 85,
                assignedCraftsmanId = "ART-01",
                assignedCraftsmanName = "Vincent Omondi (Master Joiner)",
                isDoneForDay = false,
                isCompleted = false,
                startedDate = today,
                targetCompletionDate = "29 Oct 2026",
                branch = "Bama Branch (Workshop Base)",
                notes = "Hand-applied high gloss mirror coat, brass bracket & tempered glass pre-fit"
            ),
            WorkshopProductionItem(
                id = "JOB-XL-02",
                casketType = "Executive Double-Lid Mahogany",
                woodType = "Kiln-Dried Mahogany",
                currentStage = WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY,
                percentageDone = 65,
                assignedCraftsmanId = "ART-02",
                assignedCraftsmanName = "David Ouma (Upholsterer)",
                isDoneForDay = false,
                isCompleted = false,
                startedDate = today,
                targetCompletionDate = "31 Oct 2026",
                branch = "Bama Branch (Workshop Base)",
                notes = "Cream satin velvet quilted interior with golden cord rope"
            ),
            WorkshopProductionItem(
                id = "JOB-XL-03",
                casketType = "Imperial Walnut Deluxe",
                woodType = "Highland Walnut",
                currentStage = WorkshopProductionStage.FRAME_AND_ASSEMBLY,
                percentageDone = 30,
                assignedCraftsmanId = "ART-03",
                assignedCraftsmanName = "Moses Otieno",
                isDoneForDay = false,
                isCompleted = false,
                startedDate = today,
                targetCompletionDate = "04 Nov 2026",
                branch = "Bama Branch (Workshop Base)",
                notes = "Rough frame joints cut and planed to 1.2-inch thickness"
            )
        )
    }

    // =========================================================================
    // EXPORT TO EXCEL CSV (UTF-8 BOM COMPATIBLE)
    // =========================================================================
    fun generateBlankExcelTemplate(type: ExcelDatasetType): String {
        return "\uFEFF" + when (type) {
            ExcelDatasetType.INVENTORY_STOCK ->
                "SKU,Item Name,Category,Description,Quantity,Reorder Threshold,Unit Cost (KES),Selling Price (KES),Warehouse Branch,Supplier,Invoice Batch\n" +
                        "CSK-OAK-01,Presidential Glass-Dome Oak Casket,Caskets & Coffins,Solid oak with glass viewing dome,5,2,120000,210000,Bama Branch,Central Woodcraft Ltd,LOT-2026-01\n"

            ExcelDatasetType.BURIAL_SCHEDULES ->
                "Case Reference,Deceased Name,Family Representative,Family Phone,Burial Date,Casket Model,Church Venue,Gravesite Location,Hearse Reg,Driver Name,Funeral Director\n" +
                        "JFD-2026-101,Hon. Peter Odhiambo Agutu,Mama Grace Atieno,+254 722 884 911,24 Oct 2026,Presidential Glass-Dome Oak,St. Paul's ACK Cathedral,Bama Central Homestead,KDG 705Y,Victor Owino,Fredrick Hayoyo (CEO)\n"

            ExcelDatasetType.CUSTOMER_ORDERS ->
                "Order ID,Client Name,Client Phone,Deceased Name,Package Selected,Casket Model,Total Amount (KES),Paid Amount (KES),Payment Method,Branch,Sales Agent\n" +
                        "ORD-2026-001,Senator David Ochieng,+254 722 550 119,Mzee George Ochieng,Presidential State Honors,Presidential Glass-Dome Oak,265000,265000,BANK_TRANSFER,Bama Branch,Brian Ochieng\n"

            ExcelDatasetType.STAFF_ACCOUNTS ->
                "Staff ID,Full Name,Department,Role,Phone,Email,National ID,Branch,Base Salary (KES)\n" +
                "EMP-001,Erick Odhiambo,Hearse & Fleet Logistics,Fleet Driver,+254 722 890 123,erick.o@jabimafuneral.co.ke,30192837,Bama Branch,50000\n"

            ExcelDatasetType.FLEET_VEHICLES ->
                "Plate Registration,Vehicle Model,Assigned Driver,Driver Phone,Fuel Level %,Destination Base,Status\n" +
                "KDG 705Y,Mercedes-Benz E250 Executive Limousine Hearse,Victor Owino,+254 722 000 111,95%,Bama Branch Base,Standby & Cleaned\n"

            ExcelDatasetType.WORKSHOP_JOBS ->
                "Job ID,Casket Model,Timber Wood,Assigned Craftsman,Stage,Progress %,Target Completion Date,Branch Base\n" +
                "JOB-2026-01,Presidential Glass-Dome Oak,American White Oak,Vincent Omondi,Lacquering & Polish,80%,29 Oct 2026,Bama Branch (Workshop Base)\n"
        }
    }

    // =========================================================================
    // PRIVATE INTERNAL PARSING HELPERS
    // =========================================================================
    private fun isZipStream(inputStream: InputStream): Boolean {
        return try {
            inputStream.mark(4)
            val header = ByteArray(4)
            val read = inputStream.read(header)
            inputStream.reset()
            read == 4 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() &&
                    header[2] == 0x03.toByte() && header[3] == 0x04.toByte()
        } catch (_: Exception) {
            false
        }
    }

    private fun extractXlsxRows(inputStream: InputStream): List<List<String>> {
        val sharedStrings = mutableListOf<String>()
        val sheetRows = mutableListOf<List<String>>()

        try {
            val zip = ZipInputStream(inputStream)
            var entry = zip.nextEntry
            var sheetData: ByteArray? = null

            while (entry != null) {
                val name = entry.name
                if (name.endsWith("sharedStrings.xml", ignoreCase = true)) {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    val pattern = java.util.regex.Pattern.compile("<t[^>]*>(.*?)</t>", java.util.regex.Pattern.DOTALL)
                    val matcher = pattern.matcher(xml)
                    while (matcher.find()) {
                        sharedStrings.add(unescapeXml(matcher.group(1).orEmpty()))
                    }
                } else if (name.endsWith("sheet1.xml", ignoreCase = true) || name.contains("worksheets/sheet", ignoreCase = true)) {
                    if (sheetData == null) {
                        sheetData = zip.readBytes()
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }

            if (sheetData != null) {
                val xml = sheetData.toString(Charsets.UTF_8)
                val rowPattern = java.util.regex.Pattern.compile("<row[^>]*>(.*?)</row>", java.util.regex.Pattern.DOTALL)
                val cellPattern = java.util.regex.Pattern.compile("<c\\s+r=\"([A-Z]+)[0-9]+\"([^>]*)>(.*?)</c>", java.util.regex.Pattern.DOTALL)
                val valPattern = java.util.regex.Pattern.compile("<v>(.*?)</v>")
                val inlineTextPattern = java.util.regex.Pattern.compile("<t[^>]*>(.*?)</t>", java.util.regex.Pattern.DOTALL)

                val rowMatcher = rowPattern.matcher(xml)
                while (rowMatcher.find()) {
                    val rowXml = rowMatcher.group(1).orEmpty()
                    val cellMatcher = cellPattern.matcher(rowXml)
                    val rowCells = mutableMapOf<Int, String>()

                    while (cellMatcher.find()) {
                        val colLetters = cellMatcher.group(1).orEmpty()
                        val colIndex = columnLettersToIndex(colLetters)
                        val attributes = cellMatcher.group(2).orEmpty()
                        val cellContent = cellMatcher.group(3).orEmpty()

                        val isString = attributes.contains("t=\"s\"")
                        val isInlineStr = attributes.contains("t=\"inlineStr\"")

                        var cellValue = ""
                        if (isString) {
                            val vMatcher = valPattern.matcher(cellContent)
                            if (vMatcher.find()) {
                                val idx = vMatcher.group(1).toIntOrNull()
                                if (idx != null && idx >= 0 && idx < sharedStrings.size) {
                                    cellValue = sharedStrings[idx]
                                }
                            }
                        } else if (isInlineStr) {
                            val tMatcher = inlineTextPattern.matcher(cellContent)
                            if (tMatcher.find()) {
                                cellValue = unescapeXml(tMatcher.group(1).orEmpty())
                            }
                        } else {
                            val vMatcher = valPattern.matcher(cellContent)
                            if (vMatcher.find()) {
                                cellValue = vMatcher.group(1).orEmpty()
                            }
                        }
                        rowCells[colIndex] = cellValue.trim()
                    }

                    if (rowCells.isNotEmpty()) {
                        val maxCol = (rowCells.keys.maxOrNull() ?: 0)
                        sheetRows.add((0..maxCol).map { rowCells[it].orEmpty() })
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return sheetRows
    }

    private fun extractDelimitedTextRows(inputStream: InputStream): List<List<String>> {
        val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
        val lines = reader.readLines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()

        val delimiter = if (lines.first().contains("\t")) "\t" else if (lines.first().contains(",")) "," else ";"
        return lines.map { parseLineWithQuotes(it, delimiter) }
    }

    private fun parseLineWithQuotes(line: String, delimiter: String): List<String> {
        val tokens = mutableListOf<String>()
        val sb = java.lang.StringBuilder()
        var inQuotes = false
        var i = 0
        val delimChar = delimiter[0]

        while (i < line.length) {
            val c = line[i]
            if (c == '"') {
                if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                    sb.append('"')
                    i++
                } else {
                    inQuotes = !inQuotes
                }
            } else if (c == delimChar && !inQuotes) {
                tokens.add(sb.toString().trim())
                sb.setLength(0)
            } else {
                sb.append(c)
            }
            i++
        }
        tokens.add(sb.toString().trim())
        return tokens
    }

    private fun stripHeaderRowIfPresent(
        rows: List<List<String>>,
        keywords: List<String>
    ): List<List<String>> {
        if (rows.isEmpty()) return emptyList()
        val first = rows.first()
        val isHeader = first.any { cell ->
            keywords.any { k -> cell.contains(k, ignoreCase = true) }
        }
        return if (isHeader && rows.size > 1) rows.drop(1) else rows
    }

    private fun columnLettersToIndex(letters: String): Int {
        var index = 0
        for (ch in letters.uppercase()) {
            index = index * 26 + (ch - 'A' + 1)
        }
        return (index - 1).coerceAtLeast(0)
    }

    private fun unescapeXml(text: String): String {
        return text.replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
    }

    private fun matchBranch(input: String): String {
        val matched = JABIMA_BRANCHES.firstOrNull { b ->
            input.contains(b, ignoreCase = true) || b.contains(input, ignoreCase = true)
        }
        return matched ?: (if (input.isNotBlank()) input else "Bama Branch")
    }

    private fun resolveStockCategory(categoryText: String, itemName: String): StockCategory {
        val combined = "$categoryText $itemName".lowercase()
        return when {
            combined.contains("casket") || combined.contains("coffin") || combined.contains("dome") ||
                    combined.contains("double-lid") || combined.contains("wood") || combined.contains("walnut") ||
                    combined.contains("mahogany") || combined.contains("oak") || combined.contains("cedar") -> StockCategory.CASKET

            combined.contains("chemical") || combined.contains("embalm") || combined.contains("fluid") ||
                    combined.contains("arterial") || combined.contains("cavity") || combined.contains("disinfect") ||
                    combined.contains("reagent") || combined.contains("formalin") -> StockCategory.MORTUARY_CHEMICALS

            combined.contains("suit") || combined.contains("apparel") || combined.contains("garment") ||
                    combined.contains("dress") || combined.contains("tie") || combined.contains("shroud") ||
                    combined.contains("pouch") || combined.contains("veil") -> StockCategory.BURIAL_APPAREL

            combined.contains("lowering") || combined.contains("gear") || combined.contains("strap") ||
                    combined.contains("canopy") || combined.contains("tent") || combined.contains("trolley") ||
                    combined.contains("hydraulic") || combined.contains("equipment") -> StockCategory.CEREMONIAL_EQUIPMENT

            combined.contains("vigil") || combined.contains("chapel") || combined.contains("microphone") ||
                    combined.contains("speaker") || combined.contains("candle") || combined.contains("crucifix") -> StockCategory.CHAPEL_VIGIL

            combined.contains("brass") || combined.contains("handle") || combined.contains("fitting") ||
                    combined.contains("corner") || combined.contains("hinge") -> StockCategory.BRASS_HARDWARE

            combined.contains("fleet") || combined.contains("spare") || combined.contains("tyre") ||
                    combined.contains("tire") || combined.contains("brake") || combined.contains("filter") -> StockCategory.FLEET_SPARES

            else -> StockCategory.CASKET
        }
    }

    private fun resolveStaffRole(roleText: String): StaffRole {
        val r = roleText.lowercase()
        return when {
            r.contains("driver") || r.contains("cortege") -> StaffRole.DRIVER
            r.contains("operator") || r.contains("grounds") -> StaffRole.OPERATOR
            r.contains("sales") || r.contains("marketing") -> StaffRole.SALES_MARKETING
            r.contains("director") -> StaffRole.FUNERAL_DIRECTOR
            r.contains("mortuary") || r.contains("embalm") -> StaffRole.MORTUARY_TECH
            r.contains("artisan") || r.contains("craftsman") || r.contains("carpenter") -> StaffRole.CASKET_ARTISAN
            r.contains("chapel") || r.contains("vigil") -> StaffRole.CHAPEL_COORDINATOR
            r.contains("account") || r.contains("cashier") -> StaffRole.ACCOUNTS_OFFICER
            r.contains("inventory") -> StaffRole.INVENTORY_MANAGER
            r.contains("admin") -> StaffRole.OPERATIONS_ADMIN
            else -> StaffRole.OPERATOR
        }
    }

    private fun resolveDepartment(deptText: String, role: StaffRole): Department {
        val d = deptText.lowercase()
        return when {
            d.contains("driver") || d.contains("transport") || d.contains("fleet") || d.contains("hearse") -> Department.DRIVERS
            d.contains("sales") || d.contains("marketing") || d.contains("business") -> Department.SALES_MARKETING
            d.contains("workshop") || d.contains("craft") || d.contains("casket") || d.contains("carpenter") -> Department.WORKSHOP
            d.contains("operator") || d.contains("ground") || d.contains("gravesite") || d.contains("mortuary") || d.contains("chapel") -> Department.OPERATORS
            d.contains("admin") || d.contains("account") || d.contains("finance") || d.contains("cashier") || d.contains("billing") -> Department.ADMINISTRATION
            d.contains("ceo") || d.contains("executive") || d.contains("director") -> Department.CEO
            else -> when (role) {
                StaffRole.DRIVER, StaffRole.FLEET_OPERATOR -> Department.DRIVERS
                StaffRole.SALES_MARKETING -> Department.SALES_MARKETING
                StaffRole.WORKSHOP_WORKER, StaffRole.CASKET_ARTISAN -> Department.WORKSHOP
                StaffRole.OPERATOR, StaffRole.MORTUARY_TECH, StaffRole.CHAPEL_COORDINATOR -> Department.OPERATORS
                StaffRole.MANAGING_DIRECTOR_CEO -> Department.CEO
                StaffRole.ADMINISTRATIVE_STAFF, StaffRole.ACCOUNTS_OFFICER, StaffRole.INVENTORY_MANAGER, StaffRole.OPERATIONS_ADMIN -> Department.ADMINISTRATION
                else -> Department.ADMINISTRATION
            }
        }
    }

    private fun resolveWorkshopStage(stageText: String): WorkshopProductionStage {
        val s = stageText.lowercase()
        return when {
            s.contains("frame") || s.contains("join") || s.contains("timber") || s.contains("mill") || s.contains("wood") || s.contains("stage 1") || s.contains("1") -> WorkshopProductionStage.FRAME_AND_ASSEMBLY
            s.contains("sand") || s.contains("paint") || s.contains("lacquer") || s.contains("polish") || s.contains("spray") || s.contains("stage 2") || s.contains("2") -> WorkshopProductionStage.SANDING_AND_PAINTING
            s.contains("cloth") || s.contains("lining") || s.contains("satin") || s.contains("upholster") || s.contains("handle") || s.contains("fitting") || s.contains("stage 3") || s.contains("3") -> WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY
            s.contains("glass") || s.contains("dome") || s.contains("viewing") || s.contains("qc") || s.contains("inspection") || s.contains("final") || s.contains("stage 4") || s.contains("4") -> WorkshopProductionStage.GLASS_FITTING
            else -> WorkshopProductionStage.FRAME_AND_ASSEMBLY
        }
    }
}
