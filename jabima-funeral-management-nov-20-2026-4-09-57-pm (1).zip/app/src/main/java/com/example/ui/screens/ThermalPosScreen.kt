package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.example.R
import com.example.model.PosCartItem
import com.example.model.PosCategory
import com.example.model.PosItem
import com.example.model.PosReceipt
import com.example.model.StaffAccount
import com.example.utils.AndroidPrintHelper
import com.example.utils.PdfDocumentGenerator
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// Default Funeral POS catalog items
private val defaultPosCatalog = listOf(
    PosItem("POS-101", "Imperial Hardwood Casket (Workshop Carved)", PosCategory.CASKETS, 65000.0, "Solid carved mahogany, cream velvet interior & polished brass swing bars (Workshop Crew)", "CSK-IMP-01"),
    PosItem("POS-102", "Executive Oak Satin Casket (Solid Oak)", PosCategory.CASKETS, 48000.0, "High-gloss oak with quilted champagne crepe interior (Brian Adoche & Team)", "CSK-OAK-02"),
    PosItem("POS-103", "Standard Cedar Dignity Coffin", PosCategory.CASKETS, 25000.0, "Polished cedarwood with gold-toned side handles", "CSK-CED-03"),
    PosItem("POS-104", "Hearse Limousine Lead Cortege (Fleet KDG 705Y)", PosCategory.FLEET, 28000.0, "Chauffeured Mercedes hearse with floral roof racks - Victor Owino", "FLT-KDG-705Y"),
    PosItem("POS-105", "24/7 First Call Transfer Hearse (Fleet KCL 703C)", PosCategory.FLEET, 22000.0, "Dignity transfer hearse with dual mortuary stretchers - Joseph Ouma", "FLT-KCL-703C"),
    PosItem("POS-106", "4x4 Overland All-Terrain Hearse (Fleet KBR 104R)", PosCategory.FLEET, 35000.0, "Heavy-duty 4WD hearse for rugged rural cortege - Fredrick Ochieng", "FLT-KBR-104R"),
    PosItem("POS-107", "Night Vigil Transit Hearse (Fleet KDH 172H)", PosCategory.FLEET, 30000.0, "Night vigil hearse with floral preservation and sound PA - Fredrick Osuru", "FLT-KDH-172H"),
    PosItem("POS-108", "Long-Distance Upcountry Hearse (Fleet KDY 211L)", PosCategory.FLEET, 40000.0, "Smooth air-suspension highway hearse - Fredrick Okoth", "FLT-KDY-211L"),
    PosItem("POS-109", "VIP Presidential Escort Limousine (Fleet KCT 871D)", PosCategory.FLEET, 50000.0, "Executive ceremonial lead cortege limousine - Fredrick Hayoyo", "FLT-KCT-871D"),
    PosItem("POS-110", "Complete Arterial Embalming Protocol", PosCategory.MORTUARY, 18000.0, "Comprehensive sanitary preservation, embalming certificate & cosmetics", "MRT-EMB-01"),
    PosItem("POS-112", "Memorial Chapel All-Night Vigil Setup", PosCategory.CHAPEL, 12000.0, "Exclusive chapel hire, sound amplification, hymn screens & vigil staff", "CHP-VGL-01"),
    PosItem("POS-113", "100-Seat Pavilion Tent & Brass Lowering Gear", PosCategory.CHAPEL, 20000.0, "Gravesite canopy tent, artificial grass carpets & mechanical lowering cradle", "CHP-TNT-02"),
    PosItem("POS-114", "Premium Condolence Floral Wreath (Heart)", PosCategory.FLORALS, 8500.0, "Fresh white lilies, crimson roses & customized sympathy ribbon", "FLR-WRT-01"),
    PosItem("POS-115", "Deluxe Leatherette Condolence Register Book", PosCategory.FLORALS, 3500.0, "Gold-embossed family remembrance guest registry", "FLR-REG-02")
)

@Composable
fun ThermalPosScreen(
    currentStaffAccount: StaffAccount?,
    onNavigateToStaffPortal: () -> Unit,
    onReceiptPrintedFeedback: (String) -> Unit = {}
) {
    var selectedCategory by remember { mutableStateOf(PosCategory.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    val cartItems = remember { mutableStateListOf<PosCartItem>() }

    var clientFamilyName by remember { mutableStateOf("") }
    var caseReferenceCode by remember { mutableStateOf("") }
    var selectedPaymentMode by remember { mutableStateOf("M-PESA Till") }
    var selectedPaymentTerms by remember { mutableStateOf("Full payment") }
    var selectedBranch by remember { mutableStateOf(currentStaffAccount?.branch ?: "Siaya Referral (Opposite Morgue)") }
    var generatedReceipt by remember { mutableStateOf<PosReceipt?>(null) }

    // Filter catalog items
    val filteredCatalog = defaultPosCatalog.filter { item ->
        val matchesCategory = selectedCategory == PosCategory.ALL || item.category == selectedCategory
        val matchesSearch = searchQuery.isBlank() ||
                item.name.lowercase().contains(searchQuery.trim().lowercase()) ||
                item.sku.lowercase().contains(searchQuery.trim().lowercase())
        matchesCategory && matchesSearch
    }

    // Cart calculations
    val subtotal = cartItems.sumOf { it.item.price * it.quantity }
    val vatAmount = subtotal * 0.16
    val totalAmount = subtotal

    fun addToCart(item: PosItem) {
        val existingIndex = cartItems.indexOfFirst { it.item.id == item.id }
        if (existingIndex >= 0) {
            val current = cartItems[existingIndex]
            cartItems[existingIndex] = current.copy(quantity = current.quantity + 1)
        } else {
            cartItems.add(PosCartItem(item, 1))
        }
    }

    fun removeFromCart(item: PosItem) {
        val existingIndex = cartItems.indexOfFirst { it.item.id == item.id }
        if (existingIndex >= 0) {
            val current = cartItems[existingIndex]
            if (current.quantity > 1) {
                cartItems[existingIndex] = current.copy(quantity = current.quantity - 1)
            } else {
                cartItems.removeAt(existingIndex)
            }
        }
    }

    fun clearCart() {
        cartItems.clear()
        clientFamilyName = ""
        caseReferenceCode = ""
    }

    fun checkoutAndPrint() {
        if (cartItems.isEmpty()) return
        val now = Date()
        val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(now)
        val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
        val refCode = if (caseReferenceCode.isNotBlank()) caseReferenceCode.trim().uppercase() else "JFD-2026-" + (100..999).random()
        val family = if (clientFamilyName.isNotBlank()) clientFamilyName.trim() else "Walk-in Bereaved Family"
        val cashierName = currentStaffAccount?.fullName ?: "Operations Cashier"
        val cashierId = currentStaffAccount?.id ?: "STF-CASHIER"

        val receipt = PosReceipt(
            receiptNumber = "POS-" + (10000..99999).random(),
            date = dateFmt,
            time = timeFmt,
            customerFamily = family,
            caseReference = refCode,
            cashierStaffId = cashierId,
            cashierStaffName = cashierName,
            items = cartItems.toList(),
            subtotal = subtotal,
            taxVat = vatAmount,
            totalAmount = totalAmount,
            paymentMethod = selectedPaymentMode,
            mpesaRef = if (selectedPaymentMode.contains("M-PESA")) "QMD" + (1000000..9999999).random() else null,
            paymentTerms = selectedPaymentTerms,
            mpesaStkNumber = "+254793553434",
            branch = selectedBranch
        )
        generatedReceipt = receipt
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))

            // POS HEADER BANNER
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Navy900),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("thermal_pos_header_card")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .border(1.5.dp, Color(0xFF60A5FA), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.jfd_logo),
                                contentDescription = "Jabima Funeral Logo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(42.dp).clip(CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "Jabima Thermal POS Terminal",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = "ESC/POS 58mm & 80mm Sales Receipts",
                                fontSize = 11.sp,
                                color = Color(0xFFBAE6FD)
                            )
                            if (currentStaffAccount != null) {
                                Text(
                                    text = "Operator: ${currentStaffAccount.fullName} (${currentStaffAccount.id})",
                                    fontSize = 11.sp,
                                    color = EmeraldLight,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    // Shortcut to Staff Operations Portal right next door!
                    Button(
                        onClick = onNavigateToStaffPortal,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.15f),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("pos_to_staff_portal_button")
                    ) {
                        Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Staff Portal", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // SEARCH & CATEGORY CHIPS
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search caskets, hearse transport, flowers...", fontSize = 12.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp))
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pos_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(PosCategory.values()) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat.label, fontSize = 11.sp) },
                        modifier = Modifier.testTag("pos_cat_${cat.name.lowercase()}")
                    )
                }
            }
        }

        // ACTIVE BILLING CART ACCORDION / SUMMARY
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (cartItems.isNotEmpty()) CyanPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pos_cart_container")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = null,
                                tint = CyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Current Receipt Order (${cartItems.sumOf { it.quantity }} items)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        if (cartItems.isNotEmpty()) {
                            TextButton(onClick = { clearCart() }) {
                                Text("Clear Cart", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                            }
                        }
                    }

                    if (cartItems.isEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap on any service or casket below to add it to this thermal receipt.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Spacer(modifier = Modifier.height(8.dp))

                        // Customer Details Inputs
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = clientFamilyName,
                                onValueChange = { clientFamilyName = it },
                                label = { Text("Client Family Name", fontSize = 10.sp) },
                                placeholder = { Text("e.g. Kiprono Family", fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyanPrimary
                                )
                            )

                            OutlinedTextField(
                                value = caseReferenceCode,
                                onValueChange = { caseReferenceCode = it },
                                label = { Text("Case Ref Code", fontSize = 10.sp) },
                                placeholder = { Text("JFD-2026-085", fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyanPrimary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Selected cart line items
                        cartItems.forEach { cartItem ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = cartItem.item.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "@ KES ${String.format("%,.0f", cartItem.item.price)} each",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { removeFromCart(cartItem.item) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                                    }

                                    Text(
                                        text = "${cartItem.quantity}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp)
                                    )

                                    IconButton(
                                        onClick = { addToCart(cartItem.item) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Text(
                                        text = "KES ${String.format("%,.0f", cartItem.item.price * cartItem.quantity)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        // Payment mode selector
                        Text("Payment Mode", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("M-PESA Till", "M-PESA Paybill", "Cash", "Card").forEach { mode ->
                                FilterChip(
                                    selected = selectedPaymentMode == mode,
                                    onClick = { selectedPaymentMode = mode },
                                    label = { Text(mode, fontSize = 10.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (selectedPaymentMode.contains("M-PESA")) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = EmeraldLight,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Official M-PESA STK Push Number: +254793553434",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Payment Terms (Requested: Lipa pole pole 2 installments & Full payment)
                        Text("Payment Terms", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Full payment", "Lipa pole pole Option ( 2 installments)").forEach { term ->
                                FilterChip(
                                    selected = selectedPaymentTerms == term,
                                    onClick = { selectedPaymentTerms = term },
                                    label = { Text(term, fontSize = 10.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (selectedPaymentTerms.contains("Lipa pole pole")) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = CyanContainer,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "• Installment 1 (50%): KES ${String.format("%,.0f", totalAmount / 2)} (On Intake)\n• Installment 2 (50%): KES ${String.format("%,.0f", totalAmount / 2)} (Prior to Burial Cortege)",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = CyanDark,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Total line
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("TOTAL BILL DUE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "KES ${String.format("%,.0f", totalAmount)}",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = CyanDark
                                )
                            }

                            Button(
                                onClick = { checkoutAndPrint() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldSuccess,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .height(44.dp)
                                    .testTag("pos_print_receipt_button")
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Print Thermal Receipt", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        // CATALOG SECTION HEADER
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Funeral Catalog & Services",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${filteredCatalog.size} available",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // CATALOG ITEMS
        items(filteredCatalog, key = { it.id }) { item ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { addToCart(item) }
                    .testTag("catalog_item_${item.id}")
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = CyanContainer,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = item.category.label,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SKU: ${item.sku}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = item.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = item.description,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "KES ${String.format("%,.0f", item.price)}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = CyanDark
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = { addToCart(item) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanPrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp))
        }
    }

    // THERMAL PAPER RECEIPT PREVIEW DIALOG
    generatedReceipt?.let { receipt ->
        ThermalReceiptDialog(
            receipt = receipt,
            onDismiss = { generatedReceipt = null },
            onPrinted = {
                onReceiptPrintedFeedback("Receipt #${receipt.receiptNumber} printed to 58mm Thermal Printer.")
                clearCart()
                generatedReceipt = null
            }
        )
    }
}

/**
 * High-Fidelity ESC/POS Thermal Receipt Paper Simulation
 */
@Composable
fun ThermalReceiptDialog(
    receipt: PosReceipt,
    onDismiss: () -> Unit,
    onPrinted: () -> Unit
) {
    val context = LocalContext.current
    var printStatusError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {},
        shape = RoundedCornerShape(12.dp),
        containerColor = Color(0xFFF1F5F9), // Slate background behind white thermal paper
        modifier = Modifier.testTag("thermal_receipt_dialog"),
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // White Thermal Paper Sheet
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(6.dp),
                    shadowElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Primary Company Logo on Thermal Output Header
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .border(1.5.dp, Color(0xFF1E3A8A), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.jfd_logo),
                                contentDescription = "Jabima Funeral Directors Primary Logo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Header
                        Text(
                            text = "================================",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Color(0xFF334155)
                        )
                        Text(
                            text = "JABIMA FUNERAL DIRECTORS LTD",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.Black
                        )
                        Text(
                            text = "Branch: ${receipt.branch}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = "M-PESA STK: ${receipt.mpesaStkNumber}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "KRA PIN: P051283921Q • ETR: ${receipt.etrNumber}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Color(0xFF475569)
                        )
                        Text(
                            text = "================================",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Color(0xFF334155)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Receipt Metadata
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("RECEIPT: ${receipt.receiptNumber}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${receipt.date} ${receipt.time}", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("CLIENT: ${receipt.customerFamily}", fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                            Text("CASE: ${receipt.caseReference}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("CASHIER: ${receipt.cashierStaffName}", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            Text("ID: ${receipt.cashierStaffId}", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                        }

                        Text(
                            text = "--------------------------------",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )

                        // Line items table
                        receipt.items.forEach { cartItem ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${cartItem.quantity}x ${cartItem.item.name}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = String.format("%,.0f", cartItem.item.price * cartItem.quantity),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Text(
                            text = "--------------------------------",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )

                        // Subtotals & Taxes
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("SUBTOTAL:", fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                            Text("KES ${String.format("%,.0f", receipt.subtotal)}", fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("VAT (16% INCLUDED):", fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                            Text("KES ${String.format("%,.0f", receipt.taxVat)}", fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("TOTAL PAID:", fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                            Text("KES ${String.format("%,.0f", receipt.totalAmount)}", fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Payment Details
                        Surface(
                            color = Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(6.dp)) {
                                Text("PAYMENT: ${receipt.paymentMethod}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("TERMS: ${receipt.paymentTerms}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                if (receipt.paymentTerms.contains("Lipa pole pole")) {
                                    Text("• 1ST INSTAL (50%): KES ${String.format("%,.0f", receipt.totalAmount / 2)} (PAID)", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                                    Text("• 2ND INSTAL (50%): KES ${String.format("%,.0f", receipt.totalAmount / 2)} (BALANCE DUE)", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = Color(0xFFD97706), fontWeight = FontWeight.Bold)
                                }
                                Text("M-PESA STK: ${receipt.mpesaStkNumber}", fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                                if (receipt.mpesaRef != null) {
                                    Text("M-PESA REF: ${receipt.mpesaRef} (VERIFIED)", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                                }
                                Text("BRANCH: ${receipt.branch}", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = Color(0xFF475569))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // QR / Barcode aesthetic representation
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(36.dp), tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("VERIFY KRA FISCAL RECEIPT", fontFamily = FontFamily.Monospace, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                Text("TIMS/ETR ONLINE VALID", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = Color(0xFF475569))
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "================================",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = Color(0xFF334155)
                        )
                        Text(
                            text = "BRANCHES: Siaya Referral • Siaya Shell\nBama • Bondo • Matibabu • Ukwala • Uradi • Rangala",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 7.sp,
                            color = Color(0xFF475569)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "THANK YOU FOR CHOOSING JABIMA",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                        Text(
                            text = "May their soul rest in eternal peace",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Color(0xFF475569)
                        )
                    }
                }

                if (printStatusError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = printStatusError!!,
                        color = Color(0xFFB91C1C),
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Buttons
                Button(
                    onClick = {
                        printStatusError = null
                        runCatching {
                            val pdfFile = PdfDocumentGenerator.generateThermalPosReceiptPdf(context, receipt)
                            AndroidPrintHelper.printPdfFile(
                                context = context,
                                pdfFile = pdfFile,
                                jobName = "Jabima Receipt ${receipt.receiptNumber}"
                            ).getOrThrow()
                        }.onFailure { err ->
                            printStatusError = err.localizedMessage ?: "Print service unavailable; receipt saved."
                        }
                        onPrinted()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldSuccess,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("confirm_print_thermal_button")
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Print Receipt (System / PDF Printer)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = {
                        printStatusError = null
                        runCatching {
                            val pdfFile = PdfDocumentGenerator.generateThermalPosReceiptPdf(context, receipt)
                            PdfDocumentGenerator.sharePdfFile(
                                context = context,
                                pdfFile = pdfFile,
                                title = "Jabima Receipt ${receipt.receiptNumber}"
                            )
                        }.onFailure { err ->
                            printStatusError = err.localizedMessage ?: "Unable to share PDF receipt."
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("share_pos_receipt_pdf_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Share Receipt PDF", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("Close Preview", fontSize = 12.sp)
                }
            }
        }
    )
}
