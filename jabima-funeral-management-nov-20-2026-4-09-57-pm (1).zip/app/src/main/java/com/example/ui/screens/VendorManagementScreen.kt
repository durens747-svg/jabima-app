package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VendorProfile
import com.example.model.VendorTransaction
import com.example.model.VendorTransactionType
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.Blue100
import com.example.ui.theme.Blue200
import com.example.ui.theme.Blue50
import com.example.ui.theme.Blue700
import com.example.ui.theme.Blue800
import com.example.ui.theme.Blue900
import com.example.ui.theme.Blue950
import com.example.ui.theme.PureWhite

@Composable
fun VendorManagementScreen(
    viewModel: StaffPortalViewModel,
    modifier: Modifier = Modifier
) {
    val vendors by viewModel.vendors.collectAsState()
    val transactions by viewModel.vendorTransactions.collectAsState()

    var selectedSection by remember { mutableIntStateOf(0) } // 0: Transactions Ledger, 1: Vendor Directory
    var txnTypeFilter by remember { mutableStateOf<VendorTransactionType?>(null) }
    var showRecordDialog by remember { mutableStateOf(false) }
    var preselectedVendorId by remember { mutableStateOf<String?>(null) }

    val totalSubmitted = transactions.filter { it.transactionType == VendorTransactionType.PAYMENT_SUBMITTED }.sumOf { it.amount }
    val totalReceived = transactions.filter { it.transactionType == VendorTransactionType.PAYMENT_RECEIVED }.sumOf { it.amount }
    val totalPendingDue = vendors.sumOf { it.pendingBalanceDue }

    val filteredTransactions = transactions.filter { txn ->
        txnTypeFilter == null || txn.transactionType == txnTypeFilter
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) {
        // EXECUTIVE FINANCIAL OVERVIEW BANNER
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Blue900),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("vendor_mgmt_header_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Handshake,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Vendor & Supplier Oversight",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                                Text(
                                    text = "Payments Submitted & Inflow Rebates Received",
                                    color = Blue100,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Button(
                            onClick = {
                                preselectedVendorId = null
                                showRecordDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Blue900
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("record_vendor_txn_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Record Txn", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // FINANCIAL STAT TILES
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = Color.White.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("KES ${String.format("%,.0f", totalSubmitted)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("Payments Submitted", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Blue100)
                                Text("Outflows to suppliers", fontSize = 8.sp, color = Color(0xFF93C5FD))
                            }
                        }

                        Surface(
                            color = Color.White.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("KES ${String.format("%,.0f", totalReceived)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF93C5FD))
                                Text("Rebates Received", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Blue100)
                                Text("Inflow / Cashback", fontSize = 8.sp, color = Color(0xFFBFDBFE))
                            }
                        }

                        Surface(
                            color = Color.White.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("KES ${String.format("%,.0f", totalPendingDue)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text("Pending Due", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = Blue100)
                                Text("Net supplier balance", fontSize = 8.sp, color = Color(0xFF93C5FD))
                            }
                        }
                    }
                }
            }
        }

        // TABS: TRANSACTIONS LEDGER VS VENDOR DIRECTORY
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedSection,
                containerColor = Blue50,
                contentColor = Blue900,
                edgePadding = 4.dp,
                indicator = { tabPositions ->
                    if (selectedSection < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSection]),
                            color = Blue800,
                            height = 3.dp
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, Blue200, RoundedCornerShape(8.dp))
            ) {
                Tab(
                    selected = selectedSection == 0,
                    onClick = { selectedSection = 0 },
                    text = {
                        Text(
                            text = "Ledger of Transactions (${transactions.size})",
                            fontWeight = if (selectedSection == 0) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp,
                            color = if (selectedSection == 0) Blue950 else Blue800,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                )
                Tab(
                    selected = selectedSection == 1,
                    onClick = { selectedSection = 1 },
                    text = {
                        Text(
                            text = "Vendor Directory (${vendors.size})",
                            fontWeight = if (selectedSection == 1) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp,
                            color = if (selectedSection == 1) Blue950 else Blue800,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                )
            }
        }

        // CONTENT BASED ON SELECTED TAB
        if (selectedSection == 0) {
            // FILTER CHIPS FOR TRANSACTIONS
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = txnTypeFilter == null,
                            onClick = { txnTypeFilter = null },
                            label = { Text("All Transactions (${transactions.size})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                    items(VendorTransactionType.values()) { t ->
                        val count = transactions.count { it.transactionType == t }
                        FilterChip(
                            selected = txnTypeFilter == t,
                            onClick = { txnTypeFilter = if (txnTypeFilter == t) null else t },
                            label = { Text("${t.label} ($count)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                }
            }

            // TRANSACTIONS LIST
            items(filteredTransactions, key = { it.id }) { txn ->
                VendorTransactionCard(txn = txn)
            }
        } else {
            // VENDORS LIST
            items(vendors, key = { it.id }) { vendor ->
                VendorProfileCard(
                    vendor = vendor,
                    onRecordTransaction = {
                        preselectedVendorId = vendor.id
                        showRecordDialog = true
                    }
                )
            }
        }
    }

    if (showRecordDialog) {
        RecordVendorTransactionDialog(
            vendors = vendors,
            preselectedVendorId = preselectedVendorId,
            onDismiss = { showRecordDialog = false },
            onSubmit = { vendorId, type, amount, desc, invoice, method, ref ->
                viewModel.recordVendorTransaction(vendorId, type, amount, desc, invoice, method, ref)
                showRecordDialog = false
            }
        )
    }
}

@Composable
private fun VendorTransactionCard(txn: VendorTransaction) {
    val isSubmitted = txn.transactionType == VendorTransactionType.PAYMENT_SUBMITTED

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, Blue200),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("vendor_txn_${txn.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: ID, Date, Type Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = txn.id,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Blue900
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = txn.date,
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }

                // Inflow vs Outflow Badge
                val (bgCol, fgCol, icon) = if (isSubmitted) {
                    Triple(Blue50, Blue900, Icons.Default.ArrowUpward)
                } else {
                    Triple(Color(0xFFDBEAFE), Color(0xFF1E3A8A), Icons.Default.ArrowDownward)
                }

                Surface(
                    color = bgCol,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, fgCol.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(icon, contentDescription = null, tint = fgCol, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = if (isSubmitted) "PAYMENT SUBMITTED" else "PAYMENT RECEIVED",
                            color = fgCol,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Amount & Vendor Name
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = txn.vendorName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Blue950,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "${if (isSubmitted) "- " else "+ "}KES ${String.format("%,.0f", txn.amount)}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSubmitted) Blue900 else Color(0xFF1D4ED8),
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = txn.description,
                fontSize = 12.sp,
                color = Blue900,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Details Row: Invoice, Method, Ref
            Surface(
                color = Blue50,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, Blue100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Invoice No: ${txn.invoiceNumber}", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Blue900)
                        Text("Method: ${txn.paymentMethod}", fontSize = 10.sp, color = Blue700)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Ref: ${txn.mpesaOrBankRef}", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Blue900)
                        Text("Auth: ${txn.authorizedBy}", fontSize = 9.sp, color = Blue700)
                    }
                }
            }
        }
    }
}

@Composable
private fun VendorProfileCard(
    vendor: VendorProfile,
    onRecordTransaction: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, Blue200),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("vendor_card_${vendor.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Vendor Name & Category
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = vendor.vendorName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Blue950
                    )
                    Text(
                        text = vendor.category,
                        fontSize = 11.sp,
                        color = Blue700,
                        fontWeight = FontWeight.Medium
                    )
                }

                Box(
                    modifier = Modifier
                        .background(Blue50, RoundedCornerShape(4.dp))
                        .border(1.dp, Blue200, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(vendor.id, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Blue800)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Contact & Banking Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "${vendor.contactPerson} (${vendor.phoneNumber})", fontSize = 11.sp, color = Blue900)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountBalance, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "${vendor.bankOrMpesaDetails} • Terms: ${vendor.paymentTerms}", fontSize = 10.sp, color = Color(0xFF475569))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Balance Summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = Blue50,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("KES ${String.format("%,.0f", vendor.totalPaidSubmitted)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Blue900)
                        Text("Total Paid", fontSize = 9.sp, color = Blue700)
                    }
                }
                Surface(
                    color = Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("KES ${String.format("%,.0f", vendor.totalReceivedRebates)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1D4ED8))
                        Text("Rebates Received", fontSize = 9.sp, color = Blue700)
                    }
                }
                Surface(
                    color = if (vendor.pendingBalanceDue > 0) Color(0xFFDBEAFE) else Blue50,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("KES ${String.format("%,.0f", vendor.pendingBalanceDue)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Blue950)
                        Text("Pending Due", fontSize = 9.sp, color = Blue700)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onRecordTransaction,
                colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("transact_with_${vendor.id}")
            ) {
                Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Record Payment or Rebate", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordVendorTransactionDialog(
    vendors: List<VendorProfile>,
    preselectedVendorId: String?,
    onDismiss: () -> Unit,
    onSubmit: (
        vendorId: String,
        type: VendorTransactionType,
        amount: Double,
        description: String,
        invoiceNumber: String,
        paymentMethod: String,
        mpesaOrBankRef: String
    ) -> Unit
) {
    var selectedVendor by remember {
        mutableStateOf(
            vendors.firstOrNull { it.id == preselectedVendorId }
                ?: vendors.firstOrNull()
                ?: VendorProfile(
                    id = "V-01",
                    vendorName = "Vendor",
                    category = "",
                    contactPerson = "",
                    phoneNumber = "",
                    paymentTerms = "",
                    bankOrMpesaDetails = "",
                    totalPaidSubmitted = 0.0,
                    totalReceivedRebates = 0.0,
                    pendingBalanceDue = 0.0
                )
        )
    }
    var transactionType by remember { mutableStateOf(VendorTransactionType.PAYMENT_SUBMITTED) }
    var amountText by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var invoiceNumber by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("M-PESA B2B Paybill") }
    var mpesaOrBankRef by remember { mutableStateOf("") }

    var vendorDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Paid, contentDescription = null, tint = Blue800)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Record Vendor Transaction", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Blue900)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Transaction Type Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = transactionType == VendorTransactionType.PAYMENT_SUBMITTED,
                        onClick = { transactionType = VendorTransactionType.PAYMENT_SUBMITTED },
                        label = { Text("Payment Submitted (Outflow)") },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Blue800,
                            selectedLabelColor = Color.White,
                            containerColor = Blue50,
                            labelColor = Blue900
                        )
                    )
                    FilterChip(
                        selected = transactionType == VendorTransactionType.PAYMENT_RECEIVED,
                        onClick = { transactionType = VendorTransactionType.PAYMENT_RECEIVED },
                        label = { Text("Rebate Received (Inflow)") },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Blue800,
                            selectedLabelColor = Color.White,
                            containerColor = Blue50,
                            labelColor = Blue900
                        )
                    )
                }

                // Vendor Dropdown
                ExposedDropdownMenuBox(
                    expanded = vendorDropdownExpanded,
                    onExpandedChange = { vendorDropdownExpanded = !vendorDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedVendor.vendorName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Select Vendor / Partner") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = vendorDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = vendorDropdownExpanded,
                        onDismissRequest = { vendorDropdownExpanded = false }
                    ) {
                        vendors.forEach { v ->
                            DropdownMenuItem(
                                text = { Text("${v.vendorName} (${v.category})") },
                                onClick = {
                                    selectedVendor = v
                                    vendorDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (KES)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Goods/Service Description") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = invoiceNumber,
                        onValueChange = { invoiceNumber = it },
                        label = { Text("Invoice / Bill No.") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = paymentMethod,
                        onValueChange = { paymentMethod = it },
                        label = { Text("Payment Method") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = mpesaOrBankRef,
                    onValueChange = { mpesaOrBankRef = it },
                    label = { Text("M-PESA / Bank Reference Code") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    onSubmit(selectedVendor.id, transactionType, amount, description, invoiceNumber, paymentMethod, mpesaOrBankRef)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Confirm & Record")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Blue900)
            }
        },
        containerColor = PureWhite,
        shape = RoundedCornerShape(16.dp)
    )
}
