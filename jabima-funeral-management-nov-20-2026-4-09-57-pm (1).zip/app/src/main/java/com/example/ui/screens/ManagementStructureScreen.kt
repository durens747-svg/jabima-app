package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CorporateFare
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Department
import com.example.model.StaffAccount
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PurpleLight

data class ManagementPillar(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color,
    val description: String,
    val keyFunctions: List<String>
)

data class ManagementRoleItem(
    val title: String,
    val holder: String,
    val badge: String,
    val icon: ImageVector,
    val iconBg: Color,
    val description: String,
    val coreResponsibilities: List<String>
)

@Composable
fun ManagementStructureScreen(
    staffList: List<StaffAccount>,
    onSelectStaff: (StaffAccount) -> Unit = {}
) {
    var selectedSection by remember { mutableStateOf("ALL") }

    val pillars = listOf(
        ManagementPillar(
            title = "Funeral Service Operations",
            subtitle = "24/7 Logistics & Family Coordination",
            icon = Icons.Default.MedicalServices,
            color = CyanPrimary,
            description = "Provides continuous emotional support to bereaved families, coordinating dignified transfers, embalming sanitization, hearse logistics, and chapel vigil operations.",
            keyFunctions = listOf(
                "24/7 immediate first-call family response",
                "Arterial sanitary embalming & cosmetics",
                "Dignified cortege motorcade & hearse dispatch",
                "Gravesite canopy, sound, and lowering gear protocols"
            )
        ),
        ManagementPillar(
            title = "Sales & Marketing",
            subtitle = "Family Counseling & Flexible Terms",
            icon = Icons.Default.Handshake,
            color = EmeraldSuccess,
            description = "Directs compassionate family intake, transparent package selection, pre-need peace of mind trusts, and structured Lipa Pole Pole installment schedules.",
            keyFunctions = listOf(
                "Compassionate first-contact bereavement counseling",
                "Lipa Pole Pole 2-installment financing",
                "Diaspora repatriation liaison & foreign wiring",
                "M-PESA STK Push (+254793553434) integration"
            )
        ),
        ManagementPillar(
            title = "Casket Production & Workshop",
            subtitle = "Master Carpentry & Quality Assurance",
            icon = Icons.Default.Build,
            color = AmberWarning,
            description = "Maintains artisanal woodwork standards, crafting solid mahogany, oak, and cedar caskets with custom velvet linings and solid brass swing-bars.",
            keyFunctions = listOf(
                "Solid hardwood joinery & oven curing",
                "Multi-layer high-gloss spray lacquering",
                "Quilted satin, crepe & velvet interior quilting",
                "Zinc-sealed hermetic inserts for long-distance transit"
            )
        ),
        ManagementPillar(
            title = "Administration & Compliance",
            subtitle = "Statutory Clearance & Financial Controls",
            icon = Icons.Default.AccountBalance,
            color = Color(0xFF8B5CF6),
            description = "Manages hospital/morgue clearance, statutory Registrar of Births and Deaths Form D1 filing, transparent thermal receipting, and staff payroll disbursements.",
            keyFunctions = listOf(
                "Hospital and morgue statutory document filing",
                "Audit-trail verified thermal receipting",
                "Transparent staff duty allowances & wallet payouts",
                "Inter-branch logistics synchronization across Siaya County"
            )
        )
    )

    val keyRoles = listOf(
        ManagementRoleItem(
            title = "Owner / Board of Directors",
            holder = "Executive Governance",
            badge = "Strategic Vision",
            icon = Icons.Default.CorporateFare,
            iconBg = Navy800,
            description = "Sets high-level strategy, oversees long-term capital investments, upholds institutional dignity standards, and champions regional expansion.",
            coreResponsibilities = listOf(
                "Setting strategic corporate vision and expansion across Western Kenya",
                "High-level capital allocation for fleet modernizations & workshop tech",
                "Ethical oversight, client dignity charters, and regulatory compliance"
            )
        ),
        ManagementRoleItem(
            title = "Managing Director / CEO",
            holder = "Fredrick Hayoyo",
            badge = "Executive Leadership",
            icon = Icons.Default.AdminPanelSettings,
            iconBg = CyanPrimary,
            description = "Oversees operational, financial, and regulatory compliance across all 8 branches, staff morale, facility maintenance, and fleet integrity.",
            coreResponsibilities = listOf(
                "Oversees day-to-day operations and executive leadership across all branches",
                "Financial management, regulatory compliance, and staff morale",
                "Facility maintenance, emergency escalations, and VIP cortege escort"
            )
        ),
        ManagementRoleItem(
            title = "Funeral Directors",
            holder = "Operations Lead Team",
            badge = "Coordination",
            icon = Icons.Default.Security,
            iconBg = Color(0xFF6366F1),
            description = "Directs the frontline team in funeral event coordination, family consultation, chapel vigils, and ceremonial cortege protocols.",
            coreResponsibilities = listOf(
                "Lead family consultations and custom ceremonial planning",
                "Directing hearse motorcades and church service protocols",
                "Interfacing with clergy, cemetery boards, and local administration"
            )
        ),
        ManagementRoleItem(
            title = "Administrative Staff",
            holder = "Finance & Registry Team",
            badge = "Billing & Paperwork",
            icon = Icons.Default.Business,
            iconBg = Color(0xFF10B981),
            description = "Manages statutory paperwork, morgue release permits, burial permits, transparent billing, and instant M-PESA STK validation.",
            coreResponsibilities = listOf(
                "Statutory registry filing (Births & Deaths Form D1)",
                "Transparent POS invoicing & Lipa Pole Pole installment schedules",
                "Staff wallet allowances verification and payroll processing"
            )
        ),
        ManagementRoleItem(
            title = "Support Personnel (Drivers & Fleet Crew)",
            holder = "Fleet & Maintenance Crew (6 Dedicated Drivers)",
            badge = "24/7 Logistics",
            icon = Icons.Default.DirectionsCar,
            iconBg = Color(0xFF0284C7),
            description = "Includes funeral assistants, transfer drivers, and maintenance staff who operate the 6-vehicle fleet and maintain pristine grounds.",
            coreResponsibilities = listOf(
                "24/7 first-call evacuation and morgue-to-residence transfers",
                "Ceremonial hearse driving, motorcade safety, and sound equipment",
                "Canopy setup, grass carpet laying, and lowering cradle operation"
            )
        ),
        ManagementRoleItem(
            title = "Sales / Family Service Counselors",
            holder = "Family Counselor Team (9 Specialists)",
            badge = "Operational Focus",
            icon = Icons.Default.SupportAgent,
            iconBg = Color(0xFFD97706),
            description = "Provides dedicated operational focus: compassionate walk-in family intake, pre-need consultations, and empathetic memorial guidance.",
            coreResponsibilities = listOf(
                "Empathetic counseling during first grief contact",
                "Casket showroom walkthrough & package customization",
                "Liaison on Lipa Pole Pole payment plans and memorial programs"
            )
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("management_structure_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))

            // HEADER BANNER
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Navy900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(CyanPrimary.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CorporateFare,
                                        contentDescription = null,
                                        tint = CyanPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "JABIMA FUNERAL DIRECTORS LTD",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = "Management Structure & Governance",
                                        color = CyanPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        Surface(
                            color = CyanContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "24/7 Operations",
                                color = CyanDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Jabima Funeral Directors Limited management structure is organized around the Managing Director / Owner, overseeing three key pillars: funeral service operations, sales/marketing, casket production and administration. This structure supports the main funeral director and staff in coordinating services, managing logistics, and providing emotional support to families, operating 24/7.",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // FILTER CHIPS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "ALL" to "All Overview",
                    "PILLARS" to "Key Pillars",
                    "ROLES" to "Leadership Roles",
                    "DEPARTMENTS" to "Staff Roster"
                ).forEach { (code, label) ->
                    FilterChip(
                        selected = selectedSection == code,
                        onClick = { selectedSection = code },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // SECTION 1: KEY MANAGEMENT PILLARS
        if (selectedSection == "ALL" || selectedSection == "PILLARS") {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Three Key Operational Pillars",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = AmberLight,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "Core Foundation",
                            color = AmberWarning,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            items(pillars) { pillar ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(pillar.color.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = pillar.icon,
                                    contentDescription = null,
                                    tint = pillar.color,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = pillar.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = pillar.subtitle,
                                    fontSize = 11.sp,
                                    color = pillar.color,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = pillar.description,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            pillar.keyFunctions.forEach { func ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = pillar.color,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = func,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // SECTION 2: KEY MANAGEMENT ROLES
        if (selectedSection == "ALL" || selectedSection == "ROLES") {
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Key Management Roles & Structure",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = PurpleLight,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "Chain of Command",
                            color = Color(0xFF7C3AED),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            items(keyRoles) { role ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(role.iconBg.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = role.icon,
                                        contentDescription = null,
                                        tint = role.iconBg,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = role.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = role.holder,
                                        fontSize = 11.sp,
                                        color = CyanPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = role.badge,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = role.description,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 17.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            role.coreResponsibilities.forEach { resp ->
                                Row(verticalAlignment = Alignment.Top) {
                                    Text("• ", color = CyanPrimary, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = resp,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // SECTION 3: OFFICIAL DEPARTMENT ROSTER
        if (selectedSection == "ALL" || selectedSection == "DEPARTMENTS") {
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Official Department Rosters",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = CyanContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${staffList.size} Active Personnel",
                            color = CyanDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Department.values().forEach { dept ->
                val deptStaff = staffList.filter { it.department == dept }
                if (deptStaff.isNotEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = when (dept) {
                                                Department.CEO -> Icons.Default.Star
                                                Department.WORKSHOP -> Icons.Default.Build
                                                Department.DRIVERS -> Icons.Default.DirectionsCar
                                                Department.OPERATORS -> Icons.Default.SupportAgent
                                                Department.SALES_MARKETING -> Icons.Default.Handshake
                                                Department.ADMINISTRATION -> Icons.Default.Security
                                            },
                                            contentDescription = null,
                                            tint = CyanPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = dept.displayName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }

                                    Surface(
                                        color = EmeraldLight,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "${deptStaff.size} Members",
                                            color = EmeraldSuccess,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    deptStaff.forEach { staff ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(28.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(staff.avatarColor)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = staff.fullName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                                                        color = Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text(
                                                        text = staff.fullName,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp
                                                    )
                                                    Text(
                                                        text = "${staff.id} • ${staff.branch}" + if (staff.assignedVehicle != null) " • Fleet: ${staff.assignedVehicle}" else "",
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }

                                            Surface(
                                                color = CyanContainer,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = staff.role.title.split(" ").first(),
                                                    color = CyanDark,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
