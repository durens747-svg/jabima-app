package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Satellite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import com.example.model.FleetGpsVehicle
import com.example.model.GeofenceZone
import com.example.model.GeofenceCheckinEvent
import com.example.model.FleetInspectionRecord
import com.example.model.FleetFuelLogRecord
import com.example.model.MainAppTab
import com.example.model.ShiftVehicleHandover
import com.example.ui.components.BiometricShiftHandoverDialog
import com.example.ui.components.GeofenceEventsDialog
import com.example.ui.components.FleetInspectionDialog
import com.example.ui.components.FleetFuelLogDialog
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

enum class GoogleMapType(val label: String) {
    DEFAULT("Roadmap"),
    SATELLITE("Satellite"),
    TRAFFIC("Live Traffic")
}

@Composable
fun FleetTrackingMapScreen(
    viewModel: StaffPortalViewModel,
    modifier: Modifier = Modifier,
    onNavigateToRoster: () -> Unit = {}
) {
    val vehicles by viewModel.fleetGpsVehicles.collectAsState()
    val selectedVehicle by viewModel.selectedFleetVehicle.collectAsState()
    val context = LocalContext.current

    var mapType by remember { mutableStateOf(GoogleMapType.DEFAULT) }
    var zoomLevel by remember { mutableFloatStateOf(1.0f) }
    var panOffsetX by remember { mutableFloatStateOf(0f) }
    var panOffsetY by remember { mutableFloatStateOf(0f) }
    var isSimulatingMovement by remember { mutableStateOf(true) }
    var filterStatus by remember { mutableStateOf("ALL") }

    val geofenceZones by viewModel.geofenceZones.collectAsState()
    val geofenceEvents by viewModel.geofenceCheckinEvents.collectAsState()
    val shiftHandovers by viewModel.shiftHandovers.collectAsState()
    val allAccounts by viewModel.allAccounts.collectAsState()
    val currentAccount by viewModel.currentAccount.collectAsState()
    var showGeofenceDialog by remember { mutableStateOf(false) }
    var showInspectionDialog by remember { mutableStateOf(false) }
    var showFuelLogDialog by remember { mutableStateOf(false) }
    var showShiftHandoverDialog by remember { mutableStateOf(false) }
    var showHandoverHistoryDialog by remember { mutableStateOf(false) }
    var showGeofencesOnMap by remember { mutableStateOf(true) }

    // Pulsing circle animation for moving hearses on Google Maps
    val infiniteTransition = rememberInfiniteTransition(label = "RadarPing")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RadarRadius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RadarAlpha"
    )

    // Periodic simulation loop if enabled
    LaunchedEffect(isSimulatingMovement) {
        while (isSimulatingMovement) {
            delay(3500)
            viewModel.simulateFleetStepMovement()
        }
    }

    val displayedVehicles = when (filterStatus) {
        "TRANSIT" -> vehicles.filter { it.isMoving }
        "STANDBY" -> vehicles.filter { !it.isMoving }
        else -> vehicles
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("fleet_tracking_google_maps_screen")
    ) {
        // =========================================================================
        // 1. GOOGLE MAPS INTERACTIVE CANVAS
        // =========================================================================
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        panOffsetX += dragAmount.x
                        panOffsetY += dragAmount.y
                    }
                }
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("google_maps_canvas")
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // Map Base Styling by Type
                when (mapType) {
                    GoogleMapType.DEFAULT -> {
                        drawRect(color = Color(0xFFF1EFE9)) // Google Maps Clean Terrain Canvas
                    }
                    GoogleMapType.SATELLITE -> {
                        drawRect(color = Color(0xFF1B2E24)) // Dark satellite vegetation
                    }
                    GoogleMapType.TRAFFIC -> {
                        drawRect(color = Color(0xFFEBE7DD))
                    }
                }

                // Draw Natural Features: Lake Victoria Basin (South/West) & Yala River
                drawNaturalWaterways(mapType, canvasWidth, canvasHeight, panOffsetX, panOffsetY, zoomLevel)

                // Draw Forest Reserves / Agricultural Greens
                drawGreenZones(mapType, canvasWidth, canvasHeight, panOffsetX, panOffsetY, zoomLevel)

                // Draw Highway & Arterial Road Grid (Kisumu-Busia B1, Bondo-Siaya C28, Siaya Hospital Rd)
                drawRoadNetwork(mapType, canvasWidth, canvasHeight, panOffsetX, panOffsetY, zoomLevel)

                // Draw Jabima Branch Location Landmarks (Red Google Pins)
                drawBranchLandmarks(canvasWidth, canvasHeight, panOffsetX, panOffsetY, zoomLevel)

                // Draw Geofence Perimeters around Mortuaries, Chapels & Cemeteries
                if (showGeofencesOnMap) {
                    drawGeofencePerimeters(geofenceZones, canvasWidth, canvasHeight, panOffsetX, panOffsetY, zoomLevel)
                }

                // Draw Selected Vehicle Route Breadcrumbs / Polyline
                selectedVehicle?.let { sel ->
                    drawVehicleRoute(sel, canvasWidth, canvasHeight, panOffsetX, panOffsetY, zoomLevel)
                }

                // Draw Vehicles Pins & Telemetry Markers
                displayedVehicles.forEach { vehicle ->
                    val isSelected = vehicle.registration == selectedVehicle?.registration
                    val screenPos = latLngToScreen(
                        lat = vehicle.latitude,
                        lng = vehicle.longitude,
                        width = canvasWidth,
                        height = canvasHeight,
                        panX = panOffsetX,
                        panY = panOffsetY,
                        zoom = zoomLevel
                    )

                    // Draw Pulsing Radar if moving
                    if (vehicle.isMoving) {
                        drawCircle(
                            color = EmeraldSuccess.copy(alpha = pulseAlpha),
                            radius = pulseRadius * zoomLevel,
                            center = screenPos
                        )
                    }

                    // Draw Outer Marker Drop Shadow & Pin Body
                    val pinColor = when {
                        isSelected -> Color(0xFF0284C7) // Cyan highlight
                        vehicle.isMoving -> EmeraldSuccess
                        vehicle.statusLabel.contains("Morgue", ignoreCase = true) -> Color(0xFFD97706) // Amber
                        else -> Navy900
                    }

                    drawCircle(
                        color = Color.Black.copy(alpha = 0.25f),
                        radius = (14f + (if (isSelected) 4f else 0f)) * zoomLevel,
                        center = screenPos + Offset(0f, 4f)
                    )

                    drawCircle(
                        color = Color.White,
                        radius = (13f + (if (isSelected) 3f else 0f)) * zoomLevel,
                        center = screenPos
                    )

                    drawCircle(
                        color = pinColor,
                        radius = (10f + (if (isSelected) 2f else 0f)) * zoomLevel,
                        center = screenPos
                    )

                    // Direction Heading Arrow Indicator
                    val rad = Math.toRadians((vehicle.headingDegrees - 90).toDouble())
                    val arrowEnd = screenPos + Offset(
                        (cos(rad) * 16f * zoomLevel).toFloat(),
                        (sin(rad) * 16f * zoomLevel).toFloat()
                    )
                    drawLine(
                        color = Color.White,
                        start = screenPos,
                        end = arrowEnd,
                        strokeWidth = 3f * zoomLevel,
                        cap = StrokeCap.Round
                    )
                }
            }
        }

        // =========================================================================
        // 2. TOP FLOATING CONTROLS & MAP TYPE SELECTOR
        // =========================================================================
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Header Card with Live Status Pill & Simulation Controls
            Surface(
                color = PureWhite.copy(alpha = 0.95f),
                shape = RoundedCornerShape(14.dp),
                shadowElevation = 4.dp,
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Navy900),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Google Maps Fleet Radar",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp,
                                    color = Navy900
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .background(EmeraldLight, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "LIVE GPS",
                                        color = EmeraldSuccess,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = "6 Active Hearses • Siaya County & Western Corridor",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    // Simulation play/pause & Refresh
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { isSimulatingMovement = !isSimulatingMovement },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (isSimulatingMovement) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Toggle Simulation",
                                tint = if (isSimulatingMovement) EmeraldSuccess else Color(0xFF64748B),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = { viewModel.refreshFleetTelemetry() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh GPS",
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Map Layer Types (Roadmap, Satellite, Live Traffic) & Filters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                GoogleMapType.values().forEach { type ->
                    FilterChip(
                        selected = mapType == type,
                        onClick = { mapType = type },
                        label = {
                            Text(
                                text = type.label,
                                fontSize = 11.sp,
                                fontWeight = if (mapType == type) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        leadingIcon = {
                            when (type) {
                                GoogleMapType.DEFAULT -> Icon(Icons.Default.Map, null, modifier = Modifier.size(12.dp))
                                GoogleMapType.SATELLITE -> Icon(Icons.Default.Satellite, null, modifier = Modifier.size(12.dp))
                                GoogleMapType.TRAFFIC -> Icon(Icons.Default.Traffic, null, modifier = Modifier.size(12.dp))
                            }
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Navy900,
                            selectedLabelColor = Color.White,
                            selectedLeadingIconColor = Color.White
                        ),
                        modifier = Modifier.height(32.dp)
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Status Filter Pill
                Surface(
                    color = PureWhite.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (filterStatus == "ALL") "All (6)" else if (filterStatus == "TRANSIT") "In Transit (3)" else "Standby (3)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Navy900,
                            modifier = Modifier.clickable {
                                filterStatus = when (filterStatus) {
                                    "ALL" -> "TRANSIT"
                                    "TRANSIT" -> "STANDBY"
                                    else -> "ALL"
                                }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Quick Operations Row: Geofence Check-ins, Hearse Inspection, Fuel Log
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                item {
                    Surface(
                        color = PureWhite.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Color(0xFF0284C7)),
                        modifier = Modifier
                            .clickable { showGeofenceDialog = true }
                            .testTag("open_geofence_dialog_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("📍 Geofence Check-ins", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Navy900)
                            if (geofenceEvents.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(
                                    color = Color(0xFF0284C7),
                                    shape = CircleShape
                                ) {
                                    Text(
                                        text = "${geofenceEvents.size}",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Surface(
                        color = PureWhite.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.8f)),
                        modifier = Modifier
                            .clickable { showInspectionDialog = true }
                            .testTag("open_inspection_dialog_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("📋 Hearse Inspection", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                        }
                    }
                }

                item {
                    Surface(
                        color = PureWhite.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.8f)),
                        modifier = Modifier
                            .clickable { showFuelLogDialog = true }
                            .testTag("open_fuel_log_dialog_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("⛽ Fuel Log Book", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                        }
                    }
                }

                item {
                    Surface(
                        color = PureWhite.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.85f)),
                        modifier = Modifier
                            .clickable { showShiftHandoverDialog = true }
                            .testTag("btn_open_shift_handover")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = "Shift Handover",
                                tint = RoyalCobaltBlue,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Shift Handover", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                        }
                    }
                }

                item {
                    Surface(
                        color = PureWhite.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Navy900.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .clickable { showHandoverHistoryDialog = true }
                            .testTag("btn_open_handover_history")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "Handover Log",
                                tint = Navy900,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Handovers (${shiftHandovers.size})", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Navy900)
                        }
                    }
                }

                item {
                    FilterChip(
                        selected = showGeofencesOnMap,
                        onClick = { showGeofencesOnMap = !showGeofencesOnMap },
                        label = {
                            Text(
                                text = if (showGeofencesOnMap) "Perimeters: ON" else "Perimeters: OFF",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF1E293B),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.height(28.dp).testTag("toggle_geofences_chip")
                    )
                }
            }
        }

        // =========================================================================
        // 3. FLOATING MAP NAVIGATION TOOLS (ZOOM, RECENTER, COMPASS)
        // =========================================================================
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingMapButton(
                icon = Icons.Default.Add,
                onClick = { zoomLevel = (zoomLevel * 1.25f).coerceAtMost(2.5f) }
            )
            FloatingMapButton(
                icon = Icons.Default.Remove,
                onClick = { zoomLevel = (zoomLevel * 0.8f).coerceAtLeast(0.6f) }
            )
            FloatingMapButton(
                icon = Icons.Default.MyLocation,
                onClick = {
                    panOffsetX = 0f
                    panOffsetY = 0f
                    zoomLevel = 1.0f
                }
            )
            FloatingMapButton(
                icon = Icons.Default.Explore,
                onClick = {
                    panOffsetX = 0f
                    panOffsetY = 0f
                }
            )
        }

        // =========================================================================
        // 4. AUTHENTIC GOOGLE LOGO WATERMARK (BOTTOM LEFT)
        // =========================================================================
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 14.dp, bottom = if (selectedVehicle != null) 250.dp else 125.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GoogleLogoBadge()
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Map data ©2026 Google • Imagery ©Maxar",
                fontSize = 9.sp,
                color = if (mapType == GoogleMapType.SATELLITE) Color.White.copy(alpha = 0.7f) else Color.DarkGray.copy(alpha = 0.7f)
            )
        }

        // =========================================================================
        // 5. BOTTOM FLEET CAROUSEL & DETAIL CARD
        // =========================================================================
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Selected Vehicle Telemetry Card
            AnimatedVisibility(visible = selectedVehicle != null) {
                selectedVehicle?.let { vehicle ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                        border = BorderStroke(1.5.dp, Color(0xFF0284C7)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .testTag("vehicle_telemetry_detail_card")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Header with Close
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = Navy900,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = vehicle.registration,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = vehicle.model,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = vehicle.statusLabel,
                                            color = if (vehicle.isMoving) EmeraldSuccess else Color(0xFF0284C7),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { viewModel.selectFleetVehicle(null) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Telemetry Gauge Row: Speed, Fuel, Engine, Heading
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                TelemetryMetricBadge(
                                    icon = Icons.Default.Speed,
                                    label = "Speed",
                                    value = "${vehicle.speedKmh} km/h",
                                    color = if (vehicle.isMoving) EmeraldSuccess else Color.Gray,
                                    modifier = Modifier.weight(1f)
                                )
                                TelemetryMetricBadge(
                                    icon = Icons.Default.LocalGasStation,
                                    label = "Fuel Level",
                                    value = "${vehicle.fuelPercent}%",
                                    color = if (vehicle.fuelPercent > 40) EmeraldSuccess else Color(0xFFD97706),
                                    modifier = Modifier.weight(1f)
                                )
                                TelemetryMetricBadge(
                                    icon = Icons.Default.DirectionsCar,
                                    label = "Ignition",
                                    value = if (vehicle.engineRunning) "Engine ON" else "Parked",
                                    color = if (vehicle.engineRunning) Color(0xFF0284C7) else Color.Gray,
                                    modifier = Modifier.weight(1f)
                                )
                                TelemetryMetricBadge(
                                    icon = Icons.Default.Navigation,
                                    label = "Heading",
                                    value = "${vehicle.headingDegrees.toInt()}°",
                                    color = Navy900,
                                    modifier = Modifier.weight(0.9f)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Location & Case Info Strip
                            Surface(
                                color = Color(0xFFF8FAFC),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Route, null, tint = Color(0xFF0284C7), modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Location: ${vehicle.currentStreet}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = "Mission: ${vehicle.activeCaseRef} • ETA: ${vehicle.eta}",
                                        fontSize = 10.sp,
                                        color = Color(0xFF475569)
                                    )
                                    Text(
                                        text = "Driver: ${vehicle.driverName} (${vehicle.driverPhone})",
                                        fontSize = 10.sp,
                                        color = Navy900,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Action Buttons: Call Driver, WhatsApp, Open in Google Maps, View Roster
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = {
                                        runCatching {
                                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${vehicle.driverPhone}")).apply {
                                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                            context.startActivity(intent)
                                        }.onFailure {
                                            viewModel.actionFeedbackMessage.value = "Driver Phone: ${vehicle.driverPhone}"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .testTag("call_driver_button")
                                ) {
                                    Icon(Icons.Default.Call, null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Call Driver", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        runCatching {
                                            // Open official Google Maps navigation Intent with coordinates
                                            val gmmIntentUri = Uri.parse("geo:${vehicle.latitude},${vehicle.longitude}?q=${vehicle.latitude},${vehicle.longitude}(Jabima Hearse ${vehicle.registration})")
                                            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                                            mapIntent.setPackage("com.google.android.apps.maps")
                                            if (mapIntent.resolveActivity(context.packageManager) != null) {
                                                context.startActivity(mapIntent)
                                            } else {
                                                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=${vehicle.latitude},${vehicle.longitude}"))
                                                context.startActivity(webIntent)
                                            }
                                        }.onFailure {
                                            viewModel.actionFeedbackMessage.value = "GPS Coordinates: ${vehicle.latitude}, ${vehicle.longitude}"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .height(36.dp)
                                        .testTag("open_in_google_maps_button")
                                ) {
                                    Icon(Icons.Default.Directions, null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Google Maps", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = onNavigateToRoster,
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .testTag("view_shift_roster_button")
                                ) {
                                    Text("Roster", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Horizontal Vehicles Quick-Select Strip
            Surface(
                color = PureWhite.copy(alpha = 0.95f),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                shadowElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(displayedVehicles, key = { it.registration }) { vehicle ->
                        val isSelected = vehicle.registration == selectedVehicle?.registration

                        Surface(
                            color = if (isSelected) Color(0xFFE0F2FE) else Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(
                                1.5.dp,
                                if (isSelected) Color(0xFF0284C7) else Color(0xFFE2E8F0)
                            ),
                            modifier = Modifier
                                .clickable {
                                    if (isSelected) {
                                        viewModel.selectFleetVehicle(null)
                                    } else {
                                        viewModel.selectFleetVehicle(vehicle)
                                    }
                                }
                                .testTag("fleet_vehicle_chip_${vehicle.registration}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (vehicle.isMoving) EmeraldSuccess else Color(0xFF64748B))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = vehicle.registration,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (isSelected) Color(0xFF0369A1) else Navy900
                                    )
                                    Text(
                                        text = if (vehicle.isMoving) "${vehicle.speedKmh} km/h" else "Standby",
                                        fontSize = 9.sp,
                                        color = if (vehicle.isMoving) EmeraldSuccess else Color(0xFF64748B)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // =========================================================================
        // 6. OPERATIONS DIALOGS (GEOFENCE, PRE-TRIP INSPECTION, FUEL LOG BOOK)
        // =========================================================================
        if (showGeofenceDialog) {
            GeofenceEventsDialog(
                zones = geofenceZones,
                events = geofenceEvents,
                onDismiss = { showGeofenceDialog = false },
                onTriggerTestCrossing = {
                    val reg = selectedVehicle?.registration ?: "KDE 412X"
                    viewModel.triggerGeofenceAutoCheckin(reg)
                }
            )
        }

        if (showInspectionDialog) {
            FleetInspectionDialog(
                initialVehicleReg = selectedVehicle?.registration,
                defaultDriverName = selectedVehicle?.driverName ?: "Peter Odhiambo (Driver)",
                onDismiss = { showInspectionDialog = false },
                onSubmit = { record ->
                    viewModel.submitFleetInspection(record)
                    showInspectionDialog = false
                }
            )
        }

        if (showFuelLogDialog) {
            FleetFuelLogDialog(
                initialVehicleReg = selectedVehicle?.registration,
                defaultDriverName = selectedVehicle?.driverName ?: "Peter Odhiambo",
                onDismiss = { showFuelLogDialog = false },
                onSubmit = { record ->
                    viewModel.recordFuelLog(record)
                    showFuelLogDialog = false
                }
            )
        }

        if (showShiftHandoverDialog) {
            BiometricShiftHandoverDialog(
                vehicles = vehicles,
                staffAccounts = allAccounts,
                currentStaff = currentAccount,
                onSubmitHandover = { handover ->
                    viewModel.submitShiftHandover(handover)
                    showShiftHandoverDialog = false
                },
                onDismiss = { showShiftHandoverDialog = false }
            )
        }

        if (showHandoverHistoryDialog) {
            AlertDialog(
                onDismissRequest = { showHandoverHistoryDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Fingerprint, contentDescription = null, tint = RoyalCobaltBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Biometric Vehicle Handovers (${shiftHandovers.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                },
                text = {
                    if (shiftHandovers.isEmpty()) {
                        Text(
                            "No shift handovers signed yet. Tap 'Shift Handover' to record dual-biometric key, fuel & lowering-gear transfer.",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.height(300.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(shiftHandovers, key = { it.id }) { h ->
                                Surface(
                                    color = RoyalCobaltIce.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.25f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("${h.vehicleReg} • ${h.branch}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                                            Text(h.timestamp, fontSize = 10.sp, color = Color(0xFF64748B))
                                        }
                                        Text("${h.outgoingStaffName} ➔ ${h.incomingStaffName}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = RoyalCobaltBlue)
                                        Text(
                                            "Fuel ${h.fuelPercent}% • Odo ${h.odometerKm} km • Lowering Gears: ${h.loweringGearCount}",
                                            fontSize = 10.sp,
                                            color = Navy900
                                        )
                                        val checks = buildList {
                                            add(if (h.churchTrolleyOk) "Trolley OK" else "Trolley Issue")
                                            add(if (h.velvetDeckClean) "Velvet Clean" else "Needs Clean")
                                            add(if (h.spareTireAndJackOk) "Spare/Jack OK" else "Missing Kit")
                                        }.joinToString(" • ")
                                        Text(checks, fontSize = 10.sp, color = EmeraldSuccess, fontWeight = FontWeight.Medium)
                                        if (h.conditionNotes.isNotBlank()) {
                                            Text("Note: ${h.conditionNotes}", fontSize = 10.sp, color = Color(0xFF475569))
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { showHandoverHistoryDialog = false }) {
                        Text("Close")
                    }
                }
            )
        }
    }
}

@Composable
private fun FloatingMapButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        color = PureWhite,
        shape = CircleShape,
        shadowElevation = 4.dp,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier
            .size(40.dp)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(imageVector = icon, contentDescription = null, tint = Navy900, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun TelemetryMetricBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = color)
            Text(text = label, fontSize = 8.sp, color = Color(0xFF64748B))
        }
    }
}

@Composable
private fun GoogleLogoBadge() {
    Surface(
        color = PureWhite.copy(alpha = 0.9f),
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(0.5.dp, Color.LightGray)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("G", color = Color(0xFF4285F4), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
            Text("o", color = Color(0xFFEA4335), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
            Text("o", color = Color(0xFFFBBC05), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
            Text("g", color = Color(0xFF4285F4), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
            Text("l", color = Color(0xFF34A853), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
            Text("e", color = Color(0xFFEA4335), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
        }
    }
}

// =========================================================================
// CANVAS MAP DRAWING HELPERS FOR SIAYA COUNTY & HIGHWAYS
// =========================================================================

private fun latLngToScreen(
    lat: Double,
    lng: Double,
    width: Float,
    height: Float,
    panX: Float,
    panY: Float,
    zoom: Float
): Offset {
    // Siaya region bounding box approx: Lat [ -0.15 to 0.20 ], Lng [ 34.10 to 34.45 ]
    val minLat = -0.15
    val maxLat = 0.22
    val minLng = 34.10
    val maxLng = 34.45

    val normalizedX = ((lng - minLng) / (maxLng - minLng)).toFloat()
    val normalizedY = (1.0f - ((lat - minLat) / (maxLat - minLat)).toFloat()) // Invert Y

    val centerX = width / 2f
    val centerY = height / 2f

    val screenX = centerX + (normalizedX * width - centerX + panX) * zoom
    val screenY = centerY + (normalizedY * height - centerY + panY) * zoom

    return Offset(screenX, screenY)
}

private fun DrawScope.drawNaturalWaterways(
    mapType: GoogleMapType,
    w: Float,
    h: Float,
    panX: Float,
    panY: Float,
    zoom: Float
) {
    val waterColor = if (mapType == GoogleMapType.SATELLITE) Color(0xFF0F1E28) else Color(0xFFA5D8F3)

    // Yala River Path flowing across the region
    val riverPath = Path().apply {
        val p1 = latLngToScreen(0.1200, 34.4200, w, h, panX, panY, zoom)
        val p2 = latLngToScreen(0.0900, 34.3500, w, h, panX, panY, zoom)
        val p3 = latLngToScreen(0.0600, 34.2900, w, h, panX, panY, zoom)
        val p4 = latLngToScreen(0.0300, 34.2200, w, h, panX, panY, zoom)
        val p5 = latLngToScreen(-0.0100, 34.1500, w, h, panX, panY, zoom)
        moveTo(p1.x, p1.y)
        cubicTo(p2.x, p2.y, p3.x, p3.y, p4.x, p4.y)
        lineTo(p5.x, p5.y)
    }

    drawPath(
        path = riverPath,
        color = waterColor,
        style = Stroke(width = 8f * zoom, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    // Lake Victoria southern bay curve
    val lakePath = Path().apply {
        val l1 = latLngToScreen(-0.1200, 34.1500, w, h, panX, panY, zoom)
        val l2 = latLngToScreen(-0.1000, 34.2800, w, h, panX, panY, zoom)
        val l3 = latLngToScreen(-0.1400, 34.4000, w, h, panX, panY, zoom)
        moveTo(l1.x, l1.y)
        cubicTo(l2.x, l2.y, l2.x + 50, l2.y + 40, l3.x, l3.y)
        lineTo(w + 100, h + 100)
        lineTo(-100f, h + 100)
        close()
    }
    drawPath(path = lakePath, color = waterColor)
}

private fun DrawScope.drawGreenZones(
    mapType: GoogleMapType,
    w: Float,
    h: Float,
    panX: Float,
    panY: Float,
    zoom: Float
) {
    if (mapType == GoogleMapType.SATELLITE) return

    val parkColor = Color(0xFFCCE8D2)
    val p1 = latLngToScreen(0.0800, 34.2700, w, h, panX, panY, zoom)
    val p2 = latLngToScreen(0.0400, 34.2500, w, h, panX, panY, zoom)

    drawCircle(color = parkColor, radius = 55f * zoom, center = p1)
    drawCircle(color = parkColor, radius = 45f * zoom, center = p2)
}

private fun DrawScope.drawRoadNetwork(
    mapType: GoogleMapType,
    w: Float,
    h: Float,
    panX: Float,
    panY: Float,
    zoom: Float
) {
    val highwayColor = if (mapType == GoogleMapType.TRAFFIC) Color(0xFF10B981) else Color(0xFFFDE047)
    val highwayBorder = Color(0xFFF59E0B)
    val secondaryRoadColor = Color.White

    // Highway B1: Kisumu -> Siaya Junction -> Busia
    val b1Start = latLngToScreen(-0.0200, 34.4200, w, h, panX, panY, zoom)
    val b1Mid = latLngToScreen(0.0754, 34.2982, w, h, panX, panY, zoom)
    val b1End = latLngToScreen(0.1800, 34.1800, w, h, panX, panY, zoom)

    val b1Path = Path().apply {
        moveTo(b1Start.x, b1Start.y)
        lineTo(b1Mid.x, b1Mid.y)
        lineTo(b1End.x, b1End.y)
    }

    // Border
    drawPath(path = b1Path, color = highwayBorder, style = Stroke(width = 11f * zoom, cap = StrokeCap.Round))
    drawPath(path = b1Path, color = highwayColor, style = Stroke(width = 8f * zoom, cap = StrokeCap.Round))

    // Road C28: Bondo -> Wagai -> Siaya -> Ukwala
    val c28Bondo = latLngToScreen(-0.0982, 34.2755, w, h, panX, panY, zoom)
    val c28Siaya = latLngToScreen(0.0607, 34.2881, w, h, panX, panY, zoom)
    val c28Ukwala = latLngToScreen(0.1558, 34.1884, w, h, panX, panY, zoom)

    val c28Path = Path().apply {
        moveTo(c28Bondo.x, c28Bondo.y)
        lineTo(c28Siaya.x, c28Siaya.y)
        lineTo(c28Ukwala.x, c28Ukwala.y)
    }

    drawPath(path = c28Path, color = Color(0xFFCBD5E1), style = Stroke(width = 9f * zoom, cap = StrokeCap.Round))
    drawPath(path = c28Path, color = secondaryRoadColor, style = Stroke(width = 6f * zoom, cap = StrokeCap.Round))

    // Local Siaya Hospital Link
    val hospA = latLngToScreen(0.0607, 34.2881, w, h, panX, panY, zoom)
    val hospB = latLngToScreen(0.0628, 34.2865, w, h, panX, panY, zoom)
    drawLine(color = secondaryRoadColor, start = hospA, end = hospB, strokeWidth = 5f * zoom, cap = StrokeCap.Round)
}

private fun DrawScope.drawBranchLandmarks(
    w: Float,
    h: Float,
    panX: Float,
    panY: Float,
    zoom: Float
) {
    val branches = listOf(
        Triple("Bama Base & Workshop", 0.0607, 34.2881),
        Triple("Siaya Referral Morgue Gate", 0.0628, 34.2865),
        Triple("Bondo Branch", -0.0982, 34.2755),
        Triple("Ukwala Branch", 0.1558, 34.1884),
        Triple("Rangala Branch", 0.1189, 34.3644),
        Triple("Uradi Base", 0.0412, 34.2215)
    )

    branches.forEach { (name, lat, lng) ->
        val pos = latLngToScreen(lat, lng, w, h, panX, panY, zoom)

        // Red Google Maps Teardrop landmark pin
        drawCircle(color = Color(0xFFEA4335), radius = 7f * zoom, center = pos)
        drawCircle(color = Color.White, radius = 3f * zoom, center = pos)
    }
}

private fun DrawScope.drawVehicleRoute(
    vehicle: FleetGpsVehicle,
    w: Float,
    h: Float,
    panX: Float,
    panY: Float,
    zoom: Float
) {
    if (vehicle.routeBreadcrumbs.size < 2) return

    val routePath = Path()
    vehicle.routeBreadcrumbs.forEachIndexed { index, pt ->
        val screenPos = latLngToScreen(pt.latitude, pt.longitude, w, h, panX, panY, zoom)
        if (index == 0) routePath.moveTo(screenPos.x, screenPos.y)
        else routePath.lineTo(screenPos.x, screenPos.y)

        // Waypoint dot
        drawCircle(color = Color(0xFF0284C7), radius = 4f * zoom, center = screenPos)
        drawCircle(color = Color.White, radius = 2f * zoom, center = screenPos)
    }

    // Glowing Cyan Polyline
    drawPath(
        path = routePath,
        color = Color(0xFF0284C7).copy(alpha = 0.8f),
        style = Stroke(
            width = 5f * zoom,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 10f), 0f)
        )
    )
}

private fun DrawScope.drawGeofencePerimeters(
    geofences: List<GeofenceZone>,
    w: Float,
    h: Float,
    panX: Float,
    panY: Float,
    zoom: Float
) {
    geofences.forEach { zone ->
        val center = latLngToScreen(zone.latitude, zone.longitude, w, h, panX, panY, zoom)
        val zoneColor = Color(zone.colorHex)
        val radiusPx = (zone.radiusMeters.toFloat() / 25f) * zoom

        // Draw translucent zone boundary fill
        drawCircle(
            color = zoneColor.copy(alpha = 0.15f),
            radius = radiusPx,
            center = center
        )

        // Draw perimeter stroke with dashed effect
        drawCircle(
            color = zoneColor.copy(alpha = 0.85f),
            radius = radiusPx,
            center = center,
            style = Stroke(
                width = 2.5f * zoom,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
            )
        )

        // Draw center landmark marker
        drawCircle(
            color = zoneColor,
            radius = 5f * zoom,
            center = center
        )
        drawCircle(
            color = Color.White,
            radius = 2.5f * zoom,
            center = center
        )
    }
}
