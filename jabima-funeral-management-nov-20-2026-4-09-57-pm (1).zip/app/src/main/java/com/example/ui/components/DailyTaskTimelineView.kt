package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.TimelineScheduleHelper
import com.example.model.ActivityStatus
import com.example.model.StaffActivity
import com.example.model.TaskPriority
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.Blue100
import com.example.ui.theme.Blue200
import com.example.ui.theme.Blue50
import com.example.ui.theme.Blue700
import com.example.ui.theme.Blue800
import com.example.ui.theme.Blue900
import com.example.ui.theme.Blue950
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite

/**
 * Chronological Visual Timeline View in Jetpack Compose.
 * Renders staff funeral task assignments ordered from earliest start time to latest,
 * complete with a custom vertical Canvas timeline spine, live pulsing active markers,
 * time-window duration axis, parallel-slot conflict badges, and an adaptive side detail pane
 * on tablets/foldables (>= 720.dp).
 */
@Composable
fun DailyTaskTimelineView(
    chronologicalTasks: List<StaffActivity>,
    overlappingTaskIds: Set<String>,
    selectedTaskForPane: StaffActivity?,
    isAdminOrCeo: Boolean,
    onSelectTaskForPane: (StaffActivity) -> Unit,
    onQuickStatusUpdate: (activityId: String, status: ActivityStatus) -> Unit,
    onUpdateStatusWithNotes: (activityId: String, status: ActivityStatus, notes: String?) -> Unit,
    onToggleChecklistItem: (activityId: String, item: String) -> Unit,
    onDispatchTaskAlert: (StaffActivity) -> Unit,
    onOpenStatusDialog: (StaffActivity) -> Unit,
    onOpenAssessPrice: (StaffActivity) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "timelinePulse")
    val pulseRadiusFactor by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.65f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseFactor"
    )

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .testTag("chronological_task_timeline")
    ) {
        val isWidePaneLayout = maxWidth >= 720.dp
        val activePaneTask = selectedTaskForPane
            ?.let { current -> chronologicalTasks.firstOrNull { it.id == current.id } ?: current }
            ?: if (isWidePaneLayout) chronologicalTasks.firstOrNull() else null

        if (isWidePaneLayout && activePaneTask != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.Top
            ) {
                TimelineRowsColumn(
                    chronologicalTasks = chronologicalTasks,
                    overlappingTaskIds = overlappingTaskIds,
                    highlightedTaskId = activePaneTask.id,
                    pulseRadiusFactor = pulseRadiusFactor,
                    onSelectTaskForPane = onSelectTaskForPane,
                    onQuickStatusUpdate = onQuickStatusUpdate,
                    onDispatchTaskAlert = onDispatchTaskAlert,
                    onOpenStatusDialog = onOpenStatusDialog,
                    modifier = Modifier.weight(1.15f)
                )

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = PureWhite,
                    border = BorderStroke(1.dp, Blue200),
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .weight(0.85f)
                        .testTag("timeline_inline_detail_pane")
                ) {
                    TaskDetailPaneContent(
                        activity = activePaneTask,
                        isAdminOrCeo = isAdminOrCeo,
                        showCloseButton = false,
                        onUpdateStatus = { st, notes ->
                            onUpdateStatusWithNotes(activePaneTask.id, st, notes)
                        },
                        onToggleChecklistItem = { item ->
                            onToggleChecklistItem(activePaneTask.id, item)
                        },
                        onDispatchTaskAlert = { onDispatchTaskAlert(activePaneTask) },
                        onOpenAssessPrice = { onOpenAssessPrice(activePaneTask) }
                    )
                }
            }
        } else {
            TimelineRowsColumn(
                chronologicalTasks = chronologicalTasks,
                overlappingTaskIds = overlappingTaskIds,
                highlightedTaskId = selectedTaskForPane?.id,
                pulseRadiusFactor = pulseRadiusFactor,
                onSelectTaskForPane = onSelectTaskForPane,
                onQuickStatusUpdate = onQuickStatusUpdate,
                onDispatchTaskAlert = onDispatchTaskAlert,
                onOpenStatusDialog = onOpenStatusDialog,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun TimelineRowsColumn(
    chronologicalTasks: List<StaffActivity>,
    overlappingTaskIds: Set<String>,
    highlightedTaskId: String?,
    pulseRadiusFactor: Float,
    onSelectTaskForPane: (StaffActivity) -> Unit,
    onQuickStatusUpdate: (activityId: String, status: ActivityStatus) -> Unit,
    onDispatchTaskAlert: (StaffActivity) -> Unit,
    onOpenStatusDialog: (StaffActivity) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        // Chronological summary strip
        Surface(
            color = Blue50,
            border = BorderStroke(1.dp, Blue100),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Blue800, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    val firstTime = chronologicalTasks.firstOrNull()?.time ?: "--"
                    val lastTask = chronologicalTasks.lastOrNull()
                    val lastEnd = lastTask?.let { TimelineScheduleHelper.formatEndTime(it.time, it.durationMinutes) } ?: "--"
                    Text(
                        text = "Chronological Day Flow: $firstTime → $lastEnd (${chronologicalTasks.size} duties)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Blue950
                    )
                }
                if (overlappingTaskIds.isNotEmpty()) {
                    Surface(
                        color = AmberLight,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${overlappingTaskIds.size} Parallel",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = AmberWarning,
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        chronologicalTasks.forEachIndexed { index, task ->
            val isFirst = index == 0
            val isLast = index == chronologicalTasks.lastIndex
            val isOverlapping = task.id in overlappingTaskIds
            val isSelected = task.id == highlightedTaskId

            ChronologicalTimelineRow(
                activity = task,
                isFirst = isFirst,
                isLast = isLast,
                isOverlapping = isOverlapping,
                isSelected = isSelected,
                pulseRadiusFactor = pulseRadiusFactor,
                onOpenPane = { onSelectTaskForPane(task) },
                onQuickStatusUpdate = { st -> onQuickStatusUpdate(task.id, st) },
                onDispatchTaskAlert = { onDispatchTaskAlert(task) },
                onOpenStatusDialog = { onOpenStatusDialog(task) }
            )
        }
    }
}

@Composable
private fun ChronologicalTimelineRow(
    activity: StaffActivity,
    isFirst: Boolean,
    isLast: Boolean,
    isOverlapping: Boolean,
    isSelected: Boolean,
    pulseRadiusFactor: Float,
    onOpenPane: () -> Unit,
    onQuickStatusUpdate: (ActivityStatus) -> Unit,
    onDispatchTaskAlert: () -> Unit,
    onOpenStatusDialog: () -> Unit
) {
    val nodeColor = timelineStatusColor(activity.status)
    val isLive = activity.status == ActivityStatus.IN_PROGRESS || activity.status == ActivityStatus.IN_TRANSIT
    val endTimeLabel = TimelineScheduleHelper.formatEndTime(activity.time, activity.durationMinutes)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .testTag("timeline_row_${activity.id}")
    ) {
        // 1. Left Time Window Axis
        Column(
            modifier = Modifier
                .width(74.dp)
                .padding(top = 6.dp, end = 4.dp),
            horizontalAlignment = Alignment.End
        ) {
            Surface(
                color = if (isLive) nodeColor.copy(alpha = 0.14f) else Blue50,
                border = BorderStroke(1.dp, if (isLive) nodeColor.copy(alpha = 0.45f) else Blue100),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = activity.time,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isLive) nodeColor else Navy900,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = "to $endTimeLabel",
                fontSize = 9.sp,
                color = Color(0xFF64748B),
                maxLines = 1,
                softWrap = false
            )
            Text(
                text = "${activity.durationMinutes} min",
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                color = Blue700
            )
        }

        // 2. Center Vertical Spine & Pulsing Node Canvas
        Box(
            modifier = Modifier
                .width(26.dp)
                .fillMaxHeight(),
            contentAlignment = Alignment.TopCenter
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(26.dp)
            ) {
                val centerX = size.width / 2f
                val nodeY = 18.dp.toPx()
                val railColor = Color(0xFFCBD5E1)

                if (!isFirst) {
                    drawLine(
                        color = railColor,
                        start = Offset(centerX, 0f),
                        end = Offset(centerX, nodeY - 8.dp.toPx()),
                        strokeWidth = 2.5.dp.toPx()
                    )
                }
                if (!isLast) {
                    drawLine(
                        color = railColor,
                        start = Offset(centerX, nodeY + 8.dp.toPx()),
                        end = Offset(centerX, size.height),
                        strokeWidth = 2.5.dp.toPx()
                    )
                }

                if (isLive) {
                    drawCircle(
                        color = nodeColor.copy(alpha = 0.24f),
                        radius = 8.dp.toPx() * pulseRadiusFactor,
                        center = Offset(centerX, nodeY)
                    )
                }

                if (activity.status == ActivityStatus.SCHEDULED || activity.status == ActivityStatus.ON_HOLD) {
                    drawCircle(
                        color = Color.White,
                        radius = 7.dp.toPx(),
                        center = Offset(centerX, nodeY)
                    )
                    drawCircle(
                        color = nodeColor,
                        radius = 7.dp.toPx(),
                        center = Offset(centerX, nodeY),
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                } else {
                    drawCircle(
                        color = nodeColor,
                        radius = 7.5.dp.toPx(),
                        center = Offset(centerX, nodeY)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 2.5.dp.toPx(),
                        center = Offset(centerX, nodeY)
                    )
                }
            }
        }

        // 3. Right Chronological Task Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isSelected) Blue50 else PureWhite
            ),
            border = BorderStroke(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) Blue800 else nodeColor.copy(alpha = 0.45f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp),
            modifier = Modifier
                .weight(1f)
                .padding(bottom = 12.dp)
                .clickable { onOpenPane() }
                .testTag("timeline_card_${activity.id}")
        ) {
            Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                // Status Accent Strip
                Box(
                    modifier = Modifier
                        .width(5.dp)
                        .fillMaxHeight()
                        .background(nodeColor)
                )

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Badges Row: Status, Priority, Parallel Overlap
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                color = nodeColor.copy(alpha = 0.13f),
                                border = BorderStroke(1.dp, nodeColor.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = activity.status.label,
                                    color = nodeColor,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                )
                            }

                            if (activity.priority != TaskPriority.NORMAL) {
                                val pColor = Color(activity.priority.colorHex)
                                Surface(
                                    color = pColor.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = activity.priority.label,
                                        color = pColor,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            if (isOverlapping) {
                                Surface(
                                    color = AmberLight,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "Parallel Slot",
                                        color = AmberWarning,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = "+KES ${String.format("%,.0f", activity.allowanceEarned)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = EmeraldSuccess,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    // Title + Case Family
                    Text(
                        text = activity.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Blue950,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${activity.caseReference} • ${activity.clientFamily} • ${activity.arrangementStage.label}",
                        fontSize = 11.sp,
                        color = Blue700,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    // Staff + Location + Hearse
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${activity.staffName} (${activity.department.displayName})",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Navy900,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (activity.assignedVehicle != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Blue700, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = activity.assignedVehicle.substringBefore(" "),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Blue800,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = activity.location,
                            fontSize = 10.sp,
                            color = Color(0xFF475569),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Checklist Mini Progress Bar
                    if (activity.checklistItems.isNotEmpty()) {
                        val done = activity.checklistItems.count { activity.completedChecklistItems.contains(it) }
                        val total = activity.checklistItems.size
                        val pct = done.toFloat() / total.coerceAtLeast(1)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            LinearProgressIndicator(
                                progress = { pct },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = if (pct == 1f) EmeraldSuccess else Blue800,
                                trackColor = Color(0xFFE2E8F0)
                            )
                            Text(
                                text = "$done/$total checks",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (pct == 1f) EmeraldSuccess else Blue700
                            )
                        }
                    }

                    // Quick Action Strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onOpenPane,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, Blue200),
                            modifier = Modifier.testTag("timeline_open_pane_${activity.id}")
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Blue800, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Detail Pane", fontSize = 10.sp, color = Blue900, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }

                        OutlinedButton(
                            onClick = onOpenStatusDialog,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, Blue200),
                            modifier = Modifier.testTag("timeline_status_btn_${activity.id}")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = Blue800, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Status", fontSize = 10.sp, color = Blue900, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                        }

                        OutlinedButton(
                            onClick = onDispatchTaskAlert,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.5f)),
                            modifier = Modifier.testTag("timeline_alert_btn_${activity.id}")
                        ) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Alert", fontSize = 10.sp, color = AmberWarning, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }

                        when (activity.status) {
                            ActivityStatus.SCHEDULED, ActivityStatus.ON_HOLD -> {
                                Button(
                                    onClick = { onQuickStatusUpdate(ActivityStatus.IN_PROGRESS) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.White),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("timeline_start_${activity.id}")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("Start", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                            ActivityStatus.IN_PROGRESS, ActivityStatus.IN_TRANSIT -> {
                                Button(
                                    onClick = { onQuickStatusUpdate(ActivityStatus.COMPLETED) },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.White),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("timeline_complete_${activity.id}")
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text("Done", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                            ActivityStatus.COMPLETED -> {
                                if (!activity.verifiedByAdmin) {
                                    OutlinedButton(
                                        onClick = { onQuickStatusUpdate(ActivityStatus.VERIFIED_BY_ADMIN) },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        border = BorderStroke(1.dp, Color(0xFF7C3AED))
                                    ) {
                                        Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("Verify", fontSize = 10.sp, color = Color(0xFF6D28D9), fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                            ActivityStatus.VERIFIED_BY_ADMIN -> Unit
                        }
                    }
                }
            }
        }
    }
}

private fun timelineStatusColor(status: ActivityStatus): Color = when (status) {
    ActivityStatus.IN_PROGRESS -> Color(0xFF10B981)
    ActivityStatus.IN_TRANSIT -> Color(0xFF2563EB)
    ActivityStatus.SCHEDULED -> Blue700
    ActivityStatus.ON_HOLD -> Color(0xFFD97706)
    ActivityStatus.COMPLETED -> EmeraldSuccess
    ActivityStatus.VERIFIED_BY_ADMIN -> Color(0xFF7C3AED)
}
