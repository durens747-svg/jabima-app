package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.BurialScheduleEvent
import com.example.model.BurialServiceTiming
import com.example.model.CaseDocumentRecord
import com.example.model.CaseDocumentType
import com.example.model.FamilyCortegeMilestone
import com.example.model.FuneralArrangementStage
import com.example.model.JABIMA_CASKET_TYPES
import com.example.model.JABIMA_FLEET
import com.example.model.ServiceReminderLog
import com.example.ui.StaffPortalViewModel
import com.example.utils.AndroidPrintHelper
import com.example.utils.CaseDocumentMediaHelper
import com.example.utils.PdfDocumentGenerator
import com.example.utils.PickedCaseMediaPayload
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BurialSchedulingScreen(
    viewModel: StaffPortalViewModel
) {
    val context = LocalContext.current
    val burialSchedules by viewModel.burialSchedules.collectAsState()
    val reminderLogs by viewModel.serviceReminderLogs.collectAsState()
    val allAccounts by viewModel.allAccounts.collectAsState()
    val caseDocuments by viewModel.caseDocuments.collectAsState()
    val canVerifyOrDeleteDocs = viewModel.canWriteVerifiedCloudActivity()

    var selectedSubTab by remember { mutableIntStateOf(0) }
    var showNewBurialDialog by remember { mutableStateOf(false) }
    var showUploadDocDialog by remember { mutableStateOf(false) }
    var viewerDocument by remember { mutableStateOf<CaseDocumentRecord?>(null) }
    var selectedDocTypeFilter by remember { mutableStateOf<CaseDocumentType?>(null) }
    var selectedTimingForCustomReminder by remember { mutableStateOf<Pair<BurialScheduleEvent, BurialServiceTiming>?>(null) }
    var selectedFilterIndex by remember { mutableStateOf(0) }

    val filterOptions = listOf("All Scheduled", "Confirmed & Synced", "Reminder Dispatched")
    val filteredSchedules = remember(burialSchedules, selectedFilterIndex) {
        when (selectedFilterIndex) {
            1 -> burialSchedules.filter { it.isRosterSynced }
            2 -> burialSchedules.filter { b -> b.timings.any { it.reminderSent } }
            else -> burialSchedules
        }
    }
    val filteredDocuments = remember(caseDocuments, selectedDocTypeFilter) {
        if (selectedDocTypeFilter == null) caseDocuments
        else caseDocuments.filter { it.documentType == selectedDocTypeFilter }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp)
            .testTag("burial_scheduling_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ==========================================
        // 1. DYNAMIC BURIAL SCHEDULER HERO CARD
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, StrokeRed.copy(alpha = 0.55f)),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("burial_scheduling_hero_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenLight)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CalendarMonth,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "DYNAMIC BURIAL SCHEDULING",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = "Auto-Synced with Roster • Staff Timing Reminders",
                                        color = Color(0xFF93C5FD),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Button(
                                onClick = { showNewBurialDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_schedule_burial")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Schedule", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Status indicators
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.White.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Sync, contentDescription = null, tint = EmeraldLight, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("Roster Sync", fontSize = 10.sp, color = EmeraldLight, fontWeight = FontWeight.Bold)
                                        Text("Auto-Assigned", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.White.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = Color(0xFFFDE68A), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("Timing Reminders", fontSize = 10.sp, color = Color(0xFFFDE68A), fontWeight = FontWeight.Bold)
                                        Text("${reminderLogs.size} Dispatched", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 1B. SECTION TABS: SCHEDULES VS PAPERWORK VAULT
        // ==========================================
        item {
            TabRow(
                selectedTabIndex = selectedSubTab,
                containerColor = PureWhite,
                contentColor = RoyalCobaltBlue,
                indicator = { tabPositions ->
                    if (selectedSubTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
                            color = RoyalCobaltBlue,
                            height = 3.dp
                        )
                    }
                }
            ) {
                Tab(
                    selected = selectedSubTab == 0,
                    onClick = { selectedSubTab = 0 },
                    text = {
                        Text(
                            text = "Burial Schedules (${burialSchedules.size})",
                            fontSize = 12.sp,
                            fontWeight = if (selectedSubTab == 0) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false
                        )
                    },
                    modifier = Modifier.testTag("tab_burial_schedules_list")
                )
                Tab(
                    selected = selectedSubTab == 1,
                    onClick = { selectedSubTab = 1 },
                    text = {
                        Text(
                            text = "Paperwork & Permits (${caseDocuments.size})",
                            fontSize = 12.sp,
                            fontWeight = if (selectedSubTab == 1) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false
                        )
                    },
                    modifier = Modifier.testTag("tab_case_paperwork_vault")
                )
            }
        }

        if (selectedSubTab == 1) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Case Paperwork & Permit Cloud Vault",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Navy900
                                )
                                Text(
                                    text = "Burial permits, mortuary releases, OB extracts & QC photos (zero storage permissions required)",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                            Button(
                                onClick = { showUploadDocDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("btn_upload_case_document")
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Upload Permit / Photo", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = selectedDocTypeFilter == null,
                                onClick = { selectedDocTypeFilter = null },
                                label = { Text("All (${caseDocuments.size})", fontSize = 11.sp) }
                            )
                            CaseDocumentType.entries.forEach { docType ->
                                val cnt = caseDocuments.count { it.documentType == docType }
                                FilterChip(
                                    selected = selectedDocTypeFilter == docType,
                                    onClick = {
                                        selectedDocTypeFilter = if (selectedDocTypeFilter == docType) null else docType
                                    },
                                    label = { Text("${docType.label} ($cnt)", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                                )
                            }
                        }
                    }
                }
            }

            if (filteredDocuments.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Description, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(32.dp))
                            Text("No case permits or documents uploaded yet", fontWeight = FontWeight.Bold, color = Navy900, fontSize = 13.sp)
                            Text("Tap 'Upload Permit / Photo' to attach a burial permit scan, mortuary release, or QC photo.", fontSize = 11.sp, color = TextSecondary)
                        }
                    }
                }
            } else {
                items(filteredDocuments, key = { it.id }) { doc ->
                    CaseDocumentVaultCard(
                        document = doc,
                        canVerifyOrDelete = canVerifyOrDeleteDocs,
                        onViewDocument = { viewerDocument = doc },
                        onVerifyToggle = { viewModel.verifyCaseDocument(doc.id, !doc.verifiedByAdmin) },
                        onDelete = { viewModel.deleteCaseDocument(doc.id) }
                    )
                }
            }
        } else {
        // ==========================================
        // 2. TIMELINE FILTER CHIPS
        // ==========================================
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filterOptions.forEachIndexed { index, title ->
                    FilterChip(
                        selected = selectedFilterIndex == index,
                        onClick = { selectedFilterIndex = index },
                        label = { Text(title, fontSize = 12.sp, fontWeight = if (selectedFilterIndex == index) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalCobaltIce,
                            selectedLabelColor = RoyalCobaltBlue,
                            containerColor = PureWhite
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedFilterIndex == index,
                            selectedBorderColor = RoyalCobaltBlue,
                            borderColor = BorderLight
                        ),
                        modifier = Modifier.testTag("filter_burials_$index")
                    )
                }
            }
        }

        // ==========================================
        // 3. BURIAL SERVICES LIST WITH SERVICE TIMINGS & REMINDERS
        // ==========================================
        items(filteredSchedules) { schedule ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("burial_card_${schedule.id}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header: Deceased Name, Case Reference & Roster Synced Badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = schedule.deceasedName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Navy900
                            )
                            Text(
                                text = "Case #${schedule.caseReference} • ${schedule.burialDate}",
                                fontSize = 11.sp,
                                color = RoyalCobaltBlue,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = EmeraldLight
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Roster Synced", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Key Details: Casket, Church, Gravesite, Hearse
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Inventory2, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Casket: ${schedule.casketModel}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Hearse: ${schedule.assignedHearseReg} • Driver: ${schedule.assignedDriverName}", fontSize = 12.sp, color = Navy900)
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Place, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Church: ${schedule.churchVenue} → Gravesite: ${schedule.gravesiteLocation}", fontSize = 11.sp, color = TextSecondary)
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Family Rep: ${schedule.familyRepresentative}", fontSize = 11.sp, color = TextSecondary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // FAMILY CORTEGE MILESTONE TRACKER & MEMORIAL PROGRAM CARD
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF0FDF4),
                        border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Family Cortege Milestone Tracker",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Navy900
                                )
                                Text(
                                    text = schedule.milestoneUpdatedAt,
                                    fontSize = 9.sp,
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                FamilyCortegeMilestone.values().forEach { ms ->
                                    val isDone = schedule.currentMilestone.stepNumber >= ms.stepNumber
                                    val isCurrent = schedule.currentMilestone == ms
                                    Surface(
                                        onClick = { viewModel.updateCortegeMilestone(schedule.id, ms, notifyFamilySms = false) },
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isCurrent) EmeraldSuccess else if (isDone) EmeraldLight else PureWhite,
                                        border = BorderStroke(1.dp, if (isDone) EmeraldSuccess else BorderLight),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("milestone_${schedule.id}_${ms.name}")
                                    ) {
                                        Text(
                                            text = "${ms.stepNumber}. ${ms.label}",
                                            fontSize = 9.sp,
                                            fontWeight = if (isCurrent) FontWeight.ExtraBold else FontWeight.SemiBold,
                                            color = if (isCurrent) Color.White else if (isDone) EmeraldSuccess else TextSecondary,
                                            lineHeight = 11.sp,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        viewModel.updateCortegeMilestone(
                                            schedule.id,
                                            schedule.currentMilestone,
                                            notifyFamilySms = true
                                        )
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .testTag("btn_share_milestone_sms_${schedule.id}")
                                ) {
                                    Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share SMS Update", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }

                                Button(
                                    onClick = {
                                        runCatching {
                                            val pdf = PdfDocumentGenerator.generateMemorialProgramPdf(context, schedule)
                                            PdfDocumentGenerator.sharePdfFile(
                                                context,
                                                pdf,
                                                "Memorial Program - ${schedule.deceasedName}"
                                            )
                                            viewModel.actionFeedbackMessage.value = "Generated A4 Memorial Program PDF for ${schedule.deceasedName}."
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Navy900),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .testTag("btn_memorial_program_pdf_${schedule.id}")
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Program PDF", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = {
                                    runCatching {
                                        val pdf = PdfDocumentGenerator.generateMemorialProgramPdf(context, schedule)
                                        AndroidPrintHelper.printPdfFile(
                                            context = context,
                                            pdfFile = pdf,
                                            jobName = "Jabima Program ${schedule.caseReference}"
                                        ).getOrThrow()
                                    }.onFailure { err ->
                                        viewModel.actionFeedbackMessage.value = err.localizedMessage ?: "Print service unavailable."
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(40.dp)
                                    .testTag("btn_print_memorial_program_${schedule.id}")
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Print Program (System / Wi-Fi Printer)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // DYNAMIC SERVICE TIMINGS PIPELINE & REMINDER DISPATCH BUTTONS
                    Text("Service Timings & Staff Reminders:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                    Spacer(modifier = Modifier.height(6.dp))

                    schedule.timings.forEach { timing ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (timing.reminderSent) Color(0xFFF0FDF4) else Color(0xFFFFFBEB),
                            border = BorderStroke(1.dp, if (timing.reminderSent) Color(0xFFBBF7D0) else Color(0xFFFDE68A)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = timing.timeFormatted,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp,
                                            color = RoyalCobaltBlue
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = timing.stage.label,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = Navy900
                                        )
                                    }
                                    Text(
                                        text = "Venue: ${timing.venue} • Assigned: ${timing.assignedStaffNames.joinToString(", ")}",
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                    if (timing.reminderSent && timing.lastReminderTime != null) {
                                        Text(
                                            text = "Reminder sent: ${timing.lastReminderTime}",
                                            fontSize = 9.sp,
                                            color = EmeraldSuccess,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        viewModel.sendBurialServiceReminder(schedule.id, timing.stage)
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (timing.reminderSent) Color(0xFFE2E8F0) else RoyalCobaltBlue,
                                        contentColor = if (timing.reminderSent) Navy900 else Color.White
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(30.dp).testTag("btn_send_reminder_${timing.stage.name}")
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (timing.reminderSent) "Resend SMS" else "Send Reminder", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 4. RECENT SERVICE REMINDERS LOG
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth().testTag("service_reminders_log_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Service Reminders Dispatched (${reminderLogs.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Navy900)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    reminderLogs.take(5).forEach { log ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(log.serviceStage, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = RoyalCobaltBlue)
                                    Text(log.timestamp, fontSize = 10.sp, color = TextSecondary)
                                }
                                Text("Recipients: ${log.recipients.joinToString(", ")}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(log.messageText, fontSize = 10.sp, color = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
        } // end selectedSubTab == 0

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // ==========================================
    // DIALOG: SCHEDULE NEW BURIAL SERVICE
    // ==========================================
    if (showNewBurialDialog) {
        var deceasedName by remember { mutableStateOf("") }
        var familyRep by remember { mutableStateOf("") }
        var familyPhone by remember { mutableStateOf("+254 7") }
        var burialDate by remember { mutableStateOf("14 Oct 2026") }
        var churchVenue by remember { mutableStateOf("St. Peters Cathedral, Siaya") }
        var gravesiteLocation by remember { mutableStateOf("Karemo Village, Siaya") }
        var selectedCasket by remember { mutableStateOf(JABIMA_CASKET_TYPES.first()) }
        var selectedHearse by remember { mutableStateOf(JABIMA_FLEET.first()) }
        var selectedDriver by remember { mutableStateOf("Erick Omondi") }

        var casketExpanded by remember { mutableStateOf(false) }
        var hearseExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showNewBurialDialog = false },
            title = {
                Text("Schedule Burial & Sync with Roster", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Creates burial timing milestones and automatically generates shifts in duty roster.", fontSize = 11.sp, color = TextSecondary)

                    OutlinedTextField(
                        value = deceasedName,
                        onValueChange = { deceasedName = it },
                        label = { Text("Deceased Full Name") },
                        placeholder = { Text("e.g. The late Mama Mary Achieng") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = familyRep,
                            onValueChange = { familyRep = it },
                            label = { Text("Family Contact") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = familyPhone,
                            onValueChange = { familyPhone = it },
                            label = { Text("Phone") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = burialDate,
                        onValueChange = { burialDate = it },
                        label = { Text("Burial Date") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    ExposedDropdownMenuBox(
                        expanded = casketExpanded,
                        onExpandedChange = { casketExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedCasket,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Reserved Casket") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = casketExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = casketExpanded,
                            onDismissRequest = { casketExpanded = false }
                        ) {
                            JABIMA_CASKET_TYPES.forEach { ct ->
                                DropdownMenuItem(
                                    text = { Text(ct) },
                                    onClick = {
                                        selectedCasket = ct
                                        casketExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ExposedDropdownMenuBox(
                            expanded = hearseExpanded,
                            onExpandedChange = { hearseExpanded = it },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = selectedHearse,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Hearse") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = hearseExpanded) },
                                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            )
                            ExposedDropdownMenu(
                                expanded = hearseExpanded,
                                onDismissRequest = { hearseExpanded = false }
                            ) {
                                JABIMA_FLEET.forEach { fl ->
                                    DropdownMenuItem(
                                        text = { Text(fl) },
                                        onClick = {
                                            selectedHearse = fl
                                            hearseExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = selectedDriver,
                            onValueChange = { selectedDriver = it },
                            label = { Text("Driver") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = churchVenue,
                        onValueChange = { churchVenue = it },
                        label = { Text("Church / Chapel Venue") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = gravesiteLocation,
                        onValueChange = { gravesiteLocation = it },
                        label = { Text("Gravesite / Homestead") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ref = "REF-2026-" + (100..999).random()
                        val newEvent = BurialScheduleEvent(
                            id = "BUR-2026-" + (100..999).random(),
                            caseReference = ref,
                            deceasedName = if (deceasedName.isNotBlank()) deceasedName else "The late Mzee John Oduor",
                            familyRepresentative = familyRep,
                            familyPhone = familyPhone,
                            burialDate = burialDate,
                            casketModel = "$selectedCasket Casket",
                            churchVenue = churchVenue,
                            gravesiteLocation = gravesiteLocation,
                            assignedHearseReg = selectedHearse,
                            assignedDriverName = selectedDriver,
                            assignedOperators = listOf("Duncan Odhiambo", "Samson Otieno"),
                            assignedDirector = "Fredrick Hayoyo (CEO)",
                            timings = listOf(
                                BurialServiceTiming(FuneralArrangementStage.INTAKE_MORTUARY, "07:30 AM", "Bama Morgue Intake", listOf("DRV-001"), listOf(selectedDriver), selectedHearse, false),
                                BurialServiceTiming(FuneralArrangementStage.FLEET_CORTEGE, "08:45 AM", "Highway Escort to Church", listOf("DRV-001"), listOf(selectedDriver), selectedHearse, false),
                                BurialServiceTiming(FuneralArrangementStage.CHAPEL_VIGIL, "10:30 AM", churchVenue, listOf("OPR-001", "OPR-002"), listOf("Duncan Odhiambo", "Samson Otieno"), null, false),
                                BurialServiceTiming(FuneralArrangementStage.GRAVESITE_LOWERING, "02:00 PM", gravesiteLocation, listOf("OPR-001", "OPR-002", "CEO-001"), listOf("Duncan Odhiambo", "Samson Otieno", "Fredrick Hayoyo"), selectedHearse, false)
                            ),
                            status = "Confirmed & Roster Synced",
                            isRosterSynced = true
                        )
                        viewModel.addBurialSchedule(newEvent)
                        showNewBurialDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Text("Schedule & Sync Roster")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewBurialDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showUploadDocDialog) {
        CaseDocumentUploadDialog(
            burialSchedules = burialSchedules,
            onDismiss = { showUploadDocDialog = false },
            onUpload = { caseRef, deceasedName, docType, title, notes, payload ->
                viewModel.uploadCaseDocument(
                    caseReference = caseRef,
                    deceasedName = deceasedName,
                    documentType = docType,
                    title = title,
                    notes = notes,
                    fileName = payload.fileName,
                    mimeType = payload.mimeType,
                    thumbnailBase64 = payload.thumbnailBase64
                )
                showUploadDocDialog = false
            }
        )
    }
    viewerDocument?.let { doc ->
        CaseDocumentViewerDialog(
            document = doc,
            onDismiss = { viewerDocument = null },
            onFeedback = { msg -> viewModel.actionFeedbackMessage.value = msg }
        )
    }
}

@Composable
private fun CaseDocumentVaultCard(
    document: CaseDocumentRecord,
    canVerifyOrDelete: Boolean,
    onViewDocument: () -> Unit,
    onVerifyToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val previewBitmap = remember(document.thumbnailBase64) {
        CaseDocumentMediaHelper.decodeBase64Bitmap(document.thumbnailBase64)
    }
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, if (document.verifiedByAdmin) EmeraldSuccess.copy(alpha = 0.55f) else BorderLight),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onViewDocument() }
            .testTag("case_document_card_${document.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = RoyalCobaltIce, shape = RoundedCornerShape(4.dp)) {
                            Text(
                                text = document.documentType.label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalCobaltBlue,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            color = if (document.verifiedByAdmin) EmeraldLight else AmberLight,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = if (document.verifiedByAdmin) "Admin Verified ✓" else "Pending Check",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (document.verifiedByAdmin) EmeraldSuccess else Navy900,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = document.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Navy900
                    )
                    Text(
                        text = "Case: ${document.caseReference} • ${document.deceasedName}",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                }
            }

            if (previewBitmap != null) {
                Image(
                    bitmap = previewBitmap.asImageBitmap(),
                    contentDescription = "Preview of ${document.title}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, BorderLight, RoundedCornerShape(10.dp))
                )
            } else {
                Surface(
                    color = Color(0xFFF8FAFC),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(20.dp))
                        Text(
                            text = "${document.fileName.ifBlank { "Document Attachment" }} (${document.mimeType})",
                            fontSize = 11.sp,
                            color = Navy800,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (document.notes.isNotBlank()) {
                Text(
                    text = document.notes,
                    fontSize = 11.5.sp,
                    color = TextSecondary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "By ${document.uploadedByStaffName} • ${document.uploadedAt}",
                    fontSize = 10.sp,
                    color = TextSecondary,
                    modifier = Modifier.weight(1f)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onViewDocument,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(40.dp)
                            .testTag("btn_view_case_document_${document.id}")
                    ) {
                        Icon(Icons.Default.Visibility, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("View", fontSize = 11.sp, color = RoyalCobaltBlue)
                    }
                    if (canVerifyOrDelete) {
                        OutlinedButton(
                            onClick = onVerifyToggle,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(40.dp)
                        ) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (document.verifiedByAdmin) "Unverify" else "Verify", fontSize = 11.sp)
                        }
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete document", tint = StrokeRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CaseDocumentViewerDialog(
    document: CaseDocumentRecord,
    onDismiss: () -> Unit,
    onFeedback: (String) -> Unit
) {
    val context = LocalContext.current
    val previewBitmap = remember(document.thumbnailBase64) {
        CaseDocumentMediaHelper.decodeBase64Bitmap(document.thumbnailBase64)
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.5.dp, RoyalCobaltBlue.copy(alpha = 0.4f)),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("case_document_viewer_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = document.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Navy900
                        )
                        Text(
                            text = "${document.documentType.label} • ${document.caseReference}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = RoyalCobaltBlue
                        )
                    }
                    Surface(
                        color = if (document.verifiedByAdmin) EmeraldLight else AmberLight,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (document.verifiedByAdmin) "Admin Verified" else "Pending Review",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (document.verifiedByAdmin) EmeraldSuccess else Navy900,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                if (previewBitmap != null) {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = "Full view of ${document.title}",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF1F5F9))
                            .border(1.dp, BorderLight, RoundedCornerShape(10.dp))
                    )
                } else {
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(36.dp))
                            Text(
                                text = document.fileName.ifBlank { "Attached Case Document" },
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Navy900
                            )
                            Text(
                                text = "MIME: ${document.mimeType}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                        text = "Deceased: ${document.deceasedName.ifBlank { "N/A" }}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    if (document.notes.isNotBlank()) {
                        Text(
                            text = "Notes: ${document.notes}",
                            fontSize = 11.5.sp,
                            color = TextSecondary
                        )
                    }
                    Text(
                        text = "Uploaded by ${document.uploadedByStaffName} • ${document.uploadedAt}",
                        fontSize = 10.5.sp,
                        color = TextSecondary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (previewBitmap != null) {
                        Button(
                            onClick = {
                                AndroidPrintHelper.saveBitmapToCacheAndShare(
                                    context = context,
                                    bitmap = previewBitmap,
                                    fileNamePrefix = "jabima_${document.caseReference}_${document.id}",
                                    shareTitle = "Share ${document.title} (${document.caseReference})"
                                ).onSuccess {
                                    onFeedback("Exported permit scan for ${document.caseReference}.")
                                }.onFailure { err ->
                                    onFeedback(err.localizedMessage ?: "Unable to share permit image.")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("btn_share_case_document_viewer")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Permit", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_close_case_document_viewer")
                    ) {
                        Text("Close", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CaseDocumentUploadDialog(
    burialSchedules: List<BurialScheduleEvent>,
    onDismiss: () -> Unit,
    onUpload: (
        caseRef: String,
        deceasedName: String,
        docType: CaseDocumentType,
        title: String,
        notes: String,
        payload: PickedCaseMediaPayload
    ) -> Unit
) {
    val context = LocalContext.current
    val firstSchedule = burialSchedules.firstOrNull()
    var caseReference by remember { mutableStateOf(firstSchedule?.caseReference ?: "REF-2026-001") }
    var deceasedName by remember { mutableStateOf(firstSchedule?.deceasedName ?: "") }
    var selectedType by remember { mutableStateOf(CaseDocumentType.BURIAL_PERMIT) }
    var title by remember { mutableStateOf(CaseDocumentType.BURIAL_PERMIT.label) }
    var notes by remember { mutableStateOf("") }
    var docTypeExpanded by remember { mutableStateOf(false) }
    var caseExpanded by remember { mutableStateOf(false) }
    var pickedPayload by remember {
        mutableStateOf(PickedCaseMediaPayload(fileName = "", mimeType = "application/pdf", thumbnailBase64 = ""))
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pickedPayload = CaseDocumentMediaHelper.extractPayloadFromUri(context, uri)
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            pickedPayload = CaseDocumentMediaHelper.extractPayloadFromUri(context, uri)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Upload Case Permit / Paperwork", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (burialSchedules.isNotEmpty()) {
                    ExposedDropdownMenuBox(
                        expanded = caseExpanded,
                        onExpandedChange = { caseExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = "$caseReference • ${deceasedName.ifBlank { "Custom Case" }}",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Burial Case") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = caseExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = caseExpanded,
                            onDismissRequest = { caseExpanded = false }
                        ) {
                            burialSchedules.forEach { sched ->
                                DropdownMenuItem(
                                    text = { Text("${sched.caseReference} • ${sched.deceasedName}", fontSize = 11.5.sp) },
                                    onClick = {
                                        caseReference = sched.caseReference
                                        deceasedName = sched.deceasedName
                                        caseExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = caseReference,
                        onValueChange = { caseReference = it },
                        label = { Text("Case Ref") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = deceasedName,
                        onValueChange = { deceasedName = it },
                        label = { Text("Deceased Name") },
                        singleLine = true,
                        modifier = Modifier.weight(1.3f)
                    )
                }

                ExposedDropdownMenuBox(
                    expanded = docTypeExpanded,
                    onExpandedChange = { docTypeExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedType.label,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Document Category") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = docTypeExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = docTypeExpanded,
                        onDismissRequest = { docTypeExpanded = false }
                    ) {
                        CaseDocumentType.entries.forEach { dt ->
                            DropdownMenuItem(
                                text = { Text(dt.label, fontSize = 12.sp) },
                                onClick = {
                                    selectedType = dt
                                    if (title.isBlank() || CaseDocumentType.entries.any { it.label == title }) {
                                        title = dt.label
                                    }
                                    docTypeExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Document Title / Permit No.") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Issuing Office") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_pick_permit_photo")
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pick Photo", fontSize = 11.sp, maxLines = 1, softWrap = false)
                    }
                    OutlinedButton(
                        onClick = {
                            documentPickerLauncher.launch(arrayOf("application/pdf", "image/*"))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_pick_permit_pdf")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pick PDF", fontSize = 11.sp, maxLines = 1, softWrap = false)
                    }
                }

                if (pickedPayload.fileName.isNotBlank()) {
                    Text(
                        text = "Attached: ${pickedPayload.fileName}${if (pickedPayload.thumbnailBase64.isNotBlank()) " (Compressed preview ready)" else ""}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = EmeraldSuccess
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val safePayload = if (pickedPayload.fileName.isBlank()) {
                        pickedPayload.copy(fileName = "${selectedType.name.lowercase()}_${System.currentTimeMillis() % 10000}.pdf")
                    } else {
                        pickedPayload
                    }
                    onUpload(caseReference, deceasedName, selectedType, title, notes, safePayload)
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                modifier = Modifier.testTag("btn_confirm_upload_case_document")
            ) {
                Text("Save to Cloud Vault")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

