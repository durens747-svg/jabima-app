package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.FuneralArrangementStage
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.TaskPriority
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.Blue100
import com.example.ui.theme.Blue200
import com.example.ui.theme.Blue50
import com.example.ui.theme.Blue700
import com.example.ui.theme.Blue800
import com.example.ui.theme.Blue900
import com.example.ui.theme.Blue950
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PureWhite
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.Navy900

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MenuAnchorType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import com.example.domain.TimelineScheduleHelper
import com.example.model.Department
import com.example.model.TimelineViewMode
import com.example.ui.components.DailyTaskTimelineView
import com.example.ui.components.TaskDetailDialogPane

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivitiesScreen(
    activities: List<StaffActivity>,
    searchQuery: String,
    selectedStatus: ActivityStatus?,
    selectedCategory: ActivityCategory?,
    onSearchChange: (String) -> Unit,
    onStatusSelect: (ActivityStatus?) -> Unit,
    onCategorySelect: (ActivityCategory?) -> Unit,
    onLogActivityClick: () -> Unit,
    onUpdateStatus: (activityId: String, status: ActivityStatus) -> Unit,
    onToggleChecklistItem: ((activityId: String, item: String) -> Unit)? = null,
    onRecordArrangementTask: ((StaffActivity) -> Unit)? = null,
    currentStaffAccount: StaffAccount? = null,
    onOpenRealtimeLogger: (() -> Unit)? = null,
    onOpenKraPortal: (() -> Unit)? = null,
    onOpenAppShareLink: (() -> Unit)? = null,
    isAdminOrCeo: Boolean = false,
    onAutoAssignTask: (ActivityCategory, String, String, String, String, TaskPriority, Double, String) -> Unit = { _, _, _, _, _, _, _, _ -> },
    onAdminAssessAndPrice: (String, Double, Boolean, String) -> Unit = { _, _, _, _ -> },
    onUpdateStatusWithNotes: ((activityId: String, status: ActivityStatus, notes: String?) -> Unit)? = null,
    onDispatchTaskAlert: ((StaffActivity) -> Unit)? = null,
    unreadAlertCount: Int = 0,
    onOpenShiftAlertCenter: (() -> Unit)? = null
) {
    var selectedDateFilter by remember { mutableStateOf<String?>("23 Sep 2026") }
    var selectedStageFilter by remember { mutableStateOf<FuneralArrangementStage?>(null) }
    var selectedPriorityFilter by remember { mutableStateOf<TaskPriority?>(null) }
    var selectedDepartmentFilter by remember { mutableStateOf<Department?>(null) }
    var viewMode by remember { mutableStateOf(TimelineViewMode.TIMELINE) }
    var selectedTaskForPane by remember { mutableStateOf<StaffActivity?>(null) }
    var showTaskDetailModalPane by remember { mutableStateOf(false) }

    var taskForDebrief by remember { mutableStateOf<StaffActivity?>(null) }
    var taskForStatusDialog by remember { mutableStateOf<StaffActivity?>(null) }
    var statusDialogNewStatus by remember { mutableStateOf(ActivityStatus.IN_PROGRESS) }
    var statusDialogNotes by remember { mutableStateOf("") }
    var showAutoAssignDialog by remember { mutableStateOf(false) }
    var taskForAssessPrice by remember { mutableStateOf<StaffActivity?>(null) }

    // Real-time operational metrics
    val inProgressTasks = activities.filter { it.status == ActivityStatus.IN_PROGRESS }
    val inTransitTasks = activities.filter { it.status == ActivityStatus.IN_TRANSIT }
    val scheduledTasks = activities.filter { it.status == ActivityStatus.SCHEDULED }
    val completedTasks = activities.filter { it.status == ActivityStatus.COMPLETED || it.status == ActivityStatus.VERIFIED_BY_ADMIN }
    val totalAllowances = completedTasks.sumOf { it.allowanceEarned }

    // Multi-factor filtering + chronological sorting
    val filteredActivities = remember(
        activities,
        selectedDateFilter,
        selectedStatus,
        selectedCategory,
        selectedStageFilter,
        selectedPriorityFilter,
        selectedDepartmentFilter,
        searchQuery
    ) {
        val filtered = TimelineScheduleHelper.filterActivities(
            activities = activities,
            dateFilter = selectedDateFilter,
            statusFilter = selectedStatus,
            categoryFilter = selectedCategory,
            stageFilter = selectedStageFilter,
            priorityFilter = selectedPriorityFilter,
            departmentFilter = selectedDepartmentFilter,
            searchQuery = searchQuery
        )
        TimelineScheduleHelper.sortActivitiesChronologically(filtered)
    }

    val overlappingIds = remember(filteredActivities) {
        TimelineScheduleHelper.detectOverlappingActivityIds(filteredActivities)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        val isWidePaneScreen = maxWidth >= 720.dp
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .testTag("funeral_arrangement_daily_log"),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(vertical = 14.dp)
        ) {
            // ==========================================
            // 1. DAILY LOG HEADER & OPERATIONAL METRICS
            // ==========================================
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Blue900),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("daily_log_header_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Today,
                                        contentDescription = "Daily Log",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Funeral Arrangement Daily Log",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp
                                    )
                                    Text(
                                        text = "Real-Time Tracking • Auto-Assignment & Admin Pricing",
                                        color = Blue100,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Button(
                                onClick = onLogActivityClick,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Blue900
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_log_activity")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Log Task", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }

                        if (onOpenRealtimeLogger != null || isAdminOrCeo) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (onOpenRealtimeLogger != null) {
                                    Button(
                                        onClick = onOpenRealtimeLogger,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = EmeraldSuccess,
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        modifier = Modifier.weight(1f).testTag("btn_realtime_field_log")
                                    ) {
                                        Icon(Icons.Default.DirectionsCar, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Live Field Log", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    }
                                }
                                if (isAdminOrCeo) {
                                    Button(
                                        onClick = { showAutoAssignDialog = true },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFF59E0B),
                                            contentColor = Navy900
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        modifier = Modifier.weight(1.2f).testTag("btn_activities_auto_assign_alert")
                                    ) {
                                        Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Auto-Assign & Alert", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Real-Time Metrics Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // 🟢 In Progress Metric
                            Surface(
                                color = Color(0xFF064E3B).copy(alpha = 0.6f),
                                border = BorderStroke(1.dp, Color(0xFF10B981)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onStatusSelect(ActivityStatus.IN_PROGRESS) }
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF10B981))
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(
                                            text = "${inProgressTasks.size}",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("In Progress", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA7F3D0))
                                    Text("Active Live", fontSize = 8.sp, color = Color(0xFFD1FAE5))
                                }
                            }

                            // 🚑 In Transit Metric
                            Surface(
                                color = Color(0xFF1E3A8A).copy(alpha = 0.6f),
                                border = BorderStroke(1.dp, Color(0xFF60A5FA)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onStatusSelect(ActivityStatus.IN_TRANSIT) }
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Color(0xFF93C5FD), modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${inTransitTasks.size}",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("In Transit", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFBFDBFE))
                                    Text("Cortege Escort", fontSize = 8.sp, color = Color(0xFFDBEAFE))
                                }
                            }

                            // ⏳ Scheduled Metric
                            Surface(
                                color = Color.White.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onStatusSelect(ActivityStatus.SCHEDULED) }
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Schedule, contentDescription = null, tint = Blue100, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${scheduledTasks.size}",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Scheduled", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Blue100)
                                    Text("Pending Today", fontSize = 8.sp, color = Blue100)
                                }
                            }

                            // ✅ Completed Metric
                            Surface(
                                color = Color(0xFF047857).copy(alpha = 0.4f),
                                border = BorderStroke(1.dp, Color(0xFF34D399)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onStatusSelect(ActivityStatus.COMPLETED) }
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF6EE7B7), modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${completedTasks.size}",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Done", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA7F3D0))
                                    Text("KES ${String.format("%,.0f", totalAllowances)}", fontSize = 8.sp, color = Color(0xFFD1FAE5))
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // QUICK LINKS: KRA PORTAL & APP SHARE LINK
            // ==========================================
            if (onOpenKraPortal != null || onOpenAppShareLink != null) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (onOpenKraPortal != null) {
                            Surface(
                                onClick = onOpenKraPortal,
                                shape = RoundedCornerShape(10.dp),
                                color = com.example.ui.theme.StrokeRedLight,
                                border = BorderStroke(1.dp, com.example.ui.theme.StrokeRedBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_activities_kra_portal")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(com.example.ui.theme.StrokeRed),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.AccountBalance, contentDescription = null, tint = PureWhite, modifier = Modifier.size(13.dp))
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text("KRA iTax & eTIMS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.StrokeRedDark)
                                        Text("Verify ETR & Tax Rates", fontSize = 9.sp, color = com.example.ui.theme.StrokeRed)
                                    }
                                }
                            }
                        }

                        if (onOpenAppShareLink != null) {
                            Surface(
                                onClick = onOpenAppShareLink,
                                shape = RoundedCornerShape(10.dp),
                                color = RoyalCobaltIce,
                                border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_activities_share_app")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(RoyalCobaltBlue),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, tint = PureWhite, modifier = Modifier.size(13.dp))
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text("Share App Link", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                                        Text("Online Web Portal", fontSize = 9.sp, color = Navy900)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // 2. INTERACTIVE DATE SELECTOR STRIP
            // ==========================================
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Blue50),
                    border = BorderStroke(1.dp, Blue100),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Blue800, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Daily Journal Date:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Blue950
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            listOf(
                                "All Dates" to null,
                                "Today (23 Sep)" to "23 Sep 2026",
                                "Yesterday (22 Sep)" to "22 Sep 2026",
                                "21 Sep" to "21 Sep 2026"
                            ).forEach { (label, dateVal) ->
                                val isSelected = selectedDateFilter == dateVal
                                val count = if (dateVal == null) activities.size else activities.count { it.date.contains(dateVal, ignoreCase = true) }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isSelected) Blue800 else PureWhite,
                                    border = BorderStroke(1.dp, if (isSelected) Blue800 else Blue200),
                                    modifier = Modifier
                                        .clickable { selectedDateFilter = dateVal }
                                        .testTag("date_filter_${label.lowercase().replace(" ", "_").replace("(", "").replace(")", "")}")
                                ) {
                                    Text(
                                        text = "$label ($count)",
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) Color.White else Blue900,
                                        maxLines = 1,
                                        softWrap = false,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // 3. SEARCH & REAL-TIME FILTER CONTROLS
            // ==========================================
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Outlined Search Field
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchChange,
                        placeholder = { Text("Search case ref, family, task title, hearse plate, equipment...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Blue800, modifier = Modifier.size(18.dp)) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchChange("") }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear search", tint = Color(0xFF64748B), modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("activity_search_field"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue800,
                            unfocusedBorderColor = Blue200,
                            focusedContainerColor = PureWhite,
                            unfocusedContainerColor = PureWhite
                        )
                    )

                    // Real-Time Status Filter Chips Row
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = selectedStatus == null,
                                onClick = { onStatusSelect(null) },
                                label = { Text("All Statuses (${activities.size})", fontSize = 11.sp, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Blue800,
                                    selectedLabelColor = Color.White,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                )
                            )
                        }

                        items(ActivityStatus.values()) { status ->
                            val count = activities.count { it.status == status }
                            val (badgeBg, badgeFg) = when (status) {
                                ActivityStatus.IN_PROGRESS -> Color(0xFF10B981) to Color.White
                                ActivityStatus.IN_TRANSIT -> Color(0xFF2563EB) to Color.White
                                ActivityStatus.SCHEDULED -> Blue700 to Color.White
                                ActivityStatus.ON_HOLD -> Color(0xFFD97706) to Color.White
                                ActivityStatus.COMPLETED -> Color(0xFF059669) to Color.White
                                ActivityStatus.VERIFIED_BY_ADMIN -> Color(0xFF7C3AED) to Color.White
                            }

                            FilterChip(
                                selected = selectedStatus == status,
                                onClick = { onStatusSelect(if (selectedStatus == status) null else status) },
                                label = { Text("${status.label} ($count)", fontSize = 11.sp, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = badgeBg,
                                    selectedLabelColor = badgeFg,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                )
                            )
                        }
                    }

                    // Funeral Arrangement Stage Filter Chips Row
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = selectedStageFilter == null,
                                onClick = { selectedStageFilter = null },
                                label = { Text("All Arrangement Stages", fontSize = 11.sp, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Blue800,
                                    selectedLabelColor = Color.White,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                )
                            )
                        }

                        items(FuneralArrangementStage.values()) { stg ->
                            val count = activities.count { it.arrangementStage == stg }
                            FilterChip(
                                selected = selectedStageFilter == stg,
                                onClick = { selectedStageFilter = if (selectedStageFilter == stg) null else stg },
                                label = { Text("${stg.label} ($count)", fontSize = 11.sp, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Blue800,
                                    selectedLabelColor = Color.White,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                )
                            )
                        }
                    }

                    // Priority & Department Multi-Filter Row + View Mode Switcher + Shift Alert Trigger
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Timeline vs Card List Toggle
                        TimelineViewMode.values().forEach { mode ->
                            val isModeSelected = viewMode == mode
                            FilterChip(
                                selected = isModeSelected,
                                onClick = { viewMode = mode },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (mode == TimelineViewMode.TIMELINE) Icons.Default.Timeline else Icons.Default.ViewAgenda,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                },
                                label = { Text(mode.label, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Navy900,
                                    selectedLabelColor = Color.White,
                                    selectedLeadingIconColor = Color.White,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                ),
                                modifier = Modifier.testTag("view_mode_${mode.name.lowercase()}")
                            )
                        }

                        if (onOpenShiftAlertCenter != null) {
                            FilterChip(
                                selected = unreadAlertCount > 0,
                                onClick = onOpenShiftAlertCenter,
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.NotificationsActive,
                                        contentDescription = "Open Shift Alert System",
                                        modifier = Modifier.size(14.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = if (unreadAlertCount > 0) "Shift Alerts ($unreadAlertCount)" else "Shift Alerts",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AmberLight,
                                    selectedLabelColor = Navy900,
                                    selectedLeadingIconColor = AmberWarning,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                ),
                                modifier = Modifier.testTag("btn_activities_shift_alerts")
                            )
                        }

                        // Priority Chips
                        TaskPriority.values().forEach { prio ->
                            val isSelected = selectedPriorityFilter == prio
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedPriorityFilter = if (isSelected) null else prio },
                                label = { Text(prio.label, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(prio.colorHex),
                                    selectedLabelColor = Color.White,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                ),
                                modifier = Modifier.testTag("priority_filter_${prio.name.lowercase()}")
                            )
                        }

                        // Department Chips
                        listOf(
                            Department.DRIVERS,
                            Department.OPERATORS,
                            Department.WORKSHOP,
                            Department.SALES_MARKETING
                        ).forEach { dept ->
                            val isSelected = selectedDepartmentFilter == dept
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedDepartmentFilter = if (isSelected) null else dept },
                                label = { Text(dept.displayName, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Blue700,
                                    selectedLabelColor = Color.White,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                ),
                                modifier = Modifier.testTag("dept_filter_${dept.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // ==========================================
            // 4. FUNERAL ARRANGEMENT TASKS LIST
            // ==========================================
            if (filteredActivities.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Blue50),
                        border = BorderStroke(1.dp, Blue100),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = Blue800, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No Funeral Arrangement Tasks Found",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Blue950
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Try clearing the search query, changing status, or selecting 'All Dates'.",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    selectedDateFilter = null
                                    onStatusSelect(null)
                                    onCategorySelect(null)
                                    selectedStageFilter = null
                                    selectedPriorityFilter = null
                                    selectedDepartmentFilter = null
                                    onSearchChange("")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("btn_reset_activity_filters")
                            ) {
                                Text("Reset All Filters", fontSize = 11.sp)
                            }
                        }
                    }
                }
            } else if (viewMode == TimelineViewMode.TIMELINE) {
                item {
                    DailyTaskTimelineView(
                        chronologicalTasks = filteredActivities,
                        overlappingTaskIds = overlappingIds,
                        selectedTaskForPane = selectedTaskForPane,
                        isAdminOrCeo = isAdminOrCeo,
                        onSelectTaskForPane = { act ->
                            selectedTaskForPane = act
                            if (!isWidePaneScreen) {
                                showTaskDetailModalPane = true
                            }
                        },
                        onQuickStatusUpdate = { id, status -> onUpdateStatus(id, status) },
                        onUpdateStatusWithNotes = { id, status, notes ->
                            if (onUpdateStatusWithNotes != null) {
                                onUpdateStatusWithNotes(id, status, notes)
                            } else {
                                onUpdateStatus(id, status)
                            }
                        },
                        onToggleChecklistItem = { id, item ->
                            onToggleChecklistItem?.invoke(id, item)
                        },
                        onDispatchTaskAlert = { act ->
                            onDispatchTaskAlert?.invoke(act)
                        },
                        onOpenStatusDialog = { act ->
                            taskForStatusDialog = act
                            statusDialogNewStatus = act.status
                            statusDialogNotes = ""
                        },
                        onOpenAssessPrice = { act ->
                            taskForAssessPrice = act
                        }
                    )
                }
            } else {
                items(filteredActivities, key = { it.id }) { activity ->
                    FuneralTaskCard(
                        activity = activity,
                        isAdminOrCeo = isAdminOrCeo,
                        onUpdateStatus = { newStatus -> onUpdateStatus(activity.id, newStatus) },
                        onToggleChecklist = { item ->
                            if (onToggleChecklistItem != null) {
                                onToggleChecklistItem(activity.id, item)
                            }
                        },
                        onOpenDebrief = {
                            selectedTaskForPane = activity
                            showTaskDetailModalPane = true
                        },
                        onOpenStatusDialog = {
                            taskForStatusDialog = activity
                            statusDialogNewStatus = activity.status
                            statusDialogNotes = ""
                        },
                        onOpenAssessPrice = { taskForAssessPrice = activity }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Floating Action Button to Log Task
        FloatingActionButton(
            onClick = onLogActivityClick,
            containerColor = Blue800,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 24.dp, end = 20.dp)
                .testTag("log_activity_fab")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Add, contentDescription = "Log Task")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Log Task", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Task Debrief Modal Dialog
    if (taskForDebrief != null) {
        val task = taskForDebrief!!
        AlertDialog(
            onDismissRequest = { taskForDebrief = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TaskAlt, contentDescription = null, tint = Blue800)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Funeral Task Debrief & Record", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Blue900)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        color = Blue50,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(task.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Blue950)
                            Text("Case: ${task.caseReference} • ${task.clientFamily}", fontSize = 11.sp, color = Blue700, fontWeight = FontWeight.SemiBold)
                            Text("Personnel: ${task.staffName} (${task.department.displayName})", fontSize = 11.sp, color = Blue900)
                        }
                    }

                    Text("• Stage: ${task.arrangementStage.label}", fontSize = 11.sp, color = Color(0xFF334155))
                    Text("• Status: ${task.status.label}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    Text("• Date & Time: ${task.date}, ${task.time} (${task.durationMinutes} min)", fontSize = 11.sp, color = Color(0xFF334155))
                    if (task.assignedVehicle != null) {
                        Text("• Assigned Hearse: ${task.assignedVehicle}", fontSize = 11.sp, color = Color(0xFF334155))
                    }
                    if (task.assignedEquipment != null) {
                        Text("• Equipment: ${task.assignedEquipment}", fontSize = 11.sp, color = Color(0xFF334155))
                    }
                    Text("• Allowance Earned: KES ${String.format("%,.0f", task.allowanceEarned)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF059669))
                    if (task.notes.isNotBlank()) {
                        HorizontalDivider(color = Color(0xFFE2E8F0))
                        Text("Operational Notes:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                        Text(task.notes, fontSize = 11.sp, color = Color(0xFF334155))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { taskForDebrief = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Close")
                }
            },
            containerColor = PureWhite,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Real-Time Status Update Modal Dialog
    if (taskForStatusDialog != null) {
        val task = taskForStatusDialog!!
        AlertDialog(
            onDismissRequest = { taskForStatusDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = Blue800)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Update Real-Time Activity Status", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Blue900)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        color = Blue50,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(task.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Blue950)
                            Text("Case: ${task.caseReference} • ${task.clientFamily}", fontSize = 11.sp, color = Blue800, fontWeight = FontWeight.SemiBold)
                            Text("Personnel: ${task.staffName} (${task.department.displayName})", fontSize = 10.sp, color = Color(0xFF475569))
                            Text("Current Status: ${task.status.label}", fontSize = 11.sp, color = Blue900, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text("Select New Real-Time Status:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        ActivityStatus.values().forEach { st ->
                            val isSelected = statusDialogNewStatus == st
                            val (badgeBg, badgeFg) = when (st) {
                                ActivityStatus.IN_PROGRESS -> Color(0xFF10B981) to Color.White
                                ActivityStatus.IN_TRANSIT -> Color(0xFF2563EB) to Color.White
                                ActivityStatus.SCHEDULED -> Blue700 to Color.White
                                ActivityStatus.ON_HOLD -> Color(0xFFD97706) to Color.White
                                ActivityStatus.COMPLETED -> Color(0xFF059669) to Color.White
                                ActivityStatus.VERIFIED_BY_ADMIN -> Color(0xFF7C3AED) to Color.White
                            }
                            Surface(
                                color = if (isSelected) badgeBg else Color(0xFFF8FAFC),
                                border = BorderStroke(1.dp, if (isSelected) badgeBg else Color(0xFFCBD5E1)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { statusDialogNewStatus = st }
                                    .testTag("status_option_${st.name.lowercase()}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.Schedule,
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else Color(0xFF64748B),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = st.label,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 12.sp,
                                        color = if (isSelected) Color.White else Color(0xFF1E293B)
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = statusDialogNotes,
                        onValueChange = { statusDialogNotes = it },
                        label = { Text("Progress / Debrief Notes", fontSize = 11.sp) },
                        placeholder = { Text("e.g. Arrived at Cathedral, church bier positioned at altar", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue800,
                            unfocusedBorderColor = Blue200
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cleanedNote = statusDialogNotes.ifBlank { null }
                        if (onUpdateStatusWithNotes != null) {
                            onUpdateStatusWithNotes(task.id, statusDialogNewStatus, cleanedNote)
                        } else {
                            onUpdateStatus(task.id, statusDialogNewStatus)
                        }
                        taskForStatusDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_confirm_status_update")
                ) {
                    Text("Save Status Update")
                }
            },
            dismissButton = {
                TextButton(onClick = { taskForStatusDialog = null }) {
                    Text("Cancel", color = Color(0xFF64748B))
                }
            },
            containerColor = PureWhite,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Auto-Assign & Alert Staff Dialog (Admin / CEO)
    if (showAutoAssignDialog) {
        var selectedCategory by remember { mutableStateOf(ActivityCategory.GRAVESITE_SETUP) }
        var catExpanded by remember { mutableStateOf(false) }
        var titleInput by remember { mutableStateOf("") }
        var caseRefInput by remember { mutableStateOf("CASE-2026-" + (100..999).random()) }
        var familyInput by remember { mutableStateOf("") }
        var locationInput by remember { mutableStateOf("Bama Branch / Field Site") }
        var selectedPriority by remember { mutableStateOf(TaskPriority.HIGH) }
        var paymentPriceInput by remember { mutableStateOf("2500") }
        var notesInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAutoAssignDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = Color(0xFFD97706))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Auto-Assign Task & Alert Staff", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Blue900)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "System automatically selects the matching active role & department staff member, dispatches an instant alert, and locks in the payment price.",
                        fontSize = 11.sp,
                        color = Color(0xFF475569)
                    )

                    ExposedDropdownMenuBox(
                        expanded = catExpanded,
                        onExpandedChange = { catExpanded = !catExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedCategory.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Task Role / Category", fontSize = 11.sp) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = catExpanded,
                            onDismissRequest = { catExpanded = false }
                        ) {
                            ActivityCategory.values().forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.label, fontSize = 12.sp) },
                                    onClick = {
                                        selectedCategory = cat
                                        catExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Task Title*", fontSize = 11.sp) },
                        placeholder = { Text("e.g. Gravesite Lowering Gear Setup", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("auto_assign_title_input")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = caseRefInput,
                            onValueChange = { caseRefInput = it },
                            label = { Text("Case Ref", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = paymentPriceInput,
                            onValueChange = { paymentPriceInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Pay Price (KES)*", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("auto_assign_price_input")
                        )
                    }

                    OutlinedTextField(
                        value = familyInput,
                        onValueChange = { familyInput = it },
                        label = { Text("Client / Family Name", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = locationInput,
                        onValueChange = { locationInput = it },
                        label = { Text("Duty Location", fontSize = 11.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Priority Level:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    ) {
                        TaskPriority.values().forEach { prio ->
                            FilterChip(
                                selected = selectedPriority == prio,
                                onClick = { selectedPriority = prio },
                                label = {
                                    Text(
                                        text = prio.label,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("Assignment Instructions", fontSize = 11.sp) },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val price = paymentPriceInput.toDoubleOrNull() ?: 1500.0
                        onAutoAssignTask(
                            selectedCategory,
                            titleInput.ifBlank { "${selectedCategory.label} Assignment" },
                            caseRefInput.ifBlank { "CASE-2026-GEN" },
                            familyInput.ifBlank { "Jabima Client Family" },
                            locationInput.ifBlank { "Bama Branch" },
                            selectedPriority,
                            price,
                            notesInput
                        )
                        showAutoAssignDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_confirm_auto_assign_task")
                ) {
                    Text("Assign & Send Alert", fontSize = 12.sp, maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAutoAssignDialog = false }) {
                    Text("Cancel", color = Color(0xFF64748B))
                }
            },
            containerColor = PureWhite,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Admin Assess & Assign Payment Price Dialog
    taskForAssessPrice?.let { task ->
        var priceText by remember(task.id) { mutableStateOf(task.allowanceEarned.toLong().toString()) }
        var approveAndCredit by remember(task.id) { mutableStateOf(true) }
        var assessmentNotes by remember(task.id) { mutableStateOf("Admin verified work completion & payment tariff.") }

        AlertDialog(
            onDismissRequest = { taskForAssessPrice = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AttachMoney, contentDescription = null, tint = EmeraldSuccess)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Assess Work & Assign Payment Price", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Blue900)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        color = Blue50,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(task.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Blue950)
                            Text("Staff: ${task.staffName} • ${task.department.displayName}", fontSize = 11.sp, color = Blue800, fontWeight = FontWeight.SemiBold)
                            Text("Case: ${task.caseReference} • Current Pay: KES ${String.format("%,.0f", task.allowanceEarned)}", fontSize = 10.sp, color = Color(0xFF475569))
                        }
                    }

                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Assessed Payment Price (KES)*", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("assess_payment_price_input")
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { approveAndCredit = !approveAndCredit }
                    ) {
                        Checkbox(
                            checked = approveAndCredit,
                            onCheckedChange = { approveAndCredit = it },
                            colors = CheckboxDefaults.colors(checkedColor = EmeraldSuccess)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Approve & Credit Wallet Immediately",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Blue950
                        )
                    }

                    OutlinedTextField(
                        value = assessmentNotes,
                        onValueChange = { assessmentNotes = it },
                        label = { Text("Admin Assessment Notes", fontSize = 11.sp) },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalPrice = priceText.toDoubleOrNull() ?: task.allowanceEarned
                        onAdminAssessAndPrice(task.id, finalPrice, approveAndCredit, assessmentNotes)
                        taskForAssessPrice = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_confirm_assess_payment")
                ) {
                    Text("Save Payment Price", fontSize = 12.sp, maxLines = 1, softWrap = false)
                }
            },
            dismissButton = {
                TextButton(onClick = { taskForAssessPrice = null }) {
                    Text("Cancel", color = Color(0xFF64748B))
                }
            },
            containerColor = PureWhite,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Interactive Task Detail & Status Dialog Pane (Phone / On-Demand Modal)
    val livePaneActivity = selectedTaskForPane?.let { current ->
        activities.firstOrNull { it.id == current.id } ?: current
    }
    if (showTaskDetailModalPane && livePaneActivity != null) {
        TaskDetailDialogPane(
            activity = livePaneActivity,
            isAdminOrCeo = isAdminOrCeo,
            onDismiss = { showTaskDetailModalPane = false },
            onUpdateStatus = { id, status, notes ->
                if (onUpdateStatusWithNotes != null) {
                    onUpdateStatusWithNotes(id, status, notes)
                } else {
                    onUpdateStatus(id, status)
                }
            },
            onToggleChecklistItem = { id, item ->
                onToggleChecklistItem?.invoke(id, item)
            },
            onDispatchTaskAlert = { act ->
                onDispatchTaskAlert?.invoke(act)
            },
            onOpenAssessPrice = { act ->
                showTaskDetailModalPane = false
                taskForAssessPrice = act
            }
        )
    }
}

// ==========================================
// FUNERAL ARRANGEMENT TASK CARD
// ==========================================
@Composable
fun FuneralTaskCard(
    activity: StaffActivity,
    isAdminOrCeo: Boolean = false,
    onUpdateStatus: (ActivityStatus) -> Unit,
    onToggleChecklist: (String) -> Unit,
    onOpenDebrief: () -> Unit,
    onOpenStatusDialog: () -> Unit = {},
    onOpenAssessPrice: () -> Unit = {}
) {
    // Dynamic styling based on real-time activity status
    val (statusBorderColor, statusBg, statusFg) = when (activity.status) {
        ActivityStatus.IN_PROGRESS -> Triple(Color(0xFF10B981).copy(alpha = 0.6f), Color(0xFFECFDF5), Color(0xFF047857))
        ActivityStatus.IN_TRANSIT -> Triple(Color(0xFF3B82F6).copy(alpha = 0.5f), Color(0xFFEFF6FF), Color(0xFF1D4ED8))
        ActivityStatus.SCHEDULED -> Triple(Blue200, Blue50, Blue900)
        ActivityStatus.ON_HOLD -> Triple(Color(0xFFF59E0B).copy(alpha = 0.6f), Color(0xFFFFFBEB), Color(0xFFB45309))
        ActivityStatus.COMPLETED -> Triple(Color(0xFF10B981).copy(alpha = 0.4f), Color(0xFFF0FDF4), Color(0xFF065F46))
        ActivityStatus.VERIFIED_BY_ADMIN -> Triple(Color(0xFF8B5CF6).copy(alpha = 0.5f), Color(0xFFF5F3FF), Color(0xFF6D28D9))
    }

    val (stageBg, stageFg) = when (activity.arrangementStage) {
        FuneralArrangementStage.INTAKE_MORTUARY -> Color(0xFFF3E8FF) to Color(0xFF6B21A8)
        FuneralArrangementStage.FAMILY_PLANNING -> Color(0xFFEFF6FF) to Color(0xFF1E40AF)
        FuneralArrangementStage.CASKET_FLORALS -> Color(0xFFFEF3C7) to Color(0xFF92400E)
        FuneralArrangementStage.FLEET_CORTEGE -> Color(0xFFDBEAFE) to Color(0xFF1E3A8A)
        FuneralArrangementStage.CHAPEL_VIGIL -> Color(0xFFE0E7FF) to Color(0xFF3730A3)
        FuneralArrangementStage.GRAVESITE_LOWERING -> Color(0xFFDCFCE7) to Color(0xFF166534)
        FuneralArrangementStage.DEBRIEF_COMPLETION -> Color(0xFFF1F5F9) to Color(0xFF334155)
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, statusBorderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("task_card_${activity.id}")
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            // Header Row: Stage Chip, Priority Badge & Real-Time Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Arrangement Stage Chip
                Surface(
                    color = stageBg,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = activity.arrangementStage.label,
                        color = stageFg,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                // Status & Priority
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Priority Pill
                    if (activity.priority != TaskPriority.NORMAL) {
                        Surface(
                            color = Color(activity.priority.colorHex).copy(alpha = 0.12f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, Color(activity.priority.colorHex).copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = activity.priority.label,
                                color = Color(activity.priority.colorHex),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    // Real-Time Status Pill
                    Surface(
                        color = statusBg,
                        border = BorderStroke(1.dp, statusFg.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (activity.status == ActivityStatus.IN_PROGRESS) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF10B981))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            Text(
                                text = activity.status.label,
                                color = statusFg,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Task Title
            Text(
                text = activity.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Blue950
            )

            // Case Reference & Client Family
            Text(
                text = "${activity.caseReference} • ${activity.clientFamily}",
                fontSize = 12.sp,
                color = Blue800,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Location & Date/Time Row
            Surface(
                color = Blue50,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Blue100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = activity.location, fontSize = 11.sp, color = Blue950, fontWeight = FontWeight.Medium)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${activity.date}, ${activity.time} (${activity.durationMinutes} min)",
                                fontSize = 10.sp,
                                color = Color(0xFF475569)
                            )
                        }

                        Text(
                            text = "+ KES ${String.format("%,.0f", activity.allowanceEarned)}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            color = Color(0xFF059669)
                        )
                    }
                }
            }

            // Hearse assignment chip if assigned
            if (activity.assignedVehicle != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = Color(0xFFEFF6FF),
                    border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Assigned Cortege Hearse: ${activity.assignedVehicle}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Blue900
                        )
                    }
                }
            }

            // Equipment assigned chip if assigned
            if (activity.assignedEquipment != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = Color(0xFF0369A1), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Equipment: ${activity.assignedEquipment}",
                        fontSize = 10.sp,
                        color = Color(0xFF0369A1),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Real-Time Progress / Elapsed Timer
            if (activity.elapsedMinutesLogged > 0 || activity.status == ActivityStatus.IN_PROGRESS || activity.status == ActivityStatus.IN_TRANSIT) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFECFDF5), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF10B981))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Live Active Duty: ${if (activity.elapsedMinutesLogged > 0) "${activity.elapsedMinutesLogged} mins elapsed" else "Real-time timer running"} • Started at ${activity.time}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF047857)
                    )
                }
            }

            // Interactive Arrangement Checklist Items
            if (activity.checklistItems.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                val completedCount = activity.checklistItems.count { activity.completedChecklistItems.contains(it) }
                val totalCount = activity.checklistItems.size
                val progress = if (totalCount > 0) completedCount.toFloat() / totalCount else 0f

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Arrangement Checklist ($completedCount/$totalCount)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Blue900
                        )
                        Text(
                            text = "${(progress * 100).toInt()}% Done",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (progress == 1f) Color(0xFF059669) else Blue700
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = if (progress == 1f) Color(0xFF059669) else Blue800,
                        trackColor = Color(0xFFE2E8F0)
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    activity.checklistItems.forEach { item ->
                        val isChecked = activity.completedChecklistItems.contains(item)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleChecklist(item) }
                                .padding(vertical = 2.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { onToggleChecklist(item) },
                                modifier = Modifier.size(20.dp),
                                colors = CheckboxDefaults.colors(
                                    checkedColor = Color(0xFF059669),
                                    uncheckedColor = Color(0xFF94A3B8)
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item,
                                fontSize = 11.sp,
                                color = if (isChecked) Color(0xFF94A3B8) else Color(0xFF1E293B),
                                textDecoration = if (isChecked) TextDecoration.LineThrough else TextDecoration.None
                            )
                        }
                    }
                }
            }

            // Task Notes / Operational Protocol
            if (activity.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = activity.notes,
                    fontSize = 11.sp,
                    color = Color(0xFF475569),
                    lineHeight = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 0.8.dp)
            Spacer(modifier = Modifier.height(8.dp))

            // ==========================================
            // REAL-TIME STATUS ACTION BUTTONS
            // ==========================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Actions: View Debrief Record, Status Dialog & Admin Assess/Price
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .horizontalScroll(rememberScrollState())
                ) {
                    OutlinedButton(
                        onClick = onOpenDebrief,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, Blue200),
                        modifier = Modifier.testTag("btn_debrief_${activity.id}")
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Debrief", fontSize = 11.sp, color = Blue900, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                    }

                    OutlinedButton(
                        onClick = onOpenStatusDialog,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, Blue200),
                        modifier = Modifier.testTag("btn_status_${activity.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Status", fontSize = 11.sp, color = Blue900, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                    }

                    if (isAdminOrCeo) {
                        OutlinedButton(
                            onClick = onOpenAssessPrice,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, EmeraldSuccess),
                            modifier = Modifier.testTag("btn_assess_price_${activity.id}")
                        ) {
                            Icon(Icons.Default.AttachMoney, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("Price Pay", fontSize = 11.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }

                // Right Real-Time Status Actions
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    when (activity.status) {
                        ActivityStatus.SCHEDULED -> {
                            Button(
                                onClick = { onUpdateStatus(ActivityStatus.IN_PROGRESS) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.White),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("btn_start_task_${activity.id}")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Start Task", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        ActivityStatus.IN_PROGRESS -> {
                            // If cortege/fleet, allow moving to IN_TRANSIT
                            if (activity.arrangementStage == FuneralArrangementStage.FLEET_CORTEGE || activity.category == ActivityCategory.FLEET_TRANSPORT) {
                                OutlinedButton(
                                    onClick = { onUpdateStatus(ActivityStatus.IN_TRANSIT) },
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    border = BorderStroke(1.dp, Color(0xFF3B82F6))
                                ) {
                                    Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("In Transit", fontSize = 11.sp, color = Color(0xFF1D4ED8), fontWeight = FontWeight.Bold)
                                }
                            } else {
                                OutlinedButton(
                                    onClick = { onUpdateStatus(ActivityStatus.ON_HOLD) },
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    border = BorderStroke(1.dp, Color(0xFFF59E0B))
                                ) {
                                    Icon(Icons.Default.Pause, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Hold", fontSize = 11.sp, color = Color(0xFFB45309), fontWeight = FontWeight.Bold)
                                }
                            }

                            Button(
                                onClick = { onUpdateStatus(ActivityStatus.COMPLETED) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669), contentColor = Color.White),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("btn_complete_task_${activity.id}")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Complete (+KES ${String.format("%,.0f", activity.allowanceEarned)})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        ActivityStatus.IN_TRANSIT -> {
                            Button(
                                onClick = { onUpdateStatus(ActivityStatus.COMPLETED) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669), contentColor = Color.White),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("btn_complete_task_${activity.id}")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Arrived & Complete", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        ActivityStatus.ON_HOLD -> {
                            Button(
                                onClick = { onUpdateStatus(ActivityStatus.IN_PROGRESS) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981), contentColor = Color.White),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Resume Task", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        ActivityStatus.COMPLETED -> {
                            if (!activity.verifiedByAdmin) {
                                OutlinedButton(
                                    onClick = { onUpdateStatus(ActivityStatus.VERIFIED_BY_ADMIN) },
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    border = BorderStroke(1.dp, Color(0xFF8B5CF6))
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Admin Verify", fontSize = 11.sp, color = Color(0xFF6D28D9), fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Surface(
                                    color = Color(0xFFF5F3FF),
                                    shape = RoundedCornerShape(6.dp),
                                    border = BorderStroke(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.3f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(13.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Allowance Paid", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7C3AED))
                                    }
                                }
                            }
                        }

                        ActivityStatus.VERIFIED_BY_ADMIN -> {
                            Surface(
                                color = Color(0xFFF5F3FF),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Verified & Paid", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7C3AED))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
