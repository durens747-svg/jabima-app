package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Church
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CorporateFare
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Work
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import com.example.ui.screens.CostAnalyticsScreen
import com.example.ui.screens.CostingsAndPricingScreen
import com.example.ui.screens.OrderDashboardScreen
import com.example.ui.screens.ManagementStructureScreen
import com.example.ui.screens.BranchesAndFleetScreen
import com.example.ui.screens.BranchStatusBoardsScreen
import com.example.ui.screens.RosterCalendarScreen
import com.example.ui.screens.StockMovementScreen
import com.example.ui.screens.VendorManagementScreen
import com.example.ui.screens.CrmIntegrationsScreen
import com.example.ui.components.EditStaffRoleAndValuesDialog
import com.example.ui.components.AdminPriceEditorDialog
import com.example.ui.components.OfflineSyncQueueDialog
import com.example.ui.components.UploadStockDialog
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.MoveDown
import androidx.compose.material.icons.filled.ViewKanban
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material3.HorizontalDivider
import com.example.model.ActivityStatus
import com.example.ui.components.AdminAuthorizationGate
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedDark
import com.example.ui.theme.StrokeRedLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.ForestGreenDark
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.GoogleCloudAuthHelper
import kotlinx.coroutines.launch
import com.example.model.MainAppTab
import com.example.model.NavTab
import com.example.model.StaffRole
import com.example.ui.components.AdminCreditWalletDialog
import com.example.ui.components.AdminStaffDetailSheet
import com.example.ui.components.BiometricAuthDialog
import com.example.ui.components.ChangePasswordDialog
import com.example.ui.components.ForcedPasswordRotationDialog
import com.example.ui.components.JabimaTopBar
import com.example.ui.components.LogActivityDialog
import com.example.ui.components.RequestPayoutDialog
import com.example.ui.components.TransactionReceiptDialog
import com.example.ui.components.SubmitExpenseClaimDialog
import com.example.ui.components.AwardIncentiveDialog
import com.example.ui.components.RealtimeFuneralLoggingDialog
import com.example.ui.components.KraPortalDialog
import com.example.ui.components.AppShareLinkDialog
import com.example.ui.components.UniversalExcelImportDialog
import com.example.ui.components.SpeedDialActionFab
import com.example.ui.components.ExportExcelManifestDialog
import com.example.ui.components.SpotlightCommandPaletteDialog
import com.example.ui.screens.ActivitiesScreen
import com.example.ui.screens.AdminConsoleScreen
import com.example.ui.screens.KraPortalScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.MemorialsScreen
import com.example.model.Department
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ServicesScreen
import com.example.ui.screens.ThermalPosScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.screens.CasketSelectionScreen
import com.example.ui.screens.OrderAndPaymentScreen
import com.example.ui.screens.SalesServicesScreen
import com.example.ui.screens.AccountsFinanceTab
import com.example.ui.screens.CompanyAssetsTab
import com.example.ui.screens.LeaveManagementTab
import com.example.ui.screens.UnifiedComms3cxTab
import com.example.ui.screens.BulkSmsTab
import com.example.ui.screens.FleetTrackingMapScreen
import com.example.ui.screens.LiveWorkshopScreen
import com.example.ui.screens.InventoryManagementScreen
import com.example.ui.screens.BurialSchedulingScreen
import com.example.ui.screens.DailyReportScreen
import com.example.ui.screens.GeminiCopilotScreen
import com.example.ui.screens.RemoteSurveillanceScreen
import com.example.ai.JabimaGeminiViewModel
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Sms
import com.example.ui.theme.AmberLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.automirrored.filled.EventNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.TextButton
import androidx.compose.ui.text.style.TextOverflow
import com.example.ui.components.BiometricEntryGateScreen
import com.example.ui.theme.AmberWarning

@Composable
fun StaffPortalMainScreen(
    viewModel: StaffPortalViewModel = viewModel()
) {
    val mainAppTab by viewModel.mainAppTab.collectAsState()
    val currentAccount by viewModel.currentAccount.collectAsState()
    val adminImpersonator by viewModel.adminImpersonator.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()

    val allAccounts by viewModel.allAccounts.collectAsState()
    val staffActivities by viewModel.currentStaffActivities.collectAsState()
    val staffTransactions by viewModel.currentStaffTransactions.collectAsState()
    val staffIncentives by viewModel.currentStaffIncentives.collectAsState()
    val allIncentives by viewModel.allIncentives.collectAsState()
    val staffExpenses by viewModel.currentStaffExpenses.collectAsState()
    val allExpenses by viewModel.allExpenses.collectAsState()
    val walletSummary by viewModel.currentWalletSummary.collectAsState()
    val allStaffWalletSummaries by viewModel.allStaffWalletSummaries.collectAsState()

    val allActivities by viewModel.allActivities.collectAsState()
    val allTransactions by viewModel.allTransactions.collectAsState()
    val dashboardKpis by viewModel.dashboardDailyKpis.collectAsState()
    val casketStockByBranch by viewModel.casketStockByBranch.collectAsState()

    val searchQuery by viewModel.activitySearchQuery.collectAsState()
    val selectedStatus by viewModel.activityStatusFilter.collectAsState()
    val selectedCategory by viewModel.activityCategoryFilter.collectAsState()
    val transactionFilter by viewModel.transactionFilter.collectAsState()

    val showLogActivityDialog by viewModel.showLogActivityDialog.collectAsState()
    val showRequestPayoutDialog by viewModel.showRequestPayoutDialog.collectAsState()
    val showSubmitExpenseDialog by viewModel.showSubmitExpenseDialog.collectAsState()
    val showAwardIncentiveDialog by viewModel.showAwardIncentiveDialog.collectAsState()
    val showChangePasswordDialog by viewModel.showChangePasswordDialog.collectAsState()
    val showAdminCreditDialog by viewModel.showAdminCreditDialog.collectAsState()
    val selectedStaffForAdmin by viewModel.selectedStaffForAdmin.collectAsState()
    val selectedTransactionForReceipt by viewModel.selectedTransactionForReceipt.collectAsState()

    val showEditStaffDialog by viewModel.showEditStaffDialog.collectAsState()
    val showPriceEditorDialog by viewModel.showPriceEditorDialog.collectAsState()
    val showUploadStockDialog by viewModel.showUploadStockDialog.collectAsState()
    val showUniversalExcelImportDialog by viewModel.showUniversalExcelImportDialog.collectAsState()
    val selectedExcelImportDataset by viewModel.selectedExcelImportDataset.collectAsState()
    val showExportManifestDialog by viewModel.showExportManifestDialog.collectAsState()
    val showSpotlightSearchDialog by viewModel.showSpotlightSearchDialog.collectAsState()
    val isOutdoorHighContrastMode by viewModel.isOutdoorHighContrastMode.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val autoNightShiftScheduled by viewModel.autoNightShiftScheduled.collectAsState()
    val nightShiftEyeProtection by viewModel.nightShiftEyeProtection.collectAsState()
    val burialSchedules by viewModel.burialSchedules.collectAsState()
    val caskets by viewModel.caskets.collectAsState()
    val salesServices by viewModel.salesServices.collectAsState()
    val priceAuditLog by viewModel.priceUpdateHistory.collectAsState()
    val uploadedStockList by viewModel.uploadedStockItems.collectAsState()
    val workshopItems by viewModel.workshopItems.collectAsState()
    val inventoryMaterials by viewModel.inventoryMaterials.collectAsState()
    val fleetVehicles by viewModel.fleetGpsVehicles.collectAsState()
    val customerOrders by viewModel.customerOrders.collectAsState()
    val branchBoards by viewModel.branchStatusBoards.collectAsState()
    val allStaffAccounts by viewModel.allAccounts.collectAsState()
    val craftsmenList = remember(allStaffAccounts) {
        allStaffAccounts.filter { it.department == Department.WORKSHOP || it.role == StaffRole.WORKSHOP_WORKER }
    }

    val showBiometricDialog by viewModel.showBiometricDialog.collectAsState()
    val biometricTargetStaff by viewModel.biometricTargetStaff.collectAsState()
    val isPortalBiometricLocked by viewModel.isPortalBiometricLocked.collectAsState()

    val staffAlerts by viewModel.staffAlerts.collectAsState()
    val orderPackages by viewModel.orderPackages.collectAsState()
    val orderAddons by viewModel.orderAddons.collectAsState()
    val breakageRecords by viewModel.breakageRecords.collectAsState()
    val operatorWageAllocations by viewModel.operatorWageAllocations.collectAsState()

    val authErrorMessage by viewModel.authErrorMessage.collectAsState()
    val actionFeedbackMessage by viewModel.actionFeedbackMessage.collectAsState()
    val cloudUserEmail by viewModel.cloudUserEmail.collectAsState()
    val cloudUserUid by viewModel.cloudUserUid.collectAsState()
    val cloudAdmins by viewModel.cloudAdmins.collectAsState()
    val cloudSyncState by viewModel.cloudSyncState.collectAsState()
    val cloudAuthContext = LocalContext.current
    val cloudAuthScope = rememberCoroutineScope()
    val isDeviceOnline by viewModel.isDeviceOnline.collectAsState()
    val simulatedOfflineOverride by viewModel.simulatedOfflineOverride.collectAsState()
    val offlineQueue by viewModel.offlineQueue.collectAsState()
    val isSyncingOfflineQueue by viewModel.isSyncingOfflineQueue.collectAsState()
    val showOfflineSyncDialog by viewModel.showOfflineSyncDialog.collectAsState()
    val showShiftAlertCenterDialog by viewModel.showShiftAlertCenterDialog.collectAsState()
    val prefilledAlertStaffId by viewModel.prefilledAlertStaffId.collectAsState()
    val prefilledAlertShiftId by viewModel.prefilledAlertShiftId.collectAsState()
    val shiftSchedules by viewModel.staffShiftSchedules.collectAsState()
    val shiftAttendanceLogs by viewModel.shiftAttendanceLogs.collectAsState()
    val preSelectedOrderCasketName by viewModel.preSelectedOrderCasketName.collectAsState()
    val totalUnreadAlertsCount = remember(staffAlerts) { staffAlerts.count { !it.isRead } }

    val requiresPasswordRotation by viewModel.requiresPasswordRotation.collectAsState()

    val isActuallyAdmin = currentAccount?.role == StaffRole.OPERATIONS_ADMIN ||
            currentAccount?.role == StaffRole.MANAGING_DIRECTOR_CEO ||
            currentAccount?.role == StaffRole.INVENTORY_MANAGER ||
            adminImpersonator != null

    var showRealtimeFuneralLoggingDialog by remember { mutableStateOf(false) }
    var showKraPortalDialog by remember { mutableStateOf(false) }
    var showAppShareLinkDialog by remember { mutableStateOf(false) }
    var showManagerShiftQrDialog by remember { mutableStateOf(false) }
    var isSpeedDialExpanded by remember { mutableStateOf(false) }
    var selectedHubName by remember { mutableStateOf("ALL") }
    var useRoleScope by remember(currentAccount?.id, isActuallyAdmin) { mutableStateOf(!isActuallyAdmin) }

    if (currentAccount != null && !isPortalBiometricLocked) {
        val hasOpenDialog = showRealtimeFuneralLoggingDialog ||
            showKraPortalDialog || showAppShareLinkDialog || showManagerShiftQrDialog ||
            showLogActivityDialog ||
            showRequestPayoutDialog || showSubmitExpenseDialog || showAwardIncentiveDialog ||
            showChangePasswordDialog || showAdminCreditDialog || selectedStaffForAdmin != null ||
            selectedTransactionForReceipt != null || showBiometricDialog ||
            showEditStaffDialog != null || showPriceEditorDialog || showUploadStockDialog ||
            showUniversalExcelImportDialog || showExportManifestDialog || showSpotlightSearchDialog ||
            showOfflineSyncDialog || showShiftAlertCenterDialog || isSpeedDialExpanded

        val canHandleBack = hasOpenDialog || adminImpersonator != null ||
            (mainAppTab == MainAppTab.STAFF_OPERATIONS && currentTab != NavTab.OVERVIEW) ||
            mainAppTab != MainAppTab.STAFF_OPERATIONS

        BackHandler(enabled = canHandleBack) {
            when {
                isSpeedDialExpanded -> isSpeedDialExpanded = false
                showManagerShiftQrDialog -> showManagerShiftQrDialog = false
                showShiftAlertCenterDialog -> viewModel.closeShiftAlertCenter()
                showOfflineSyncDialog -> viewModel.showOfflineSyncDialog.value = false
                showRealtimeFuneralLoggingDialog -> showRealtimeFuneralLoggingDialog = false
                showKraPortalDialog -> showKraPortalDialog = false
                showAppShareLinkDialog -> showAppShareLinkDialog = false
                showSpotlightSearchDialog -> viewModel.showSpotlightSearchDialog.value = false
                showExportManifestDialog -> viewModel.showExportManifestDialog.value = false
                showUniversalExcelImportDialog -> viewModel.showUniversalExcelImportDialog.value = false
                showUploadStockDialog -> viewModel.showUploadStockDialog.value = false
                showPriceEditorDialog -> viewModel.showPriceEditorDialog.value = false
                showEditStaffDialog != null -> viewModel.showEditStaffDialog.value = null
                showBiometricDialog -> viewModel.dismissBiometricDialog()
                selectedTransactionForReceipt != null -> viewModel.selectedTransactionForReceipt.value = null
                selectedStaffForAdmin != null -> viewModel.selectedStaffForAdmin.value = null
                showAdminCreditDialog -> viewModel.showAdminCreditDialog.value = false
                showChangePasswordDialog -> viewModel.showChangePasswordDialog.value = false
                showAwardIncentiveDialog -> viewModel.showAwardIncentiveDialog.value = false
                showSubmitExpenseDialog -> viewModel.showSubmitExpenseDialog.value = false
                showRequestPayoutDialog -> viewModel.showRequestPayoutDialog.value = false
                showLogActivityDialog -> viewModel.showLogActivityDialog.value = false
                adminImpersonator != null -> viewModel.returnToAdminAccount()
                mainAppTab == MainAppTab.STAFF_OPERATIONS && currentTab != NavTab.OVERVIEW -> viewModel.setTab(NavTab.OVERVIEW)
                mainAppTab != MainAppTab.STAFF_OPERATIONS -> viewModel.setMainAppTab(MainAppTab.STAFF_OPERATIONS)
            }
        }
    }

    if (isPortalBiometricLocked || currentAccount == null) {
        BiometricEntryGateScreen(
            allAccounts = allAccounts,
            targetStaff = biometricTargetStaff,
            onSelectTargetStaff = { acc -> viewModel.biometricTargetStaff.value = acc },
            onBiometricUnlocked = { acc ->
                viewModel.biometricTargetStaff.value = acc
                viewModel.onBiometricSuccess()
            },
            onOpenBiometricDialog = { acc -> viewModel.triggerBiometricAuth(acc) },
            cloudUserEmail = cloudUserEmail,
            onCloudSignedIn = { user -> viewModel.onCloudSignedIn(user) },
            passwordAuthContent = { _ ->
                AuthScreen(
                    sampleAccounts = allAccounts,
                    errorMessage = authErrorMessage,
                    onSignIn = { id, pass -> viewModel.signIn(id, pass) },
                    onQuickSignIn = { acc -> viewModel.quickSignIn(acc) },
                    onBiometricSignIn = { acc -> viewModel.triggerBiometricAuth(acc) },
                    cloudUserEmail = cloudUserEmail,
                    onCloudSignedIn = { user -> viewModel.onCloudSignedIn(user) },
                    onRegister = { name, email, phone, role, pass, nid, branch, mpesa ->
                        viewModel.registerStaff(name, email, phone, role, pass, nid, branch, mpesa)
                    }
                )
            }
        )
    } else {
    Scaffold(
        topBar = {
            JabimaTopBar(
                currentAccount = currentAccount,
                adminImpersonator = adminImpersonator,
                onSignOut = { viewModel.signOut() },
                onReturnToAdmin = { viewModel.returnToAdminAccount() },
                onChangePassword = { viewModel.showChangePasswordDialog.value = true },
                onBiometricClick = { viewModel.triggerBiometricAuth(currentAccount) },
                onOpenServices = { viewModel.setMainAppTab(MainAppTab.SERVICES) },
                onOpenMemorials = { viewModel.setMainAppTab(MainAppTab.MEMORIALS) },
                currentMainTab = mainAppTab,
                onOpenKraPortal = { showKraPortalDialog = true },
                onOpenAppShareLink = { showAppShareLinkDialog = true },
                onOpenExcelImport = { viewModel.openExcelImportHub() },
                onOpenSpotlight = { viewModel.openSpotlightSearch() },
                onOpenExcelExport = { viewModel.openExportManifestDialog() },
                isOutdoorMode = isOutdoorHighContrastMode,
                onToggleOutdoorMode = { viewModel.toggleOutdoorHighContrastMode() },
                isDarkMode = isDarkMode,
                onToggleDarkMode = { viewModel.toggleDarkMode() },
                isOnline = isDeviceOnline,
                pendingSyncCount = offlineQueue.count { !it.synced },
                onOpenOfflineQueue = { viewModel.showOfflineSyncDialog.value = true },
                unreadAlertCount = totalUnreadAlertsCount,
                onOpenShiftAlerts = { viewModel.openShiftAlertCenter() },
                onOpenGeminiAi = { viewModel.setMainAppTab(MainAppTab.AI_ASSISTANT) },
                cloudUserEmail = cloudUserEmail,
                cloudSyncState = cloudSyncState,
                onCloudSyncClick = {
                    if (cloudUserEmail == null) {
                        cloudAuthScope.launch {
                            GoogleCloudAuthHelper.launchInteractiveSignIn(cloudAuthContext)
                                .onSuccess { user -> viewModel.onCloudSignedIn(user) }
                                .onFailure { err ->
                                    viewModel.actionFeedbackMessage.value = err.localizedMessage ?: "Google Cloud Sign-In cancelled."
                                }
                        }
                    } else {
                        viewModel.setMainAppTab(MainAppTab.CRM_INTEGRATIONS)
                    }
                }
            )
        },
        floatingActionButton = {
            SpeedDialActionFab(
                isExpanded = isSpeedDialExpanded,
                onToggleExpand = { isSpeedDialExpanded = !isSpeedDialExpanded },
                onOpenExcelImport = { viewModel.openExcelImportHub() },
                onOpenExportManifest = { viewModel.openExportManifestDialog() },
                onOpenPriceEditor = { viewModel.showPriceEditorDialog.value = true },
                onOpenRealtimeLogger = { showRealtimeFuneralLoggingDialog = true },
                onOpenSpotlight = { viewModel.openSpotlightSearch() },
                onOpenGeminiAi = { viewModel.setMainAppTab(MainAppTab.AI_ASSISTANT) }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(if (isOutdoorHighContrastMode && !isDarkMode) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.background)
        ) {
            // TOP HORIZONTAL TAB BAR - Clean, Space-Maximizing, Single-Line Typography
            // Fixes vertical text, maximizes screen width (no 76dp loss), avoids bulky tabs
            Surface(
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                shadowElevation = 1.dp
            ) {
                val mainTabs = listOf(
                    MainAppTab.STAFF_OPERATIONS to ("Staff Portal" to Icons.Default.AdminPanelSettings),
                    MainAppTab.AI_ASSISTANT to ("Gemini AI" to Icons.Default.AutoAwesome),
                    MainAppTab.KRA_PORTAL to ("KRA iTax & eTIMS" to Icons.Default.AccountBalance),
                    MainAppTab.WORKSHOP_PRODUCTION to ("Live Workshop" to Icons.Default.PrecisionManufacturing),
                    MainAppTab.COSTINGS_AND_PRICING to ("Costings & BOM" to Icons.Default.Calculate),
                    MainAppTab.COST_ANALYTICS to ("Cost Analytics" to Icons.AutoMirrored.Filled.TrendingUp),
                    MainAppTab.ADMIN_CONSOLE to ("Admin Console" to Icons.Default.Security),
                    MainAppTab.ORDERS_PAYMENTS to ("Order & Pay" to Icons.Default.CreditCard),
                    MainAppTab.ORDER_DASHBOARD to ("Order Dashboard" to Icons.Default.Analytics),
                    MainAppTab.CASKET_SELECTION to ("Casket Order" to Icons.Default.Inventory2),
                    MainAppTab.THERMAL_POS to ("Thermal POS" to Icons.Default.PointOfSale),
                    MainAppTab.INVENTORY_MANAGEMENT to ("Inventory Tracker" to Icons.Default.Inventory),
                    MainAppTab.STAFF_WALLET to ("Staff Wallet" to Icons.Default.AccountBalanceWallet),
                    MainAppTab.ROSTER_CALENDAR to ("Roster" to Icons.Default.CalendarMonth),
                    MainAppTab.FLEET_TRACKING to ("Fleet GPS" to Icons.Default.GpsFixed),
                    MainAppTab.BURIAL_SCHEDULING to ("Burials" to Icons.Default.EventNote),
                    MainAppTab.DAILY_REPORT to ("Reports" to Icons.AutoMirrored.Filled.Assignment),
                    MainAppTab.DAILY_LOG to ("Daily Log" to Icons.Default.FactCheck),
                    MainAppTab.STOCK_MOVEMENT to ("Stock Move" to Icons.Default.MoveDown),
                    MainAppTab.BRANCH_BOARDS to ("Status Boards" to Icons.Default.ViewKanban),
                    MainAppTab.CRM_INTEGRATIONS to ("CRM & Cloud" to Icons.Default.CloudSync),
                    MainAppTab.COMMUNICATION_3CX to ("3CX Comms" to Icons.Default.PhoneInTalk),
                    MainAppTab.BULK_SMS to ("Bulk SMS" to Icons.Default.Sms),
                    MainAppTab.BRANCHES_FLEET to ("Branches & Fleet" to Icons.Default.DirectionsCar),
                    MainAppTab.REMOTE_SURVEILLANCE to ("Surveillance" to Icons.Default.Videocam),
                    MainAppTab.SALES_SERVICES to ("Sales Services" to Icons.Default.Storefront),
                    MainAppTab.VENDOR_MANAGEMENT to ("Vendors" to Icons.Default.Handshake),
                    MainAppTab.MANAGEMENT_STRUCTURE to ("Org & Roles" to Icons.Default.AccountTree),
                    MainAppTab.MEMORIALS to ("Memorials" to Icons.Default.Church)
                )

                val roleScopedSet = remember(currentAccount?.id, currentAccount?.role, currentAccount?.department) {
                    recommendedTabsForRole(currentAccount?.role, currentAccount?.department)
                }

                val visibleTabs = remember(selectedHubName, useRoleScope, roleScopedSet, mainTabs) {
                    val hubSet: Set<MainAppTab>? = when (selectedHubName) {
                        "OPERATIONS" -> setOf(
                            MainAppTab.STAFF_OPERATIONS, MainAppTab.AI_ASSISTANT,
                            MainAppTab.DAILY_LOG, MainAppTab.ROSTER_CALENDAR,
                            MainAppTab.BURIAL_SCHEDULING, MainAppTab.FLEET_TRACKING, MainAppTab.BRANCHES_FLEET,
                            MainAppTab.BRANCH_BOARDS, MainAppTab.DAILY_REPORT, MainAppTab.MEMORIALS
                        )
                        "WORKSHOP_STORE" -> setOf(
                            MainAppTab.WORKSHOP_PRODUCTION, MainAppTab.COSTINGS_AND_PRICING,
                            MainAppTab.COST_ANALYTICS, MainAppTab.INVENTORY_MANAGEMENT,
                            MainAppTab.STOCK_MOVEMENT, MainAppTab.CASKET_SELECTION, MainAppTab.VENDOR_MANAGEMENT
                        )
                        "FINANCE_WALLET" -> setOf(
                            MainAppTab.ORDERS_PAYMENTS, MainAppTab.ORDER_DASHBOARD,
                            MainAppTab.COSTINGS_AND_PRICING, MainAppTab.COST_ANALYTICS,
                            MainAppTab.THERMAL_POS, MainAppTab.STAFF_WALLET,
                            MainAppTab.SALES_SERVICES, MainAppTab.KRA_PORTAL
                        )
                        "ADMIN_COMMS" -> setOf(
                            MainAppTab.ADMIN_CONSOLE, MainAppTab.MANAGEMENT_STRUCTURE,
                            MainAppTab.COMMUNICATION_3CX, MainAppTab.BULK_SMS,
                            MainAppTab.CRM_INTEGRATIONS, MainAppTab.REMOTE_SURVEILLANCE
                        )
                        else -> if (useRoleScope) roleScopedSet else null
                    }
                    if (hubSet == null) mainTabs else mainTabs.filter { it.first in hubSet }
                }

                val selectedTabIdx = visibleTabs.indexOfFirst { it.first == mainAppTab }.coerceAtLeast(0)

                Column(modifier = Modifier.fillMaxWidth()) {
                    // Role-Scoped & 4-Hub Ergonomic Category Strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("navigation_hub_filter_strip"),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = useRoleScope && selectedHubName == "ALL",
                            onClick = {
                                val nextScope = !useRoleScope
                                useRoleScope = nextScope
                                selectedHubName = "ALL"
                                if (nextScope && mainAppTab !in roleScopedSet) {
                                    viewModel.setMainAppTab(MainAppTab.STAFF_OPERATIONS)
                                }
                            },
                            label = {
                                Text(
                                    text = if (useRoleScope) "My Role (${roleScopedSet.size}) ✓" else "Scope to Role",
                                    fontSize = 11.sp,
                                    fontWeight = if (useRoleScope) FontWeight.Bold else FontWeight.Medium,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            modifier = Modifier
                                .height(30.dp)
                                .testTag("role_scope_toggle_chip")
                        )

                        val hubs = listOf(
                            "ALL" to "All (${mainTabs.size})",
                            "OPERATIONS" to "Operations",
                            "WORKSHOP_STORE" to "Workshop & Store",
                            "FINANCE_WALLET" to "Finance & Wallet",
                            "ADMIN_COMMS" to "Admin & Comms"
                        )
                        hubs.forEach { (hubKey, hubLabel) ->
                            val selected = selectedHubName == hubKey && (hubKey != "ALL" || !useRoleScope)
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    selectedHubName = hubKey
                                    if (hubKey == "ALL") {
                                        useRoleScope = false
                                    }
                                    val firstMatching = when (hubKey) {
                                        "OPERATIONS" -> MainAppTab.STAFF_OPERATIONS
                                        "WORKSHOP_STORE" -> MainAppTab.WORKSHOP_PRODUCTION
                                        "FINANCE_WALLET" -> MainAppTab.ORDERS_PAYMENTS
                                        "ADMIN_COMMS" -> MainAppTab.ADMIN_CONSOLE
                                        else -> null
                                    }
                                    if (firstMatching != null) {
                                        val isCurrentlyVisible = when (hubKey) {
                                            "OPERATIONS" -> mainAppTab in setOf(MainAppTab.STAFF_OPERATIONS, MainAppTab.AI_ASSISTANT, MainAppTab.DAILY_LOG, MainAppTab.ROSTER_CALENDAR, MainAppTab.BURIAL_SCHEDULING, MainAppTab.FLEET_TRACKING, MainAppTab.BRANCHES_FLEET, MainAppTab.BRANCH_BOARDS, MainAppTab.DAILY_REPORT, MainAppTab.MEMORIALS)
                                            "WORKSHOP_STORE" -> mainAppTab in setOf(MainAppTab.WORKSHOP_PRODUCTION, MainAppTab.COSTINGS_AND_PRICING, MainAppTab.COST_ANALYTICS, MainAppTab.INVENTORY_MANAGEMENT, MainAppTab.STOCK_MOVEMENT, MainAppTab.CASKET_SELECTION, MainAppTab.VENDOR_MANAGEMENT)
                                            "FINANCE_WALLET" -> mainAppTab in setOf(MainAppTab.ORDERS_PAYMENTS, MainAppTab.ORDER_DASHBOARD, MainAppTab.COSTINGS_AND_PRICING, MainAppTab.COST_ANALYTICS, MainAppTab.THERMAL_POS, MainAppTab.STAFF_WALLET, MainAppTab.SALES_SERVICES, MainAppTab.KRA_PORTAL)
                                            "ADMIN_COMMS" -> mainAppTab in setOf(MainAppTab.ADMIN_CONSOLE, MainAppTab.MANAGEMENT_STRUCTURE, MainAppTab.COMMUNICATION_3CX, MainAppTab.BULK_SMS, MainAppTab.CRM_INTEGRATIONS, MainAppTab.REMOTE_SURVEILLANCE)
                                            else -> true
                                        }
                                        if (!isCurrentlyVisible) {
                                            viewModel.setMainAppTab(firstMatching)
                                        }
                                    }
                                },
                                label = {
                                    Text(
                                        text = hubLabel,
                                        fontSize = 11.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                },
                                modifier = Modifier
                                    .height(30.dp)
                                    .testTag("hub_chip_${hubKey.lowercase()}")
                            )
                        }
                    }

                ScrollableTabRow(
                    selectedTabIndex = selectedTabIdx,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary,
                    edgePadding = 8.dp,
                    indicator = { tabPositions ->
                        if (selectedTabIdx < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIdx]),
                                color = if (mainAppTab == MainAppTab.ADMIN_CONSOLE) StrokeRed else MaterialTheme.colorScheme.primary,
                                height = 3.dp
                            )
                        }
                    },
                    divider = { HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), thickness = 0.5.dp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("main_navigation_rail")
                        .testTag("main_bottom_navigation")
                        .testTag("left_navigation_rail")
                ) {
                    visibleTabs.forEach { (tab, meta) ->
                        val (title, icon) = meta
                        val isSelected = mainAppTab == tab
                        val activeColor = if (tab == MainAppTab.ADMIN_CONSOLE) StrokeRed else MaterialTheme.colorScheme.primary

                        Tab(
                            selected = isSelected,
                            onClick = { viewModel.setMainAppTab(tab) },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = title,
                                        modifier = Modifier.size(15.dp),
                                        tint = if (isSelected) activeColor else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = title,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) activeColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (tab == MainAppTab.ADMIN_CONSOLE) {
                                        Box(
                                            modifier = Modifier
                                                .background(StrokeRedLight, RoundedCornerShape(3.dp))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "CEO/INV",
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = StrokeRedDark,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .height(44.dp)
                                .testTag(
                                    when (tab) {
                                        MainAppTab.STAFF_OPERATIONS -> "nav_staff_operations"
                                        MainAppTab.ADMIN_CONSOLE -> "nav_admin"
                                        MainAppTab.ORDERS_PAYMENTS -> "nav_orders_payments"
                                        MainAppTab.CASKET_SELECTION -> "nav_casket_order"
                                        MainAppTab.THERMAL_POS -> "nav_thermal_pos"
                                        MainAppTab.STAFF_WALLET -> "nav_staff_wallet"
                                        MainAppTab.CRM_INTEGRATIONS -> "nav_crm_integrations"
                                        MainAppTab.COMMUNICATION_3CX -> "nav_comms_3cx"
                                        MainAppTab.BULK_SMS -> "nav_bulk_sms"
                                        MainAppTab.ROSTER_CALENDAR -> "nav_roster"
                                        MainAppTab.FLEET_TRACKING -> "nav_fleet_tracking"
                                        MainAppTab.WORKSHOP_PRODUCTION -> "nav_workshop"
                                        MainAppTab.COSTINGS_AND_PRICING -> "nav_costings_pricing"
                                        MainAppTab.INVENTORY_MANAGEMENT -> "nav_inventory"
                                        MainAppTab.BURIAL_SCHEDULING -> "nav_burials"
                                        MainAppTab.DAILY_REPORT -> "nav_daily_reports"
                                        MainAppTab.DAILY_LOG -> "nav_daily_log"
                                        MainAppTab.STOCK_MOVEMENT -> "nav_stock_movement"
                                        MainAppTab.BRANCH_BOARDS -> "nav_branch_boards"
                                        MainAppTab.VENDOR_MANAGEMENT -> "nav_vendors"
                                        MainAppTab.BRANCHES_FLEET -> "nav_branches_fleet"
                                        MainAppTab.SALES_SERVICES -> "nav_sales_services"
                                        MainAppTab.MANAGEMENT_STRUCTURE -> "nav_org_roles"
                                        MainAppTab.MEMORIALS -> "nav_memorials"
                                        else -> "nav_tab_${tab.name.lowercase()}"
                                    }
                                )
                        )
                    }
                }
                }
            }

            // MAIN CONTENT AREA (Occupies 100% of the screen width!)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
            ) {
            // FEEDBACK TOAST BAR
            if (actionFeedbackMessage != null) {
                Surface(
                    color = EmeraldLight,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = actionFeedbackMessage ?: "",
                            color = Color(0xFF065F46),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearFeedback() },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = Color(0xFF065F46), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            // UNREAD STAFF ROLE / TASK / PRICING ALERTS BANNER
            val unreadAlerts = currentAccount?.let { acc ->
                staffAlerts.filter { !it.isRead && it.recipientStaffId == acc.id }
            }.orEmpty()
            if (unreadAlerts.isNotEmpty()) {
                val topAlert = unreadAlerts.first()
                Surface(
                    color = AmberLight,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .testTag("staff_unread_alert_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${topAlert.title} (${unreadAlerts.size} unread)",
                                color = Navy900,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = topAlert.message,
                                color = Color(0xFF78350F),
                                fontSize = 11.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        TextButton(
                            onClick = { viewModel.openShiftAlertCenter() },
                            modifier = Modifier.testTag("btn_open_alert_center_banner")
                        ) {
                            Text("Alert Hub", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Navy900, maxLines = 1, softWrap = false)
                        }
                        TextButton(
                            onClick = { viewModel.markStaffAlertRead(topAlert.id) },
                            modifier = Modifier.testTag("btn_mark_alert_read_${topAlert.id}")
                        ) {
                            Text("Mark Read", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Navy900, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }

            when (mainAppTab) {
                MainAppTab.ADMIN_CONSOLE -> {
                    val ceoAccount = allAccounts.firstOrNull { it.role == StaffRole.MANAGING_DIRECTOR_CEO || it.id == "CEO-001" }
                    val inventoryManagerAccount = allAccounts.firstOrNull { it.role == StaffRole.INVENTORY_MANAGER || it.id == "INV-001" }

                    val isAuthorized = viewModel.isAuthorizedForAdminChanges()
                    if (isAuthorized) {
                        val adminUser = adminImpersonator ?: currentAccount ?: ceoAccount ?: allAccounts.first()
                        AdminConsoleScreen(
                            adminAccount = adminUser,
                            staffAccounts = allAccounts,
                            activities = allActivities,
                            transactions = allTransactions,
                            caskets = caskets,
                            inventoryMaterials = inventoryMaterials,
                            workshopItems = workshopItems,
                            fleetVehicles = fleetVehicles,
                            customerOrders = customerOrders,
                            branchBoards = branchBoards,
                            onAccessStaffAccount = { targetStaff -> viewModel.adminAccessStaffAccount(targetStaff) },
                            onInspectStaff = { targetStaff -> viewModel.selectedStaffForAdmin.value = targetStaff },
                            onApprovePayout = { txnId -> viewModel.adminApprovePayout(txnId) },
                            onRejectPayout = { txnId, reason -> viewModel.adminRejectPayout(txnId, reason) },
                            onCreditStaffWallet = { targetStaff ->
                                viewModel.selectedStaffForAdmin.value = targetStaff
                                viewModel.showAdminCreditDialog.value = true
                            },
                            onOpenPriceEditor = { viewModel.showPriceEditorDialog.value = true },
                            onOpenStockUpload = { viewModel.showUploadStockDialog.value = true },
                            onOpenUniversalExcelImport = { dataset -> viewModel.openExcelImportHub(dataset) },
                            onOpenCrmIntegrations = { viewModel.setMainAppTab(MainAppTab.CRM_INTEGRATIONS) },
                            onEditStaffValues = { targetStaff -> viewModel.showEditStaffDialog.value = targetStaff },
                            onAddOrReplaceStaff = { viewModel.addOrReplaceStaffAccount(it) },
                            onDeleteStaff = { viewModel.deleteStaffAccount(it) },
                            onAddOrReplaceCasket = { viewModel.addOrReplaceCasketItem(it) },
                            onDeleteCasket = { viewModel.deleteCasketItem(it) },
                            onAddOrReplaceMaterial = { viewModel.addOrReplaceInventoryMaterial(it) },
                            onDeleteMaterial = { viewModel.deleteInventoryMaterial(it) },
                            onAddOrReplaceWorkshopItem = { viewModel.addOrReplaceWorkshopItem(it) },
                            onDeleteWorkshopItem = { viewModel.deleteWorkshopItem(it) },
                            onAddOrReplaceActivity = { viewModel.addOrReplaceActivity(it) },
                            onDeleteActivity = { viewModel.deleteActivity(it) },
                            onAddOrReplaceFleetVehicle = { viewModel.addOrReplaceFleetVehicle(it) },
                            onDeleteFleetVehicle = { viewModel.deleteFleetVehicle(it) },
                            onAddOrReplaceCustomerOrder = { viewModel.addOrReplaceCustomerOrder(it) },
                            onDeleteCustomerOrder = { viewModel.deleteCustomerOrder(it) },
                            onAddOrReplaceBranch = { viewModel.addOrReplaceBranchStatusBoard(it) },
                            onDeleteBranch = { viewModel.deleteBranchStatusBoard(it) },
                            orderPackages = orderPackages,
                            orderAddons = orderAddons,
                            staffAlerts = staffAlerts,
                            breakageRecords = breakageRecords,
                            operatorWageAllocations = operatorWageAllocations,
                            onAutoAssignTask = { cat, title, caseRef, family, loc, prio, pay, notes ->
                                viewModel.autoAssignAndAlertTask(cat, title, caseRef, family, loc, prio, pay, notes)
                            },
                            onAdminAssessAndPriceActivity = { actId, price, approve, notes ->
                                viewModel.adminAssessAndPriceActivity(actId, price, approve, notes)
                            },
                            onRecordBreakage = { sId, item, desc, cost, deduct ->
                                viewModel.recordAndDeductBreakage(sId, item, desc, cost, deduct)
                            },
                            onExecutePendingBreakage = { bId -> viewModel.executePendingBreakageDeduction(bId) },
                            onAllocateOperatorWage = { sId, tFee, dWage, duty, disburse ->
                                viewModel.allocateOperatorTransportAndWage(sId, tFee, dWage, duty, disburse)
                            },
                            onDisburseOperatorWage = { aId -> viewModel.disburseOperatorWageAllocation(aId) },
                            walletSummaries = allStaffWalletSummaries,
                            onAccessStaffWallet = { targetStaff ->
                                viewModel.adminAccessStaffAccount(targetStaff, initialTab = NavTab.WALLET, stayOnWalletTab = false)
                            },
                            onUpdateActivityStatus = { id, status -> viewModel.updateActivityStatus(id, status) },
                            onDispatchTaskAlert = { act -> viewModel.dispatchShiftAlertForTask(act) },
                            onOpenDailyTimeline = {
                                viewModel.setMainAppTab(MainAppTab.STAFF_OPERATIONS)
                                viewModel.setTab(NavTab.ACTIVITIES)
                            },
                            attendanceLogs = shiftAttendanceLogs,
                            onOpenShiftQrScanner = { showManagerShiftQrDialog = true },
                            cloudUserEmail = cloudUserEmail,
                            cloudUserUid = cloudUserUid,
                            cloudAdmins = cloudAdmins,
                            onAuthorizeCloudBranchAdmin = { uid, email, branch ->
                                viewModel.authorizeCloudBranchAdmin(uid, email, branch)
                            },
                            onRevokeCloudBranchAdmin = { uid ->
                                viewModel.revokeCloudBranchAdmin(uid)
                            },
                            onOpenCloudAuth = {
                                cloudAuthScope.launch {
                                    GoogleCloudAuthHelper.launchInteractiveSignIn(cloudAuthContext)
                                        .onSuccess { user -> viewModel.onCloudSignedIn(user) }
                                        .onFailure { err ->
                                            viewModel.actionFeedbackMessage.value = err.localizedMessage ?: "Google Cloud Sign-In cancelled."
                                        }
                                }
                            }
                        )
                    } else {
                        val activeAcc = currentAccount ?: allAccounts.first()
                        AdminAuthorizationGate(
                            currentAccount = activeAcc,
                            ceoAccount = ceoAccount,
                            inventoryManagerAccount = inventoryManagerAccount,
                            onAuthorize = { authorizedAcc ->
                                viewModel.quickSignIn(authorizedAcc)
                                viewModel.actionFeedbackMessage.value = "Authorized as ${authorizedAcc.fullName} (${authorizedAcc.role.title})"
                            }
                        )
                    }
                }

                MainAppTab.COMMUNICATION_3CX -> {
                    UnifiedComms3cxTab(viewModel = viewModel)
                }

                MainAppTab.BULK_SMS -> {
                    BulkSmsTab(viewModel = viewModel)
                }

                MainAppTab.REMOTE_SURVEILLANCE -> {
                    RemoteSurveillanceScreen(viewModel = viewModel)
                }

                MainAppTab.CASKET_SELECTION -> {
                    CasketSelectionScreen(
                        viewModel = viewModel,
                        onNavigateToCheckout = { _ ->
                            viewModel.setMainAppTab(MainAppTab.ORDERS_PAYMENTS)
                        }
                    )
                }

                MainAppTab.ORDERS_PAYMENTS -> {
                    OrderAndPaymentScreen(
                        viewModel = viewModel,
                        preSelectedCasketName = preSelectedOrderCasketName
                    )
                }

                MainAppTab.SALES_SERVICES, MainAppTab.SERVICES -> {
                    SalesServicesScreen(
                        viewModel = viewModel,
                        onBookServiceCheckout = { _ ->
                            viewModel.setMainAppTab(MainAppTab.ORDERS_PAYMENTS)
                        }
                    )
                }

                MainAppTab.MANAGEMENT_STRUCTURE -> {
                    ManagementStructureScreen(
                        staffList = allAccounts,
                        onSelectStaff = { staff ->
                            if (isActuallyAdmin) {
                                viewModel.adminAccessStaffAccount(staff)
                            }
                        }
                    )
                }

                MainAppTab.BRANCHES_FLEET -> {
                    BranchesAndFleetScreen(
                        onTriggerMpesaPush = { phone, amount ->
                            viewModel.actionFeedbackMessage.value = "M-PESA STK prompt sent to $phone for KES ${String.format("%,.0f", amount)}! Linked to STK # +254793553434"
                        },
                        onOpenFleetTrackingMap = { viewModel.setMainAppTab(MainAppTab.FLEET_TRACKING) }
                    )
                }

                MainAppTab.FLEET_TRACKING -> {
                    FleetTrackingMapScreen(
                        viewModel = viewModel,
                        onNavigateToRoster = { viewModel.setMainAppTab(MainAppTab.ROSTER_CALENDAR) }
                    )
                }

                MainAppTab.MEMORIALS -> {
                    MemorialsScreen(
                        onNavigateToStaffPortal = { viewModel.setMainAppTab(MainAppTab.STAFF_OPERATIONS) }
                    )
                }

                MainAppTab.THERMAL_POS -> {
                    ThermalPosScreen(
                        currentStaffAccount = currentAccount,
                        onNavigateToStaffPortal = { viewModel.setMainAppTab(MainAppTab.STAFF_OPERATIONS) },
                        onReceiptPrintedFeedback = { msg -> viewModel.actionFeedbackMessage.value = msg }
                    )
                }

                MainAppTab.ROSTER_CALENDAR -> {
                    RosterCalendarScreen(
                        viewModel = viewModel,
                        onOpenShiftQrScanner = { showManagerShiftQrDialog = true }
                    )
                }

                MainAppTab.DAILY_LOG -> {
                    ActivitiesScreen(
                        activities = allActivities,
                        searchQuery = searchQuery,
                        selectedStatus = selectedStatus,
                        selectedCategory = selectedCategory,
                        onSearchChange = { viewModel.activitySearchQuery.value = it },
                        onStatusSelect = { viewModel.activityStatusFilter.value = it },
                        onCategorySelect = { viewModel.activityCategoryFilter.value = it },
                        onLogActivityClick = { viewModel.showLogActivityDialog.value = true },
                        onUpdateStatus = { id, status -> viewModel.updateActivityStatus(id, status) },
                        onToggleChecklistItem = { id, item -> viewModel.toggleChecklistItem(id, item) },
                        onRecordArrangementTask = { task -> viewModel.recordFuneralArrangementTask(task) },
                        currentStaffAccount = currentAccount,
                        onOpenRealtimeLogger = { showRealtimeFuneralLoggingDialog = true },
                        onOpenKraPortal = { showKraPortalDialog = true },
                        onOpenAppShareLink = { showAppShareLinkDialog = true },
                        isAdminOrCeo = isActuallyAdmin,
                        onAutoAssignTask = { cat, title, caseRef, family, loc, prio, pay, notes ->
                            viewModel.autoAssignAndAlertTask(cat, title, caseRef, family, loc, prio, pay, notes)
                        },
                        onAdminAssessAndPrice = { actId, price, approve, notes ->
                            viewModel.adminAssessAndPriceActivity(actId, price, approve, notes)
                        },
                        onUpdateStatusWithNotes = { id, status, notes ->
                            viewModel.updateActivityStatus(id, status, notes)
                        },
                        onDispatchTaskAlert = { act ->
                            viewModel.dispatchShiftAlertForTask(act)
                        },
                        unreadAlertCount = totalUnreadAlertsCount,
                        onOpenShiftAlertCenter = { viewModel.openShiftAlertCenter() }
                    )
                }

                MainAppTab.WORKSHOP_PRODUCTION -> {
                    LiveWorkshopScreen(viewModel = viewModel)
                }

                MainAppTab.COSTINGS_AND_PRICING -> {
                    CostingsAndPricingScreen(viewModel = viewModel)
                }

                MainAppTab.COST_ANALYTICS -> {
                    CostAnalyticsScreen(viewModel = viewModel)
                }

                MainAppTab.ORDER_DASHBOARD -> {
                    OrderDashboardScreen(viewModel = viewModel)
                }

                MainAppTab.INVENTORY_MANAGEMENT -> {
                    InventoryManagementScreen(viewModel = viewModel)
                }

                MainAppTab.BURIAL_SCHEDULING -> {
                    BurialSchedulingScreen(viewModel = viewModel)
                }

                MainAppTab.DAILY_REPORT -> {
                    DailyReportScreen(viewModel = viewModel)
                }

                MainAppTab.STOCK_MOVEMENT -> {
                    StockMovementScreen(viewModel = viewModel)
                }

                MainAppTab.BRANCH_BOARDS -> {
                    BranchStatusBoardsScreen(viewModel = viewModel)
                }

                MainAppTab.VENDOR_MANAGEMENT -> {
                    VendorManagementScreen(viewModel = viewModel)
                }

                MainAppTab.STAFF_WALLET -> {
                    val activeAcc = currentAccount ?: allAccounts.firstOrNull { it.id == "CEO-001" } ?: allAccounts.first()
                    val applyStatutoryOnPayslip by viewModel.applyStatutoryOnPayslip.collectAsState()
                    WalletScreen(
                        currentAccount = activeAcc,
                        walletSummary = walletSummary,
                        transactions = staffTransactions,
                        incentives = staffIncentives,
                        expenses = staffExpenses,
                        activeFilter = transactionFilter,
                        onFilterChange = { viewModel.transactionFilter.value = it },
                        onRequestPayout = { viewModel.showRequestPayoutDialog.value = true },
                        onSelectTransaction = { txn -> viewModel.selectedTransactionForReceipt.value = txn },
                        onSubmitExpenseClaim = { viewModel.showSubmitExpenseDialog.value = true },
                        onAwardIncentiveClick = { viewModel.showAwardIncentiveDialog.value = true },
                        onApproveExpense = { expId -> viewModel.approveExpenseClaim(expId) },
                        onRejectExpense = { expId, reason -> viewModel.rejectExpenseClaim(expId, reason) },
                        onApprovePayout = { txnId -> viewModel.adminApprovePayout(txnId) },
                        onRejectPayout = { txnId, reason -> viewModel.adminRejectPayout(txnId, reason) },
                        onExportStatement = { period -> viewModel.exportPaymentStatement(period) },
                        allAccounts = if (isActuallyAdmin) allAccounts else emptyList(),
                        onSelectStaffAccount = { target ->
                            viewModel.adminAccessStaffAccount(target, initialTab = NavTab.WALLET, stayOnWalletTab = true)
                        },
                        onInstantMpesaB2c = { amt, phone, cat, reason ->
                            viewModel.executeInstantMpesaB2cPayout(activeAcc.id, amt, phone, cat, reason)
                        },
                        breakageRecords = breakageRecords,
                        operatorWageAllocations = operatorWageAllocations,
                        isAdminAccess = isActuallyAdmin,
                        isAdminImpersonating = adminImpersonator != null,
                        onReturnToAdmin = { viewModel.returnToAdminAccount() },
                        onRunBatchPayroll = { viewModel.runBatchMonthlyPayroll() },
                        onExportPdfPayslip = { period ->
                            viewModel.actionFeedbackMessage.value = "Generated printable A4 PDF Payslip ($period)."
                        },
                        applyStatutoryDeductions = applyStatutoryOnPayslip,
                        onToggleStatutoryDeductions = { viewModel.toggleStatutoryPayslipMode(it) }
                    )
                }

                MainAppTab.CRM_INTEGRATIONS -> {
                    CrmIntegrationsScreen(viewModel = viewModel)
                }

                MainAppTab.KRA_PORTAL -> {
                    KraPortalScreen(onNavigateTab = { viewModel.setMainAppTab(it) })
                }

                MainAppTab.AI_ASSISTANT -> {
                    val geminiViewModel: JabimaGeminiViewModel = viewModel()
                    GeminiCopilotScreen(
                        portalViewModel = viewModel,
                        geminiViewModel = geminiViewModel,
                        onSendToBulkSms = { _ ->
                            viewModel.setMainAppTab(MainAppTab.BULK_SMS)
                        }
                    )
                }

                MainAppTab.STAFF_OPERATIONS -> {
                    if (currentAccount == null) {
                        // Staff is not signed in: show Staff Operations Portal Auth & Role Quick Switch
                        AuthScreen(
                            sampleAccounts = allAccounts,
                            errorMessage = authErrorMessage,
                            onSignIn = { id, pass -> viewModel.signIn(id, pass) },
                            onQuickSignIn = { acc -> viewModel.quickSignIn(acc) },
                            onBiometricSignIn = { acc -> viewModel.triggerBiometricAuth(acc) },
                            cloudUserEmail = cloudUserEmail,
                            onCloudSignedIn = { user -> viewModel.onCloudSignedIn(user) },
                            onRegister = { name, email, phone, role, pass, nid, branch, mpesa ->
                                viewModel.registerStaff(name, email, phone, role, pass, nid, branch, mpesa)
                            }
                        )
                    } else {
                        val activeAcc = currentAccount!!

                        // ADMIN INDEPENDENT PORTAL BANNER (When Admin accesses a specific staff member's portal)
                        if (adminImpersonator != null) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("admin_impersonation_portal_banner")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Security,
                                            contentDescription = "Admin Independent Portal Access",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = "INDEPENDENT PORTAL: ${activeAcc.fullName}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${activeAcc.role.title} • ${activeAcc.department.displayName} (${activeAcc.id})",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        TextButton(
                                            onClick = { viewModel.setTab(NavTab.WALLET) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("impersonation_banner_wallet_button")
                                        ) {
                                            Text("Wallet", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                        }
                                        Button(
                                            onClick = { viewModel.returnToAdminAccount() },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("return_to_admin_banner_button")
                                        ) {
                                            Text("Exit to Admin", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                        }
                                    }
                                }
                            }
                        }

                        // STAFF OPERATIONS PORTAL SUB-NAVIGATION TABS (Adaptive Theme Surface)
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        ) {
                            val tabs = mutableListOf(
                                NavTab.OVERVIEW to "Overview",
                                NavTab.ACTIVITIES to "Duties",
                                NavTab.WALLET to "Staff Payment Wallet",
                                NavTab.ROSTER to "Roster Shifts",
                                NavTab.ACCOUNTS_FINANCE to "Accounts & Finance",
                                NavTab.COMPANY_ASSETS to "Company Assets",
                                NavTab.LEAVE_MANAGEMENT to "Leave Mgmt",
                                NavTab.COMMUNICATION_3CX to "3CX Comms",
                                NavTab.BULK_SMS to "Bulk SMS",
                                NavTab.CRM_INTEGRATIONS to "CRM & Cloud",
                                NavTab.WORKSHOP_PRODUCTION to "Live Workshop",
                                NavTab.COSTINGS_PRICING to "Costings & BOM",
                                NavTab.INVENTORY_MANAGEMENT to "Inventory Mgmt",
                                NavTab.BURIAL_SCHEDULING to "Burial Schedule",
                                NavTab.DAILY_REPORT to "Daily Reports",
                                NavTab.REMOTE_SURVEILLANCE to "Surveillance"
                            )
                            if (isActuallyAdmin) {
                                tabs.add(NavTab.ADMIN_CONSOLE to "Admin")
                            }
                            tabs.add(NavTab.PROFILE to "Settings & Profile")

                            val selectedIndex = tabs.indexOfFirst { it.first == currentTab }.coerceAtLeast(0)

                            ScrollableTabRow(
                                selectedTabIndex = selectedIndex,
                                containerColor = MaterialTheme.colorScheme.surface,
                                contentColor = MaterialTheme.colorScheme.secondary,
                                edgePadding = 12.dp,
                                indicator = { tabPositions ->
                                    if (selectedIndex < tabPositions.size) {
                                        TabRowDefaults.SecondaryIndicator(
                                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                                            color = MaterialTheme.colorScheme.secondary,
                                            height = 3.dp
                                        )
                                    }
                                }
                            ) {
                                tabs.forEachIndexed { index, (tab, title) ->
                                    val isSelected = currentTab == tab
                                    Tab(
                                        selected = isSelected,
                                        onClick = { viewModel.setTab(tab) },
                                        text = {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                val iconColor = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                                                when (tab) {
                                                    NavTab.OVERVIEW -> Icon(Icons.Default.Dashboard, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.ACTIVITIES -> Icon(Icons.AutoMirrored.Filled.Assignment, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.WALLET -> Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.ROSTER -> Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.ACCOUNTS_FINANCE -> Icon(Icons.Default.AccountBalance, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.COMPANY_ASSETS -> Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.LEAVE_MANAGEMENT -> Icon(Icons.AutoMirrored.Filled.EventNote, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.COMMUNICATION_3CX -> Icon(Icons.Default.PhoneInTalk, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.BULK_SMS -> Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.CRM_INTEGRATIONS -> Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.WORKSHOP_PRODUCTION -> Icon(Icons.Default.PrecisionManufacturing, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.COSTINGS_PRICING -> Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.INVENTORY_MANAGEMENT -> Icon(Icons.Default.Inventory, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.BURIAL_SCHEDULING -> Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.DAILY_REPORT -> Icon(Icons.AutoMirrored.Filled.Assignment, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.ADMIN_CONSOLE -> Icon(Icons.Default.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.REMOTE_SURVEILLANCE -> Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                    NavTab.PROFILE -> Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(14.dp), tint = iconColor)
                                                }
                                                Text(
                                                    text = title,
                                                    fontSize = 12.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    softWrap = false,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        },
                                        modifier = Modifier
                                            .testTag("staff_subtab_${tab.name.lowercase()}")
                                            .testTag(if (tab == NavTab.WALLET) "tab_staff_payment_wallet" else "staff_subtab_other_${tab.name.lowercase()}")
                                    )
                                }
                            }
                        }

                        // SUB-TAB CONTENT
                        when (currentTab) {
                            NavTab.OVERVIEW -> {
                                OverviewScreen(
                                    currentAccount = activeAcc,
                                    walletSummary = walletSummary,
                                    activities = staffActivities,
                                    recentTransactions = staffTransactions,
                                    dailyKpis = dashboardKpis,
                                    casketStockByBranch = casketStockByBranch,
                                    workshopItems = workshopItems,
                                    craftsmenList = craftsmenList,
                                    inventoryMaterials = inventoryMaterials,
                                    onRequestPayout = { viewModel.showRequestPayoutDialog.value = true },
                                    onLogActivity = { viewModel.showLogActivityDialog.value = true },
                                    onNavigateTab = { tab -> viewModel.setTab(tab) },
                                    onOpenLiveWorkshop = { viewModel.setTab(NavTab.WORKSHOP_PRODUCTION) },
                                    onOpenInventory = { viewModel.setTab(NavTab.INVENTORY_MANAGEMENT) },
                                    onOpenBurialScheduler = { viewModel.setTab(NavTab.BURIAL_SCHEDULING) },
                                    onOpenDailyReport = { viewModel.setTab(NavTab.DAILY_REPORT) },
                                    onUpdateActivityStatus = { id, status -> viewModel.updateActivityStatus(id, status) },
                                    onSelectTransaction = { txn -> viewModel.selectedTransactionForReceipt.value = txn },
                                    onToggleChecklistItem = { id, item -> viewModel.toggleChecklistItem(id, item) },
                                    onOpenRealtimeLogger = { showRealtimeFuneralLoggingDialog = true },
                                    onOpenPriceEditor = { viewModel.showPriceEditorDialog.value = true },
                                    onOpenStockUpload = { viewModel.showUploadStockDialog.value = true },
                                    onOpenUniversalExcelImport = { dataset -> viewModel.openExcelImportHub(dataset) },
                                    onOpenExportManifest = { viewModel.openExportManifestDialog() },
                                    burialSchedules = burialSchedules,
                                    fleetVehicles = fleetVehicles,
                                    allActivities = allActivities,
                                    allStaffAccounts = allAccounts,
                                    onDispatchTaskAlert = { act -> viewModel.dispatchShiftAlertForTask(act) },
                                    onOpenOrderDashboard = { viewModel.setMainAppTab(MainAppTab.ORDER_DASHBOARD) },
                                    onOpenCostAnalytics = { viewModel.setMainAppTab(MainAppTab.COST_ANALYTICS) }
                                )
                            }
                            NavTab.ACTIVITIES -> {
                                ActivitiesScreen(
                                    activities = staffActivities,
                                    searchQuery = searchQuery,
                                    selectedStatus = selectedStatus,
                                    selectedCategory = selectedCategory,
                                    onSearchChange = { viewModel.activitySearchQuery.value = it },
                                    onStatusSelect = { viewModel.activityStatusFilter.value = it },
                                    onCategorySelect = { viewModel.activityCategoryFilter.value = it },
                                    onLogActivityClick = { viewModel.showLogActivityDialog.value = true },
                                    onUpdateStatus = { id, status -> viewModel.updateActivityStatus(id, status) },
                                    onToggleChecklistItem = { id, item -> viewModel.toggleChecklistItem(id, item) },
                                    onRecordArrangementTask = { task -> viewModel.recordFuneralArrangementTask(task) },
                                    currentStaffAccount = activeAcc,
                                    onOpenRealtimeLogger = { showRealtimeFuneralLoggingDialog = true },
                                    onOpenKraPortal = { showKraPortalDialog = true },
                                    onOpenAppShareLink = { showAppShareLinkDialog = true },
                                    isAdminOrCeo = isActuallyAdmin,
                                    onAutoAssignTask = { cat, title, caseRef, family, loc, prio, pay, notes ->
                                        viewModel.autoAssignAndAlertTask(cat, title, caseRef, family, loc, prio, pay, notes)
                                    },
                                    onAdminAssessAndPrice = { actId, price, approve, notes ->
                                        viewModel.adminAssessAndPriceActivity(actId, price, approve, notes)
                                    },
                                    onUpdateStatusWithNotes = { id, status, notes ->
                                        viewModel.updateActivityStatus(id, status, notes)
                                    },
                                    onDispatchTaskAlert = { act ->
                                        viewModel.dispatchShiftAlertForTask(act)
                                    },
                                    unreadAlertCount = totalUnreadAlertsCount,
                                    onOpenShiftAlertCenter = { viewModel.openShiftAlertCenter() }
                                )
                            }
                            NavTab.WALLET -> {
                                val applyStatutoryOnPayslip by viewModel.applyStatutoryOnPayslip.collectAsState()
                                WalletScreen(
                                    currentAccount = activeAcc,
                                    walletSummary = walletSummary,
                                    transactions = staffTransactions,
                                    incentives = staffIncentives,
                                    expenses = staffExpenses,
                                    activeFilter = transactionFilter,
                                    onFilterChange = { viewModel.transactionFilter.value = it },
                                    onRequestPayout = { viewModel.showRequestPayoutDialog.value = true },
                                    onSelectTransaction = { txn -> viewModel.selectedTransactionForReceipt.value = txn },
                                    onSubmitExpenseClaim = { viewModel.showSubmitExpenseDialog.value = true },
                                    onAwardIncentiveClick = { viewModel.showAwardIncentiveDialog.value = true },
                                    onApproveExpense = { expId -> viewModel.approveExpenseClaim(expId) },
                                    onRejectExpense = { expId, reason -> viewModel.rejectExpenseClaim(expId, reason) },
                                    onApprovePayout = { txnId -> viewModel.adminApprovePayout(txnId) },
                                    onRejectPayout = { txnId, reason -> viewModel.adminRejectPayout(txnId, reason) },
                                    onExportStatement = { period -> viewModel.exportPaymentStatement(period) },
                                    allAccounts = if (isActuallyAdmin) allAccounts else emptyList(),
                                    onSelectStaffAccount = { target ->
                                        viewModel.adminAccessStaffAccount(target, initialTab = NavTab.WALLET, stayOnWalletTab = false)
                                    },
                                    onInstantMpesaB2c = { amt, phone, cat, reason ->
                                        viewModel.executeInstantMpesaB2cPayout(activeAcc.id, amt, phone, cat, reason)
                                    },
                                    breakageRecords = breakageRecords,
                                    operatorWageAllocations = operatorWageAllocations,
                                    isAdminAccess = isActuallyAdmin,
                                    isAdminImpersonating = adminImpersonator != null,
                                    onReturnToAdmin = { viewModel.returnToAdminAccount() },
                                    onRunBatchPayroll = { viewModel.runBatchMonthlyPayroll() },
                                    onExportPdfPayslip = { period ->
                                        viewModel.actionFeedbackMessage.value = "Generated printable A4 PDF Payslip ($period)."
                                    },
                                    applyStatutoryDeductions = applyStatutoryOnPayslip,
                                    onToggleStatutoryDeductions = { viewModel.toggleStatutoryPayslipMode(it) }
                                )
                            }
                            NavTab.ROSTER -> {
                                RosterCalendarScreen(
                                    viewModel = viewModel,
                                    onOpenShiftQrScanner = { showManagerShiftQrDialog = true }
                                )
                            }
                            NavTab.ACCOUNTS_FINANCE -> {
                                AccountsFinanceTab(viewModel = viewModel)
                            }
                            NavTab.COMPANY_ASSETS -> {
                                CompanyAssetsTab(viewModel = viewModel)
                            }
                            NavTab.LEAVE_MANAGEMENT -> {
                                LeaveManagementTab(viewModel = viewModel)
                            }
                            NavTab.COMMUNICATION_3CX -> {
                                UnifiedComms3cxTab(viewModel = viewModel)
                            }
                            NavTab.BULK_SMS -> {
                                BulkSmsTab(viewModel = viewModel)
                            }
                            NavTab.CRM_INTEGRATIONS -> {
                                CrmIntegrationsScreen(viewModel = viewModel)
                            }
                            NavTab.ADMIN_CONSOLE -> {
                                val adminUser = adminImpersonator ?: activeAcc
                                AdminConsoleScreen(
                                    adminAccount = adminUser,
                                    staffAccounts = allAccounts,
                                    activities = allActivities,
                                    transactions = allTransactions,
                                    caskets = caskets,
                                    inventoryMaterials = inventoryMaterials,
                                    workshopItems = workshopItems,
                                    fleetVehicles = fleetVehicles,
                                    customerOrders = customerOrders,
                                    branchBoards = branchBoards,
                                    onAccessStaffAccount = { targetStaff -> viewModel.adminAccessStaffAccount(targetStaff) },
                                    onInspectStaff = { targetStaff -> viewModel.selectedStaffForAdmin.value = targetStaff },
                                    onApprovePayout = { txnId -> viewModel.adminApprovePayout(txnId) },
                                    onRejectPayout = { txnId, reason -> viewModel.adminRejectPayout(txnId, reason) },
                                    onCreditStaffWallet = { targetStaff ->
                                        viewModel.selectedStaffForAdmin.value = targetStaff
                                        viewModel.showAdminCreditDialog.value = true
                                    },
                                    onOpenPriceEditor = { viewModel.showPriceEditorDialog.value = true },
                                    onOpenStockUpload = { viewModel.showUploadStockDialog.value = true },
                                    onOpenUniversalExcelImport = { dataset -> viewModel.openExcelImportHub(dataset) },
                                    onOpenCrmIntegrations = { viewModel.setMainAppTab(MainAppTab.CRM_INTEGRATIONS) },
                                    onEditStaffValues = { targetStaff -> viewModel.showEditStaffDialog.value = targetStaff },
                                    onAddOrReplaceStaff = { viewModel.addOrReplaceStaffAccount(it) },
                                    onDeleteStaff = { viewModel.deleteStaffAccount(it) },
                                    onAddOrReplaceCasket = { viewModel.addOrReplaceCasketItem(it) },
                                    onDeleteCasket = { viewModel.deleteCasketItem(it) },
                                    onAddOrReplaceMaterial = { viewModel.addOrReplaceInventoryMaterial(it) },
                                    onDeleteMaterial = { viewModel.deleteInventoryMaterial(it) },
                                    onAddOrReplaceWorkshopItem = { viewModel.addOrReplaceWorkshopItem(it) },
                                    onDeleteWorkshopItem = { viewModel.deleteWorkshopItem(it) },
                                    onAddOrReplaceActivity = { viewModel.addOrReplaceActivity(it) },
                                    onDeleteActivity = { viewModel.deleteActivity(it) },
                                    onAddOrReplaceFleetVehicle = { viewModel.addOrReplaceFleetVehicle(it) },
                                    onDeleteFleetVehicle = { viewModel.deleteFleetVehicle(it) },
                                    onAddOrReplaceCustomerOrder = { viewModel.addOrReplaceCustomerOrder(it) },
                                    onDeleteCustomerOrder = { viewModel.deleteCustomerOrder(it) },
                                    onAddOrReplaceBranch = { viewModel.addOrReplaceBranchStatusBoard(it) },
                                    onDeleteBranch = { viewModel.deleteBranchStatusBoard(it) },
                                    orderPackages = orderPackages,
                                    orderAddons = orderAddons,
                                    staffAlerts = staffAlerts,
                                    breakageRecords = breakageRecords,
                                    operatorWageAllocations = operatorWageAllocations,
                                    onAutoAssignTask = { cat, title, caseRef, family, loc, prio, pay, notes ->
                                        viewModel.autoAssignAndAlertTask(cat, title, caseRef, family, loc, prio, pay, notes)
                                    },
                                    onAdminAssessAndPriceActivity = { actId, price, approve, notes ->
                                        viewModel.adminAssessAndPriceActivity(actId, price, approve, notes)
                                    },
                                    onRecordBreakage = { sId, item, desc, cost, deduct ->
                                        viewModel.recordAndDeductBreakage(sId, item, desc, cost, deduct)
                                    },
                                    onExecutePendingBreakage = { bId -> viewModel.executePendingBreakageDeduction(bId) },
                                    onAllocateOperatorWage = { sId, tFee, dWage, duty, disburse ->
                                        viewModel.allocateOperatorTransportAndWage(sId, tFee, dWage, duty, disburse)
                                    },
                                    onDisburseOperatorWage = { aId -> viewModel.disburseOperatorWageAllocation(aId) },
                                    walletSummaries = allStaffWalletSummaries,
                                    onAccessStaffWallet = { targetStaff ->
                                        viewModel.adminAccessStaffAccount(targetStaff, initialTab = NavTab.WALLET, stayOnWalletTab = false)
                                    },
                                    onUpdateActivityStatus = { id, status -> viewModel.updateActivityStatus(id, status) },
                                    onDispatchTaskAlert = { act -> viewModel.dispatchShiftAlertForTask(act) },
                                    onOpenDailyTimeline = {
                                        viewModel.setMainAppTab(MainAppTab.STAFF_OPERATIONS)
                                        viewModel.setTab(NavTab.ACTIVITIES)
                                    },
                                    attendanceLogs = shiftAttendanceLogs,
                                    onOpenShiftQrScanner = { showManagerShiftQrDialog = true },
                                    cloudUserEmail = cloudUserEmail,
                                    cloudUserUid = cloudUserUid,
                                    cloudAdmins = cloudAdmins,
                                    onAuthorizeCloudBranchAdmin = { uid, email, branch ->
                                        viewModel.authorizeCloudBranchAdmin(uid, email, branch)
                                    },
                                    onRevokeCloudBranchAdmin = { uid ->
                                        viewModel.revokeCloudBranchAdmin(uid)
                                    },
                                    onOpenCloudAuth = {
                                        cloudAuthScope.launch {
                                            GoogleCloudAuthHelper.launchInteractiveSignIn(cloudAuthContext)
                                                .onSuccess { user -> viewModel.onCloudSignedIn(user) }
                                                .onFailure { err ->
                                                    viewModel.actionFeedbackMessage.value = err.localizedMessage ?: "Google Cloud Sign-In cancelled."
                                                }
                                        }
                                    }
                                )
                            }
                            NavTab.PROFILE -> {
                                ProfileScreen(
                                    currentAccount = activeAcc,
                                    isDarkMode = isDarkMode,
                                    onToggleDarkMode = { viewModel.setDarkMode(it) },
                                    autoNightShiftScheduled = autoNightShiftScheduled,
                                    onToggleAutoNightShift = { viewModel.setAutoNightShiftScheduled(it) },
                                    eyeProtectionActive = nightShiftEyeProtection,
                                    onToggleEyeProtection = { viewModel.setNightShiftEyeProtection(it) },
                                    onChangePassword = { viewModel.showChangePasswordDialog.value = true },
                                    onToggleBiometric = { viewModel.toggleStaffBiometric(it) },
                                    onTestBiometrics = { viewModel.triggerBiometricAuth(activeAcc) },
                                    attendanceLogs = shiftAttendanceLogs,
                                    canVerifyShiftAttendance = viewModel.canCurrentUserVerifyShiftAttendance(),
                                    onOpenShiftQrScanner = { showManagerShiftQrDialog = true },
                                    cloudUserEmail = cloudUserEmail,
                                    cloudSyncState = cloudSyncState,
                                    onCloudSignedIn = { viewModel.onCloudSignedIn(it) },
                                    onCloudSignedOut = { viewModel.onCloudSignedOut() },
                                    onManualCloudSync = { viewModel.triggerManualCloudSync() },
                                    onSignOut = { viewModel.signOut() }
                                )
                            }
                            NavTab.WORKSHOP_PRODUCTION -> {
                                LiveWorkshopScreen(viewModel = viewModel)
                            }
                            NavTab.COSTINGS_PRICING -> {
                                CostingsAndPricingScreen(viewModel = viewModel)
                            }
                            NavTab.INVENTORY_MANAGEMENT -> {
                                InventoryManagementScreen(viewModel = viewModel)
                            }
                            NavTab.BURIAL_SCHEDULING -> {
                                BurialSchedulingScreen(viewModel = viewModel)
                            }
                            NavTab.DAILY_REPORT -> {
                                DailyReportScreen(viewModel = viewModel)
                            }
                            NavTab.REMOTE_SURVEILLANCE -> {
                                RemoteSurveillanceScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
    }
    }

    // APPLICATION DIALOGS
    if (showLogActivityDialog) {
        LogActivityDialog(
            onDismiss = { viewModel.showLogActivityDialog.value = false },
            onSubmit = { cat, title, caseRef, family, loc, date, time, duration, notes, allowance ->
                viewModel.logActivity(cat, title, caseRef, family, loc, date, time, duration, notes, allowance)
            },
            onSubmitFuneralTask = { task ->
                val currentAcc = currentAccount
                val enriched = if (currentAcc != null) {
                    task.copy(
                        staffId = currentAcc.id,
                        staffName = currentAcc.fullName,
                        department = currentAcc.department
                    )
                } else task
                viewModel.recordFuneralArrangementTask(enriched)
            }
        )
    }

    if (showRequestPayoutDialog && currentAccount != null) {
        RequestPayoutDialog(
            staffAccount = currentAccount!!,
            availableBalance = walletSummary.availableBalance,
            onDismiss = { viewModel.showRequestPayoutDialog.value = false },
            onSubmitPayout = { amt, method, dest, notes ->
                viewModel.requestPayout(amt, method, dest, notes)
            }
        )
    }

    if (showSubmitExpenseDialog) {
        val activeStaff = currentAccount ?: allAccounts.firstOrNull { it.id == "CEO-001" } ?: allAccounts.first()
        SubmitExpenseClaimDialog(
            staffAccount = activeStaff,
            onDismiss = { viewModel.showSubmitExpenseDialog.value = false },
            onSubmitExpense = { category, title, amount, caseRef, receiptNo, plate, notes, reimbMethod ->
                viewModel.submitExpenseClaim(category, title, amount, caseRef, receiptNo, plate, notes, reimbMethod)
                viewModel.showSubmitExpenseDialog.value = false
            }
        )
    }

    if (showAwardIncentiveDialog) {
        val supervisor = currentAccount ?: allAccounts.firstOrNull { it.id == "CEO-001" } ?: allAccounts.first()
        AwardIncentiveDialog(
            staffAccounts = allAccounts,
            currentSupervisor = supervisor,
            onDismiss = { viewModel.showAwardIncentiveDialog.value = false },
            onAwardIncentive = { staffId, category, title, amount, caseRef, awardedBy, rationale ->
                viewModel.awardPerformanceIncentive(staffId, category, title, amount, caseRef, awardedBy, rationale)
                viewModel.showAwardIncentiveDialog.value = false
            }
        )
    }

    if (showChangePasswordDialog && currentAccount != null) {
        ChangePasswordDialog(
            staffName = currentAccount!!.fullName,
            onDismiss = { viewModel.showChangePasswordDialog.value = false },
            onSubmitNewPassword = { newPass ->
                viewModel.updateDesiredPassword(newPass)
            }
        )
    }

    if (showAdminCreditDialog) {
        AdminCreditWalletDialog(
            staffList = allAccounts,
            preselectedStaff = selectedStaffForAdmin,
            onDismiss = { viewModel.showAdminCreditDialog.value = false },
            onSubmitCredit = { staffId, amt, title, type, notes ->
                viewModel.adminCreditStaffWallet(staffId, amt, title, type, notes)
            }
        )
    }

    selectedStaffForAdmin?.let { staffToInspect ->
        if (!showAdminCreditDialog) {
            val staffSummary = viewModel.getWalletSummaryForStaff(staffToInspect.id)

            val actCount = allActivities.count { it.staffId == staffToInspect.id }

            AdminStaffDetailSheet(
                staff = staffToInspect,
                walletSummary = staffSummary,
                activityCount = actCount,
                onDismiss = { viewModel.selectedStaffForAdmin.value = null },
                onAccessAccount = { targetStaff ->
                    viewModel.selectedStaffForAdmin.value = null
                    viewModel.adminAccessStaffAccount(targetStaff)
                },
                onCreditWallet = { targetStaff ->
                    viewModel.selectedStaffForAdmin.value = targetStaff
                    viewModel.showAdminCreditDialog.value = true
                },
                onResetPassword = { staffId, newPass ->
                    viewModel.adminResetStaffPassword(staffId, newPass)
                },
                onEditRoleAndValues = { targetStaff ->
                    viewModel.selectedStaffForAdmin.value = null
                    viewModel.showEditStaffDialog.value = targetStaff
                },
                onOpenWallet = { targetStaff ->
                    viewModel.selectedStaffForAdmin.value = null
                    viewModel.adminAccessStaffAccount(targetStaff, initialTab = NavTab.WALLET, stayOnWalletTab = false)
                }
            )
        }
    }

    selectedTransactionForReceipt?.let { txn ->
        val staffName = allAccounts.firstOrNull { it.id == txn.staffId }?.fullName ?: (currentAccount?.fullName ?: "Staff Member")
        TransactionReceiptDialog(
            transaction = txn,
            staffName = staffName,
            onDismiss = { viewModel.selectedTransactionForReceipt.value = null }
        )
    }

    if (showBiometricDialog) {
        BiometricAuthDialog(
            staffAccount = biometricTargetStaff,
            purpose = "Secure Staff Operations & Payroll Ledger",
            onSuccess = { viewModel.onBiometricSuccess() },
            onDismiss = { viewModel.dismissBiometricDialog() },
            onFallbackPassword = { viewModel.dismissBiometricDialog() }
        )
    }

    if (showRealtimeFuneralLoggingDialog) {
        RealtimeFuneralLoggingDialog(
            currentStaffAccount = currentAccount,
            onDismiss = { showRealtimeFuneralLoggingDialog = false },
            onSubmitUpdate = { updatedActivity ->
                viewModel.recordFuneralArrangementTask(updatedActivity)
                showRealtimeFuneralLoggingDialog = false
            }
        )
    }

    if (showKraPortalDialog) {
        KraPortalDialog(
            onDismiss = { showKraPortalDialog = false }
        )
    }

    if (showAppShareLinkDialog) {
        AppShareLinkDialog(
            onDismiss = { showAppShareLinkDialog = false }
        )
    }

    showEditStaffDialog?.let { staffToEdit ->
        EditStaffRoleAndValuesDialog(
            staff = staffToEdit,
            onDismiss = { viewModel.showEditStaffDialog.value = null },
            onSave = { fullName, phone, email, role, dept, branch, nationalId, vehicle, baseSalary, allowance, commRate, mpesa, bank, isActive, notes ->
                viewModel.adminUpdateStaffRoleAndValues(
                    staffId = staffToEdit.id,
                    fullName = fullName,
                    phone = phone,
                    email = email,
                    role = role,
                    department = dept,
                    branch = branch,
                    nationalId = nationalId,
                    assignedVehicle = vehicle,
                    baseSalaryKes = baseSalary,
                    allowanceKes = allowance,
                    commissionRatePercent = commRate,
                    defaultMpesa = mpesa,
                    defaultBank = bank,
                    isActive = isActive,
                    notes = notes
                )
                viewModel.showEditStaffDialog.value = null
            }
        )
    }

    if (showPriceEditorDialog) {
        AdminPriceEditorDialog(
            caskets = caskets,
            salesServices = salesServices,
            priceAuditLog = priceAuditLog,
            onDismiss = { viewModel.showPriceEditorDialog.value = false },
            onUpdateCasketPrice = { casketId, newPriceKes, newStock, inStock, notes ->
                viewModel.updateCasketPrice(
                    casketId = casketId,
                    newPriceKes = newPriceKes,
                    newStockCount = newStock,
                    inStock = inStock,
                    notes = notes
                )
            },
            onUpdateServicePrice = { serviceId, newPriceKes, notes ->
                viewModel.updateSalesServicePrice(
                    serviceId = serviceId,
                    newPriceKes = newPriceKes,
                    notes = notes
                )
            },
            orderPackages = orderPackages,
            orderAddons = orderAddons,
            onUpdatePackagePrice = { id, price -> viewModel.updateOrderPackagePrice(id, price) },
            onUpdateAddonPrice = { id, price -> viewModel.updateOrderAddonPrice(id, price) },
            onUpdateCasketDetails = { updated -> viewModel.addOrReplaceCasketItem(updated) }
        )
    }

    if (showUploadStockDialog) {
        UploadStockDialog(
            uploadedStockList = uploadedStockList,
            onDismiss = { viewModel.showUploadStockDialog.value = false },
            onUploadItem = { name, category, sku, desc, qty, threshold, cost, selling, branch, supplier, invoice ->
                viewModel.uploadStockItem(
                    name = name,
                    category = category,
                    sku = sku,
                    description = desc,
                    quantity = qty,
                    reorderThreshold = threshold,
                    costPriceKes = cost,
                    sellingPriceKes = selling,
                    branchWarehouse = branch,
                    supplierName = supplier,
                    invoiceOrBatchNumber = invoice
                )
            },
            onUploadPresetBatch = { presetName ->
                viewModel.uploadStockBatchPreset(presetName)
            },
            onBatchUpload = { items ->
                viewModel.batchUploadStockItems(items)
            },
            onDeleteStockItem = { itemId ->
                viewModel.deleteUploadedStockItem(itemId)
            }
        )
    }

    if (showUniversalExcelImportDialog) {
        UniversalExcelImportDialog(
            initialDataset = selectedExcelImportDataset,
            onDismiss = { viewModel.showUniversalExcelImportDialog.value = false },
            onImportStockItems = { items ->
                viewModel.batchUploadStockItems(items)
                viewModel.showUniversalExcelImportDialog.value = false
            },
            onImportBurialSchedules = { schedules ->
                viewModel.batchImportBurialSchedules(schedules)
                viewModel.showUniversalExcelImportDialog.value = false
            },
            onImportCustomerOrders = { orders ->
                viewModel.batchImportCustomerOrders(orders)
                viewModel.showUniversalExcelImportDialog.value = false
            },
            onImportStaffAccounts = { accounts ->
                viewModel.batchImportStaffAccounts(accounts)
                viewModel.showUniversalExcelImportDialog.value = false
            },
            onImportFleetVehicles = { vehicles ->
                viewModel.batchImportFleetVehicles(vehicles)
                viewModel.showUniversalExcelImportDialog.value = false
            },
            onImportWorkshopJobs = { jobs ->
                viewModel.batchImportWorkshopJobs(jobs)
                viewModel.showUniversalExcelImportDialog.value = false
            }
        )
    }

    if (showExportManifestDialog) {
        ExportExcelManifestDialog(
            burialSchedules = burialSchedules,
            fleetVehicles = fleetVehicles,
            staffAccounts = allStaffAccounts,
            caskets = caskets,
            onDismiss = { viewModel.showExportManifestDialog.value = false }
        )
    }

    if (showSpotlightSearchDialog) {
        SpotlightCommandPaletteDialog(
            burialSchedules = burialSchedules,
            fleetVehicles = fleetVehicles,
            staffAccounts = allStaffAccounts,
            caskets = caskets,
            onNavigateTab = { tab -> viewModel.setMainAppTab(tab) },
            onOpenExcelImport = { viewModel.openExcelImportHub() },
            onOpenPriceEditor = { viewModel.showPriceEditorDialog.value = true },
            onOpenExportManifest = { viewModel.openExportManifestDialog() },
            onDismiss = { viewModel.showSpotlightSearchDialog.value = false }
        )
    }

    if (showOfflineSyncDialog) {
        OfflineSyncQueueDialog(
            isOnline = isDeviceOnline,
            isSimulatedOffline = simulatedOfflineOverride,
            isSyncing = isSyncingOfflineQueue,
            queuedActions = offlineQueue,
            onToggleSimulatedOffline = { viewModel.toggleSimulatedOfflineMode() },
            onLogRuralCheckIn = { loc, notes -> viewModel.logRuralFieldCheckIn(loc, notes) },
            onSyncNow = { viewModel.syncPendingOfflineQueue() },
            onDismiss = { viewModel.showOfflineSyncDialog.value = false }
        )
    }

    if (showShiftAlertCenterDialog) {
        com.example.ui.components.ShiftAlertCenterDialog(
            alerts = staffAlerts,
            staffAccounts = allStaffAccounts,
            shiftSchedules = shiftSchedules,
            prefilledStaffId = prefilledAlertStaffId,
            prefilledShiftId = prefilledAlertShiftId,
            onScanDueShifts = { viewModel.triggerDueShiftAlertsScan() },
            onMarkAllRead = { viewModel.markAllShiftAlertsRead() },
            onAcknowledgeAlert = { alertId -> viewModel.acknowledgeShiftAlert(alertId) },
            onDismissAlert = { alertId -> viewModel.dismissShiftAlert(alertId) },
            onDispatchShiftAlert = { staffId, title, message, priority, shiftId, timeLabel, branch, sendSms ->
                viewModel.dispatchShiftAlert(
                    recipientStaffId = staffId,
                    title = title,
                    message = message,
                    priority = priority,
                    shiftId = shiftId,
                    scheduledTimeLabel = timeLabel,
                    branch = branch,
                    sendSmsAlso = sendSms
                )
            },
            onDismiss = { viewModel.closeShiftAlertCenter() }
        )
    }

    if (showManagerShiftQrDialog && currentAccount != null) {
        val verifier = adminImpersonator ?: currentAccount!!
        com.example.ui.components.ManagerShiftQrAttendanceDialog(
            verifierAccount = verifier,
            allStaff = allStaffAccounts,
            shiftSchedules = shiftSchedules,
            recentLogs = shiftAttendanceLogs,
            onVerifyAttendance = { scannedCode, action, checkpoint, shiftId, windowLabel, notes ->
                viewModel.verifyStaffShiftAttendanceByQr(
                    scannedCode = scannedCode,
                    action = action,
                    checkpointLocation = checkpoint,
                    shiftId = shiftId,
                    shiftWindowLabel = windowLabel,
                    notes = notes
                )
            },
            onDismiss = { showManagerShiftQrDialog = false }
        )
    }

    val pendingRotationAccount = requiresPasswordRotation
    if (pendingRotationAccount != null) {
        ForcedPasswordRotationDialog(
            staffAccount = pendingRotationAccount,
            onRotatePassword = { newPass ->
                viewModel.completeForcedPasswordRotation(newPass)
            },
            onSignOutInstead = {
                viewModel.requiresPasswordRotation.value = null
                viewModel.signOut()
            }
        )
    }
}

private fun recommendedTabsForRole(
    role: StaffRole?,
    department: Department?
): Set<MainAppTab> {
    return when {
        role == StaffRole.OPERATIONS_ADMIN ||
            role == StaffRole.MANAGING_DIRECTOR_CEO ||
            department == Department.CEO ||
            department == Department.ADMINISTRATION -> MainAppTab.entries.toSet()

        role == StaffRole.INVENTORY_MANAGER -> setOf(
            MainAppTab.STAFF_OPERATIONS, MainAppTab.INVENTORY_MANAGEMENT, MainAppTab.STOCK_MOVEMENT,
            MainAppTab.WORKSHOP_PRODUCTION, MainAppTab.COSTINGS_AND_PRICING, MainAppTab.COST_ANALYTICS,
            MainAppTab.CASKET_SELECTION, MainAppTab.VENDOR_MANAGEMENT, MainAppTab.ADMIN_CONSOLE,
            MainAppTab.DAILY_REPORT, MainAppTab.STAFF_WALLET, MainAppTab.AI_ASSISTANT
        )

        role == StaffRole.WORKSHOP_WORKER || role == StaffRole.CASKET_ARTISAN || department == Department.WORKSHOP -> setOf(
            MainAppTab.STAFF_OPERATIONS, MainAppTab.WORKSHOP_PRODUCTION, MainAppTab.INVENTORY_MANAGEMENT,
            MainAppTab.STOCK_MOVEMENT, MainAppTab.COSTINGS_AND_PRICING, MainAppTab.CASKET_SELECTION,
            MainAppTab.DAILY_LOG, MainAppTab.ROSTER_CALENDAR, MainAppTab.DAILY_REPORT,
            MainAppTab.STAFF_WALLET, MainAppTab.AI_ASSISTANT
        )

        role == StaffRole.DRIVER || role == StaffRole.FLEET_OPERATOR || department == Department.DRIVERS -> setOf(
            MainAppTab.STAFF_OPERATIONS, MainAppTab.FLEET_TRACKING, MainAppTab.BRANCHES_FLEET,
            MainAppTab.BURIAL_SCHEDULING, MainAppTab.DAILY_LOG, MainAppTab.ROSTER_CALENDAR,
            MainAppTab.DAILY_REPORT, MainAppTab.STAFF_WALLET, MainAppTab.AI_ASSISTANT
        )

        role == StaffRole.OPERATOR || department == Department.OPERATORS -> setOf(
            MainAppTab.STAFF_OPERATIONS, MainAppTab.BURIAL_SCHEDULING, MainAppTab.DAILY_LOG,
            MainAppTab.ROSTER_CALENDAR, MainAppTab.BRANCH_BOARDS, MainAppTab.DAILY_REPORT,
            MainAppTab.STAFF_WALLET, MainAppTab.MEMORIALS, MainAppTab.AI_ASSISTANT
        )

        role == StaffRole.SALES_MARKETING || department == Department.SALES_MARKETING -> setOf(
            MainAppTab.STAFF_OPERATIONS, MainAppTab.CASKET_SELECTION, MainAppTab.ORDERS_PAYMENTS,
            MainAppTab.ORDER_DASHBOARD, MainAppTab.SALES_SERVICES, MainAppTab.THERMAL_POS,
            MainAppTab.KRA_PORTAL, MainAppTab.BULK_SMS, MainAppTab.COMMUNICATION_3CX,
            MainAppTab.STAFF_WALLET, MainAppTab.MEMORIALS, MainAppTab.AI_ASSISTANT
        )

        role == StaffRole.ACCOUNTS_OFFICER || role == StaffRole.ADMINISTRATIVE_STAFF -> setOf(
            MainAppTab.STAFF_OPERATIONS, MainAppTab.ORDERS_PAYMENTS, MainAppTab.ORDER_DASHBOARD,
            MainAppTab.COSTINGS_AND_PRICING, MainAppTab.COST_ANALYTICS, MainAppTab.THERMAL_POS,
            MainAppTab.KRA_PORTAL, MainAppTab.STAFF_WALLET, MainAppTab.BURIAL_SCHEDULING,
            MainAppTab.DAILY_REPORT, MainAppTab.AI_ASSISTANT
        )

        role == StaffRole.FUNERAL_DIRECTOR || role == StaffRole.CHAPEL_COORDINATOR || role == StaffRole.MORTUARY_TECH -> setOf(
            MainAppTab.STAFF_OPERATIONS, MainAppTab.BURIAL_SCHEDULING, MainAppTab.CASKET_SELECTION,
            MainAppTab.DAILY_LOG, MainAppTab.ROSTER_CALENDAR, MainAppTab.BRANCH_BOARDS,
            MainAppTab.MEMORIALS, MainAppTab.DAILY_REPORT, MainAppTab.STAFF_WALLET, MainAppTab.AI_ASSISTANT
        )

        else -> setOf(
            MainAppTab.STAFF_OPERATIONS, MainAppTab.DAILY_LOG, MainAppTab.ROSTER_CALENDAR,
            MainAppTab.STAFF_WALLET, MainAppTab.DAILY_REPORT, MainAppTab.AI_ASSISTANT
        )
    }
}

