package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCartCheckout
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.CasketCostingEngine
import com.example.domain.CasketProductionCostModel
import com.example.model.MarginStatus
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CostingOrderPriceGuideTab(
    models: List<CasketProductionCostModel>,
    currencyMode: String,
    onSendToOrderCheckout: (CasketProductionCostModel) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedModelId by remember { mutableStateOf(models.firstOrNull()?.id ?: "MOD-SIMPLE") }
    val selectedModel = models.firstOrNull { it.id == selectedModelId } ?: models.first()
    var dropdownExpanded by remember { mutableStateOf(false) }
    var customSellInput by remember(selectedModelId) {
        mutableStateOf(selectedModel.recommendedOrderPriceKes.toInt().toString())
    }
    val selectedEquipIds = remember { mutableStateListOf<String>() }

    val parsedOverride = customSellInput.toDoubleOrNull()
    val quote = remember(selectedModel, selectedEquipIds.toList(), parsedOverride) {
        CasketCostingEngine.buildOrderQuoteBreakdown(
            model = selectedModel,
            casketQuantity = 1,
            selectedEquipmentIds = selectedEquipIds.toSet(),
            overrideUnitSellingPriceKes = parsedOverride
        )
    }

    LazyColumn(
        modifier = modifier.padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // 1. Live Interactive Order Quote Calculator using Document Pricing
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("costings_order_quote_builder")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Interactive Client Order Price Formulator",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Navy900
                    )
                    Text(
                        text = "Combines PDF production floor & guide prices with Page 9 event equipment hire rates.",
                        fontSize = 11.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = "${selectedModel.modelName} (Guide ${formatCurrencyDisplay(selectedModel.recommendedOrderPriceKes, currencyMode)})",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Formulated Casket Model") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .testTag("quote_casket_selector")
                        )
                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            models.forEach { m ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(m.modelName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(
                                                "Cost ${formatCurrencyDisplay(m.totalProductionCostKes, currencyMode)} • Guide ${formatCurrencyDisplay(m.recommendedOrderPriceKes, currencyMode)}",
                                                fontSize = 10.sp,
                                                color = RoyalCobaltBlue
                                            )
                                        }
                                    },
                                    onClick = {
                                        selectedModelId = m.id
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = customSellInput,
                        onValueChange = { customSellInput = it },
                        label = { Text("Quoted Casket Selling Price (KES) — Min Floor KES ${selectedModel.floorOrderPriceKes.toInt()}") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quote_selling_price_input")
                    )

                    if (quote.marginEvaluation.status != MarginStatus.HEALTHY) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = if (quote.marginEvaluation.status == MarginStatus.BELOW_COST) StrokeRedLight else AmberLight,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Margin warning",
                                    tint = if (quote.marginEvaluation.status == MarginStatus.BELOW_COST) StrokeRed else AmberWarning,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = quote.marginEvaluation.warningMessage ?: "Low margin detected",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (quote.marginEvaluation.status == MarginStatus.BELOW_COST) StrokeRed else AmberWarning
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Equipment Hire & Funeral Services (PDF Page 9 Exact Rates)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Navy900
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    CasketCostingEngine.equipmentHireRates.forEach { eqp ->
                        val checked = selectedEquipIds.contains(eqp.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (checked) selectedEquipIds.remove(eqp.id) else selectedEquipIds.add(eqp.id)
                                }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = {
                                        if (checked) selectedEquipIds.remove(eqp.id) else selectedEquipIds.add(eqp.id)
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = RoyalCobaltBlue)
                                )
                                Column {
                                    Text(eqp.serviceName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                                    Text("${eqp.category} • ${eqp.unitBasis}", fontSize = 9.sp, color = TextMuted)
                                }
                            }
                            Text(
                                text = formatCurrencyDisplay(eqp.rateKes, currencyMode),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalCobaltBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = BorderLight)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Total Quote Financial Summary
                    Surface(
                        color = Navy900,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("RECOMMENDED CLIENT ORDER TOTAL", fontSize = 9.sp, color = Color(0xFF93C5FD), fontWeight = FontWeight.Bold)
                                    Text(
                                        text = String.format(Locale.US, "KES %,.0f", quote.clientOrderTotalKes),
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = String.format(Locale.US, "Approx. $ %,.0f USD • Equipment Hire: KES %,.0f", quote.clientOrderTotalUsd, quote.equipmentHireTotalKes),
                                        fontSize = 10.sp,
                                        color = Color(0xFFDBEAFE)
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Casket Margin", fontSize = 9.sp, color = Color(0xFF86EFAC))
                                    Text(
                                        text = "${quote.marginEvaluation.marginPercent}%",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF4ADE80)
                                    )
                                    Text(
                                        text = "5% Comm: KES ${String.format(Locale.US, "%,.0f", quote.expectedSalesCommissionKes)}",
                                        fontSize = 9.sp,
                                        color = Color(0xFFFDE68A)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = { onSendToOrderCheckout(selectedModel) },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(42.dp)
                                    .testTag("btn_load_quote_to_order")
                            ) {
                                Icon(Icons.Default.ShoppingCartCheckout, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Load Selected Casket Into Order & Pay", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        }

        // 2. Full Comparison Price Matrix across All 9 Models
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Complete Casket Production & Order Guide Matrix",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Navy900
                    )
                    Text(
                        text = "Use Floor Price as walk-away minimum; Guide Price preserves healthy workshop profit.",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    models.forEachIndexed { idx, m ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (idx % 2 == 0) Color(0xFFF8FAFC) else PureWhite)
                                .clickable { selectedModelId = m.id }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.3f)) {
                                Text(m.modelName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Navy900, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("Floor: ${formatCurrencyDisplay(m.floorOrderPriceKes, currencyMode)}", fontSize = 9.sp, color = TextMuted)
                            }
                            Column(modifier = Modifier.weight(0.9f), horizontalAlignment = Alignment.End) {
                                Text(formatCurrencyDisplay(m.totalProductionCostKes, currencyMode), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = AmberWarning)
                                Text("Cost", fontSize = 8.sp, color = TextMuted)
                            }
                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text(formatCurrencyDisplay(m.recommendedOrderPriceKes, currencyMode), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = RoyalCobaltBlue)
                                Text("${m.grossMarginPercent}%", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CostingRawMaterialsTab(
    onOpenInventory: () -> Unit,
    modifier: Modifier = Modifier
) {
    var search by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    val categories = remember {
        CasketCostingEngine.rawMaterialCatalog.map { it.category }.distinct()
    }
    val filtered = remember(search, selectedCategory) {
        CasketCostingEngine.rawMaterialCatalog.filter { item ->
            val matchCat = selectedCategory == null || item.category == selectedCategory
            val matchSearch = search.isBlank() ||
                item.name.contains(search, ignoreCase = true) ||
                item.category.contains(search, ignoreCase = true)
            matchCat && matchSearch
        }
    }

    LazyColumn(
        modifier = modifier.padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = RoyalCobaltIce),
                border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "PDF Master Raw Material Price Catalog (32 Items)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Navy900
                        )
                        Text(
                            text = "Catalog Avg: KES ${String.format(Locale.US, "%,.2f", CasketCostingEngine.catalogAverageMaterialPriceKes)} • Peak Item: KES ${String.format(Locale.US, "%,.0f", CasketCostingEngine.catalogHighestPricedMaterialKes)} (Indasa P60 Roll)",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                    OutlinedButton(
                        onClick = onOpenInventory,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp).testTag("btn_costings_open_inventory")
                    ) {
                        Icon(Icons.Default.Inventory, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Stock", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("Search chipboard, handles, satin, paint, sandpaper...", fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (search.isNotEmpty()) {
                        IconButton(onClick = { search = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search", modifier = Modifier.size(16.dp))
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("raw_materials_search_input")
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { selectedCategory = null },
                    label = { Text("All (${CasketCostingEngine.rawMaterialCatalog.size})", fontSize = 11.sp, maxLines = 1, softWrap = false) }
                )
                categories.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RoyalCobaltBlue,
                            selectedLabelColor = PureWhite
                        )
                    )
                }
            }
        }

        items(filtered, key = { it.code }) { item ->
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (item.isBulkDiscountOption) ForestGreenPrimary.copy(alpha = 0.5f) else BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy900)
                        Text(
                            text = "${item.category} • Unit: ${item.unitOfMeasure}" + if (item.isBulkDiscountOption) " • Bulk Savings" else "",
                            fontSize = 10.sp,
                            color = if (item.isBulkDiscountOption) EmeraldSuccess else TextMuted
                        )
                    }
                    Text(
                        text = String.format(Locale.US, "KES %,.2f", item.unitPriceKes),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = RoyalCobaltBlue
                    )
                }
            }
        }
    }
}

@Composable
fun CostingCrewAndShopsTab(
    onOpenBranchesBoards: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // 1. Workshop Personnel Directory (PDF Page 10)
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Build, contentDescription = null, tint = ForestGreenPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Workshop Craft Personnel & Roles (PDF Page 10)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Navy900)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    CasketCostingEngine.workshopPersonnelDirectory.forEach { person ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(person.staffName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy900)
                                Text(person.department, fontSize = 10.sp, color = TextMuted)
                            }
                            Surface(color = EmeraldLight, shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = person.status,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Branch / Shop Network (SH-01 to SH-08)
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storefront, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("8-Shop Network (SH-01 to SH-08)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Navy900)
                        }
                        OutlinedButton(
                            onClick = onOpenBranchesBoards,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Boards", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    CasketCostingEngine.shopBranchNetwork.forEach { shop ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Surface(color = RoyalCobaltIce, shape = RoundedCornerShape(4.dp)) {
                                    Text(
                                        text = shop.shopId,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = RoyalCobaltBlue,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(shop.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Navy900)
                            }
                            Text(shop.networkRole, fontSize = 10.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }

        // 3. Sales, Dressing & Fleet Transport Items (PDF Page 9)
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Dressing, Apparels & Transport Fleet Items", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Navy900)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    CasketCostingEngine.salesDressingAndTransportItems.forEach { (item, desc, cat) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Navy900)
                            Text("$desc • $cat", fontSize = 10.sp, color = TextMuted)
                        }
                    }
                }
            }
        }
    }
}
