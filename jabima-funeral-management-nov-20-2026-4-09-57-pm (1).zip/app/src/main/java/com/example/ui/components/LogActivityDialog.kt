package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ActivityCategory
import com.example.model.FuneralArrangementStage
import com.example.model.JABIMA_FLEET
import com.example.model.StaffActivity
import com.example.model.TaskPriority
import com.example.ui.theme.Blue100
import com.example.ui.theme.Blue200
import com.example.ui.theme.Blue50
import com.example.ui.theme.Blue700
import com.example.ui.theme.Blue800
import com.example.ui.theme.Blue900
import com.example.ui.theme.Blue950
import com.example.ui.theme.PureWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogActivityDialog(
    onDismiss: () -> Unit,
    onSubmit: (
        category: ActivityCategory,
        title: String,
        caseReference: String,
        clientFamily: String,
        location: String,
        date: String,
        time: String,
        durationMinutes: Int,
        notes: String,
        allowanceEarned: Double
    ) -> Unit,
    onSubmitFuneralTask: ((StaffActivity) -> Unit)? = null
) {
    var selectedCategory by remember { mutableStateOf(ActivityCategory.CASE_HANDLING) }
    var selectedStage by remember { mutableStateOf(FuneralArrangementStage.FAMILY_PLANNING) }
    var selectedPriority by remember { mutableStateOf(TaskPriority.NORMAL) }

    var title by remember { mutableStateOf("") }
    var caseReference by remember { mutableStateOf("JFD-2026-") }
    var clientFamily by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("Siaya Referral Care Center") }

    val todayStr = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()) }
    val timeStr = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()) }

    var date by remember { mutableStateOf(todayStr) }
    var time by remember { mutableStateOf(timeStr) }
    var durationMinutesText by remember { mutableStateOf("90") }
    var allowanceText by remember { mutableStateOf("2500") }
    var assignedHearse by remember { mutableStateOf<String?>(null) }
    var assignedEquipment by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var categoryExpanded by remember { mutableStateOf(false) }
    var stageExpanded by remember { mutableStateOf(false) }
    var hearseExpanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Funeral task presets to expedite daily recording
    val taskPresets = listOf(
        "Deceased Body Intake & Cold Room Tagging",
        "Mortuary Embalming & Preservation Treatment",
        "Bereaved Family Service Consultation & Program",
        "President Royal Oak Casket Assembly & Lining",
        "VIP Hearse Escort Departure & Procession",
        "Church / Chapel Vigil & Sound Setup",
        "Gravesite Excavation Check & Lowering Gear Rigging",
        "Post-Burial Repatriation & Equipment Check-in"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = BorderStroke(1.dp, Blue200),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp)
                .testTag("log_activity_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Record Funeral Daily Task",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Blue950
                        )
                        Text(
                            text = "Log real-time funeral arrangements & earn activity allowance",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quick Task Presets
                Text("Quick Funeral Task Presets:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(taskPresets) { preset ->
                        FilterChip(
                            selected = title == preset,
                            onClick = {
                                title = preset
                                when (preset) {
                                    "Deceased Body Intake & Cold Room Tagging" -> {
                                        selectedCategory = ActivityCategory.CASE_HANDLING
                                        selectedStage = FuneralArrangementStage.INTAKE_MORTUARY
                                        allowanceText = "3500"
                                        assignedEquipment = "Deceased Stretcher & Preservation Cold Tray"
                                    }
                                    "Mortuary Embalming & Preservation Treatment" -> {
                                        selectedCategory = ActivityCategory.EMBALMING_PREPARATION
                                        selectedStage = FuneralArrangementStage.INTAKE_MORTUARY
                                        allowanceText = "5000"
                                        assignedEquipment = "Hydraulic Embalming Station & Sanitized Kit"
                                    }
                                    "Bereaved Family Service Consultation & Program" -> {
                                        selectedCategory = ActivityCategory.SALES_CONSULTATION
                                        selectedStage = FuneralArrangementStage.FAMILY_PLANNING
                                        allowanceText = "3000"
                                        location = "Siaya Shell Consultation Suite"
                                    }
                                    "President Royal Oak Casket Assembly & Lining" -> {
                                        selectedCategory = ActivityCategory.CASKET_FITTING
                                        selectedStage = FuneralArrangementStage.CASKET_FLORALS
                                        allowanceText = "4000"
                                        location = "Bama Central Workshop"
                                        assignedEquipment = "Velvet Lining Stitcher & Brass Handle Jig"
                                    }
                                    "VIP Hearse Escort Departure & Procession" -> {
                                        selectedCategory = ActivityCategory.FLEET_TRANSPORT
                                        selectedStage = FuneralArrangementStage.FLEET_CORTEGE
                                        allowanceText = "4500"
                                        assignedHearse = "KDG 705Y"
                                        assignedEquipment = "Cortege Flags & PA Sound Horns"
                                    }
                                    "Church / Chapel Vigil & Sound Setup" -> {
                                        selectedCategory = ActivityCategory.CHAPEL_SERVICE
                                        selectedStage = FuneralArrangementStage.CHAPEL_VIGIL
                                        allowanceText = "2500"
                                        assignedEquipment = "Church Trolley Bier #02, Condolence Book Stand & PA"
                                    }
                                    "Gravesite Excavation Check & Lowering Gear Rigging" -> {
                                        selectedCategory = ActivityCategory.GRAVESITE_SETUP
                                        selectedStage = FuneralArrangementStage.GRAVESITE_LOWERING
                                        allowanceText = "3500"
                                        assignedEquipment = "Lowering Gear #LG-01, 16 Brass Stunchions & Red Carpet"
                                    }
                                    "Post-Burial Repatriation & Equipment Check-in" -> {
                                        selectedCategory = ActivityCategory.ADMIN_INVENTORY
                                        selectedStage = FuneralArrangementStage.DEBRIEF_COMPLETION
                                        allowanceText = "2000"
                                        location = "Bama Headquarters Depot"
                                    }
                                }
                            },
                            label = { Text(preset, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Arrangement Stage Selector
                Text("Arrangement Stage:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                ExposedDropdownMenuBox(
                    expanded = stageExpanded,
                    onExpandedChange = { stageExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedStage.label,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = stageExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue800,
                            unfocusedBorderColor = Blue200
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = stageExpanded,
                        onDismissRequest = { stageExpanded = false }
                    ) {
                        FuneralArrangementStage.values().forEach { stg ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(stg.label, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(stg.description, fontSize = 10.sp, color = Color(0xFF64748B))
                                    }
                                },
                                onClick = {
                                    selectedStage = stg
                                    stageExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Priority Selection
                Text("Task Priority:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TaskPriority.values().forEach { p ->
                        FilterChip(
                            selected = selectedPriority == p,
                            onClick = { selectedPriority = p },
                            label = { Text(p.label, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(p.colorHex),
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Activity Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task / Arrangement Title") },
                    placeholder = { Text("e.g. Lowering Gear Rigging & Gravesite Preparation") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue800,
                        unfocusedBorderColor = Blue200
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Case Reference & Client Family
                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = caseReference,
                        onValueChange = { caseReference = it },
                        label = { Text("Case Ref #") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = clientFamily,
                        onValueChange = { clientFamily = it },
                        label = { Text("Family Name") },
                        placeholder = { Text("Late Mzee Omondi") },
                        modifier = Modifier.weight(1.3f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Location
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Location / Chapel / Cemetery") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = Blue800)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Assigned Hearse Fleet (Optional)
                Text("Assigned Hearse Fleet (Optional):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                ExposedDropdownMenuBox(
                    expanded = hearseExpanded,
                    onExpandedChange = { hearseExpanded = it }
                ) {
                    OutlinedTextField(
                        value = assignedHearse?.let { "Hearse $it (VIP Cortege)" } ?: "No Vehicle Assigned",
                        onValueChange = {},
                        readOnly = true,
                        leadingIcon = { Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Blue800) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = hearseExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = hearseExpanded,
                        onDismissRequest = { hearseExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("None (Workshop / Stationary Duty)", fontSize = 12.sp) },
                            onClick = {
                                assignedHearse = null
                                hearseExpanded = false
                            }
                        )
                        JABIMA_FLEET.forEach { v ->
                            DropdownMenuItem(
                                text = { Text("Fleet $v (Hearse Escort)", fontSize = 12.sp) },
                                onClick = {
                                    assignedHearse = v
                                    hearseExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Assigned Equipment
                OutlinedTextField(
                    value = assignedEquipment,
                    onValueChange = { assignedEquipment = it },
                    label = { Text("Funeral Equipment Assigned") },
                    leadingIcon = { Icon(Icons.Default.Build, contentDescription = null, tint = Blue800) },
                    placeholder = { Text("Lowering Gear #LG-01, Church Trolley Bier, Red Carpet...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Date & Time
                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("Date") },
                        leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Blue800) },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("Time") },
                        leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null, tint = Blue800) },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Duration & Allowance
                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = durationMinutesText,
                        onValueChange = { durationMinutesText = it },
                        label = { Text("Duration (min)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = allowanceText,
                        onValueChange = { allowanceText = it },
                        label = { Text("Allowance (KES)") },
                        leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = null, tint = Color(0xFF059669)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1.2f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Progress Notes & Protocols") },
                    placeholder = { Text("Protocol instructions, checklist remarks, special family wishes...") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 4
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Cancel", color = Blue900)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            if (title.isBlank()) {
                                errorMessage = "Please enter an activity title"
                                return@Button
                            }
                            val duration = durationMinutesText.toIntOrNull() ?: 60
                            val allowance = allowanceText.toDoubleOrNull() ?: 0.0

                            // Default checklist items based on arrangement stage
                            val defaultChecklist = when (selectedStage) {
                                FuneralArrangementStage.INTAKE_MORTUARY -> listOf("Family consultation & intake logged", "Burial permit statutory forms verified", "Service program itinerary scheduled")
                                FuneralArrangementStage.FAMILY_PLANNING -> listOf("Casket selection finalized", "Program order of service verified", "Floral tributes coordinated with family")
                                FuneralArrangementStage.CASKET_FLORALS -> listOf("Hardwood joinery & bevels inspected", "Velvet interior lining fitted", "Brass plate engraving checked")
                                FuneralArrangementStage.FLEET_CORTEGE -> listOf("Hearse fueled & washed", "Cortege flags & PA horns mounted", "Motorcade speed escort briefing")
                                FuneralArrangementStage.CHAPEL_VIGIL -> listOf("Church trolley bier placed", "Sound system & microphones tested", "Condolence book & pens staged")
                                FuneralArrangementStage.GRAVESITE_LOWERING -> listOf("Grave excavation depth inspected", "Hydraulic lowering straps tested", "16 Brass stunchions & red carpet rigged")
                                FuneralArrangementStage.DEBRIEF_COMPLETION -> listOf("Equipment sanitized & returned to base", "Hearse post-trip inspection logged", "Family condolence debrief signed")
                            }

                            if (onSubmitFuneralTask != null) {
                                val newTask = StaffActivity(
                                    id = "ACT-" + System.currentTimeMillis().toString().takeLast(6),
                                    staffId = "STAFF-LOG",
                                    staffName = "Duty Personnel",
                                    department = selectedCategory.let {
                                        when (it) {
                                            ActivityCategory.WORKSHOP_PRODUCTION, ActivityCategory.CASKET_FITTING -> com.example.model.Department.WORKSHOP
                                            ActivityCategory.FLEET_TRANSPORT -> com.example.model.Department.DRIVERS
                                            ActivityCategory.GRAVESITE_SETUP, ActivityCategory.OPERATOR_SETUP -> com.example.model.Department.OPERATORS
                                            ActivityCategory.SALES_CONSULTATION, ActivityCategory.CASE_HANDLING -> com.example.model.Department.SALES_MARKETING
                                            else -> com.example.model.Department.ADMINISTRATION
                                        }
                                    },
                                    category = selectedCategory,
                                    title = title,
                                    caseReference = caseReference,
                                    clientFamily = clientFamily,
                                    location = location,
                                    date = date,
                                    time = time,
                                    durationMinutes = duration,
                                    status = com.example.model.ActivityStatus.SCHEDULED,
                                    notes = notes,
                                    allowanceEarned = allowance,
                                    verifiedByAdmin = false,
                                    arrangementStage = selectedStage,
                                    priority = selectedPriority,
                                    assignedVehicle = assignedHearse,
                                    assignedEquipment = assignedEquipment.ifBlank { null },
                                    checklistItems = defaultChecklist,
                                    completedChecklistItems = emptyList()
                                )
                                onSubmitFuneralTask(newTask)
                            } else {
                                onSubmit(
                                    selectedCategory,
                                    title,
                                    caseReference,
                                    clientFamily,
                                    location,
                                    date,
                                    time,
                                    duration,
                                    notes,
                                    allowance
                                )
                            }
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("submit_activity_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Record Daily Task")
                    }
                }
            }
        }
    }
}
