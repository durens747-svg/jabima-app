package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JABIMA_BRANCHES
import com.example.model.JABIMA_FLEET
import com.example.model.StockMovementRecord
import com.example.model.StockMovementStatus
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.Blue100
import com.example.ui.theme.Blue200
import com.example.ui.theme.Blue50
import com.example.ui.theme.Blue700
import com.example.ui.theme.Blue800
import com.example.ui.theme.Blue900
import com.example.ui.theme.Blue950
import com.example.ui.theme.PureWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockMovementScreen(
    viewModel: StaffPortalViewModel,
    modifier: Modifier = Modifier
) {
    val stockMovements by viewModel.stockMovements.collectAsState()
    val isManagerAuthorized = viewModel.isInventoryManagerAuthorized()
    val currentAccount by viewModel.currentAccount.collectAsState()

    var statusFilter by remember { mutableStateOf<StockMovementStatus?>(null) }
    var branchFilter by remember { mutableStateOf<String?>(null) }
    var showNewRequestDialog by remember { mutableStateOf(false) }

    val filteredList = stockMovements.filter { record ->
        val matchesStatus = statusFilter == null || record.status == statusFilter
        val matchesBranch = branchFilter == null || record.sourceBranch == branchFilter || record.destinationBranch == branchFilter
        matchesStatus && matchesBranch
    }

    val pendingCount = stockMovements.count { it.status == StockMovementStatus.PENDING_AUTHORIZATION }
    val inTransitCount = stockMovements.count { it.status == StockMovementStatus.IN_TRANSIT }
    val authorizedCount = stockMovements.count { it.status == StockMovementStatus.AUTHORIZED }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) {
        // HEADER CARD
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Blue900),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("stock_movement_header_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocalShipping,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Inter-Branch Stock Movement",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                                Text(
                                    text = "Logistics Oversight Across 8 Branches",
                                    color = Blue100,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.showUploadStockDialog.value = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF0D9488),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("upload_stock_intake_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Inventory,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Upload Stock", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { showNewRequestDialog = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Blue900
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("request_stock_movement_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Transfer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // INVENTORY MANAGER SOLE AUTHORITY BANNER
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isManagerAuthorized) Color.White.copy(alpha = 0.15f) else Color(0xFF1E3A8A).copy(alpha = 0.6f),
                        border = BorderStroke(1.dp, if (isManagerAuthorized) Color(0xFF60A5FA) else Color(0xFF3B82F6)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isManagerAuthorized) Icons.Default.Security else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (isManagerAuthorized) Color(0xFF93C5FD) else Color(0xFFBFDBFE),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isManagerAuthorized)
                                        "AUTHORIZATION AUTHORITY: Inventory Manager"
                                    else
                                        "RESTRICTED AUTHORITY: Inventory Manager Sole Right",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = if (isManagerAuthorized)
                                        "You are signed in as an authorized Inventory Authority (${currentAccount?.fullName ?: "Brian Adoche / CEO"}). You have sole authority to approve or reject stock movements."
                                    else
                                        "Per company regulations, an Inventory Manager has the sole authority of authorizing the movements between branches.",
                                    color = Blue100,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // STATS ROW
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatCard(
                            label = "Pending Auth",
                            count = pendingCount,
                            color = Color(0xFF93C5FD),
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            label = "Authorized",
                            count = authorizedCount,
                            color = Color.White,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            label = "In Transit",
                            count = inTransitCount,
                            color = Color(0xFF60A5FA),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // FILTER CHIPS (STATUS)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Filter by Transfer State",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Blue900
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = statusFilter == null,
                            onClick = { statusFilter = null },
                            label = { Text("All Transfers (${stockMovements.size})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                    items(StockMovementStatus.values()) { st ->
                        val count = stockMovements.count { it.status == st }
                        FilterChip(
                            selected = statusFilter == st,
                            onClick = { statusFilter = if (statusFilter == st) null else st },
                            label = { Text("${st.label} ($count)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                }
            }
        }

        // TRANSFER CARDS LIST
        if (filteredList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = Blue50),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Inventory,
                            contentDescription = null,
                            tint = Blue700,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No stock movement records found for this filter.",
                            color = Blue900,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        } else {
            items(filteredList, key = { it.id }) { record ->
                StockMovementCard(
                    record = record,
                    isManagerAuthorized = isManagerAuthorized,
                    onAuthorize = { viewModel.authorizeStockMovement(record.id) },
                    onReject = { viewModel.rejectStockMovement(record.id) },
                    onDispatch = { viewModel.markStockInTransit(record.id) },
                    onDelivered = { viewModel.markStockDelivered(record.id) }
                )
            }
        }
    }

    if (showNewRequestDialog) {
        NewStockMovementDialog(
            onDismiss = { showNewRequestDialog = false },
            onSubmit = { item, cat, qty, src, dest, veh, driver, urgency, notes ->
                viewModel.requestStockMovement(item, cat, qty, src, dest, veh, driver, urgency, notes)
                showNewRequestDialog = false
            }
        )
    }
}

@Composable
private fun StatCard(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White.copy(alpha = 0.12f),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$count", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = label, fontSize = 9.sp, color = Blue100, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun StockMovementCard(
    record: StockMovementRecord,
    isManagerAuthorized: Boolean,
    onAuthorize: () -> Unit,
    onReject: () -> Unit,
    onDispatch: () -> Unit,
    onDelivered: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, Blue200),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("stock_card_${record.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: ID, Category, Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = record.id,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Blue900
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(Blue50, RoundedCornerShape(4.dp))
                            .border(1.dp, Blue200, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = record.category,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Blue800
                        )
                    }
                }

                // Status Chip
                val (stBg, stFg) = when (record.status) {
                    StockMovementStatus.PENDING_AUTHORIZATION -> Blue50 to Blue800
                    StockMovementStatus.AUTHORIZED -> Blue100 to Blue900
                    StockMovementStatus.IN_TRANSIT -> Color(0xFFDBEAFE) to Color(0xFF1D4ED8)
                    StockMovementStatus.DELIVERED -> Color(0xFFEFF6FF) to Color(0xFF1E3A8A)
                    StockMovementStatus.REJECTED -> Color(0xFFF1F5F9) to Color(0xFF475569)
                }

                Box(
                    modifier = Modifier
                        .background(stBg, RoundedCornerShape(6.dp))
                        .border(1.dp, stFg.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = record.status.label,
                        color = stFg,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Item Name & Quantity
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = record.itemName,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Blue950,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .background(Blue800, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "Qty: ${record.quantity}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Branch Routing: Source -> Destination
            Surface(
                color = Blue50,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Blue100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("FROM (ORIGIN)", fontSize = 8.sp, color = Blue700, fontWeight = FontWeight.Bold)
                        Text(record.sourceBranch, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Blue900)
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Blue800,
                        modifier = Modifier.size(16.dp)
                    )
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                        Text("TO (DESTINATION)", fontSize = 8.sp, color = Blue700, fontWeight = FontWeight.Bold)
                        Text(record.destinationBranch, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Blue900)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Transport Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Blue700, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${record.assignedVehicle} • Driver: ${record.assignedDriverName}",
                        fontSize = 11.sp,
                        color = Blue900,
                        fontWeight = FontWeight.Medium
                    )
                }
                Text(
                    text = record.urgency,
                    fontSize = 10.sp,
                    color = Blue800,
                    fontWeight = FontWeight.Bold
                )
            }

            // Authorization Footnote or Pending Note
            Spacer(modifier = Modifier.height(6.dp))
            if (record.authorizedByManagerName != null) {
                Surface(
                    color = Blue50,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, Blue200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Authorized by: ${record.authorizedByManagerName} (${record.authorizationTimestamp ?: ""})",
                            fontSize = 10.sp,
                            color = Blue900,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else if (record.status == StockMovementStatus.PENDING_AUTHORIZATION) {
                Surface(
                    color = Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, Color(0xFF93C5FD)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Sole Authority: Pending Inventory Manager review & authorization",
                            fontSize = 10.sp,
                            color = Blue800,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // ACTIONS
            Spacer(modifier = Modifier.height(10.dp))
            when (record.status) {
                StockMovementStatus.PENDING_AUTHORIZATION -> {
                    if (isManagerAuthorized) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onAuthorize,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Blue800,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("authorize_transfer_${record.id}")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Authorize Transfer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = onReject,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Blue900),
                                border = BorderStroke(1.dp, Blue700),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("reject_transfer_${record.id}")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reject", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Text(
                            text = "Login as Brian Adoche (Inventory Manager) or CEO to authorize this transfer.",
                            fontSize = 10.sp,
                            color = Blue700,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                StockMovementStatus.AUTHORIZED -> {
                    Button(
                        onClick = onDispatch,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Blue700,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dispatch_transfer_${record.id}")
                    ) {
                        Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Dispatch & Mark In Transit", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                StockMovementStatus.IN_TRANSIT -> {
                    Button(
                        onClick = onDelivered,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Blue900,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("deliver_transfer_${record.id}")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Confirm Arrival & Stocked", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                StockMovementStatus.DELIVERED -> {
                    Text(
                        text = "Delivered to destination branch and verified in stock.",
                        fontSize = 10.sp,
                        color = Blue800,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                StockMovementStatus.REJECTED -> {
                    Text(
                        text = "Movement declined by Inventory Manager.",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B),
                        fontWeight = FontWeight.Normal
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewStockMovementDialog(
    onDismiss: () -> Unit,
    onSubmit: (
        itemName: String,
        category: String,
        quantity: Int,
        sourceBranch: String,
        destinationBranch: String,
        assignedVehicle: String,
        assignedDriverName: String,
        urgency: String,
        notes: String
    ) -> Unit
) {
    var itemName by remember { mutableStateOf("Imperial Hardwood Mahogany Casket") }
    var category by remember { mutableStateOf("Caskets & Coffins") }
    var quantityText by remember { mutableStateOf("1") }
    var sourceBranch by remember { mutableStateOf(JABIMA_BRANCHES[6]) } // Siaya Referral
    var destinationBranch by remember { mutableStateOf(JABIMA_BRANCHES[1]) } // Bondo
    var assignedVehicle by remember { mutableStateOf(JABIMA_FLEET[0]) } // KDG 705Y
    var assignedDriver by remember { mutableStateOf("Victor Owino") }
    var urgency by remember { mutableStateOf("Routine Restock") }
    var notes by remember { mutableStateOf("") }

    var srcExpanded by remember { mutableStateOf(false) }
    var destExpanded by remember { mutableStateOf(false) }
    var fleetExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Blue800)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Request Stock Movement", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Blue900)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Requires Inventory Manager sole authorization before dispatch.",
                    fontSize = 11.sp,
                    color = Blue700,
                    fontWeight = FontWeight.Medium
                )

                OutlinedTextField(
                    value = itemName,
                    onValueChange = { itemName = it },
                    label = { Text("Item / Equipment Description") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue800,
                        focusedLabelColor = Blue800
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category") },
                        modifier = Modifier.weight(1.5f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue800,
                            focusedLabelColor = Blue800
                        )
                    )
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Quantity") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue800,
                            focusedLabelColor = Blue800
                        )
                    )
                }

                // Source Branch
                ExposedDropdownMenuBox(
                    expanded = srcExpanded,
                    onExpandedChange = { srcExpanded = !srcExpanded }
                ) {
                    OutlinedTextField(
                        value = sourceBranch,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Origin Branch") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = srcExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = srcExpanded,
                        onDismissRequest = { srcExpanded = false }
                    ) {
                        JABIMA_BRANCHES.forEach { b ->
                            DropdownMenuItem(
                                text = { Text(b) },
                                onClick = {
                                    sourceBranch = b
                                    srcExpanded = false
                                }
                            )
                        }
                    }
                }

                // Destination Branch
                ExposedDropdownMenuBox(
                    expanded = destExpanded,
                    onExpandedChange = { destExpanded = !destExpanded }
                ) {
                    OutlinedTextField(
                        value = destinationBranch,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Destination Branch") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = destExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = destExpanded,
                        onDismissRequest = { destExpanded = false }
                    ) {
                        JABIMA_BRANCHES.forEach { b ->
                            DropdownMenuItem(
                                text = { Text(b) },
                                onClick = {
                                    destinationBranch = b
                                    destExpanded = false
                                }
                            )
                        }
                    }
                }

                // Vehicle Assignment
                ExposedDropdownMenuBox(
                    expanded = fleetExpanded,
                    onExpandedChange = { fleetExpanded = !fleetExpanded }
                ) {
                    OutlinedTextField(
                        value = assignedVehicle,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Assigned Fleet Hearse/Van") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = fleetExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = fleetExpanded,
                        onDismissRequest = { fleetExpanded = false }
                    ) {
                        JABIMA_FLEET.forEach { v ->
                            DropdownMenuItem(
                                text = { Text(v) },
                                onClick = {
                                    assignedVehicle = v
                                    fleetExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = assignedDriver,
                    onValueChange = { assignedDriver = it },
                    label = { Text("Driver Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Reason / Transfer Justification") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantityText.toIntOrNull() ?: 1
                    onSubmit(itemName, category, qty, sourceBranch, destinationBranch, assignedVehicle, assignedDriver, urgency, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Submit Request")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Blue900)
            }
        },
        containerColor = PureWhite,
        shape = RoundedCornerShape(16.dp)
    )
}
