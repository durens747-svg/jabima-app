package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AlertFilterCategory
import com.example.model.StaffAccount
import com.example.model.StaffAlertNotification
import com.example.model.StaffShiftSchedule
import com.example.model.TaskPriority
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.Blue100
import com.example.ui.theme.Blue200
import com.example.ui.theme.Blue50
import com.example.ui.theme.Blue700
import com.example.ui.theme.Blue800
import com.example.ui.theme.Blue900
import com.example.ui.theme.Blue950
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedLight

/**
 * Shift & Operations Alert System Hub.
 * Supports scanning due shifts/tasks for automatic standby alerts, broadcasting manual
 * shift alerts with optional Bulk SMS escalation, filtering by Shift/Task/Unread,
 * and acknowledging or dismissing alerts.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShiftAlertCenterDialog(
    alerts: List<StaffAlertNotification>,
    staffAccounts: List<StaffAccount>,
    shiftSchedules: List<StaffShiftSchedule>,
    prefilledStaffId: String? = null,
    prefilledShiftId: String? = null,
    onScanDueShifts: () -> Unit,
    onMarkAllRead: () -> Unit,
    onAcknowledgeAlert: (String) -> Unit,
    onDismissAlert: (String) -> Unit,
    onDispatchShiftAlert: (
        staffId: String,
        title: String,
        message: String,
        priority: TaskPriority,
        shiftId: String?,
        scheduledTimeLabel: String?,
        branch: String?,
        sendSmsAlso: Boolean
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val unreadCount = alerts.count { !it.isRead }
    var activeFilter by remember { mutableStateOf(AlertFilterCategory.ALL) }
    var showComposer by remember(prefilledStaffId, prefilledShiftId) {
        mutableStateOf(prefilledStaffId != null || prefilledShiftId != null)
    }

    val prefilledShift = remember(prefilledShiftId, shiftSchedules) {
        prefilledShiftId?.let { id -> shiftSchedules.firstOrNull { it.id == id } }
    }
    var selectedStaff by remember(prefilledStaffId, staffAccounts) {
        mutableStateOf(
            staffAccounts.firstOrNull { it.id == (prefilledStaffId ?: prefilledShift?.staffId) }
                ?: staffAccounts.firstOrNull()
        )
    }
    var staffDropdownExpanded by remember { mutableStateOf(false) }
    var alertPriority by remember { mutableStateOf(TaskPriority.HIGH) }
    var alertTitle by remember(prefilledShift) {
        mutableStateOf(
            if (prefilledShift != null) "Shift Readiness Callout: ${prefilledShift.shiftType}"
            else ""
        )
    }
    var alertMessage by remember(prefilledShift) {
        mutableStateOf(
            if (prefilledShift != null) {
                "Report to ${prefilledShift.assignedBranch} (${prefilledShift.startTime}–${prefilledShift.endTime}). Hearse: ${prefilledShift.hearseAssigned ?: "Standard Duty"}."
            } else {
                ""
            }
        )
    }
    var sendSmsToo by remember { mutableStateOf(true) }

    val filteredAlerts = remember(alerts, activeFilter) {
        when (activeFilter) {
            AlertFilterCategory.ALL -> alerts
            AlertFilterCategory.SHIFT -> alerts.filter { it.category == "SHIFT_ALERT" || it.shiftId != null }
            AlertFilterCategory.TASK -> alerts.filter { it.category != "SHIFT_ALERT" && it.shiftId == null }
            AlertFilterCategory.UNREAD -> alerts.filter { !it.isRead }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = PureWhite,
            tonalElevation = 6.dp,
            shadowElevation = 10.dp,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .widthIn(max = 620.dp)
                .heightIn(max = 760.dp)
                .testTag("shift_alert_center_dialog")
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Surface(color = Navy900, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFF59E0B).copy(alpha = 0.22f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = "Shift Alert System",
                                    tint = Color(0xFFFBBF24),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Shift & Operations Alert Center",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "$unreadCount unread • ${alerts.size} total shift & duty notifications",
                                    color = Blue200,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("close_shift_alert_center")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Alert Center",
                                tint = Color.White
                            )
                        }
                    }
                }

                // Controls Strip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Blue50)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onScanDueShifts,
                        colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_scan_due_shifts")
                    ) {
                        Icon(Icons.Default.Radar, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(5.dp))
                        Text("Scan Due Shifts", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }

                    Button(
                        onClick = { showComposer = !showComposer },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (showComposer) Navy900 else Color(0xFFF59E0B),
                            contentColor = if (showComposer) Color.White else Navy900
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_toggle_broadcast_alert")
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (showComposer) "Hide Composer" else "Broadcast Alert",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            softWrap = false
                        )
                    }

                    if (unreadCount > 0) {
                        OutlinedButton(
                            onClick = onMarkAllRead,
                            border = BorderStroke(1.dp, EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_mark_all_alerts_read")
                        ) {
                            Icon(Icons.Default.DoneAll, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Acknowledge All", fontSize = 11.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }

                // Filter Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AlertFilterCategory.values().forEach { cat ->
                        val count = when (cat) {
                            AlertFilterCategory.ALL -> alerts.size
                            AlertFilterCategory.SHIFT -> alerts.count { it.category == "SHIFT_ALERT" || it.shiftId != null }
                            AlertFilterCategory.TASK -> alerts.count { it.category != "SHIFT_ALERT" && it.shiftId == null }
                            AlertFilterCategory.UNREAD -> unreadCount
                        }
                        FilterChip(
                            selected = activeFilter == cat,
                            onClick = { activeFilter = cat },
                            label = {
                                Text(
                                    text = "${cat.label} ($count)",
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            ),
                            modifier = Modifier.testTag("alert_filter_${cat.name.lowercase()}")
                        )
                    }
                }

                HorizontalDivider(color = Blue100)

                // Body: Optional Composer + Alert Feed
                LazyColumn(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (showComposer) {
                        item {
                            Surface(
                                color = Blue50,
                                border = BorderStroke(1.dp, Blue200),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("shift_alert_composer_card")
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "Dispatch Manual Shift Alert",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Blue950
                                    )

                                    ExposedDropdownMenuBox(
                                        expanded = staffDropdownExpanded,
                                        onExpandedChange = { staffDropdownExpanded = !staffDropdownExpanded }
                                    ) {
                                        OutlinedTextField(
                                            value = selectedStaff?.let { "${it.fullName} (${it.role.title} • ${it.branch})" } ?: "Select Staff",
                                            onValueChange = {},
                                            readOnly = true,
                                            label = { Text("Recipient Staff*", fontSize = 11.sp) },
                                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = staffDropdownExpanded) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                        )
                                        ExposedDropdownMenu(
                                            expanded = staffDropdownExpanded,
                                            onDismissRequest = { staffDropdownExpanded = false }
                                        ) {
                                            staffAccounts.forEach { acc ->
                                                DropdownMenuItem(
                                                    text = { Text("${acc.fullName} • ${acc.department.displayName}", fontSize = 12.sp) },
                                                    onClick = {
                                                        selectedStaff = acc
                                                        staffDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        TaskPriority.values().forEach { prio ->
                                            FilterChip(
                                                selected = alertPriority == prio,
                                                onClick = { alertPriority = prio },
                                                label = {
                                                    Text(
                                                        text = prio.label,
                                                        fontSize = 10.sp,
                                                        maxLines = 1,
                                                        softWrap = false
                                                    )
                                                }
                                            )
                                        }
                                    }

                                    OutlinedTextField(
                                        value = alertTitle,
                                        onValueChange = { alertTitle = it },
                                        label = { Text("Alert Title*", fontSize = 11.sp) },
                                        placeholder = { Text("e.g. Urgent Hearse Dispatch Check-In", fontSize = 11.sp) },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("shift_alert_title_input")
                                    )

                                    OutlinedTextField(
                                        value = alertMessage,
                                        onValueChange = { alertMessage = it },
                                        label = { Text("Alert Instructions*", fontSize = 11.sp) },
                                        placeholder = { Text("Specify shift timing, vehicle plate, or standby location", fontSize = 11.sp) },
                                        maxLines = 2,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("shift_alert_message_input")
                                    )

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { sendSmsToo = !sendSmsToo }
                                    ) {
                                        Checkbox(
                                            checked = sendSmsToo,
                                            onCheckedChange = { sendSmsToo = it },
                                            colors = CheckboxDefaults.colors(checkedColor = EmeraldSuccess)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Also dispatch SMS Alert to staff phone",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Blue950
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            val target = selectedStaff ?: return@Button
                                            onDispatchShiftAlert(
                                                target.id,
                                                alertTitle.ifBlank { "Shift Readiness Callout (${target.department.displayName})" },
                                                alertMessage.ifBlank { "Please report ready for assigned shift at ${target.branch}." },
                                                alertPriority,
                                                prefilledShift?.id,
                                                prefilledShift?.let { "${it.startTime}–${it.endTime}" },
                                                prefilledShift?.assignedBranch ?: target.branch,
                                                sendSmsToo
                                            )
                                            alertTitle = ""
                                            alertMessage = ""
                                            showComposer = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess, contentColor = Color.White),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 48.dp)
                                            .testTag("btn_submit_shift_alert")
                                    ) {
                                        Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Send Shift Alert", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                        }
                    }

                    if (filteredAlerts.isEmpty()) {
                        item {
                            Surface(
                                color = Blue50,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "No Alerts in This Filter",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Blue950
                                    )
                                    Text(
                                        text = "Use 'Scan Due Shifts' to check upcoming shifts for today.",
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }
                            }
                        }
                    } else {
                        items(filteredAlerts, key = { it.id }) { alert ->
                            ShiftAlertNotificationCard(
                                alert = alert,
                                onAcknowledge = { onAcknowledgeAlert(alert.id) },
                                onDismiss = { onDismissAlert(alert.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShiftAlertNotificationCard(
    alert: StaffAlertNotification,
    onAcknowledge: () -> Unit,
    onDismiss: () -> Unit
) {
    val prioColor = when (alert.priority) {
        TaskPriority.URGENT -> StrokeRed
        TaskPriority.HIGH -> AmberWarning
        TaskPriority.NORMAL -> Blue700
    }
    val cardBg = if (!alert.isRead) {
        if (alert.priority == TaskPriority.URGENT) StrokeRedLight.copy(alpha = 0.4f) else AmberLight.copy(alpha = 0.45f)
    } else {
        PureWhite
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = cardBg,
        border = BorderStroke(1.dp, if (!alert.isRead) prioColor.copy(alpha = 0.5f) else Blue100),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("alert_card_${alert.id}")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (!alert.isRead) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(prioColor)
                        )
                    }
                    Surface(
                        color = prioColor.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(5.dp)
                    ) {
                        Text(
                            text = if (alert.category == "SHIFT_ALERT") "SHIFT • ${alert.priority.label}" else alert.category,
                            color = prioColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    if (alert.smsDispatched) {
                        Surface(
                            color = EmeraldLight,
                            shape = RoundedCornerShape(5.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Sms, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(10.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("SMS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                            }
                        }
                    }
                }

                Text(
                    text = alert.timestamp,
                    fontSize = 10.sp,
                    color = Color(0xFF64748B),
                    maxLines = 1,
                    softWrap = false
                )
            }

            Text(
                text = alert.title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Blue950
            )
            Text(
                text = "To: ${alert.recipientName}${if (!alert.branch.isNullOrBlank()) " • ${alert.branch}" else ""}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Blue800
            )
            if (!alert.scheduledTimeLabel.isNullOrBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = Blue700, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Scheduled Slot: ${alert.scheduledTimeLabel}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Blue700
                    )
                }
            }
            Text(
                text = alert.message,
                fontSize = 11.sp,
                color = Color(0xFF334155),
                lineHeight = 15.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!alert.isRead) {
                    TextButton(
                        onClick = onAcknowledge,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("btn_ack_alert_${alert.id}")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Acknowledge", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess, maxLines = 1, softWrap = false)
                    }
                } else if (!alert.acknowledgedAt.isNullOrBlank()) {
                    Text(
                        text = "Acknowledged",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = EmeraldSuccess,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
                TextButton(
                    onClick = onDismiss,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.testTag("btn_dismiss_alert_${alert.id}")
                ) {
                    Text("Dismiss", fontSize = 11.sp, color = Color(0xFF64748B), maxLines = 1, softWrap = false)
                }
            }
        }
    }
}
