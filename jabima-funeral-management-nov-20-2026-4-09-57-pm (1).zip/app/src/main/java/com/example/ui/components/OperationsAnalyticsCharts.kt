package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FleetGpsVehicle
import com.example.model.WorkshopProductionItem
import com.example.model.WorkshopProductionStage
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextMuted

@Composable
fun OperationsAnalyticsCharts(
    workshopItems: List<WorkshopProductionItem>,
    fleetVehicles: List<FleetGpsVehicle>,
    modifier: Modifier = Modifier
) {
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, BorderLight),
        shadowElevation = 2.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("operations_analytics_charts_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BarChart,
                        contentDescription = null,
                        tint = ForestGreenPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "EXECUTIVE OPERATIONAL VISUAL METRICS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ForestGreenPrimary,
                        letterSpacing = 0.5.sp
                    )
                }
                Text(
                    text = "Real-Time Telemetry",
                    fontSize = 10.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Two-column layout: Workshop 4-Stage Distribution + Fleet Readiness Dials
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 1. Workshop 4-Stage Distribution
                WorkshopStageDistributionChart(
                    items = workshopItems,
                    modifier = Modifier.weight(1.3f)
                )

                // 2. Fleet Readiness & Fuel Gauges
                FleetReadinessDialChart(
                    vehicles = fleetVehicles,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun WorkshopStageDistributionChart(
    items: List<WorkshopProductionItem>,
    modifier: Modifier = Modifier
) {
    val stage1Count = items.count { it.currentStage == WorkshopProductionStage.FRAME_AND_ASSEMBLY }
    val stage2Count = items.count { it.currentStage == WorkshopProductionStage.SANDING_AND_PAINTING }
    val stage3Count = items.count { it.currentStage == WorkshopProductionStage.CLOTH_LINING_AND_FINAL_ASSEMBLY }
    val stage4Count = items.count { it.currentStage == WorkshopProductionStage.GLASS_FITTING }
    val total = (stage1Count + stage2Count + stage3Count + stage4Count).coerceAtLeast(1)

    Surface(
        color = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, BorderLight),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PrecisionManufacturing,
                        contentDescription = null,
                        tint = CyanPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Workshop 4 Stages",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Navy900
                    )
                }
                Text(
                    text = "${items.size} Caskets in Craft",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanPrimary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Segmented Bar with Native Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(14.dp)
            ) {
                val cornerRadius = 6.dp.toPx()
                var currentX = 0f
                val totalWidth = size.width

                val p1 = (stage1Count.toFloat() / total) * totalWidth
                val p2 = (stage2Count.toFloat() / total) * totalWidth
                val p3 = (stage3Count.toFloat() / total) * totalWidth
                val p4 = (stage4Count.toFloat() / total) * totalWidth

                // Stage 1 (Frame) - Blue
                drawRect(
                    color = Color(0xFF2563EB),
                    topLeft = Offset(currentX, 0f),
                    size = Size(p1, size.height)
                )
                currentX += p1

                // Stage 2 (Sanding) - Amber
                drawRect(
                    color = Color(0xFFD97706),
                    topLeft = Offset(currentX, 0f),
                    size = Size(p2, size.height)
                )
                currentX += p2

                // Stage 3 (Cloth Lining) - Purple
                drawRect(
                    color = Color(0xFF7C3AED),
                    topLeft = Offset(currentX, 0f),
                    size = Size(p3, size.height)
                )
                currentX += p3

                // Stage 4 (Glass Fitting) - Emerald
                drawRect(
                    color = Color(0xFF059669),
                    topLeft = Offset(currentX, 0f),
                    size = Size(p4.coerceAtLeast(totalWidth - currentX), size.height)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Legend labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StageLegendDot("Frame", stage1Count, Color(0xFF2563EB))
                StageLegendDot("Paint", stage2Count, Color(0xFFD97706))
                StageLegendDot("Lining", stage3Count, Color(0xFF7C3AED))
                StageLegendDot("Glass", stage4Count, Color(0xFF059669))
            }
        }
    }
}

@Composable
private fun StageLegendDot(name: String, count: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(color = color, shape = CircleShape, modifier = Modifier.size(6.dp)) {}
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = "$name: $count",
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium,
            color = Navy900
        )
    }
}

@Composable
private fun FleetReadinessDialChart(
    vehicles: List<FleetGpsVehicle>,
    modifier: Modifier = Modifier
) {
    val avgFuel = if (vehicles.isNotEmpty()) vehicles.map { it.fuelPercent }.average().toInt() else 85
    val inspectedCount = vehicles.count { !it.statusLabel.contains("Maintenance", ignoreCase = true) }
    val totalVehicles = vehicles.size.coerceAtLeast(1)
    val inspectionRatio = (inspectedCount.toFloat() / totalVehicles).coerceIn(0f, 1f)

    Surface(
        color = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, BorderLight),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            // Fuel Circular Gauge
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier.size(46.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(44.dp)) {
                        val stroke = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                        // Background track
                        drawArc(
                            color = Color(0xFFE2E8F0),
                            startAngle = 135f,
                            sweepAngle = 270f,
                            useCenter = false,
                            style = stroke
                        )
                        // Progress arc
                        val sweep = 270f * (avgFuel / 100f)
                        drawArc(
                            color = if (avgFuel > 50) EmeraldSuccess else Color(0xFFD97706),
                            startAngle = 135f,
                            sweepAngle = sweep,
                            useCenter = false,
                            style = stroke
                        )
                    }
                    Text(
                        text = "$avgFuel%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Navy900
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Fleet Fuel",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextMuted
                )
            }

            // Inspection Dial
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier.size(46.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(44.dp)) {
                        val stroke = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                        drawArc(
                            color = Color(0xFFE2E8F0),
                            startAngle = 135f,
                            sweepAngle = 270f,
                            useCenter = false,
                            style = stroke
                        )
                        val sweep = 270f * inspectionRatio
                        drawArc(
                            color = ForestGreenPrimary,
                            startAngle = 135f,
                            sweepAngle = sweep,
                            useCenter = false,
                            style = stroke
                        )
                    }
                    Text(
                        text = "$inspectedCount/$totalVehicles",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Navy900
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Inspected",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextMuted
                )
            }
        }
    }
}
