package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BulkSmsMessage
import com.example.model.DEFAULT_SMS_TEMPLATES
import com.example.model.SmsTemplate
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class BulkSmsSubTab(val label: String) {
    COMPOSER("Compose & Broadcast"),
    TEMPLATES("Funeral Templates"),
    TRANSMISSION_LOG("Transmission Log")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkSmsTab(
    viewModel: StaffPortalViewModel
) {
    val messages by viewModel.bulkSmsMessages.collectAsState()
    val gatewayStatus by viewModel.externalGatewayStatus.collectAsState()

    var activeSubTab by remember { mutableStateOf(BulkSmsSubTab.COMPOSER) }

    val senderIds = listOf("JABIMA_LTD", "JABIMA_CORTEGE", "JABIMA_24_7")
    var selectedSenderId by remember { mutableStateOf(senderIds[0]) }

    val recipientGroups = listOf(
        "Client Family Contact",
        "All 8 Branches Dispatch",
        "Workshop Production Team (Bama)",
        "Drivers & Fleet Logistics (Bama)",
        "Operators Grounds Crew (Bama)",
        "Sales & Marketing Team",
        "Custom Phone Number"
    )

    var selectedGroup by remember { mutableStateOf(recipientGroups[0]) }
    var recipientsInput by remember { mutableStateOf("+254 712 345 678") }
    var messageBody by remember {
        mutableStateOf("Jabima Funeral Directors Ltd: We convey our heartfelt condolences. Cortege departure is scheduled for 09:00 AM from Bama Branch base. 24/7 Hotline: +254793553434.")
    }

    var selectedLogFilter by remember { mutableStateOf("All") }

    val charCount = messageBody.length
    val smsUnits = ((charCount - 1) / 160) + 1

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp)
            .testTag("bulk_sms_tab")
    ) {
        // TOP SYSTEM HEADER
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(RoyalCobaltIce),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sms,
                            contentDescription = null,
                            tint = RoyalCobaltBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Bulk SMS Broadcast System",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = ObsidianBlack,
                            modifier = Modifier.testTag("bulk_sms_header_title")
                        )
                        Text(
                            text = gatewayStatus.bulkSmsStatusLabel,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            // GATEWAY STATUS BADGE
            Surface(
                color = if (gatewayStatus.bulkSmsLiveConfigured) EmeraldLight else Color(0xFFFEF3C7),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, if (gatewayStatus.bulkSmsLiveConfigured) Color(0xFFA7F3D0) else Color(0xFFFDE68A))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (gatewayStatus.bulkSmsLiveConfigured) EmeraldSuccess else Color(0xFFD97706),
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (gatewayStatus.bulkSmsLiveConfigured) "Live SMS Gateway" else "Local SMS Log Mode",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (gatewayStatus.bulkSmsLiveConfigured) Color(0xFF065F46) else Color(0xFF92400E),
                        modifier = Modifier.testTag("bulk_sms_gateway_status_badge")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // SMS CREDITS & SENDER ID STRIP
        Surface(
            color = Color(0xFFF8FAFC),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, BorderLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "SMS Credits:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "14,850 Units",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldSuccess
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• Rate: KES 0.40/SMS • 50 SMS/sec throughput",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Sender ID: ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                    senderIds.forEach { id ->
                        val isSel = selectedSenderId == id
                        Surface(
                            color = if (isSel) RoyalCobaltBlue else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                            border = if (!isSel) BorderStroke(1.dp, BorderLight) else null,
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .clickable { selectedSenderId = id }
                                .testTag("sender_id_chip_$id")
                        ) {
                            Text(
                                text = id,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) PureWhite else TextSecondary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // SUB-NAVIGATION TABS (Composer, Templates, Transmission Log)
        ScrollableTabRow(
            selectedTabIndex = activeSubTab.ordinal,
            containerColor = PureWhite,
            contentColor = TextPrimary,
            edgePadding = 0.dp,
            indicator = { tabPositions ->
                if (activeSubTab.ordinal < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[activeSubTab.ordinal]),
                        color = RoyalCobaltBlue,
                        height = 3.dp
                    )
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderLight, RoundedCornerShape(8.dp))
                .clip(RoundedCornerShape(8.dp))
        ) {
            BulkSmsSubTab.values().forEach { tab ->
                val isSelected = activeSubTab == tab
                Tab(
                    selected = isSelected,
                    onClick = { activeSubTab = tab },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = when (tab) {
                                    BulkSmsSubTab.COMPOSER -> Icons.Default.Campaign
                                    BulkSmsSubTab.TEMPLATES -> Icons.Default.ContentCopy
                                    BulkSmsSubTab.TRANSMISSION_LOG -> Icons.Default.MarkEmailRead
                                },
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                                tint = if (isSelected) RoyalCobaltBlue else TextSecondary
                            )
                            Text(
                                text = tab.label,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) RoyalCobaltBlue else TextSecondary,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    modifier = Modifier.testTag("sms_subtab_${tab.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (activeSubTab) {
            BulkSmsSubTab.COMPOSER -> {
                // COMPOSER VIEW
                Card(
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sms_composer_card")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Compose SMS Broadcast",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = ObsidianBlack
                            )

                            // Quick template drop-in helper
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Quick Template: ",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                                var templateMenuExpanded by remember { mutableStateOf(false) }
                                Box {
                                    Surface(
                                        color = RoyalCobaltIce,
                                        shape = RoundedCornerShape(6.dp),
                                        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                                        modifier = Modifier
                                            .clickable { templateMenuExpanded = true }
                                            .testTag("sms_template_selector")
                                    ) {
                                        Text(
                                            text = "Select Preset ▼",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = RoyalCobaltBlue,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }

                                    DropdownMenu(
                                        expanded = templateMenuExpanded,
                                        onDismissRequest = { templateMenuExpanded = false }
                                    ) {
                                        DEFAULT_SMS_TEMPLATES.forEach { tpl ->
                                            DropdownMenuItem(
                                                text = {
                                                    Column {
                                                        Text(tpl.title, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                        Text(tpl.category, fontSize = 9.sp, color = TextSecondary)
                                                    }
                                                },
                                                onClick = {
                                                    messageBody = tpl.bodyTemplate
                                                    templateMenuExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // RECIPIENT GROUP DROPDOWN
                        var groupExpanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(
                            expanded = groupExpanded,
                            onExpandedChange = { groupExpanded = it },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = selectedGroup,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Target Recipient Group", fontSize = 11.sp) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = groupExpanded) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = RoyalCobaltBlue,
                                    unfocusedBorderColor = BorderLight
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                                    .testTag("sms_recipient_group_selector")
                            )
                            ExposedDropdownMenu(
                                expanded = groupExpanded,
                                onDismissRequest = { groupExpanded = false }
                            ) {
                                recipientGroups.forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text(g, fontSize = 11.sp) },
                                        onClick = {
                                            selectedGroup = g
                                            groupExpanded = false
                                            recipientsInput = when (g) {
                                                "Client Family Contact" -> "+254 712 345 678 (Ezekiel Ochieng)"
                                                "All 8 Branches Dispatch" -> "Bama, Bondo, Matibabu, Shell, Ukwala, Uradi, Referral, Rangala"
                                                "Drivers & Fleet Logistics (Bama)" -> "All Hearse Drivers (KDG 705Y, KCL 703C, KBR 104R, KDH 172H, KDY 211L)"
                                                "Workshop Production Team (Bama)" -> "Brian Adoche, George Munono, Tobias Ochieng, Duncan"
                                                "Operators Grounds Crew (Bama)" -> "Peter Erkundi, Victor Ojow, David Omondi, Francis Gwayi"
                                                "Sales & Marketing Team" -> "Clara Mwamburi, Michael Wasamba, Grace Achieng"
                                                else -> "+254 7XX XXX XXX"
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // RECIPIENT INPUT
                        OutlinedTextField(
                            value = recipientsInput,
                            onValueChange = { recipientsInput = it },
                            label = { Text("Recipients Phone Number(s) / Branch Group", fontSize = 11.sp) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RoyalCobaltBlue,
                                unfocusedBorderColor = BorderLight
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sms_recipients_input"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // MESSAGE BODY TEXTAREA
                        OutlinedTextField(
                            value = messageBody,
                            onValueChange = { messageBody = it },
                            label = {
                                Text(
                                    "Message Body ($charCount / 160 characters • $smsUnits SMS segment)",
                                    fontSize = 11.sp
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RoyalCobaltBlue,
                                unfocusedBorderColor = BorderLight
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sms_body_input"),
                            maxLines = 5,
                            minLines = 3
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // DISPATCH ACTION BUTTON
                        Button(
                            onClick = {
                                if (messageBody.isNotBlank()) {
                                    viewModel.sendBulkSms(
                                        recipientType = selectedGroup,
                                        recipients = recipientsInput,
                                        body = messageBody,
                                        senderId = selectedSenderId,
                                        units = smsUnits
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("send_bulk_sms_button")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Broadcast via $selectedSenderId ($smsUnits Unit${if (smsUnits > 1) "s" else ""})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            BulkSmsSubTab.TEMPLATES -> {
                // TEMPLATES LIBRARY VIEW
                Column(modifier = Modifier.fillMaxSize()) {
                    Text(
                        text = "Standard Funeral Communication Templates",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ObsidianBlack
                    )
                    Text(
                        text = "Pre-approved templates for cortege alerts, family receipts, and staff recall",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(DEFAULT_SMS_TEMPLATES) { tpl ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                border = BorderStroke(1.dp, BorderLight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = tpl.title,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = ObsidianBlack
                                        )
                                        Surface(
                                            color = RoyalCobaltIce,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = tpl.category,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = RoyalCobaltBlue,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = tpl.bodyTemplate,
                                        fontSize = 11.sp,
                                        color = Color(0xFF334155),
                                        lineHeight = 16.sp
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        Button(
                                            onClick = {
                                                messageBody = tpl.bodyTemplate
                                                activeSubTab = BulkSmsSubTab.COMPOSER
                                                viewModel.actionFeedbackMessage.value = "Template '${tpl.title}' loaded into composer."
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(12.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Use in Composer", fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            BulkSmsSubTab.TRANSMISSION_LOG -> {
                // TRANSMISSION LOG VIEW
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("sms_history_list")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SMS Broadcast Transmission Log",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = ObsidianBlack
                        )

                        Text(
                            text = "${messages.size} Broadcasts Logged",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages) { msg ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                border = BorderStroke(1.dp, BorderLight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                color = RoyalCobaltIce,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = msg.senderId,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = RoyalCobaltBlue,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "To: ${msg.recipientDetails}",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = ObsidianBlack
                                            )
                                        }

                                        Text(
                                            text = msg.timestamp,
                                            fontSize = 9.sp,
                                            color = TextSecondary
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = msg.messageBody,
                                        fontSize = 11.sp,
                                        color = Color(0xFF334155),
                                        lineHeight = 15.sp
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = EmeraldSuccess,
                                                modifier = Modifier.size(12.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = msg.status,
                                                fontSize = 10.sp,
                                                color = EmeraldSuccess,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }

                                        TextButton(
                                            onClick = {
                                                messageBody = msg.messageBody
                                                recipientsInput = msg.recipientDetails
                                                activeSubTab = BulkSmsSubTab.COMPOSER
                                                viewModel.actionFeedbackMessage.value = "Message cloned into composer."
                                            }
                                        ) {
                                            Text("Resend / Edit", fontSize = 10.sp, color = RoyalCobaltBlue)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
