package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================================
// Jabima Funeral Directors Ltd Brand Palette
// Forest Green + Pure White Background + Stroke of Red (+ Graph/Tab Accents)
// ============================================================================

// Pure White Canvas & Surfaces (White Background Requested)
val PureWhite = Color(0xFFFFFFFF)
val PureWhiteSurface = Color(0xFFFFFFFF)
val OffWhiteSurface = Color(0xFFFFFFFF)      // Pure crisp white background canvas
val LightGreenSurface = Color(0xFFECFDF5)    // Subtle sage-emerald wash
val LightBlueSurface = Color(0xFFEFF6FF)     // Subtle sapphire wash for analytics/charts
val BorderLight = Color(0xFFD5E2DA)          // Crisp subtle sage-tinted hairline border
val BorderLightGreen = Color(0xFFA7F3D0)     // Emerald border
val BorderLightBlue = Color(0xFFBFDBFE)      // Chart/tab sapphire border

// Core Corporate Forest Greens (Primary Brand Anchor & Positive Operations)
val ForestGreenPrimary = Color(0xFF145A32)   // Rich Jabima forest green
val ForestGreenDark = Color(0xFF0B3B22)      // Deep executive pine green
val ForestGreenLight = Color(0xFF1E7E48)     // Vibrant dignified emerald green
val EmeraldGreenIce = Color(0xFFECFDF5)      // Crisp light sage surface tint
val ForestGreenBorder = Color(0xFF86EFAC)

// Deep Dark Slate & Secondary Graph/Tab Accents
val Navy900 = Color(0xFF0F291E)              // Deep forest-charcoal ink for crisp legibility on white
val Navy800 = Color(0xFF163D2B)              // Dark forest slate
val Navy700 = Color(0xFF1E4E79)              // Accent steel blue (charts/tabs)
val Navy600 = Color(0xFF2563EB)              // Refined royal blue (charts/tabs)

val RoyalCobaltBlue = Color(0xFF1D4E7B)      // Multi-tab / chart sapphire blue accent
val RoyalCobaltDark = Color(0xFF0F2942)      // Chart deep anchor
val RoyalCobaltLight = Color(0xFF2B6CB0)     // Chart steel blue
val RoyalCobaltIce = Color(0xFFEFF6FF)       // Soft sapphire chart tint
val RoyalCobaltBorder = Color(0xFFBFDBFE)

val Blue950 = Color(0xFF0A1E32)
val Blue900 = Color(0xFF0F2942)
val Blue800 = Color(0xFF16426B)
val Blue700 = Color(0xFF1D4E89)
val Blue600 = Color(0xFF2563EB)
val Blue500 = Color(0xFF3B82F6)
val Blue400 = Color(0xFF60A5FA)
val Blue300 = Color(0xFF93C5FD)
val Blue200 = Color(0xFFDBEAFE)
val Blue100 = Color(0xFFEFF6FF)
val Blue50 = Color(0xFFF5F8FC)

// Teal-Cyan Accent (Charts & Operational Metrics)
val CyanPrimary = Color(0xFF0E6B74)
val CyanLight = Color(0xFF148994)
val CyanDark = Color(0xFF094B53)
val CyanContainer = Color(0xFFE6F4F5)
val OnCyanContainer = Color(0xFF083940)

// Signature Stroke of Red (Crisp Brand Stroke, Borders & Critical Alerts)
val StrokeRed = Color(0xFFDC2626)            // Signature Jabima Stroke of Red
val StrokeRedLight = Color(0xFFFEE2E2)
val StrokeRedDark = Color(0xFF991B1B)
val StrokeRedBorder = Color(0xFFFCA5A5)

// High-Contrast Executive Typography Tokens
val TextPrimary = Color(0xFF0F172A)          // Deep crisp slate ink
val TextSecondary = Color(0xFF334155)        // Slate 700
val TextMuted = Color(0xFF64748B)            // Slate 500
val TextBlue = Color(0xFF145A32)             // Green accent text

val ObsidianBlack = Color(0xFF0F172A)
val ObsidianDark = Color(0xFF020617)
val ObsidianSurface = Color(0xFFFFFFFF)
val ObsidianBorder = Color(0xFFD5E2DA)

val EmeraldSuccess = Color(0xFF15803D)       // Vibrant balanced green
val EmeraldLight = Color(0xFFD1FAE5)
val AmberWarning = Color(0xFFB45309)         // Burnished gold / amber for charts & warnings
val AmberLight = Color(0xFFFEF3C7)
val RoseError = StrokeRed
val RoseLight = StrokeRedLight
val PurpleAccent = Color(0xFF6D28D9)         // Indigo/purple for chart differentiation
val PurpleLight = Color(0xFFEDE9FE)

val BackgroundLight = PureWhite
val SurfaceLight = PureWhite
val SurfaceVariantLight = Color(0xFFF6F9F7)

// 24/7 Night Shift & Eye Strain Reduction Dark Theme Palette (Forest-Slate & Deep Navy)
val MidnightBackground = Color(0xFF08121E)     // Deep midnight navy-charcoal
val NocturnalSurface = Color(0xFF102131)       // Refined dark corporate slate-navy card
val NocturnalSurfaceVariant = Color(0xFF182F44)// Elevated corporate steel-navy surface
val NocturnalBorder = Color(0xFF2B4661)        // Crisp muted corporate border
val NocturnalEmerald = Color(0xFF34D399)       // Soft high-legibility emerald
val NocturnalContainer = Color(0xFF0E3B26)     // Deep executive forest green container
val NocturnalBlue = Color(0xFF60A5FA)          // Soft corporate sky blue
val NocturnalBlueContainer = Color(0xFF15385A) // Deep sapphire container
val NocturnalCrimson = Color(0xFFF87171)       // Low-glare soft crimson
val NocturnalAmber = Color(0xFFFBBF24)         // Warm burnished gold
val NocturnalTextPrimary = Color(0xFFF1F5F9)   // Crisp cool alabaster text for dark surfaces
val NocturnalTextSecondary = Color(0xFFB0C4D8) // Muted silver-slate secondary text for dark surfaces
