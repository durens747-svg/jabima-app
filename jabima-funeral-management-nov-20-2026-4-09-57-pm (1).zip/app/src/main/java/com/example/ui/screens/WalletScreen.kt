package com.example.ui.screens

import com.example.ui.components.InstantMpesaB2cDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.text.style.TextOverflow
import com.example.domain.PayrollRulesEngine
import com.example.utils.PdfDocumentGenerator
import com.example.model.Department
import com.example.model.ExpenseCategory
import com.example.model.ExpenseStatus
import com.example.model.IncentiveCategory
import com.example.model.OperatorWageAllocation
import com.example.model.PaymentStatus
import com.example.model.PerformanceIncentive
import com.example.model.StaffAccount
import com.example.model.StaffBreakageRecord
import com.example.model.StaffExpenseClaim
import com.example.model.StaffRole
import com.example.model.StaffWalletSummary
import com.example.model.TransactionType
import com.example.model.WalletTransaction
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseLight
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltDark
import com.example.ui.theme.RoyalCobaltIce
import kotlin.math.abs

enum class CompensationSectionView(val label: String) {
    ALL_IN_ONE("Overview"),
    COMMISSIONS("Commissions"),
    SERVICE_PAYOUTS("Service Payouts"),
    PAYOUTS("Withdrawals"),
    INCENTIVES("Incentives"),
    EXPENSES("Expenses"),
    PAYMENT_HISTORY("History")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WalletScreen(
    currentAccount: StaffAccount,
    walletSummary: StaffWalletSummary,
    transactions: List<WalletTransaction>,
    incentives: List<PerformanceIncentive> = emptyList(),
    expenses: List<StaffExpenseClaim> = emptyList(),
    activeFilter: String = "ALL", // "ALL", "CREDITS", "WITHDRAWALS", "PENDING", "INCENTIVES", "EXPENSES"
    onFilterChange: (String) -> Unit = {},
    onRequestPayout: () -> Unit = {},
    onSelectTransaction: (WalletTransaction) -> Unit = {},
    onSubmitExpenseClaim: () -> Unit = {},
    onAwardIncentiveClick: () -> Unit = {},
    onApproveExpense: (String) -> Unit = {},
    onRejectExpense: (String, String) -> Unit = { _, _ -> },
    onApprovePayout: (String) -> Unit = {},
    onRejectPayout: (String, String) -> Unit = { _, _ -> },
    onExportStatement: (String) -> Unit = {},
    allAccounts: List<StaffAccount> = emptyList(),
    onSelectStaffAccount: (StaffAccount) -> Unit = {},
    onInstantMpesaB2c: (amount: Double, phone: String, category: String, reason: String) -> Unit = { _, _, _, _ -> },
    breakageRecords: List<StaffBreakageRecord> = emptyList(),
    operatorWageAllocations: List<OperatorWageAllocation> = emptyList(),
    isAdminAccess: Boolean = false,
    isAdminImpersonating: Boolean = false,
    onReturnToAdmin: () -> Unit = {},
    onRunBatchPayroll: () -> Unit = {},
    onExportPdfPayslip: (String) -> Unit = {},
    applyStatutoryDeductions: Boolean = true,
    onToggleStatutoryDeductions: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    var selectedSection by remember { mutableStateOf(CompensationSectionView.ALL_IN_ONE) }
    var hideBalance by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var staffWalletSearch by remember { mutableStateOf("") }
    var showInstantMpesaDialog by remember { mutableStateOf(false) }
    var incentiveCategoryFilter by remember { mutableStateOf<IncentiveCategory?>(null) }
    var expenseStatusFilter by remember { mutableStateOf<ExpenseStatus?>(null) }
    var expenseCategoryFilter by remember { mutableStateOf<ExpenseCategory?>(null) }

    var rejectTargetExpenseId by remember { mutableStateOf<String?>(null) }
    var rejectExpenseReason by remember { mutableStateOf("") }

    var rejectTargetPayoutId by remember { mutableStateOf<String?>(null) }
    var rejectPayoutReason by remember { mutableStateOf("") }

    val isSupervisorOrAdmin = isAdminAccess ||
            currentAccount.role == StaffRole.MANAGING_DIRECTOR_CEO ||
            currentAccount.role == StaffRole.OPERATIONS_ADMIN ||
            currentAccount.role == StaffRole.INVENTORY_MANAGER

    // Breakdown calculations
    val baseSalary = transactions.filter { it.type == TransactionType.SALARY_BASE && it.status == PaymentStatus.DISBURSED }.sumOf { it.amount }
    val allowances = transactions.filter { it.type == TransactionType.ACTIVITY_ALLOWANCE && it.status == PaymentStatus.DISBURSED }.sumOf { it.amount }
    val overtime = transactions.filter { it.type == TransactionType.OVERTIME_BONUS && it.status == PaymentStatus.DISBURSED }.sumOf { it.amount }
    val commissions = transactions.filter { (it.type == TransactionType.COMMISSION || it.type == TransactionType.ADMIN_ADJUSTMENT) && it.status == PaymentStatus.DISBURSED }.sumOf { it.amount }
    val incentivesTotal = transactions.filter { it.type == TransactionType.PERFORMANCE_INCENTIVE && it.status == PaymentStatus.DISBURSED }.sumOf { it.amount }
    val reimbursementsTotal = transactions.filter { it.type == TransactionType.EXPENSE_REIMBURSEMENT && it.status == PaymentStatus.DISBURSED }.sumOf { it.amount }
    val operatorTransportTotal = transactions.filter { it.type == TransactionType.OPERATOR_TRANSPORT_FEE && it.status == PaymentStatus.DISBURSED }.sumOf { it.amount }
    val operatorDailyWagesTotal = transactions.filter { it.type == TransactionType.OPERATOR_DAILY_WAGE && it.status == PaymentStatus.DISBURSED }.sumOf { it.amount }
    val perDiemTotal = transactions.filter { it.type == TransactionType.PER_DIEM && it.status == PaymentStatus.DISBURSED }.sumOf { it.amount }
    val earnedCommissionTxns = transactions.filter {
        it.type == TransactionType.COMMISSION || it.type == TransactionType.PERFORMANCE_INCENTIVE
    }
    val servicePayoutTxns = transactions.filter {
        it.type == TransactionType.ACTIVITY_ALLOWANCE ||
            it.type == TransactionType.OVERTIME_BONUS ||
            it.type == TransactionType.OPERATOR_TRANSPORT_FEE ||
            it.type == TransactionType.OPERATOR_DAILY_WAGE ||
            it.type == TransactionType.PER_DIEM
    }
    val breakageTotal = walletSummary.breakageDeductionsTotal
    val staffBreakages = remember(breakageRecords, currentAccount.id) {
        breakageRecords.filter { it.staffId == currentAccount.id }
    }
    val staffOperatorAllocations = remember(operatorWageAllocations, currentAccount.id) {
        operatorWageAllocations.filter { it.staffId == currentAccount.id }
    }

    // Filter transactions
    val filteredTransactions = transactions.filter { txn ->
        val matchesSearch = if (searchQuery.isBlank()) true
        else {
            val q = searchQuery.trim().lowercase()
            txn.title.lowercase().contains(q) ||
                    txn.referenceNumber.lowercase().contains(q) ||
                    (txn.payoutDestination?.lowercase()?.contains(q) == true) ||
                    txn.notes.lowercase().contains(q) ||
                    txn.type.label.lowercase().contains(q)
        }

        val matchesFilter = when (activeFilter) {
            "CREDITS" -> txn.amount > 0
            "WITHDRAWALS" -> txn.amount < 0
            "PENDING" -> txn.status == PaymentStatus.PENDING_APPROVAL || txn.status == PaymentStatus.PROCESSING
            "INCENTIVES" -> txn.type == TransactionType.PERFORMANCE_INCENTIVE || txn.type == TransactionType.COMMISSION
            "EXPENSES" -> txn.type == TransactionType.EXPENSE_REIMBURSEMENT
            else -> true
        }

        matchesSearch && matchesFilter
    }

    // Payout transactions
    val payoutTransactions = transactions.filter { it.type == TransactionType.PAYOUT_WITHDRAWAL }

    // Filtered Incentives
    val filteredIncentives = incentives.filter { inc ->
        incentiveCategoryFilter == null || inc.category == incentiveCategoryFilter
    }

    // Filtered Expenses
    val filteredExpenses = expenses.filter { exp ->
        val matchesStatus = expenseStatusFilter == null || exp.status == expenseStatusFilter
        val matchesCategory = expenseCategoryFilter == null || exp.category == expenseCategoryFilter
        matchesStatus && matchesCategory
    }

    // Reject Dialogs
    if (rejectTargetExpenseId != null) {
        AlertDialog(
            onDismissRequest = { rejectTargetExpenseId = null },
            title = { Text("Reject Expense Claim", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Provide a reason for rejecting this claim:", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectExpenseReason,
                        onValueChange = { rejectExpenseReason = it },
                        placeholder = { Text("e.g. Missing official VAT receipt / Ineligible fuel refuel") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val id = rejectTargetExpenseId ?: return@Button
                        onRejectExpense(id, rejectExpenseReason.ifBlank { "Insufficient documentation" })
                        rejectTargetExpenseId = null
                        rejectExpenseReason = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Confirm Rejection")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { rejectTargetExpenseId = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (rejectTargetPayoutId != null) {
        AlertDialog(
            onDismissRequest = { rejectTargetPayoutId = null },
            title = { Text("Reject Payout Request", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Provide a reason for rejecting this payout:", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectPayoutReason,
                        onValueChange = { rejectPayoutReason = it },
                        placeholder = { Text("e.g. Unverified M-PESA ownership / Insufficient cleared balance") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val id = rejectTargetPayoutId ?: return@Button
                        onRejectPayout(id, rejectPayoutReason.ifBlank { "Rejected by Admin" })
                        rejectTargetPayoutId = null
                        rejectPayoutReason = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Confirm Rejection")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { rejectTargetPayoutId = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showInstantMpesaDialog) {
        InstantMpesaB2cDialog(
            staffAccount = currentAccount,
            availableBalance = walletSummary.availableBalance,
            onDismiss = { showInstantMpesaDialog = false },
            onDisburse = { amount, phone, category, reason ->
                onInstantMpesaB2c(amount, phone, category, reason)
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("staff_payment_wallet_component"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ==========================================
        // HEADER CARD & STAFF IDENTIFIER
        // ==========================================
        item {
            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("staff_payment_wallet_header")
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "Staff Payment Wallet",
                                tint = MaterialTheme.colorScheme.onSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Staff Payment Wallet",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.testTag("staff_payment_wallet_title")
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "LIVE MPESA B2C",
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = "${currentAccount.fullName} • ${currentAccount.role.title} (${currentAccount.id})",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.secondary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "M-PESA: ${currentAccount.defaultMpesaNumber} • ${currentAccount.branch}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Statement export button
                    IconButton(
                        onClick = { onExportStatement("September 2026") },
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.secondaryContainer)
                            .testTag("export_statement_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Export Statement",
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // ==========================================
        // ADMIN IMPERSONATION BANNER (INDEPENDENT STAFF WALLET)
        // ==========================================
        if (isAdminImpersonating) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("wallet_admin_impersonation_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Admin Portal Inspection",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "ADMIN INDEPENDENT PORTAL ACCESS",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Viewing ${currentAccount.fullName} (${currentAccount.id}) Digital Wallet",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onReturnToAdmin,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("wallet_return_to_admin_button")
                        ) {
                            Text("Return to Admin", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }

        // ==========================================
        // ADMIN-ONLY STAFF MEMBER INDEPENDENT WALLET SWITCHER
        // ==========================================
        if (isAdminAccess && allAccounts.isNotEmpty()) {
            item {
                val matchingStaff = remember(allAccounts, staffWalletSearch) {
                    if (staffWalletSearch.isBlank()) allAccounts
                    else {
                        val q = staffWalletSearch.trim().lowercase()
                        allAccounts.filter {
                            it.fullName.lowercase().contains(q) ||
                                it.id.lowercase().contains(q) ||
                                it.role.title.lowercase().contains(q) ||
                                it.department.displayName.lowercase().contains(q)
                        }
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("staff_member_wallet_selector")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Admin Staff Wallet Switcher (${allAccounts.size})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = "Portal: ${currentAccount.fullName.split(" ").firstOrNull() ?: currentAccount.fullName}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = staffWalletSearch,
                            onValueChange = { staffWalletSearch = it },
                            placeholder = { Text("Filter staff by name, ID, role or dept...", fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = "Filter staff", modifier = Modifier.size(16.dp))
                            },
                            trailingIcon = {
                                if (staffWalletSearch.isNotBlank()) {
                                    IconButton(onClick = { staffWalletSearch = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(14.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_wallet_staff_search_field")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(matchingStaff, key = { it.id }) { staff ->
                                val isSelected = staff.id == currentAccount.id
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { onSelectStaffAccount(staff) },
                                    label = {
                                        Text(
                                            text = "${staff.fullName} (${staff.id})",
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    },
                                    leadingIcon = if (isSelected) {
                                        {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onSecondary,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    } else null,
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.secondary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onSecondary,
                                        containerColor = MaterialTheme.colorScheme.surface,
                                        labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline
                                    ),
                                    modifier = Modifier.testTag("staff_chip_${staff.id}")
                                )
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // SECTION SWITCHER TABS
        // ==========================================
        item {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                ScrollableTabRow(
                    selectedTabIndex = selectedSection.ordinal,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.secondary,
                    edgePadding = 8.dp,
                    indicator = { tabPositions ->
                        if (selectedSection.ordinal < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSection.ordinal]),
                                color = MaterialTheme.colorScheme.secondary,
                                height = 3.dp
                            )
                        }
                    }
                ) {
                    CompensationSectionView.values().forEach { section ->
                        val isSelected = selectedSection == section
                        Tab(
                            selected = isSelected,
                            onClick = { selectedSection = section },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    when (section) {
                                        CompensationSectionView.ALL_IN_ONE -> Icon(Icons.Default.AccountBalanceWallet, null, modifier = Modifier.size(13.dp))
                                        CompensationSectionView.COMMISSIONS -> Icon(Icons.Default.Star, null, modifier = Modifier.size(13.dp))
                                        CompensationSectionView.SERVICE_PAYOUTS -> Icon(Icons.Default.MonetizationOn, null, modifier = Modifier.size(13.dp))
                                        CompensationSectionView.PAYOUTS -> Icon(Icons.Default.Send, null, modifier = Modifier.size(13.dp))
                                        CompensationSectionView.INCENTIVES -> Icon(Icons.Default.EmojiEvents, null, modifier = Modifier.size(13.dp))
                                        CompensationSectionView.EXPENSES -> Icon(Icons.Default.Receipt, null, modifier = Modifier.size(13.dp))
                                        CompensationSectionView.PAYMENT_HISTORY -> Icon(Icons.Default.Paid, null, modifier = Modifier.size(13.dp))
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = section.label,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            },
                            modifier = Modifier.testTag("section_tab_${section.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // ==========================================
        // 1. CURRENT BALANCE & DIGITAL CARD
        // ==========================================
        if (selectedSection == CompensationSectionView.ALL_IN_ONE ||
            selectedSection == CompensationSectionView.COMMISSIONS ||
            selectedSection == CompensationSectionView.SERVICE_PAYOUTS ||
            selectedSection == CompensationSectionView.PAYOUTS
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("staff_digital_wallet_card")
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush = Brush.linearGradient(
                                    colors = listOf(Navy900, Color(0xFF14426B), ForestGreenDark)
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column {
                            // Top row with chip and hide toggle
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color.White.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CreditCard,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "JABIMA PAYROLL CURRENT BALANCE",
                                            color = Color(0xFFBAE6FD),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.5.sp
                                        )
                                        Text(
                                            text = "Disbursement Account: Active",
                                            color = EmeraldLight,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { hideBalance = !hideBalance },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("toggle_balance_visibility")
                                ) {
                                    Icon(
                                        imageVector = if (hideBalance) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (hideBalance) "Show balance" else "Hide balance",
                                        tint = Color.White.copy(alpha = 0.8f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // EMV Metallic Gold Chip & Contactless Payment Waves
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        color = Color(0xFFF59E0B),
                                        shape = RoundedCornerShape(5.dp),
                                        border = BorderStroke(1.dp, Color(0xFFD97706)),
                                        modifier = Modifier.size(36.dp, 28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                                                drawLine(Color(0xFFB45309), Offset(size.width * 0.35f, 0f), Offset(size.width * 0.35f, size.height), strokeWidth = 1.5f)
                                                drawLine(Color(0xFFB45309), Offset(size.width * 0.65f, 0f), Offset(size.width * 0.65f, size.height), strokeWidth = 1.5f)
                                                drawLine(Color(0xFFB45309), Offset(0f, size.height * 0.5f), Offset(size.width, size.height * 0.5f), strokeWidth = 1.5f)
                                            }
                                        }
                                    }
                                    Icon(
                                        imageVector = Icons.Default.FlashOn,
                                        contentDescription = "Contactless Waves",
                                        tint = Color(0xFFBAE6FD),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Text(
                                    text = "4219  ••••  ••••  ${currentAccount.nationalId.takeLast(4).ifBlank { "8894" }}",
                                    fontSize = 13.sp,
                                    letterSpacing = 1.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Big Available Balance Display
                            Text(
                                text = "AVAILABLE FOR WITHDRAWAL",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF93C5FD),
                                letterSpacing = 1.sp
                            )

                            Text(
                                text = if (hideBalance) "••••••••••" else "KES ${String.format("%,.2f", walletSummary.availableBalance)}",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                modifier = Modifier.testTag("available_balance_text")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Cardholder Name, Rate & Department Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("STAFF CARDHOLDER", fontSize = 8.sp, color = Color(0xFFBAE6FD), letterSpacing = 0.5.sp)
                                    Text(currentAccount.fullName.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("COMMISSION TIER", fontSize = 8.sp, color = Color(0xFFBAE6FD), letterSpacing = 0.5.sp)
                                    Text("${currentAccount.commissionRatePercent}% Casket Rate", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFDE68A))
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Prominent Earned Commissions & Service Payouts Pillars
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = Color.White.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color(0xFFFDE68A).copy(alpha = 0.35f)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { selectedSection = CompensationSectionView.COMMISSIONS }
                                        .testTag("hero_earned_commissions_pill")
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                                        Text(
                                            text = "EARNED COMMISSIONS",
                                            color = Color(0xFFFDE68A),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.4.sp
                                        )
                                        Text(
                                            text = if (hideBalance) "••••" else "KES ${String.format("%,.0f", walletSummary.casketCommissionTotal)}",
                                            color = Color.White,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 15.sp,
                                            modifier = Modifier.testTag("earned_commissions_total_text")
                                        )
                                    }
                                }

                                Surface(
                                    color = Color.White.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, EmeraldLight.copy(alpha = 0.35f)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { selectedSection = CompensationSectionView.SERVICE_PAYOUTS }
                                        .testTag("hero_service_payouts_pill")
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                                        Text(
                                            text = "SERVICE PAYOUTS",
                                            color = EmeraldLight,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.4.sp
                                        )
                                        Text(
                                            text = if (hideBalance) "••••" else "KES ${String.format("%,.0f", walletSummary.servicePayoutsTotal)}",
                                            color = Color.White,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 15.sp,
                                            modifier = Modifier.testTag("service_payouts_total_text")
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Three Sub-Metrics
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Total Lifetime Earned", color = Color(0xFFBAE6FD), fontSize = 10.sp)
                                    Text(
                                        text = if (hideBalance) "••••" else "KES ${String.format("%,.0f", walletSummary.totalEarned)}",
                                        color = EmeraldLight,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        modifier = Modifier.testTag("lifetime_earned_text")
                                    )
                                }

                                Column(modifier = Modifier.testTag("pending_payouts_metric")) {
                                    Text(text = "Pending Payouts", color = Color(0xFFBAE6FD), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        text = if (hideBalance) "••••" else "KES ${String.format("%,.0f", walletSummary.pendingPayouts)}",
                                        color = AmberLight,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        modifier = Modifier.testTag("pending_payouts_text")
                                    )
                                }

                                Column {
                                    Text(text = "Total Paid Out", color = Color(0xFFBAE6FD), fontSize = 10.sp)
                                    Text(
                                        text = if (hideBalance) "••••" else "KES ${String.format("%,.0f", walletSummary.totalWithdrawn)}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        modifier = Modifier.testTag("total_withdrawn_text")
                                    )
                                }
                            }

                            if (walletSummary.pendingPayouts > 0) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Surface(
                                    color = Color(0xFFFEF3C7).copy(alpha = 0.95f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("pending_payouts_card")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.HourglassTop,
                                            contentDescription = null,
                                            tint = AmberWarning,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "Pending Payout: KES ${String.format("%,.2f", walletSummary.pendingPayouts)}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = Color(0xFF92400E)
                                            )
                                            Text(
                                                text = "Queued for Safaricom M-PESA B2C payout approval by Admin.",
                                                fontSize = 9.sp,
                                                color = Color(0xFFB45309)
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Payout Details Strip
                            Surface(
                                color = Color.White.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Shield,
                                        contentDescription = null,
                                        tint = Color(0xFFBAE6FD),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Min Payout: KES 500 • Instant M-PESA B2C & SCBLKENX Bank EFT",
                                        fontSize = 10.sp,
                                        color = Color(0xFFE0F2FE)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Primary Action Buttons Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { showInstantMpesaDialog = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = EmeraldSuccess,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1.1f)
                                        .height(44.dp)
                                        .testTag("instant_mpesa_b2c_button")
                                ) {
                                    Icon(imageVector = Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Instant M-PESA", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = onRequestPayout,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Navy900,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(44.dp)
                                        .testTag("wallet_screen_payout_button")
                                        .testTag("request_payout_button")
                                ) {
                                    Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Request", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = onSubmitExpenseClaim,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF0284C7),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(44.dp)
                                        .testTag("wallet_submit_expense_button")
                                ) {
                                    Icon(imageVector = Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Claim Exp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Secondary Actions: Printable PDF Payslip + Admin Batch Payroll Run
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        runCatching {
                                            val pdfFile = PdfDocumentGenerator.generateStaffPayslipPdf(
                                                context = context,
                                                staff = currentAccount,
                                                summary = walletSummary,
                                                transactions = transactions,
                                                periodLabel = "Current Cycle",
                                                includeKenyanStatutory = applyStatutoryDeductions
                                            )
                                            PdfDocumentGenerator.sharePdfFile(
                                                context = context,
                                                pdfFile = pdfFile,
                                                title = "Jabima Payslip - ${currentAccount.fullName}"
                                            )
                                        }
                                        onExportPdfPayslip("Current Cycle")
                                    },
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.55f)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(38.dp)
                                        .testTag("btn_export_pdf_payslip")
                                ) {
                                    Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text("Share PDF Payslip", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }

                                if (isSupervisorOrAdmin) {
                                    Button(
                                        onClick = onRunBatchPayroll,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFFD97706),
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(38.dp)
                                            .testTag("btn_run_batch_payroll")
                                    ) {
                                        Icon(imageVector = Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text("Run Batch Payroll", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Quick Breakdown 4-Cards + Commissions/Service Payouts
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BreakdownItem(
                        label = "Earned Commissions",
                        amount = "KES ${String.format("%,.0f", walletSummary.casketCommissionTotal)}",
                        icon = Icons.Default.Star,
                        color = Color(0xFFD97706),
                        modifier = Modifier.weight(1f)
                    )
                    BreakdownItem(
                        label = "Service Payouts",
                        amount = "KES ${String.format("%,.0f", walletSummary.servicePayoutsTotal)}",
                        icon = Icons.Default.MonetizationOn,
                        color = EmeraldSuccess,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BreakdownItem(
                        label = "Base Retainer",
                        amount = "KES ${String.format("%,.0f", baseSalary)}",
                        icon = Icons.Default.AccountBalance,
                        color = CyanPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    BreakdownItem(
                        label = "Bonuses & Reimb.",
                        amount = "KES ${String.format("%,.0f", incentivesTotal + reimbursementsTotal)}",
                        icon = Icons.Default.EmojiEvents,
                        color = Color(0xFF7C3AED),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Kenyan Statutory Payroll Deductions Card (PAYE, NSSF, SHIF & Housing Levy)
                val monthlyGrossForStatutory = (baseSalary + allowances + overtime + commissions + incentivesTotal)
                    .let { if (it > 0.0) it else (currentAccount.baseSalaryKes + currentAccount.allowanceKes) }
                val statutory = PayrollRulesEngine.computeKenyanStatutoryBreakdown(
                    grossMonthlyPayKes = monthlyGrossForStatutory,
                    applyStatutory = applyStatutoryDeductions
                )
                val netAfterAllDeductions = (statutory.netTakeHomeBeforeBreakageKes - breakageTotal).coerceAtLeast(0.0)

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, RoyalCobaltBlue.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("kenyan_statutory_payroll_card")
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Kenyan Statutory Payroll Breakdown",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (applyStatutoryDeductions) {
                                        "PAYE (KRA), NSSF Tier I/II, SHIF (2.75%) & Housing Levy (1.5%)"
                                    } else {
                                        "Gross / Contract Mode (Statutory exempt on payslip)"
                                    },
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = applyStatutoryDeductions,
                                onCheckedChange = onToggleStatutoryDeductions,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = PureWhite,
                                    checkedTrackColor = EmeraldSuccess
                                ),
                                modifier = Modifier.testTag("switch_kenyan_statutory_payroll")
                            )
                        }

                        HorizontalDivider(color = BorderLight, thickness = 0.8.dp)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Taxable Gross Earnings", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("KES ${String.format("%,.2f", statutory.grossPayKes)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Navy900)
                        }
                        if (applyStatutoryDeductions) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("SHIF (2.75%, min KES 300)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("- KES ${String.format("%,.2f", statutory.shifDeductionKes)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFB45309))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("NSSF Tier I + II (6% capped)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("- KES ${String.format("%,.2f", statutory.nssfDeductionKes)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFB45309))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Affordable Housing Levy (1.5%)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("- KES ${String.format("%,.2f", statutory.housingLevyKes)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFB45309))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("KRA PAYE (less KES 2,400 Relief)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("- KES ${String.format("%,.2f", statutory.netPayeKes)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = com.example.ui.theme.StrokeRed)
                            }
                        }
                        if (breakageTotal > 0.0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Asset Breakage Deductions", fontSize = 11.sp, color = com.example.ui.theme.StrokeRed)
                                Text("- KES ${String.format("%,.2f", breakageTotal)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.StrokeRed)
                            }
                        }

                        Surface(
                            color = EmeraldLight,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Estimated Net Take-Home Pay",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ForestGreenDark
                                )
                                Text(
                                    text = "KES ${String.format("%,.2f", netAfterAllDeductions)}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = EmeraldSuccess
                                )
                            }
                        }
                    }
                }

                // Operators Transport Fee & Daily Wages Card
                if (currentAccount.department == Department.OPERATORS ||
                    currentAccount.role == StaffRole.OPERATOR ||
                    currentAccount.transportFeeKes > 0 ||
                    currentAccount.dailyWageKes > 0 ||
                    staffOperatorAllocations.isNotEmpty() ||
                    operatorTransportTotal > 0 ||
                    operatorDailyWagesTotal > 0
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.45f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("operator_wages_transport_wallet_card")
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Operator Transport & Daily Wages",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Surface(color = EmeraldLight, shape = RoundedCornerShape(6.dp)) {
                                    Text(
                                        text = "ADMIN ALLOCATED",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldSuccess,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                BreakdownItem(
                                    label = "Transport Fee",
                                    amount = "KES ${String.format("%,.0f", maxOf(currentAccount.transportFeeKes, operatorTransportTotal))}",
                                    icon = Icons.Default.DirectionsCar,
                                    color = RoyalCobaltBlue,
                                    modifier = Modifier.weight(1f)
                                )
                                BreakdownItem(
                                    label = "Daily Wage",
                                    amount = "KES ${String.format("%,.0f", maxOf(currentAccount.dailyWageKes, operatorDailyWagesTotal))}",
                                    icon = Icons.Default.Paid,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            if (staffOperatorAllocations.isNotEmpty()) {
                                staffOperatorAllocations.take(4).forEach { alloc ->
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(alloc.dutyAssignment, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                                Text("${alloc.date} • By ${alloc.allocatedBy}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("KES ${String.format("%,.0f", alloc.totalPaidKes)}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = EmeraldSuccess)
                                                Text(if (alloc.isDisbursed) "Disbursed" else "Pending", fontSize = 9.sp, color = if (alloc.isDisbursed) EmeraldSuccess else AmberWarning)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Breakage Costs & Deductions Card
                if (breakageTotal > 0 || staffBreakages.isNotEmpty() || currentAccount.totalBreakageDeductionsKes > 0) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("staff_breakage_deductions_wallet_card")
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Breakage Costs & Deductions",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                Text(
                                    text = "- KES ${String.format("%,.0f", maxOf(breakageTotal, currentAccount.totalBreakageDeductionsKes))}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }

                            staffBreakages.forEach { br ->
                                Surface(
                                    color = RoseLight.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(br.itemBroken, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                                            Text("${br.description} • ${br.date}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text("- KES ${String.format("%,.0f", br.breakageCostKes)}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                            Text(if (br.isDeducted) "Deducted" else "Pending", fontSize = 9.sp, color = if (br.isDeducted) MaterialTheme.colorScheme.error else AmberWarning)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 1B. EARNED COMMISSIONS LEDGER
        // ==========================================
        if (selectedSection == CompensationSectionView.ALL_IN_ONE ||
            selectedSection == CompensationSectionView.COMMISSIONS
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("earned_commissions_section")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(AmberLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = Color(0xFFD97706),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Earned Commissions",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${currentAccount.commissionRatePercent}% Tier • Casket sales & completion commissions",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Surface(
                                color = AmberLight,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "KES ${String.format("%,.0f", walletSummary.casketCommissionTotal)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFF92400E),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        if (earnedCommissionTxns.isEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "No commission credits recorded for ${currentAccount.fullName} under the active filter.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            earnedCommissionTxns.take(if (selectedSection == CompensationSectionView.COMMISSIONS) 40 else 4).forEach { txn ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSelectTransaction(txn) }
                                        .testTag("commission_item_${txn.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = txn.title,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "${txn.type.label} • ${txn.date} • Ref: ${txn.referenceNumber}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            if (txn.notes.isNotBlank()) {
                                                Text(
                                                    text = txn.notes,
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "+ KES ${String.format("%,.0f", txn.amount)}",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 14.sp,
                                                color = EmeraldSuccess
                                            )
                                            Text(
                                                text = txn.status.label,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 1C. FUNERAL SERVICE PAYOUTS LEDGER
        // ==========================================
        if (selectedSection == CompensationSectionView.ALL_IN_ONE ||
            selectedSection == CompensationSectionView.SERVICE_PAYOUTS
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("funeral_service_payouts_section")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(EmeraldLight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MonetizationOn,
                                        contentDescription = null,
                                        tint = EmeraldSuccess,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Funeral Service Payouts",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Case duties, hearse escorts, overtime, operator wages & stipends",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Surface(
                                color = EmeraldLight,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "KES ${String.format("%,.0f", walletSummary.servicePayoutsTotal)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            BreakdownItem(
                                label = "Case & Duty Pay",
                                amount = "KES ${String.format("%,.0f", allowances + overtime)}",
                                icon = Icons.Default.TrendingUp,
                                color = EmeraldSuccess,
                                modifier = Modifier.weight(1f)
                            )
                            BreakdownItem(
                                label = "Wages & Per Diem",
                                amount = "KES ${String.format("%,.0f", operatorTransportTotal + operatorDailyWagesTotal + perDiemTotal)}",
                                icon = Icons.Default.Paid,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (servicePayoutTxns.isEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "No funeral service payouts recorded for ${currentAccount.fullName} under the active filter.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            servicePayoutTxns.take(if (selectedSection == CompensationSectionView.SERVICE_PAYOUTS) 40 else 4).forEach { txn ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onSelectTransaction(txn) }
                                        .testTag("service_payout_item_${txn.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = txn.title,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "${txn.type.label} • ${txn.date} • Ref: ${txn.referenceNumber}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            if (txn.notes.isNotBlank()) {
                                                Text(
                                                    text = txn.notes,
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "+ KES ${String.format("%,.0f", txn.amount)}",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 14.sp,
                                                color = EmeraldSuccess
                                            )
                                            Text(
                                                text = txn.status.label,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 2. PAYOUTS MANAGEMENT VIEW
        // ==========================================
        if (selectedSection == CompensationSectionView.PAYOUTS) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Payout Requests & Disbursals",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Manage withdrawals, pending approvals & M-PESA B2C transactions",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = onRequestPayout,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("payout_section_request_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("New Request", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (payoutTransactions.isEmpty()) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Send, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No payout requests found", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text("Click 'New Request' above to withdraw cleared funds to M-PESA or Bank.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                items(payoutTransactions, key = { it.id }) { txn ->
                    val isPending = txn.status == PaymentStatus.PENDING_APPROVAL || txn.status == PaymentStatus.PROCESSING
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, if (isPending) AmberWarning.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("payout_item_${txn.id}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(if (isPending) AmberLight else EmeraldLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isPending) Icons.Default.HourglassTop else Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = if (isPending) AmberWarning else EmeraldSuccess,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(text = txn.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(text = "Ref: ${txn.referenceNumber} • ${txn.date}", fontSize = 11.sp, color = Color.Gray)
                                    }
                                }

                                Text(
                                    text = "KES ${String.format("%,.2f", abs(txn.amount))}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = if (isPending) AmberWarning else MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PhoneAndroid, null, modifier = Modifier.size(14.dp), tint = RoyalCobaltBlue)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = txn.payoutDestination ?: "Registered Payroll Channel",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = RoyalCobaltBlue
                                    )
                                }

                                Surface(
                                    color = when (txn.status) {
                                        PaymentStatus.DISBURSED -> EmeraldLight
                                        PaymentStatus.PENDING_APPROVAL -> AmberLight
                                        PaymentStatus.PROCESSING -> CyanContainer
                                        PaymentStatus.REJECTED -> RoseLight
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = txn.status.label,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (txn.status) {
                                            PaymentStatus.DISBURSED -> EmeraldSuccess
                                            PaymentStatus.PENDING_APPROVAL -> AmberWarning
                                            PaymentStatus.PROCESSING -> CyanDark
                                            PaymentStatus.REJECTED -> MaterialTheme.colorScheme.error
                                        },
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            if (txn.notes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = "Note: ${txn.notes}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            // Supervisor / Admin instant disburse action
                            if (isSupervisorOrAdmin && isPending) {
                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = BorderLight)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = { rejectTargetPayoutId = txn.id },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp).testTag("reject_payout_${txn.id}")
                                    ) {
                                        Text("Reject", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = { onApprovePayout(txn.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp).testTag("approve_payout_${txn.id}")
                                    ) {
                                        Icon(Icons.Default.FlashOn, null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Disburse via M-PESA B2C", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 3. PERFORMANCE INCENTIVES MODULE
        // ==========================================
        if (selectedSection == CompensationSectionView.ALL_IN_ONE ||
            selectedSection == CompensationSectionView.INCENTIVES
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("performance_incentives_section")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFEF3C7)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = Color(0xFFD97706),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Performance Incentives & Commissions",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.testTag("performance_incentives_title")
                                    )
                                    Text(
                                        text = "Awarded bonuses, 5% casket commissions & excellence praise",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Supervisor / Admin action to grant incentive
                            Button(
                                onClick = onAwardIncentiveClick,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("award_incentive_header_button")
                            ) {
                                Icon(Icons.Default.Add, null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Award Bonus", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Category Filter Chips
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = incentiveCategoryFilter == null,
                                onClick = { incentiveCategoryFilter = null },
                                label = { Text("All (${incentives.size})", fontSize = 11.sp) },
                                modifier = Modifier.testTag("incentive_filter_all")
                            )
                            IncentiveCategory.values().forEach { cat ->
                                val count = incentives.count { it.category == cat }
                                val isSelected = incentiveCategoryFilter == cat
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { incentiveCategoryFilter = if (isSelected) null else cat },
                                    label = { Text("${cat.label} ($count)", fontSize = 11.sp) },
                                    modifier = Modifier.testTag("incentive_filter_${cat.name.lowercase()}")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (filteredIncentives.isEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "No performance incentives match the selected criteria.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            filteredIncentives.take(if (selectedSection == CompensationSectionView.INCENTIVES) 50 else 3).forEach { inc ->
                                val badgeColor = Color(inc.category.badgeColorHex)
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .testTag("incentive_card_${inc.id}")
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Surface(
                                                    color = badgeColor.copy(alpha = 0.14f),
                                                    shape = RoundedCornerShape(6.dp)
                                                ) {
                                                    Text(
                                                        text = inc.category.label.uppercase(),
                                                        color = badgeColor,
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = inc.title,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "${inc.staffName} (${inc.staffId}) • Awarded by ${inc.awardedBy} on ${inc.date}",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(
                                                    text = "+ KES ${String.format("%,.0f", inc.amount)}",
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 15.sp,
                                                    color = EmeraldSuccess
                                                )
                                                if (inc.caseReference != null) {
                                                    Surface(
                                                        color = RoyalCobaltIce,
                                                        shape = RoundedCornerShape(4.dp)
                                                    ) {
                                                        Text(
                                                            text = inc.caseReference,
                                                            fontSize = 9.sp,
                                                            color = RoyalCobaltBlue,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Star, null, tint = Color(0xFFD97706), modifier = Modifier.size(13.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "\"${inc.rationale}\"",
                                                    fontSize = 11.sp,
                                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 4. EXPENSE TRACKING MODULE
        // ==========================================
        if (selectedSection == CompensationSectionView.ALL_IN_ONE ||
            selectedSection == CompensationSectionView.EXPENSES
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_tracking_section")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(RoyalCobaltIce),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Receipt,
                                        contentDescription = null,
                                        tint = RoyalCobaltBlue,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Field Expense Claims & Tracking",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.testTag("expense_tracking_title")
                                    )
                                    Text(
                                        text = "Hearse fuel, tolls, police escorts, vigils & road repairs",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Button(
                                onClick = onSubmitExpenseClaim,
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("claim_expense_header_button")
                            ) {
                                Icon(Icons.Default.Add, null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Claim", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Status Filter Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = expenseStatusFilter == null,
                                onClick = { expenseStatusFilter = null },
                                label = { Text("All (${expenses.size})", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f).testTag("expense_filter_status_all")
                            )
                            FilterChip(
                                selected = expenseStatusFilter == ExpenseStatus.PENDING_APPROVAL,
                                onClick = { expenseStatusFilter = if (expenseStatusFilter == ExpenseStatus.PENDING_APPROVAL) null else ExpenseStatus.PENDING_APPROVAL },
                                label = { Text("Pending", fontSize = 11.sp) },
                                modifier = Modifier.weight(1.1f).testTag("expense_filter_status_pending")
                            )
                            FilterChip(
                                selected = expenseStatusFilter == ExpenseStatus.APPROVED_REIMBURSED,
                                onClick = { expenseStatusFilter = if (expenseStatusFilter == ExpenseStatus.APPROVED_REIMBURSED) null else ExpenseStatus.APPROVED_REIMBURSED },
                                label = { Text("Reimbursed", fontSize = 11.sp) },
                                modifier = Modifier.weight(1.2f).testTag("expense_filter_status_approved")
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (filteredExpenses.isEmpty()) {
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "No expense claims found for this filter.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else {
                            filteredExpenses.take(if (selectedSection == CompensationSectionView.EXPENSES) 50 else 3).forEach { exp ->
                                val catBadgeColor = Color(exp.category.badgeColorHex)
                                val isPending = exp.status == ExpenseStatus.PENDING_APPROVAL

                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, if (isPending) AmberWarning.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .testTag("expense_card_${exp.id}")
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Surface(
                                                        color = catBadgeColor.copy(alpha = 0.14f),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = exp.category.label.uppercase(),
                                                            color = catBadgeColor,
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        color = when (exp.status) {
                                                            ExpenseStatus.APPROVED_REIMBURSED -> EmeraldLight
                                                            ExpenseStatus.PENDING_APPROVAL -> AmberLight
                                                            ExpenseStatus.REJECTED -> RoseLight
                                                        },
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = exp.status.label,
                                                            color = when (exp.status) {
                                                                ExpenseStatus.APPROVED_REIMBURSED -> EmeraldSuccess
                                                                ExpenseStatus.PENDING_APPROVAL -> AmberWarning
                                                                ExpenseStatus.REJECTED -> MaterialTheme.colorScheme.error
                                                            },
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = exp.title,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "${exp.staffName} • Receipt: ${exp.receiptNumber} • Case: ${exp.caseReference}",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                if (exp.vehiclePlate != null) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(Icons.Default.DirectionsCar, null, modifier = Modifier.size(11.dp), tint = Color.Gray)
                                                        Spacer(modifier = Modifier.width(3.dp))
                                                        Text(text = "Plate: ${exp.vehiclePlate}", fontSize = 10.sp, color = Color.Gray)
                                                    }
                                                }
                                            }

                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(
                                                    text = "KES ${String.format("%,.0f", exp.amount)}",
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 15.sp,
                                                    color = if (isPending) AmberWarning else RoyalCobaltBlue
                                                )
                                                Text(
                                                    text = exp.date,
                                                    fontSize = 10.sp,
                                                    color = Color.Gray
                                                )
                                            }
                                        }

                                        if (exp.notes.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "Proof/Note: ${exp.notes}",
                                                fontSize = 11.sp,
                                                color = Color(0xFF475569)
                                            )
                                        }

                                        // Supervisor / Admin review actions on pending expense claims
                                        if (isSupervisorOrAdmin && isPending) {
                                            Spacer(modifier = Modifier.height(10.dp))
                                            HorizontalDivider(color = BorderLight)
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.End,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                OutlinedButton(
                                                    onClick = { rejectTargetExpenseId = exp.id },
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.height(34.dp).testTag("reject_expense_${exp.id}")
                                                ) {
                                                    Text("Reject", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Button(
                                                    onClick = { onApproveExpense(exp.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.height(34.dp).testTag("approve_expense_${exp.id}")
                                                ) {
                                                    Icon(Icons.Default.Check, null, modifier = Modifier.size(14.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Approve & Reimburse", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 5. TRANSACTION HISTORY LOG
        // ==========================================
        if (selectedSection == CompensationSectionView.ALL_IN_ONE ||
            selectedSection == CompensationSectionView.PAYMENT_HISTORY
        ) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("transaction_history_log")
                        .testTag("payment_history_section_header"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Transaction History Log",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("transaction_history_log_header")
                        )
                        Text(
                            text = "Audit trail of earnings, disbursements, incentives & expenses",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = "${filteredTransactions.size} records",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by reference, case, notes...", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp))
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.secondary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("payment_history_search_field")
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Filter Chips
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = activeFilter == "ALL",
                        onClick = { onFilterChange("ALL") },
                        label = { Text("All", fontSize = 11.sp) },
                        modifier = Modifier.testTag("filter_all")
                    )

                    FilterChip(
                        selected = activeFilter == "CREDITS",
                        onClick = { onFilterChange("CREDITS") },
                        label = { Text("Earnings (+)", fontSize = 11.sp) },
                        modifier = Modifier.testTag("filter_credits")
                    )

                    FilterChip(
                        selected = activeFilter == "WITHDRAWALS",
                        onClick = { onFilterChange("WITHDRAWALS") },
                        label = { Text("Payouts (-)", fontSize = 11.sp) },
                        modifier = Modifier.testTag("filter_withdrawals")
                    )

                    FilterChip(
                        selected = activeFilter == "INCENTIVES",
                        onClick = { onFilterChange("INCENTIVES") },
                        label = { Text("Incentives", fontSize = 11.sp) },
                        modifier = Modifier.testTag("filter_incentives")
                    )

                    FilterChip(
                        selected = activeFilter == "EXPENSES",
                        onClick = { onFilterChange("EXPENSES") },
                        label = { Text("Expenses", fontSize = 11.sp) },
                        modifier = Modifier.testTag("filter_expenses")
                    )

                    FilterChip(
                        selected = activeFilter == "PENDING",
                        onClick = { onFilterChange("PENDING") },
                        label = { Text("Pending", fontSize = 11.sp) },
                        modifier = Modifier.testTag("filter_pending")
                    )
                }
            }

            // TRANSACTION ITEMS LIST
            if (filteredTransactions.isEmpty()) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Receipt, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No payment records found", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Text("Try adjusting your search query or transaction filter", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                items(filteredTransactions, key = { it.id }) { txn ->
                    val isCredit = txn.amount > 0
                    val absAmount = abs(txn.amount)

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectTransaction(txn) }
                            .testTag("transaction_item_${txn.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isCredit) EmeraldLight
                                            else if (txn.status == PaymentStatus.PENDING_APPROVAL) AmberLight
                                            else CyanContainer
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = when {
                                            txn.type == TransactionType.BREAKAGE_DEDUCTION -> Icons.Default.Warning
                                            txn.type == TransactionType.OPERATOR_TRANSPORT_FEE -> Icons.Default.DirectionsCar
                                            txn.type == TransactionType.OPERATOR_DAILY_WAGE -> Icons.Default.Paid
                                            txn.type == TransactionType.PERFORMANCE_INCENTIVE -> Icons.Default.EmojiEvents
                                            txn.type == TransactionType.EXPENSE_REIMBURSEMENT -> Icons.Default.Receipt
                                            isCredit -> Icons.Default.ArrowDownward
                                            else -> Icons.Default.ArrowUpward
                                        },
                                        contentDescription = null,
                                        tint = when {
                                            txn.type == TransactionType.BREAKAGE_DEDUCTION -> MaterialTheme.colorScheme.error
                                            isCredit -> EmeraldSuccess
                                            txn.status == PaymentStatus.PENDING_APPROVAL -> AmberWarning
                                            else -> CyanDark
                                        },
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = txn.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "${txn.date} • Ref: ${txn.referenceNumber}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    if (txn.payoutDestination != null) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.PhoneAndroid,
                                                contentDescription = null,
                                                tint = CyanPrimary,
                                                modifier = Modifier.size(11.dp)
                                            )
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = txn.payoutDestination,
                                                fontSize = 10.sp,
                                                color = CyanPrimary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = if (isCredit) "+ KES ${String.format("%,.0f", absAmount)}"
                                    else "- KES ${String.format("%,.0f", absAmount)}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = if (isCredit) EmeraldSuccess else if (txn.status == PaymentStatus.PENDING_APPROVAL) AmberWarning else MaterialTheme.colorScheme.onSurface
                                )

                                Surface(
                                    color = when (txn.status) {
                                        PaymentStatus.DISBURSED -> EmeraldLight
                                        PaymentStatus.PENDING_APPROVAL -> AmberLight
                                        PaymentStatus.PROCESSING -> CyanContainer
                                        PaymentStatus.REJECTED -> RoseLight
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = txn.status.label,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (txn.status) {
                                            PaymentStatus.DISBURSED -> EmeraldSuccess
                                            PaymentStatus.PENDING_APPROVAL -> AmberWarning
                                            PaymentStatus.PROCESSING -> CyanDark
                                            PaymentStatus.REJECTED -> MaterialTheme.colorScheme.error
                                        },
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(90.dp)) // padding for bottom bar
        }
    }
}

@Composable
private fun BreakdownItem(
    label: String,
    amount: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(text = label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = amount, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}
