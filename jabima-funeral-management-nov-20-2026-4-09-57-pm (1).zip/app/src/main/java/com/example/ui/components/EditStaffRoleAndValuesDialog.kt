package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Department
import com.example.model.JABIMA_BRANCHES
import com.example.model.JABIMA_FLEET
import com.example.model.StaffAccount
import com.example.model.StaffRole
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditStaffRoleAndValuesDialog(
    staff: StaffAccount,
    onDismiss: () -> Unit,
    onSave: (
        fullName: String,
        phone: String,
        email: String,
        role: StaffRole,
        department: Department,
        branch: String,
        nationalId: String,
        assignedVehicle: String?,
        baseSalaryKes: Double,
        allowanceKes: Double,
        commissionRatePercent: Double,
        defaultMpesa: String,
        defaultBank: String,
        isActive: Boolean,
        notes: String
    ) -> Unit
) {
    var fullName by remember { mutableStateOf(staff.fullName) }
    var phone by remember { mutableStateOf(staff.phone) }
    var email by remember { mutableStateOf(staff.email) }
    var selectedRole by remember { mutableStateOf(staff.role) }
    var selectedDepartment by remember { mutableStateOf(staff.department) }
    var selectedBranch by remember { mutableStateOf(staff.branch) }
    var nationalId by remember { mutableStateOf(staff.nationalId) }
    var assignedVehicle by remember { mutableStateOf(staff.assignedVehicle ?: "None") }
    var baseSalaryText by remember { mutableStateOf(staff.baseSalaryKes.toLong().toString()) }
    var allowanceText by remember { mutableStateOf(staff.allowanceKes.toLong().toString()) }
    var commissionRateText by remember { mutableStateOf(staff.commissionRatePercent.toString()) }
    var defaultMpesa by remember { mutableStateOf(staff.defaultMpesaNumber) }
    var defaultBank by remember { mutableStateOf(staff.defaultBankDetails) }
    var isActive by remember { mutableStateOf(staff.isActive) }
    var notes by remember { mutableStateOf(staff.notes) }

    var roleMenuExpanded by remember { mutableStateOf(false) }
    var deptMenuExpanded by remember { mutableStateOf(false) }
    var branchMenuExpanded by remember { mutableStateOf(false) }
    var vehicleMenuExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .testTag("edit_staff_role_values_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CyanContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Work,
                                contentDescription = null,
                                tint = CyanPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Edit Staff Role & Values",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${staff.id} • ${staff.fullName}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(14.dp))

                // SECTION 1: ROLE & DEPARTMENT
                Text(
                    text = "1. ROLE & ORGANIZATIONAL PLACEMENT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanPrimary,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Role Dropdown
                ExposedDropdownMenuBox(
                    expanded = roleMenuExpanded,
                    onExpandedChange = { roleMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedRole.title,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Assigned Staff Role") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = roleMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .testTag("role_dropdown_input")
                    )
                    ExposedDropdownMenu(
                        expanded = roleMenuExpanded,
                        onDismissRequest = { roleMenuExpanded = false }
                    ) {
                        StaffRole.entries.forEach { role ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(role.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(role.description, fontSize = 10.sp, color = Color.Gray)
                                    }
                                },
                                onClick = {
                                    selectedRole = role
                                    roleMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Department Dropdown
                ExposedDropdownMenuBox(
                    expanded = deptMenuExpanded,
                    onExpandedChange = { deptMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedDepartment.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Department") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = deptMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .testTag("dept_dropdown_input")
                    )
                    ExposedDropdownMenu(
                        expanded = deptMenuExpanded,
                        onDismissRequest = { deptMenuExpanded = false }
                    ) {
                        Department.entries.forEach { dept ->
                            DropdownMenuItem(
                                text = { Text(dept.displayName, fontSize = 13.sp) },
                                onClick = {
                                    selectedDepartment = dept
                                    deptMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Branch Dropdown
                ExposedDropdownMenuBox(
                    expanded = branchMenuExpanded,
                    onExpandedChange = { branchMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedBranch,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Duty Branch Location") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .testTag("branch_dropdown_input")
                    )
                    ExposedDropdownMenu(
                        expanded = branchMenuExpanded,
                        onDismissRequest = { branchMenuExpanded = false }
                    ) {
                        JABIMA_BRANCHES.forEach { b ->
                            DropdownMenuItem(
                                text = { Text(b, fontSize = 13.sp) },
                                onClick = {
                                    selectedBranch = b
                                    branchMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Assigned Vehicle (Optional for drivers / fleet)
                val fleetOptions = listOf("None") + JABIMA_FLEET
                ExposedDropdownMenuBox(
                    expanded = vehicleMenuExpanded,
                    onExpandedChange = { vehicleMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = assignedVehicle,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Assigned Hearse / Fleet Vehicle") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = vehicleMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .testTag("vehicle_dropdown_input")
                    )
                    ExposedDropdownMenu(
                        expanded = vehicleMenuExpanded,
                        onDismissRequest = { vehicleMenuExpanded = false }
                    ) {
                        fleetOptions.forEach { v ->
                            DropdownMenuItem(
                                text = { Text(v, fontSize = 13.sp) },
                                onClick = {
                                    assignedVehicle = v
                                    vehicleMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // SECTION 2: STAFF VALUES & COMPENSATION
                Text(
                    text = "2. COMPENSATION & FINANCIAL VALUES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldSuccess,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = baseSalaryText,
                        onValueChange = { baseSalaryText = it },
                        label = { Text("Base Salary (KES)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("edit_base_salary_input")
                    )

                    OutlinedTextField(
                        value = allowanceText,
                        onValueChange = { allowanceText = it },
                        label = { Text("Allowance (KES)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("edit_allowance_input")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = commissionRateText,
                    onValueChange = { commissionRateText = it },
                    label = { Text("Casket Sales Commission Rate (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_commission_rate_input"),
                    supportingText = { Text("Standard policy: 5% for Sales & Marketing staff", fontSize = 10.sp) }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // SECTION 3: PERSONAL & DISBURSEMENT DETAILS
                Text(
                    text = "3. CONTACT & DISBURSEMENT CREDENTIALS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Staff Full Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_staff_name_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone Number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = nationalId,
                        onValueChange = { nationalId = it },
                        label = { Text("National ID") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = defaultMpesa,
                    onValueChange = { defaultMpesa = it },
                    label = { Text("M-PESA Payout Number") },
                    placeholder = { Text("+254 7XX XXX XXX") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_staff_mpesa_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = defaultBank,
                    onValueChange = { defaultBank = it },
                    label = { Text("Bank Account Details") },
                    placeholder = { Text("Bank name, branch, account number") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("CEO / Executive Admin Remarks") },
                    placeholder = { Text("Special duties, appraisal notes, contract term...") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Active Switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (isActive) EmeraldLight.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isActive) "Staff Status: Active" else "Staff Status: Inactive / Suspended",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isActive) EmeraldSuccess else com.example.ui.theme.StrokeRed
                        )
                        Text(
                            text = if (isActive) "Eligible for shift rostering and disbursements" else "Access temporarily locked",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = isActive,
                        onCheckedChange = { isActive = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = EmeraldSuccess)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            val parsedSalary = baseSalaryText.toDoubleOrNull() ?: staff.baseSalaryKes
                            val parsedAllowance = allowanceText.toDoubleOrNull() ?: staff.allowanceKes
                            val parsedCommission = commissionRateText.toDoubleOrNull() ?: staff.commissionRatePercent
                            val vehicleVal = if (assignedVehicle == "None") null else assignedVehicle

                            onSave(
                                fullName,
                                phone,
                                email,
                                selectedRole,
                                selectedDepartment,
                                selectedBranch,
                                nationalId,
                                vehicleVal,
                                parsedSalary,
                                parsedAllowance,
                                parsedCommission,
                                defaultMpesa,
                                defaultBank,
                                isActive,
                                notes
                            )
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_staff_role_values_button")
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save Changes", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
