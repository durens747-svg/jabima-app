package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PurpleLight

data class BranchLocationInfo(
    val name: String,
    val locationDescription: String,
    val operatingHours: String,
    val primaryContact: String,
    val features: List<String>
)

data class FleetVehicleInfo(
    val registration: String,
    val model: String,
    val primaryDriver: String,
    val specialty: String,
    val status: String,
    val equipment: List<String>
)

@Composable
fun BranchesAndFleetScreen(
    onTriggerMpesaPush: (phoneNumber: String, amount: Double) -> Unit = { _, _ -> },
    onOpenFleetTrackingMap: () -> Unit = {}
) {
    var selectedTab by remember { mutableStateOf("ALL") }
    var showStkDialog by remember { mutableStateOf(false) }
    var stkPhoneNumber by remember { mutableStateOf("+254793553434") }
    var stkAmount by remember { mutableStateOf("50000") }
    var stkSuccessMessage by remember { mutableStateOf<String?>(null) }

    val branches = listOf(
        BranchLocationInfo(
            name = "Siaya Referral (Opposite Morgue)",
            locationDescription = "Directly opposite Siaya County Referral Hospital Morgue Gate",
            operatingHours = "Open 24/7 (Emergency & First-Call Intake)",
            primaryContact = "+254 793 553 434 / +254 722 000 001",
            features = listOf("Direct morgue liaison", "Immediate body transfer", "Casket display room", "First-call intake desk")
        ),
        BranchLocationInfo(
            name = "Siaya opposite Shell Petrol",
            locationDescription = "Siaya Town Central, directly opposite Shell Petrol Station",
            operatingHours = "Mon - Sun: 7:00 AM - 8:00 PM (24/7 on call)",
            primaryContact = "+254 793 553 434 / +254 722 000 002",
            features = listOf("Main executive showroom", "Thermal POS cashier desk", "Family consultation lounges", "Statutory registry help")
        ),
        BranchLocationInfo(
            name = "Bama Branch",
            locationDescription = "Bama Market Centre along Siaya-Ndori Highway",
            operatingHours = "Mon - Sat: 8:00 AM - 6:30 PM",
            primaryContact = "+254 793 553 434 / +254 722 000 003",
            features = listOf("Pre-need trust desk", "Cedar & oak caskets", "Floral sympathy booking", "Lipa Pole Pole enrollment")
        ),
        BranchLocationInfo(
            name = "Bondo Branch",
            locationDescription = "Bondo Town Central, Kisumu-Usenge Highway",
            operatingHours = "Mon - Sun: 7:30 AM - 7:30 PM",
            primaryContact = "+254 793 553 434 / +254 722 000 004",
            features = listOf("Sub-county coordination", "Hearse dispatch bay", "Church liaison office", "M-PESA STK payment desk")
        ),
        BranchLocationInfo(
            name = "Matibabu Branch",
            locationDescription = "Matibabu Hospital Road, Ukwala-Siaya Link",
            operatingHours = "Mon - Sat: 8:00 AM - 6:00 PM",
            primaryContact = "+254 793 553 434 / +254 722 000 005",
            features = listOf("Hospital patient discharge liaison", "Hymn booklet printing", "Condolence register books", "Family counseling")
        ),
        BranchLocationInfo(
            name = "Ukwala Branch",
            locationDescription = "Ukwala Town Commercial Arcade",
            operatingHours = "Mon - Sat: 8:00 AM - 6:00 PM",
            primaryContact = "+254 793 553 434 / +254 722 000 006",
            features = listOf("Diaspora repatriation intake", "Long-distance cortege booking", "Casket viewing annex", "Mobile sound setup")
        ),
        BranchLocationInfo(
            name = "Uradi Branch",
            locationDescription = "Uradi Commercial Centre near Community Health Hospital",
            operatingHours = "Mon - Sat: 8:00 AM - 6:00 PM",
            primaryContact = "+254 793 553 434 / +254 722 000 007",
            features = listOf("Rural parish outreach", "Gravesite canopy hire", "Lowering gear dispatch", "Community bereavement trust")
        ),
        BranchLocationInfo(
            name = "Rangala Branch",
            locationDescription = "Rangala Junction near Rangala Mission Hospital",
            operatingHours = "Mon - Sun: 7:30 AM - 7:00 PM",
            primaryContact = "+254 793 553 434 / +254 722 000 008",
            features = listOf("Mission hospital clearance", "Floral refrigeration storage", "Night vigil hearse standby", "Cortege motorcade lead")
        )
    )

    val fleetVehicles = listOf(
        FleetVehicleInfo(
            registration = "KDG 705Y",
            model = "Mercedes-Benz E-Class Hearse Limousine",
            primaryDriver = "Victor Owino (Lead Driver)",
            specialty = "Lead Cortege & Ceremonial Procession",
            status = "Ready / Active",
            equipment = listOf("Floral roof carriage", "Hydraulic interior casket tray", "Digital chime PA chime", "LED cortege beacons")
        ),
        FleetVehicleInfo(
            registration = "KCL 703C",
            model = "Toyota HiAce Dignity Transfer Hearse",
            primaryDriver = "Joseph Ouma",
            specialty = "24/7 First Call Emergency Evacuation",
            status = "On 24/7 Standby",
            equipment = listOf("Stainless steel roll-in stretcher", "Climate controlled cabin", "Disinfection sanitizing kit", "Dual mortuary cots")
        ),
        FleetVehicleInfo(
            registration = "KBR 104R",
            model = "Toyota LandCruiser 4x4 Heavy Duty Hearse",
            primaryDriver = "Fredrick Ochieng",
            specialty = "Rural All-Terrain & Tough Terrains",
            status = "Ready / Active",
            equipment = listOf("Snorkel 4WD drive", "High clearance chassis", "Heavy-duty casket lock bars", "All-weather rain protection")
        ),
        FleetVehicleInfo(
            registration = "KDH 172H",
            model = "Isuzu D-Max Executive Cortege Hearse",
            primaryDriver = "Fredrick Osuru",
            specialty = "Night Vigils & Rural Parishes",
            status = "Scheduled Duty",
            equipment = listOf("Mobile floral preservation unit", "Battery-powered public address PA system", "Inverter 220V power", "Perimeter night LED floodlights")
        ),
        FleetVehicleInfo(
            registration = "KDY 211L",
            model = "Mercedes-Benz Sprinter Executive Hearse",
            primaryDriver = "Fredrick Okoth",
            specialty = "Long Distance & Upcountry Highway Transit",
            status = "Ready / Active",
            equipment = listOf("Extended casket compartment", "Air-suspension smooth transit", "Family forward cabin seats (4 PAX)", "GPS highway tracker")
        ),
        FleetVehicleInfo(
            registration = "KCT 871D",
            model = "Mercedes-Benz S-Class Limousine VIP Hearse",
            primaryDriver = "Fredrick Hayoyo (Executive Escort)",
            specialty = "VIP Ceremonial & State-Class Escorts",
            status = "Executive Reserve",
            equipment = listOf("Polished walnut interior deck", "Presidential flag mounts", "Full chrome exterior trim", "Silent gliding transmission")
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("branches_fleet_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))

            // HEADER BANNER
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Navy900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "BRANCHES, FLEET & PAYMENT",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Jabima Funeral Directors Network",
                                color = CyanPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Surface(
                            color = EmeraldLight,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "8 Branches • 6 Hearses",
                                color = EmeraldSuccess,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Serving Siaya County and Western Kenya with localized branches, fully equipped modern cortege hearse fleet, and flexible payment terms including Lipa Pole Pole (2 installments) and instant M-PESA STK Push (+254793553434).",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // PAYMENT TERMS HIGHLIGHT CARD (Requested: Lipa Pole Pole & M-PESA STK)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, EmeraldSuccess.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Payments,
                                    contentDescription = null,
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Official Payment Terms",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "M-PESA STK: +254793553434",
                                    fontSize = 11.sp,
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Button(
                            onClick = { showStkDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("STK Push", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2 Options: Lipa Pole Pole & Full Payment
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // OPTION 1: LIPA POLE POLE
                        Surface(
                            color = CyanContainer.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Lipa Pole Pole",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = CyanDark
                                )
                                Text(
                                    text = "2 Installments",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "• 1st Installment (50%): Upon intake & casket selection\n• 2nd Installment (50%): Prior to funeral cortege dispatch",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 14.sp
                                )
                            }
                        }

                        // OPTION 2: FULL PAYMENT
                        Surface(
                            color = EmeraldLight.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Full Payment",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = EmeraldSuccess
                                )
                                Text(
                                    text = "Instant Clearance",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "• 100% upfront settlement\n• Immediate official thermal receipt & burial permit clearance issued",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // SUCCESS SNACKBAR/MESSAGE IF TRIGGERED
        stkSuccessMessage?.let { msg ->
            item {
                Surface(
                    color = EmeraldLight,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = msg, fontSize = 12.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // FILTER TABS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "ALL" to "All View",
                    "BRANCHES" to "Branches (8)",
                    "FLEET" to "Hearse Fleet (6)",
                    "PAYMENTS" to "Payment Info"
                ).forEach { (code, label) ->
                    FilterChip(
                        selected = selectedTab == code,
                        onClick = { selectedTab = code },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // SECTION: BRANCHES
        if (selectedTab == "ALL" || selectedTab == "BRANCHES") {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "The 8 Official Branches",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = CyanContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "Siaya County Network",
                            color = CyanDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            items(branches) { branch ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(CyanContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Store,
                                        contentDescription = null,
                                        tint = CyanDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = branch.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = branch.operatingHours,
                                        fontSize = 10.sp,
                                        color = if (branch.operatingHours.contains("24/7")) EmeraldSuccess else CyanPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = branch.locationDescription,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = branch.primaryContact,
                                fontSize = 11.sp,
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Features chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            branch.features.take(3).forEach { feat ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = feat,
                                        fontSize = 9.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // SECTION: FLEET
        if (selectedTab == "ALL" || selectedTab == "FLEET") {
            item {
                Spacer(modifier = Modifier.height(6.dp))

                // GOOGLE MAPS LIVE FLEET RADAR BANNER
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Navy900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0284C7)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DirectionsCar,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Google Maps Fleet Radar",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(EmeraldLight, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    ) {
                                        Text("LIVE GPS", color = EmeraldSuccess, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Text(
                                    text = "Real-time telemetry, speeds, fuel & routes for 6 hearses",
                                    fontSize = 10.sp,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                        }

                        Button(
                            onClick = onOpenFleetTrackingMap,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(36.dp)
                                .testTag("launch_google_maps_radar_button")
                        ) {
                            Text("Open Radar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Official Cortege Fleet",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = AmberLight,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "6 Vehicles",
                            color = AmberWarning,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            items(fleetVehicles) { vehicle ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Navy900),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DirectionsCar,
                                        contentDescription = null,
                                        tint = CyanPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = vehicle.registration,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = vehicle.model,
                                        fontSize = 11.sp,
                                        color = CyanPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Surface(
                                color = if (vehicle.status.contains("Ready") || vehicle.status.contains("Active")) EmeraldLight else PurpleLight,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = vehicle.status,
                                    color = if (vehicle.status.contains("Ready") || vehicle.status.contains("Active")) EmeraldSuccess else Color(0xFF7C3AED),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Assigned Driver: ${vehicle.primaryDriver}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Specialty: ${vehicle.specialty}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            vehicle.equipment.forEach { eq ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = eq,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // M-PESA STK PUSH DIALOG
    if (showStkDialog) {
        AlertDialog(
            onDismissRequest = { showStkDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = EmeraldSuccess)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Trigger M-PESA STK Push", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Official STK Recipient Number: +254793553434\nInitiates secure real-time mobile checkout directly to bereaved family or treasurer phone.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = stkPhoneNumber,
                        onValueChange = { stkPhoneNumber = it },
                        label = { Text("Family / Payer Phone (+254...)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = stkAmount,
                        onValueChange = { stkAmount = it },
                        label = { Text("Amount (KES)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Surface(
                        color = CyanContainer,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Supports 50% Lipa Pole Pole deposit or full payment settlement.",
                            fontSize = 11.sp,
                            color = CyanDark,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amountVal = stkAmount.toDoubleOrNull() ?: 50000.0
                        onTriggerMpesaPush(stkPhoneNumber, amountVal)
                        stkSuccessMessage = "M-PESA STK prompt sent to $stkPhoneNumber for KES ${String.format("%,.0f", amountVal)}! Receipt synced with +254793553434."
                        showStkDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Send STK Prompt")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStkDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
