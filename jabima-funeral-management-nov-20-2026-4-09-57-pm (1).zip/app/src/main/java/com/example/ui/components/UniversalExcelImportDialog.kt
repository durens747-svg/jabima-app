package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.BurialScheduleEvent
import com.example.model.CustomerOrderRecord
import com.example.model.ExcelDatasetType
import com.example.model.FleetGpsVehicle
import com.example.model.StaffAccount
import com.example.model.StockUploadItem
import com.example.model.WorkshopProductionItem
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite

@Composable
fun UniversalExcelImportDialog(
    initialDataset: ExcelDatasetType = ExcelDatasetType.INVENTORY_STOCK,
    onDismiss: () -> Unit,
    onImportStockItems: (List<StockUploadItem>) -> Unit,
    onImportBurialSchedules: (List<BurialScheduleEvent>) -> Unit,
    onImportCustomerOrders: (List<CustomerOrderRecord>) -> Unit,
    onImportStaffAccounts: (List<StaffAccount>) -> Unit,
    onImportFleetVehicles: (List<FleetGpsVehicle>) -> Unit,
    onImportWorkshopJobs: (List<WorkshopProductionItem>) -> Unit,
    liveStockItems: List<StockUploadItem> = emptyList(),
    liveBurialSchedules: List<BurialScheduleEvent> = emptyList(),
    liveCustomerOrders: List<CustomerOrderRecord> = emptyList(),
    liveStaffAccounts: List<StaffAccount> = emptyList(),
    liveFleetVehicles: List<FleetGpsVehicle> = emptyList(),
    liveWorkshopJobs: List<WorkshopProductionItem> = emptyList()
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var selectedDataset by remember { mutableStateOf(initialDataset) }

    // Parsed rows for current dataset
    val parsedStockItems = remember { mutableStateListOf<StockUploadItem>() }
    val parsedBurials = remember { mutableStateListOf<BurialScheduleEvent>() }
    val parsedOrders = remember { mutableStateListOf<CustomerOrderRecord>() }
    val parsedStaff = remember { mutableStateListOf<StaffAccount>() }
    val parsedFleet = remember { mutableStateListOf<FleetGpsVehicle>() }
    val parsedWorkshop = remember { mutableStateListOf<WorkshopProductionItem>() }

    var selectedFileName by remember { mutableStateOf<String?>(null) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var showPasteBox by remember { mutableStateOf(false) }
    var pasteTextInput by remember { mutableStateOf("") }

    // File picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "spreadsheet.xlsx"
                selectedFileName = fileName
                val stream = context.contentResolver.openInputStream(uri)
                if (stream != null) {
                    val rawRows = stream.use {
                        UniversalExcelDataImporter.extractRawRows(it, fileName)
                    }
                    when (selectedDataset) {
                        ExcelDatasetType.INVENTORY_STOCK -> {
                            val items = UniversalExcelDataImporter.parseStockItems(rawRows)
                            parsedStockItems.clear()
                            parsedStockItems.addAll(items)
                            statusMessage = "Extracted ${items.size} stock items from '$fileName'."
                        }
                        ExcelDatasetType.BURIAL_SCHEDULES -> {
                            val burials = UniversalExcelDataImporter.parseBurialSchedules(rawRows)
                            parsedBurials.clear()
                            parsedBurials.addAll(burials)
                            statusMessage = "Extracted ${burials.size} burial schedule cases from '$fileName'."
                        }
                        ExcelDatasetType.CUSTOMER_ORDERS -> {
                            val orders = UniversalExcelDataImporter.parseCustomerOrders(rawRows)
                            parsedOrders.clear()
                            parsedOrders.addAll(orders)
                            statusMessage = "Extracted ${orders.size} customer orders from '$fileName'."
                        }
                        ExcelDatasetType.STAFF_ACCOUNTS -> {
                            val accounts = UniversalExcelDataImporter.parseStaffAccounts(rawRows)
                            parsedStaff.clear()
                            parsedStaff.addAll(accounts)
                            statusMessage = "Extracted ${accounts.size} staff profiles from '$fileName'."
                        }
                        ExcelDatasetType.FLEET_VEHICLES -> {
                            val vehicles = UniversalExcelDataImporter.parseFleetVehicles(rawRows)
                            parsedFleet.clear()
                            parsedFleet.addAll(vehicles)
                            statusMessage = "Extracted ${vehicles.size} fleet vehicles from '$fileName'."
                        }
                        ExcelDatasetType.WORKSHOP_JOBS -> {
                            val jobs = UniversalExcelDataImporter.parseWorkshopJobs(rawRows)
                            parsedWorkshop.clear()
                            parsedWorkshop.addAll(jobs)
                            statusMessage = "Extracted ${jobs.size} production jobs from '$fileName'."
                        }
                    }
                    Toast.makeText(context, "Parsed Excel data successfully!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                statusMessage = "Failed to parse Excel file: ${e.localizedMessage}"
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .height(720.dp)
                .padding(vertical = 4.dp)
                .testTag("universal_excel_import_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header Banner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF107C41)), // Microsoft Excel green
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TableChart,
                                contentDescription = "Excel",
                                tint = PureWhite,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Universal Excel Data Import Hub",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Import, parse & sync multi-department Excel data",
                                fontSize = 11.sp,
                                color = Color(0xFF107C41),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Dataset Selector Scrollable Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedDataset.ordinal,
                    edgePadding = 0.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    ExcelDatasetType.entries.forEach { dataset ->
                        val isSelected = selectedDataset == dataset
                        val icon = getDatasetIcon(dataset)
                        val count = when (dataset) {
                            ExcelDatasetType.INVENTORY_STOCK -> parsedStockItems.size
                            ExcelDatasetType.BURIAL_SCHEDULES -> parsedBurials.size
                            ExcelDatasetType.CUSTOMER_ORDERS -> parsedOrders.size
                            ExcelDatasetType.STAFF_ACCOUNTS -> parsedStaff.size
                            ExcelDatasetType.FLEET_VEHICLES -> parsedFleet.size
                            ExcelDatasetType.WORKSHOP_JOBS -> parsedWorkshop.size
                        }

                        Tab(
                            selected = isSelected,
                            onClick = {
                                selectedDataset = dataset
                                statusMessage = null
                                showPasteBox = false
                            },
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (isSelected) Color(0xFF107C41) else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = if (count > 0) "${dataset.title} ($count)" else dataset.title,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color(0xFF107C41) else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                    )
                                }
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Main Content Body (Scrollable)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Dataset Info Card & Action Controls
                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(Color(0xFF107C41), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = getDatasetIcon(selectedDataset),
                                        contentDescription = null,
                                        tint = PureWhite,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${selectedDataset.title} Excel Import",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFF166534)
                                    )
                                    Text(
                                        text = selectedDataset.subtitle,
                                        fontSize = 10.sp,
                                        color = Color(0xFF15803D)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Expected Columns: ${selectedDataset.columnsSummary}",
                                fontSize = 9.sp,
                                color = Color(0xFF166534).copy(alpha = 0.8f)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Action buttons: File Picker, Sample Loader, Paste, Copy Blank Template
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { filePickerLauncher.launch("*/*") },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .height(36.dp)
                                        .testTag("btn_universal_choose_file")
                                ) {
                                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Choose File", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        when (selectedDataset) {
                                            ExcelDatasetType.INVENTORY_STOCK -> {
                                                val sample = ExcelStockHelper.getSampleExcelConsignmentItems()
                                                parsedStockItems.clear()
                                                parsedStockItems.addAll(sample)
                                            }
                                            ExcelDatasetType.BURIAL_SCHEDULES -> {
                                                val sample = UniversalExcelDataImporter.getSampleBurialSchedules()
                                                parsedBurials.clear()
                                                parsedBurials.addAll(sample)
                                            }
                                            ExcelDatasetType.CUSTOMER_ORDERS -> {
                                                val sample = UniversalExcelDataImporter.getSampleCustomerOrders()
                                                parsedOrders.clear()
                                                parsedOrders.addAll(sample)
                                            }
                                            ExcelDatasetType.STAFF_ACCOUNTS -> {
                                                val sample = UniversalExcelDataImporter.getSampleStaffAccounts()
                                                parsedStaff.clear()
                                                parsedStaff.addAll(sample)
                                            }
                                            ExcelDatasetType.FLEET_VEHICLES -> {
                                                val sample = UniversalExcelDataImporter.getSampleFleetVehicles()
                                                parsedFleet.clear()
                                                parsedFleet.addAll(sample)
                                            }
                                            ExcelDatasetType.WORKSHOP_JOBS -> {
                                                val sample = UniversalExcelDataImporter.getSampleWorkshopJobs()
                                                parsedWorkshop.clear()
                                                parsedWorkshop.addAll(sample)
                                            }
                                        }
                                        selectedFileName = "Sample_${selectedDataset.shortCode}_Template.xlsx"
                                        statusMessage = "Loaded verified sample data for ${selectedDataset.title}."
                                        Toast.makeText(context, "Loaded sample Excel records", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .height(36.dp)
                                        .testTag("btn_universal_load_sample")
                                ) {
                                    Icon(Icons.Default.TableChart, contentDescription = null, tint = Color(0xFF107C41), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Sample Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF107C41))
                                }

                                OutlinedButton(
                                    onClick = { showPasteBox = !showPasteBox },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                ) {
                                    Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(if (showPasteBox) "Hide" else "Paste", fontSize = 11.sp)
                                }
                            }

                            // Expandable Paste Box
                            if (showPasteBox) {
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = pasteTextInput,
                                    onValueChange = { pasteTextInput = it },
                                    label = { Text("Paste Excel Tab-Separated or CSV Rows") },
                                    placeholder = { Text("Column 1\tColumn 2\tColumn 3\t...") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 3,
                                    maxLines = 6
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Button(
                                    onClick = {
                                        if (pasteTextInput.isNotBlank()) {
                                            val rawRows = UniversalExcelDataImporter.extractRawRowsFromText(pasteTextInput)
                                            when (selectedDataset) {
                                                ExcelDatasetType.INVENTORY_STOCK -> {
                                                    val items = UniversalExcelDataImporter.parseStockItems(rawRows)
                                                    parsedStockItems.clear()
                                                    parsedStockItems.addAll(items)
                                                    statusMessage = "Parsed ${items.size} stock items."
                                                }
                                                ExcelDatasetType.BURIAL_SCHEDULES -> {
                                                    val burials = UniversalExcelDataImporter.parseBurialSchedules(rawRows)
                                                    parsedBurials.clear()
                                                    parsedBurials.addAll(burials)
                                                    statusMessage = "Parsed ${burials.size} burial schedules."
                                                }
                                                ExcelDatasetType.CUSTOMER_ORDERS -> {
                                                    val orders = UniversalExcelDataImporter.parseCustomerOrders(rawRows)
                                                    parsedOrders.clear()
                                                    parsedOrders.addAll(orders)
                                                    statusMessage = "Parsed ${orders.size} customer orders."
                                                }
                                                ExcelDatasetType.STAFF_ACCOUNTS -> {
                                                    val accounts = UniversalExcelDataImporter.parseStaffAccounts(rawRows)
                                                    parsedStaff.clear()
                                                    parsedStaff.addAll(accounts)
                                                    statusMessage = "Parsed ${accounts.size} staff profiles."
                                                }
                                                ExcelDatasetType.FLEET_VEHICLES -> {
                                                    val vehicles = UniversalExcelDataImporter.parseFleetVehicles(rawRows)
                                                    parsedFleet.clear()
                                                    parsedFleet.addAll(vehicles)
                                                    statusMessage = "Parsed ${vehicles.size} fleet vehicles."
                                                }
                                                ExcelDatasetType.WORKSHOP_JOBS -> {
                                                    val jobs = UniversalExcelDataImporter.parseWorkshopJobs(rawRows)
                                                    parsedWorkshop.clear()
                                                    parsedWorkshop.addAll(jobs)
                                                    statusMessage = "Parsed ${jobs.size} production jobs."
                                                }
                                            }
                                            selectedFileName = "Pasted_Excel_Data"
                                            showPasteBox = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth().height(34.dp)
                                ) {
                                    Text("Parse & Load Pasted Rows", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Status / Feedback message
                    statusMessage?.let { msg ->
                        Surface(
                            color = EmeraldLight,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(msg, fontSize = 11.sp, color = Color(0xFF065F46), fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    // Render Preview Table & Commit Action based on active dataset
                    when (selectedDataset) {
                        ExcelDatasetType.INVENTORY_STOCK -> {
                            StockPreviewSection(
                                items = parsedStockItems,
                                selectedFileName = selectedFileName,
                                onCommit = {
                                    onImportStockItems(parsedStockItems.toList())
                                    Toast.makeText(context, "Imported ${parsedStockItems.size} stock items from Excel!", Toast.LENGTH_LONG).show()
                                    parsedStockItems.clear()
                                    onDismiss()
                                },
                                onRemoveAt = { parsedStockItems.removeAt(it) }
                            )
                        }
                        ExcelDatasetType.BURIAL_SCHEDULES -> {
                            BurialsPreviewSection(
                                items = parsedBurials,
                                selectedFileName = selectedFileName,
                                onCommit = {
                                    onImportBurialSchedules(parsedBurials.toList())
                                    Toast.makeText(context, "Imported ${parsedBurials.size} burial schedules from Excel!", Toast.LENGTH_LONG).show()
                                    parsedBurials.clear()
                                    onDismiss()
                                },
                                onRemoveAt = { parsedBurials.removeAt(it) }
                            )
                        }
                        ExcelDatasetType.CUSTOMER_ORDERS -> {
                            OrdersPreviewSection(
                                items = parsedOrders,
                                selectedFileName = selectedFileName,
                                onCommit = {
                                    onImportCustomerOrders(parsedOrders.toList())
                                    Toast.makeText(context, "Imported ${parsedOrders.size} customer orders from Excel!", Toast.LENGTH_LONG).show()
                                    parsedOrders.clear()
                                    onDismiss()
                                },
                                onRemoveAt = { parsedOrders.removeAt(it) }
                            )
                        }
                        ExcelDatasetType.STAFF_ACCOUNTS -> {
                            StaffPreviewSection(
                                items = parsedStaff,
                                selectedFileName = selectedFileName,
                                onCommit = {
                                    onImportStaffAccounts(parsedStaff.toList())
                                    Toast.makeText(context, "Imported ${parsedStaff.size} staff accounts from Excel!", Toast.LENGTH_LONG).show()
                                    parsedStaff.clear()
                                    onDismiss()
                                },
                                onRemoveAt = { parsedStaff.removeAt(it) }
                            )
                        }
                        ExcelDatasetType.FLEET_VEHICLES -> {
                            FleetPreviewSection(
                                items = parsedFleet,
                                selectedFileName = selectedFileName,
                                onCommit = {
                                    onImportFleetVehicles(parsedFleet.toList())
                                    Toast.makeText(context, "Imported ${parsedFleet.size} fleet vehicles from Excel!", Toast.LENGTH_LONG).show()
                                    parsedFleet.clear()
                                    onDismiss()
                                },
                                onRemoveAt = { parsedFleet.removeAt(it) }
                            )
                        }
                        ExcelDatasetType.WORKSHOP_JOBS -> {
                            WorkshopPreviewSection(
                                items = parsedWorkshop,
                                selectedFileName = selectedFileName,
                                onCommit = {
                                    onImportWorkshopJobs(parsedWorkshop.toList())
                                    Toast.makeText(context, "Imported ${parsedWorkshop.size} workshop jobs from Excel!", Toast.LENGTH_LONG).show()
                                    parsedWorkshop.clear()
                                    onDismiss()
                                },
                                onRemoveAt = { parsedWorkshop.removeAt(it) }
                            )
                        }
                    }

                    // Blank Template & Export tools
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                val template = UniversalExcelDataImporter.generateBlankExcelTemplate(selectedDataset)
                                clipboardManager.setText(AnnotatedString(template))
                                Toast.makeText(context, "Copied ${selectedDataset.title} Excel CSV template to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy Blank Excel Template", fontSize = 10.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                val csv = UniversalExcelDataImporter.generateBlankExcelTemplate(selectedDataset)
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, csv)
                                    putExtra(Intent.EXTRA_SUBJECT, "Jabima_${selectedDataset.shortCode}_Export.csv")
                                    type = "text/csv"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share Excel File"))
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF107C41), modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export Template", fontSize = 10.sp, color = Color(0xFF107C41))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(8.dp))

                // Footer Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Microsoft Excel (.xlsx, .csv) Engine",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Close / Done", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// =============================================================================
// SUB-SECTIONS FOR PREVIEWING & COMMITTING EACH DATASET
// =============================================================================

@Composable
private fun StockPreviewSection(
    items: List<StockUploadItem>,
    selectedFileName: String?,
    onCommit: () -> Unit,
    onRemoveAt: (Int) -> Unit
) {
    if (items.isEmpty()) {
        EmptyExcelPlaceholder("No Inventory items parsed yet. Choose a .xlsx file or load sample.")
        return
    }

    val totalQty = items.sumOf { it.quantity }
    val totalCost = items.sumOf { it.costPriceKes * it.quantity }
    val totalRetail = items.sumOf { it.sellingPriceKes * it.quantity }

    PreviewSummaryCard(
        title = "INVENTORY ITEMS PREVIEW (${items.size})",
        subtitle = "Source: ${selectedFileName ?: "Excel Sheet"} • $totalQty Units",
        metricText = "Retail Sum: KES ${String.format("%,.0f", totalRetail)}",
        commitButtonText = "Import ${items.size} Items to Inventory",
        onCommit = onCommit
    )

    items.forEachIndexed { index, item ->
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                    Text("${item.sku} • ${item.category.label} • ${item.branchWarehouse}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Supplier: ${item.supplierName} • ${item.quantity} pcs @ KES ${String.format("%,.0f", item.sellingPriceKes)}", fontSize = 9.sp, color = Color.Gray)
                }
                IconButton(onClick = { onRemoveAt(index) }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun BurialsPreviewSection(
    items: List<BurialScheduleEvent>,
    selectedFileName: String?,
    onCommit: () -> Unit,
    onRemoveAt: (Int) -> Unit
) {
    if (items.isEmpty()) {
        EmptyExcelPlaceholder("No Burial Schedules parsed yet. Choose a .xlsx file or load sample.")
        return
    }

    PreviewSummaryCard(
        title = "BURIAL SCHEDULES PREVIEW (${items.size})",
        subtitle = "Source: ${selectedFileName ?: "Excel Sheet"} • Funerals & Committals",
        metricText = "${items.size} Cases Ready for Sync",
        commitButtonText = "Import ${items.size} Burial Schedules to App",
        onCommit = onCommit
    )

    items.forEachIndexed { index, item ->
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.deceasedName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                    Text("Date: ${item.burialDate} • Case: ${item.caseReference}", fontSize = 10.sp, color = Color(0xFF0284C7), fontWeight = FontWeight.SemiBold)
                    Text("Family: ${item.familyRepresentative} (${item.familyPhone})", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Venue: ${item.churchVenue} -> ${item.gravesiteLocation}", fontSize = 9.sp, color = Color.Gray)
                    Text("Hearse: ${item.assignedHearseReg} | Driver: ${item.assignedDriverName}", fontSize = 9.sp, color = EmeraldSuccess, fontWeight = FontWeight.Medium)
                }
                IconButton(onClick = { onRemoveAt(index) }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun OrdersPreviewSection(
    items: List<CustomerOrderRecord>,
    selectedFileName: String?,
    onCommit: () -> Unit,
    onRemoveAt: (Int) -> Unit
) {
    if (items.isEmpty()) {
        EmptyExcelPlaceholder("No Customer Orders parsed yet. Choose a .xlsx file or load sample.")
        return
    }

    val totalKes = items.sumOf { it.totalAmountKes }

    PreviewSummaryCard(
        title = "CUSTOMER ORDERS PREVIEW (${items.size})",
        subtitle = "Source: ${selectedFileName ?: "Excel Sheet"} • Funeral Contracts",
        metricText = "Total Bookings: KES ${String.format("%,.0f", totalKes)}",
        commitButtonText = "Import ${items.size} Orders to Bookings",
        onCommit = onCommit
    )

    items.forEachIndexed { index, item ->
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.clientName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                    Text("Deceased: ${item.deceasedName} • ${item.selectedPackage}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Amount: KES ${String.format("%,.0f", item.totalAmountKes)} (${item.paymentStatus}) • ${item.branch}", fontSize = 9.sp, color = CyanPrimary, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { onRemoveAt(index) }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun StaffPreviewSection(
    items: List<StaffAccount>,
    selectedFileName: String?,
    onCommit: () -> Unit,
    onRemoveAt: (Int) -> Unit
) {
    if (items.isEmpty()) {
        EmptyExcelPlaceholder("No Staff accounts parsed yet. Choose a .xlsx file or load sample.")
        return
    }

    PreviewSummaryCard(
        title = "STAFF DIRECTORY PREVIEW (${items.size})",
        subtitle = "Source: ${selectedFileName ?: "Excel Sheet"} • Personnel Profiles",
        metricText = "${items.size} Employees Ready",
        commitButtonText = "Import ${items.size} Staff Accounts to Roster",
        onCommit = onCommit
    )

    items.forEachIndexed { index, item ->
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.fullName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                    Text("${item.id} • ${item.role.title} • ${item.department.displayName}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Phone: ${item.phone} • Base: KES ${String.format("%,.0f", item.baseSalaryKes)} • ${item.branch}", fontSize = 9.sp, color = Color.Gray)
                }
                IconButton(onClick = { onRemoveAt(index) }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun FleetPreviewSection(
    items: List<FleetGpsVehicle>,
    selectedFileName: String?,
    onCommit: () -> Unit,
    onRemoveAt: (Int) -> Unit
) {
    if (items.isEmpty()) {
        EmptyExcelPlaceholder("No Fleet vehicles parsed yet. Choose a .xlsx file or load sample.")
        return
    }

    PreviewSummaryCard(
        title = "FLEET ASSETS PREVIEW (${items.size})",
        subtitle = "Source: ${selectedFileName ?: "Excel Sheet"} • Hearses & Vans",
        metricText = "${items.size} Vehicles Ready",
        commitButtonText = "Import ${items.size} Vehicles to Fleet Registry",
        onCommit = onCommit
    )

    items.forEachIndexed { index, item ->
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.registration, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                    Text(item.model, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Driver: ${item.driverName} • Fuel: ${item.fuelPercent}% • ${item.statusLabel}", fontSize = 9.sp, color = EmeraldSuccess, fontWeight = FontWeight.Medium)
                }
                IconButton(onClick = { onRemoveAt(index) }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun WorkshopPreviewSection(
    items: List<WorkshopProductionItem>,
    selectedFileName: String?,
    onCommit: () -> Unit,
    onRemoveAt: (Int) -> Unit
) {
    if (items.isEmpty()) {
        EmptyExcelPlaceholder("No Workshop jobs parsed yet. Choose a .xlsx file or load sample.")
        return
    }

    PreviewSummaryCard(
        title = "WORKSHOP JOBS PREVIEW (${items.size})",
        subtitle = "Source: ${selectedFileName ?: "Excel Sheet"} • Production Queue",
        metricText = "${items.size} Crafting Jobs",
        commitButtonText = "Import ${items.size} Jobs to Workshop Queue",
        onCommit = onCommit
    )

    items.forEachIndexed { index, item ->
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.casketType, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                    Text("Wood: ${item.woodType} • Artisan: ${item.assignedCraftsmanName}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Stage: ${item.currentStage.title} (${item.percentageDone}%) • Target: ${item.targetCompletionDate}", fontSize = 9.sp, color = CyanPrimary, fontWeight = FontWeight.SemiBold)
                }
                IconButton(onClick = { onRemoveAt(index) }, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun PreviewSummaryCard(
    title: String,
    subtitle: String,
    metricText: String,
    commitButtonText: String,
    onCommit: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = CyanPrimary)
                    Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Surface(
                    color = Color(0xFF107C41).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = metricText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF107C41),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onCommit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("btn_universal_commit_excel")
            ) {
                Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(commitButtonText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun EmptyExcelPlaceholder(message: String) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.TableChart, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(message, fontSize = 11.sp, color = Color.Gray, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

private fun getDatasetIcon(type: ExcelDatasetType): ImageVector {
    return when (type) {
        ExcelDatasetType.INVENTORY_STOCK -> Icons.Default.Inventory
        ExcelDatasetType.BURIAL_SCHEDULES -> Icons.Default.CalendarMonth
        ExcelDatasetType.CUSTOMER_ORDERS -> Icons.Default.ReceiptLong
        ExcelDatasetType.STAFF_ACCOUNTS -> Icons.Default.People
        ExcelDatasetType.FLEET_VEHICLES -> Icons.Default.DirectionsCar
        ExcelDatasetType.WORKSHOP_JOBS -> Icons.Default.PrecisionManufacturing
    }
}
