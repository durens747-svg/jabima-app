package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.domain.TimelineScheduleHelper
import com.example.model.ActivityStatus
import com.example.model.StaffActivity
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.Blue100
import com.example.ui.theme.Blue200
import com.example.ui.theme.Blue50
import com.example.ui.theme.Blue700
import com.example.ui.theme.Blue800
import com.example.ui.theme.Blue900
import com.example.ui.theme.Blue950
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite

/**
 * Interactive Detail & Action Dialog Pane for inspecting a chronological funeral task,
 * toggling arrangement checklist items, switching real-time status with progress notes,
 * and alerting the assigned crew member.
 */
@Composable
fun TaskDetailDialogPane(
    activity: StaffActivity,
    isAdminOrCeo: Boolean,
    onDismiss: () -> Unit,
    onUpdateStatus: (activityId: String, status: ActivityStatus, notes: String?) -> Unit,
    onToggleChecklistItem: (activityId: String, item: String) -> Unit,
    onDispatchTaskAlert: (StaffActivity) -> Unit,
    onOpenAssessPrice: (StaffActivity) -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = PureWhite,
            tonalElevation = 6.dp,
            shadowElevation = 10.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 580.dp)
                .heightIn(max = 720.dp)
                .testTag("task_detail_dialog_pane")
        ) {
            TaskDetailPaneContent(
                activity = activity,
                isAdminOrCeo = isAdminOrCeo,
                showCloseButton = true,
                onClose = onDismiss,
                onUpdateStatus = { newStatus, notes ->
                    onUpdateStatus(activity.id, newStatus, notes)
                },
                onToggleChecklistItem = { item ->
                    onToggleChecklistItem(activity.id, item)
                },
                onDispatchTaskAlert = { onDispatchTaskAlert(activity) },
                onOpenAssessPrice = { onOpenAssessPrice(activity) }
            )
        }
    }
}

/**
 * Shared pane content usable both inside the phone Dialog Pane and inside
 * the wide-screen / foldable List-Detail Timeline side pane.
 */
@Composable
fun TaskDetailPaneContent(
    activity: StaffActivity,
    isAdminOrCeo: Boolean,
    showCloseButton: Boolean = false,
    onClose: () -> Unit = {},
    onUpdateStatus: (status: ActivityStatus, notes: String?) -> Unit,
    onToggleChecklistItem: (item: String) -> Unit,
    onDispatchTaskAlert: () -> Unit,
    onOpenAssessPrice: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedStatus by remember(activity.id, activity.status) { mutableStateOf(activity.status) }
    var progressNotes by remember(activity.id) { mutableStateOf("") }
    val timeWindow = TimelineScheduleHelper.formatTimeWindow(activity.time, activity.durationMinutes)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("task_detail_pane_content_${activity.id}")
    ) {
        // Header Banner
        Surface(
            color = Navy900,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = Color.White.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = timeWindow,
                                color = Color(0xFFBAE6FD),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Surface(
                            color = Color(activity.priority.colorHex).copy(alpha = 0.25f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = activity.priority.label,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = activity.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${activity.caseReference} • ${activity.clientFamily}",
                        color = Blue200,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (showCloseButton) {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("pane_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Task Detail Pane",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // Scrollable Body
        Column(
            modifier = Modifier
                .weight(1f, fill = false)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Assignment Details Card
            Surface(
                color = Blue50,
                border = BorderStroke(1.dp, Blue100),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = Blue800, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${activity.staffName} • ${activity.department.displayName}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Blue950
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = Blue800, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = activity.location,
                            fontSize = 12.sp,
                            color = Blue900
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = Blue700, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${activity.date} • ${activity.durationMinutes} min",
                                fontSize = 11.sp,
                                color = Color(0xFF475569)
                            )
                        }
                        Surface(
                            color = EmeraldLight,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "+KES ${String.format("%,.0f", activity.allowanceEarned)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = EmeraldSuccess,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    if (activity.assignedVehicle != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Blue800, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Fleet: ${activity.assignedVehicle}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Blue900
                            )
                        }
                    }
                    if (activity.assignedEquipment != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Build, contentDescription = null, tint = Blue800, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Gear: ${activity.assignedEquipment}",
                                fontSize = 11.sp,
                                color = Color(0xFF334155)
                            )
                        }
                    }
                    if (activity.notes.isNotBlank()) {
                        HorizontalDivider(color = Blue100)
                        Text(
                            text = activity.notes,
                            fontSize = 11.sp,
                            color = Color(0xFF475569),
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // Real-Time Status Update Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Task Status Control (Current: ${activity.status.label})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Blue950
                )

                val statusChoices = ActivityStatus.values().toList()
                statusChoices.chunked(2).forEach { rowStatuses ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowStatuses.forEach { st ->
                            val isSelected = selectedStatus == st
                            val accentColor = statusAccentColor(st)
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) accentColor else Color(0xFFF8FAFC),
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) accentColor else Color(0xFFCBD5E1)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 44.dp)
                                    .clickable { selectedStatus = st }
                                    .testTag("pane_status_option_${st.name.lowercase()}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = statusIcon(st),
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else accentColor,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = st.label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) Color.White else Blue950,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = progressNotes,
                    onValueChange = { progressNotes = it },
                    label = { Text("Field Progress / Handover Note (Optional)", fontSize = 11.sp) },
                    placeholder = { Text("e.g. Lowering straps tension verified; family seated.", fontSize = 11.sp) },
                    maxLines = 2,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue800,
                        unfocusedBorderColor = Blue200
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pane_status_notes_input")
                )

                Button(
                    onClick = { onUpdateStatus(selectedStatus, progressNotes.ifBlank { null }) },
                    colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("pane_save_status_button")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Apply Status: ${selectedStatus.label}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            // Interactive Arrangement Checklist
            if (activity.checklistItems.isNotEmpty()) {
                val doneCount = activity.checklistItems.count { activity.completedChecklistItems.contains(it) }
                val totalCount = activity.checklistItems.size
                val ratio = if (totalCount > 0) doneCount.toFloat() / totalCount else 0f

                Surface(
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Arrangement Checklist ($doneCount/$totalCount)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Blue900
                            )
                            Text(
                                text = "${(ratio * 100).toInt()}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (ratio == 1f) EmeraldSuccess else Blue700
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { ratio },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (ratio == 1f) EmeraldSuccess else Blue800,
                            trackColor = Color(0xFFE2E8F0)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        activity.checklistItems.forEach { item ->
                            val checked = activity.completedChecklistItems.contains(item)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onToggleChecklistItem(item) }
                                    .padding(vertical = 4.dp)
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { onToggleChecklistItem(item) },
                                    modifier = Modifier.size(22.dp),
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = EmeraldSuccess,
                                        uncheckedColor = Color(0xFF94A3B8)
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = item,
                                    fontSize = 11.sp,
                                    color = if (checked) Color(0xFF94A3B8) else Blue950,
                                    textDecoration = if (checked) TextDecoration.LineThrough else TextDecoration.None
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Coordination Actions (Shift Alert + Admin Pricing)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onDispatchTaskAlert,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberLight,
                        contentColor = Navy900
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("pane_alert_crew_button")
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Send Shift Alert",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                if (isAdminOrCeo) {
                    OutlinedButton(
                        onClick = onOpenAssessPrice,
                        border = BorderStroke(1.dp, EmeraldSuccess),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("pane_assess_price_button")
                    ) {
                        Icon(Icons.Default.AttachMoney, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Price & Pay",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }
            }
        }
    }
}

private fun statusAccentColor(status: ActivityStatus): Color = when (status) {
    ActivityStatus.IN_PROGRESS -> Color(0xFF10B981)
    ActivityStatus.IN_TRANSIT -> Color(0xFF2563EB)
    ActivityStatus.SCHEDULED -> Blue700
    ActivityStatus.ON_HOLD -> Color(0xFFD97706)
    ActivityStatus.COMPLETED -> EmeraldSuccess
    ActivityStatus.VERIFIED_BY_ADMIN -> Color(0xFF7C3AED)
}

private fun statusIcon(status: ActivityStatus) = when (status) {
    ActivityStatus.IN_PROGRESS -> Icons.Default.CheckCircle
    ActivityStatus.IN_TRANSIT -> Icons.Default.DirectionsCar
    ActivityStatus.SCHEDULED -> Icons.Default.Schedule
    ActivityStatus.ON_HOLD -> Icons.Default.Pause
    ActivityStatus.COMPLETED -> Icons.Default.Check
    ActivityStatus.VERIFIED_BY_ADMIN -> Icons.Default.Verified
}
