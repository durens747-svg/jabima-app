package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Department
import com.example.model.JABIMA_BRANCHES
import com.example.model.JABIMA_FLEET
import com.example.model.ShiftPeriod
import com.example.model.StaffAccount
import com.example.model.StaffShiftSchedule
import com.example.ui.StaffPortalViewModel
import com.example.ui.components.ShiftAttendanceVerificationSection
import com.example.ui.theme.Blue100
import com.example.ui.theme.Blue200
import com.example.ui.theme.Blue50
import com.example.ui.theme.Blue700
import com.example.ui.theme.Blue800
import com.example.ui.theme.Blue900
import com.example.ui.theme.Blue950
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PureWhite
import java.util.UUID

// Day selector model for interactive week strip
data class CalendarDay(
    val dayName: String,
    val dayNumber: String,
    val fullDate: String,
    val isToday: Boolean = false,
    val isPast: Boolean = false
)

private val CALENDAR_DAYS = listOf(
    CalendarDay("Mon", "21", "21 Sep 2026", isPast = true),
    CalendarDay("Tue", "22", "22 Sep 2026", isPast = true),
    CalendarDay("Wed", "23", "23 Sep 2026", isToday = true),
    CalendarDay("Thu", "24", "24 Sep 2026"),
    CalendarDay("Fri", "25", "25 Sep 2026"),
    CalendarDay("Sat", "26", "26 Sep 2026"),
    CalendarDay("Sun", "27", "27 Sep 2026")
)

enum class RosterFilterTab(val title: String, val subtitle: String) {
    ALL("All Shifts", "Complete schedule"),
    ACTIVE("Active Now", "Currently on-duty"),
    UPCOMING("Upcoming", "Scheduled rosters"),
    PAST("Past Shifts", "Completed history")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RosterCalendarScreen(
    viewModel: StaffPortalViewModel,
    onOpenShiftQrScanner: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val shifts by viewModel.staffShiftSchedules.collectAsState()
    val allStaff by viewModel.allAccounts.collectAsState()
    val staffAlerts by viewModel.staffAlerts.collectAsState()
    val shiftAttendanceLogs by viewModel.shiftAttendanceLogs.collectAsState()
    val currentActor by viewModel.currentAccount.collectAsState()
    val adminImpersonator by viewModel.adminImpersonator.collectAsState()
    val canVerifyShiftAttendance = remember(currentActor, adminImpersonator) {
        viewModel.canCurrentUserVerifyShiftAttendance()
    }
    val unreadShiftAlertsCount = remember(staffAlerts) { staffAlerts.count { !it.isRead } }

    var selectedTab by remember { mutableStateOf(RosterFilterTab.ALL) }
    var selectedDay by remember { mutableStateOf<CalendarDay?>(null) } // null = All days
    var departmentFilter by remember { mutableStateOf<Department?>(null) }
    var branchFilter by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    // Dialog controllers
    var shiftToEdit by remember { mutableStateOf<StaffShiftSchedule?>(null) }
    var shiftForStatusUpdate by remember { mutableStateOf<StaffShiftSchedule?>(null) }
    var shiftForDetailReport by remember { mutableStateOf<StaffShiftSchedule?>(null) }
    var showAddShiftDialog by remember { mutableStateOf(false) }

    // Counts for high-level dashboard
    val activeShifts = shifts.filter { it.shiftPeriod == ShiftPeriod.ACTIVE }
    val upcomingShifts = shifts.filter { it.shiftPeriod == ShiftPeriod.UPCOMING }
    val pastShifts = shifts.filter { it.shiftPeriod == ShiftPeriod.PAST }
    val activeHearsesCount = activeShifts.count { it.hearseAssigned != null }

    // Multi-factor filtering
    val filteredShifts = shifts.filter { shift ->
        val matchesTab = when (selectedTab) {
            RosterFilterTab.ALL -> true
            RosterFilterTab.ACTIVE -> shift.shiftPeriod == ShiftPeriod.ACTIVE
            RosterFilterTab.UPCOMING -> shift.shiftPeriod == ShiftPeriod.UPCOMING
            RosterFilterTab.PAST -> shift.shiftPeriod == ShiftPeriod.PAST
        }
        val matchesDay = selectedDay == null || shift.dateFormatted == selectedDay?.fullDate
        val matchesDept = departmentFilter == null || shift.department == departmentFilter
        val matchesBranch = branchFilter == null || shift.assignedBranch == branchFilter
        val matchesSearch = searchQuery.isBlank() ||
                shift.staffName.contains(searchQuery, ignoreCase = true) ||
                shift.shiftType.contains(searchQuery, ignoreCase = true) ||
                (shift.hearseAssigned?.contains(searchQuery, ignoreCase = true) == true) ||
                (shift.destination?.contains(searchQuery, ignoreCase = true) == true) ||
                (shift.caseReference?.contains(searchQuery, ignoreCase = true) == true) ||
                (shift.familyName?.contains(searchQuery, ignoreCase = true) == true)

        matchesTab && matchesDay && matchesDept && matchesBranch && matchesSearch
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(horizontal = 16.dp)
            .testTag("staff_roster_dashboard"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) {
        // ==========================================
        // 1. DASHBOARD OVERVIEW & METRICS BANNER
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Blue900),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("roster_dashboard_header_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Header Row with Title & Schedule Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = "Staff Roster",
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Staff Roster Dashboard",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = "Deployment & Shift Oversight • Active, Upcoming & Past Funeral Operations",
                                    color = Blue100,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Button(
                            onClick = { showAddShiftDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Blue900
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_schedule_new_shift")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Schedule Shift", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 4 KEY OPERATIONAL METRICS CARDS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 🟢 ACTIVE SHIFTS METRIC
                        Surface(
                            color = Color(0xFF064E3B).copy(alpha = 0.6f),
                            border = BorderStroke(1.dp, Color(0xFF10B981)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedTab = RosterFilterTab.ACTIVE }
                                .testTag("metric_active_shifts")
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF10B981))
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "${activeShifts.size}",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Active Now",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFA7F3D0)
                                )
                                Text(
                                    text = "On-Duty & Transit",
                                    fontSize = 8.sp,
                                    color = Color(0xFFD1FAE5)
                                )
                            }
                        }

                        // 🔵 UPCOMING SHIFTS METRIC
                        Surface(
                            color = Color(0xFF1E3A8A).copy(alpha = 0.6f),
                            border = BorderStroke(1.dp, Color(0xFF60A5FA)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedTab = RosterFilterTab.UPCOMING }
                                .testTag("metric_upcoming_shifts")
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Schedule,
                                        contentDescription = null,
                                        tint = Color(0xFF93C5FD),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${upcomingShifts.size}",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Upcoming",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFBFDBFE)
                                )
                                Text(
                                    text = "Next 72 Hours",
                                    fontSize = 8.sp,
                                    color = Color(0xFFDBEAFE)
                                )
                            }
                        }

                        // ⚪ PAST SHIFTS METRIC
                        Surface(
                            color = Color(0xFF334155).copy(alpha = 0.6f),
                            border = BorderStroke(1.dp, Color(0xFF94A3B8)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedTab = RosterFilterTab.PAST }
                                .testTag("metric_past_shifts")
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.History,
                                        contentDescription = null,
                                        tint = Color(0xFFCBD5E1),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${pastShifts.size}",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Past Shifts",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFE2E8F0)
                                )
                                Text(
                                    text = "Hours Verified",
                                    fontSize = 8.sp,
                                    color = Color(0xFFF1F5F9)
                                )
                            }
                        }

                        // 🚑 HEARSES EN ROUTE METRIC
                        Surface(
                            color = Color.White.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.DirectionsCar,
                                        contentDescription = null,
                                        tint = Color(0xFF93C5FD),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "$activeHearsesCount",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Hearses Out",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Blue100
                                )
                                Text(
                                    text = "Fleet Escort",
                                    fontSize = 8.sp,
                                    color = Blue100
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // SHIFT ALERT SYSTEM QUICK BAR
                    Surface(
                        color = Color.White.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, Color(0xFFFBBF24).copy(alpha = 0.55f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("roster_shift_alert_bar")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "Shift Alert System",
                                tint = Color(0xFFFBBF24),
                                modifier = Modifier.size(18.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Shift Alert System",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "$unreadShiftAlertsCount active alert(s) • SMS & Hub",
                                    color = Color(0xFFFDE68A),
                                    fontSize = 10.sp
                                )
                            }
                            OutlinedButton(
                                onClick = { viewModel.triggerDueShiftAlertsScan() },
                                border = BorderStroke(1.dp, Color(0xFFFBBF24)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("btn_roster_scan_due_shifts")
                            ) {
                                Icon(Icons.Default.Radar, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Scan Shifts", fontSize = 10.sp, color = Color(0xFFFBBF24), fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                            Button(
                                onClick = { viewModel.openShiftAlertCenter() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color(0xFF0F2942)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("btn_roster_open_alert_center")
                            ) {
                                Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Alert Hub ($unreadShiftAlertsCount)", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                            }
                        }
                    }

                    if (canVerifyShiftAttendance) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onOpenShiftQrScanner,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldSuccess,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_roster_verify_qr_attendance")
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Verify 24/7 Staff Shift QR Attendance (${shiftAttendanceLogs.size})",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // 2. PRIMARY TIMELINE TABS (ALL, ACTIVE, UPCOMING, PAST)
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, Blue200),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("roster_timeline_tab_card")
            ) {
                androidx.compose.material3.ScrollableTabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = PureWhite,
                    contentColor = Blue900,
                    edgePadding = 8.dp,
                    indicator = { tabPositions ->
                        if (selectedTab.ordinal < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                                color = Blue800,
                                height = 3.dp
                            )
                        }
                    }
                ) {
                    RosterFilterTab.values().forEach { tab ->
                        val count = when (tab) {
                            RosterFilterTab.ALL -> shifts.size
                            RosterFilterTab.ACTIVE -> activeShifts.size
                            RosterFilterTab.UPCOMING -> upcomingShifts.size
                            RosterFilterTab.PAST -> pastShifts.size
                        }

                        val badgeColor = when (tab) {
                            RosterFilterTab.ALL -> Blue800
                            RosterFilterTab.ACTIVE -> Color(0xFF059669)
                            RosterFilterTab.UPCOMING -> Color(0xFF2563EB)
                            RosterFilterTab.PAST -> Color(0xFF64748B)
                        }

                        Tab(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            modifier = Modifier.testTag("tab_roster_${tab.name.lowercase()}"),
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = tab.title,
                                        fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 12.sp,
                                        color = if (selectedTab == tab) Blue900 else Color(0xFF64748B),
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (selectedTab == tab) badgeColor else badgeColor.copy(alpha = 0.15f),
                                                CircleShape
                                            )
                                            .padding(horizontal = 6.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "$count",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (selectedTab == tab) Color.White else badgeColor,
                                            maxLines = 1,
                                            softWrap = false
                                        )
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }

        // ==========================================
        // 3. INTERACTIVE VISUAL WEEK CALENDAR STRIP
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Blue50),
                border = BorderStroke(1.dp, Blue100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = Blue800, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Weekly Day Strip • Week 39 (Sep 2026)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Blue950
                            )
                        }

                        if (selectedDay != null) {
                            TextButton(
                                onClick = { selectedDay = null },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Clear Day Filter", fontSize = 11.sp, color = Blue800, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        CALENDAR_DAYS.forEach { day ->
                            val isSelected = day == selectedDay
                            val dayShiftCount = shifts.count { it.dateFormatted == day.fullDate }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) Blue900 else if (day.isToday) Color(0xFFDBEAFE) else PureWhite,
                                border = if (day.isToday && !isSelected) BorderStroke(1.dp, Color(0xFF3B82F6)) else BorderStroke(1.dp, Blue100),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 2.dp)
                                    .clickable { selectedDay = if (isSelected) null else day }
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = day.dayName,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) Color.White else if (day.isToday) Blue900 else Color(0xFF64748B)
                                    )
                                    Text(
                                        text = day.dayNumber,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else Blue950
                                    )
                                    // Day shift count dot
                                    if (dayShiftCount > 0) {
                                        Box(
                                            modifier = Modifier
                                                .padding(top = 2.dp)
                                                .size(4.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isSelected) Color.White else if (day.isToday) Color(0xFF10B981) else Blue700
                                                )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 4. SEARCH & MULTI-FILTER BAR
        // ==========================================
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_roster_input"),
                    placeholder = {
                        Text("Search personnel, hearse plate (e.g. KDG 705Y), destination, case...", fontSize = 12.sp)
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Blue800, modifier = Modifier.size(18.dp))
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color(0xFF64748B), modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue800,
                        unfocusedBorderColor = Blue200,
                        focusedContainerColor = PureWhite,
                        unfocusedContainerColor = PureWhite
                    )
                )

                // Department filter chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = departmentFilter == null,
                            onClick = { departmentFilter = null },
                            label = { Text("All Depts (${shifts.size})", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                    items(Department.values()) { dept ->
                        val count = shifts.count { it.department == dept }
                        FilterChip(
                            selected = departmentFilter == dept,
                            onClick = { departmentFilter = if (departmentFilter == dept) null else dept },
                            label = { Text("${dept.displayName} ($count)", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                }

                // Branch filter chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = branchFilter == null,
                            onClick = { branchFilter = null },
                            label = { Text("All 8 Branches", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                    items(JABIMA_BRANCHES) { b ->
                        val count = shifts.count { it.assignedBranch == b }
                        FilterChip(
                            selected = branchFilter == b,
                            onClick = { branchFilter = if (branchFilter == b) null else b },
                            label = { Text("$b ($count)", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                }
            }
        }

        // ==========================================
        // 4B. 24/7 QR SHIFT ATTENDANCE LEDGER
        // ==========================================
        item {
            ShiftAttendanceVerificationSection(
                attendanceLogs = shiftAttendanceLogs,
                canVerifyAttendance = canVerifyShiftAttendance,
                onOpenScanner = onOpenShiftQrScanner
            )
        }

        // ==========================================
        // 5. SHIFT CARDS LIST (ORGANIZED BY PERIOD)
        // ==========================================
        if (filteredShifts.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Blue50),
                    border = BorderStroke(1.dp, Blue100),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Blue800, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No Shifts Found Matching Filters",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Blue950
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Try clearing search filters or changing the active timeline tab.",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                selectedTab = RosterFilterTab.ALL
                                selectedDay = null
                                departmentFilter = null
                                branchFilter = null
                                searchQuery = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Reset All Filters", fontSize = 11.sp)
                        }
                    }
                }
            }
        } else {
            // Grouped Section: ACTIVE SHIFTS (if viewing ALL or ACTIVE)
            val showActiveSection = (selectedTab == RosterFilterTab.ALL || selectedTab == RosterFilterTab.ACTIVE) &&
                    filteredShifts.any { it.shiftPeriod == ShiftPeriod.ACTIVE }

            if (showActiveSection) {
                val activeItems = filteredShifts.filter { it.shiftPeriod == ShiftPeriod.ACTIVE }
                item {
                    SectionHeader(
                        title = "Active Operations & Live Personnel",
                        count = activeItems.size,
                        badgeColor = Color(0xFF059669),
                        indicatorText = "LIVE ON-DUTY"
                    )
                }

                items(activeItems, key = { it.id }) { shift ->
                    ShiftRosterCard(
                        shift = shift,
                        onEdit = { shiftToEdit = shift },
                        onUpdateStatus = { shiftForStatusUpdate = shift },
                        onViewReport = { shiftForDetailReport = shift },
                        onContactStaff = {
                            viewModel.openShiftAlertCenter(staffId = shift.staffId, shiftId = shift.id)
                        }
                    )
                }
            }

            // Grouped Section: UPCOMING SHIFTS (if viewing ALL or UPCOMING)
            val showUpcomingSection = (selectedTab == RosterFilterTab.ALL || selectedTab == RosterFilterTab.UPCOMING) &&
                    filteredShifts.any { it.shiftPeriod == ShiftPeriod.UPCOMING }

            if (showUpcomingSection) {
                val upcomingItems = filteredShifts.filter { it.shiftPeriod == ShiftPeriod.UPCOMING }
                item {
                    SectionHeader(
                        title = "Upcoming Scheduled Rosters",
                        count = upcomingItems.size,
                        badgeColor = Color(0xFF2563EB),
                        indicatorText = "SCHEDULED"
                    )
                }

                items(upcomingItems, key = { it.id }) { shift ->
                    ShiftRosterCard(
                        shift = shift,
                        onEdit = { shiftToEdit = shift },
                        onUpdateStatus = { shiftForStatusUpdate = shift },
                        onViewReport = { shiftForDetailReport = shift },
                        onContactStaff = {
                            viewModel.dispatchShiftAlert(
                                recipientStaffId = shift.staffId,
                                title = "Upcoming Shift Alert: ${shift.shiftType}",
                                message = "Scheduled ${shift.startTime}–${shift.endTime} at ${shift.assignedBranch}. Confirm readiness.",
                                priority = com.example.model.TaskPriority.HIGH,
                                shiftId = shift.id,
                                scheduledTimeLabel = "${shift.startTime}–${shift.endTime}",
                                branch = shift.assignedBranch,
                                relatedEntityId = shift.caseReference
                            )
                        }
                    )
                }
            }

            // Grouped Section: PAST SHIFTS (if viewing ALL or PAST)
            val showPastSection = (selectedTab == RosterFilterTab.ALL || selectedTab == RosterFilterTab.PAST) &&
                    filteredShifts.any { it.shiftPeriod == ShiftPeriod.PAST }

            if (showPastSection) {
                val pastItems = filteredShifts.filter { it.shiftPeriod == ShiftPeriod.PAST }
                item {
                    SectionHeader(
                        title = "Past Shifts & Verified Log History",
                        count = pastItems.size,
                        badgeColor = Color(0xFF64748B),
                        indicatorText = "COMPLETED"
                    )
                }

                items(pastItems, key = { it.id }) { shift ->
                    ShiftRosterCard(
                        shift = shift,
                        onEdit = { shiftToEdit = shift },
                        onUpdateStatus = { shiftForStatusUpdate = shift },
                        onViewReport = { shiftForDetailReport = shift },
                        onContactStaff = {
                            viewModel.actionFeedbackMessage.value = "Shift history record for ${shift.staffName} (Verified by ${shift.supervisorName})"
                        }
                    )
                }
            }
        }
    }

    // ==========================================
    // DIALOGS & ACTION SHEETS
    // ==========================================

    // 1. ADD / SCHEDULE NEW SHIFT DIALOG
    if (showAddShiftDialog) {
        AddShiftDialog(
            allStaff = allStaff,
            onDismiss = { showAddShiftDialog = false },
            onSave = { newShift ->
                viewModel.addShiftSchedule(newShift)
                showAddShiftDialog = false
            }
        )
    }

    // 2. EDIT / REASSIGN SHIFT DIALOG
    if (shiftToEdit != null) {
        EditShiftDialog(
            shift = shiftToEdit!!,
            onDismiss = { shiftToEdit = null },
            onSave = { updated ->
                viewModel.updateShiftSchedule(updated)
                shiftToEdit = null
            }
        )
    }

    // 3. STATUS UPDATE DIALOG (Switch status between On-Duty, Transit, On-Call, or Complete Shift)
    if (shiftForStatusUpdate != null) {
        UpdateShiftStatusDialog(
            shift = shiftForStatusUpdate!!,
            onDismiss = { shiftForStatusUpdate = null },
            onConfirmStatus = { newAvailability, newPeriod ->
                viewModel.setShiftStatus(shiftForStatusUpdate!!.id, newAvailability, newPeriod)
                shiftForStatusUpdate = null
            }
        )
    }

    // 4. SHIFT DETAIL & PROTOCOL REPORT DIALOG
    if (shiftForDetailReport != null) {
        ShiftDetailReportDialog(
            shift = shiftForDetailReport!!,
            onDismiss = { shiftForDetailReport = null }
        )
    }
}

// Section Header component for grouped timelines
@Composable
private fun SectionHeader(
    title: String,
    count: Int,
    badgeColor: Color,
    indicatorText: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(badgeColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Blue950
            )
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .background(badgeColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "$count",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = badgeColor
                )
            }
        }

        Box(
            modifier = Modifier
                .background(badgeColor.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
                .border(1.dp, badgeColor.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = indicatorText,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = badgeColor
            )
        }
    }
}

// ==========================================
// SHIFT ROSTER CARD COMPONENT
// ==========================================
@Composable
private fun ShiftRosterCard(
    shift: StaffShiftSchedule,
    onEdit: () -> Unit,
    onUpdateStatus: () -> Unit,
    onViewReport: () -> Unit,
    onContactStaff: () -> Unit
) {
    // Dynamic styling based on shift period
    val (cardBorderColor, periodBadgeBg, periodBadgeFg) = when (shift.shiftPeriod) {
        ShiftPeriod.ACTIVE -> Triple(Color(0xFF10B981).copy(alpha = 0.5f), Color(0xFFECFDF5), Color(0xFF047857))
        ShiftPeriod.UPCOMING -> Triple(Color(0xFF3B82F6).copy(alpha = 0.4f), Color(0xFFEFF6FF), Color(0xFF1D4ED8))
        ShiftPeriod.PAST -> Triple(Color(0xFF94A3B8).copy(alpha = 0.4f), Color(0xFFF8FAFC), Color(0xFF475569))
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, cardBorderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("shift_card_${shift.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Avatar, Name, Dept & Period Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                when (shift.shiftPeriod) {
                                    ShiftPeriod.ACTIVE -> Color(0xFF059669)
                                    ShiftPeriod.UPCOMING -> Blue800
                                    ShiftPeriod.PAST -> Color(0xFF475569)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = shift.staffName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = shift.staffName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Blue950
                            )
                            if (shift.shiftPeriod == ShiftPeriod.ACTIVE) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF10B981))
                                )
                            }
                        }
                        Text(
                            text = "${shift.department.displayName} • ${shift.staffId}",
                            fontSize = 11.sp,
                            color = Blue700,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Availability / Status Badge
                Column(horizontalAlignment = Alignment.End) {
                    Box(
                        modifier = Modifier
                            .background(periodBadgeBg, RoundedCornerShape(6.dp))
                            .border(1.dp, periodBadgeFg.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = shift.availabilityStatus,
                            color = periodBadgeFg,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = shift.shiftPeriod.label,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = periodBadgeFg.copy(alpha = 0.8f)
                    )
                    if (shift.checkInStatus.contains("QR Verified", ignoreCase = true)) {
                        Spacer(modifier = Modifier.height(3.dp))
                        Surface(
                            color = Color(0xFFECFDF5),
                            border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCode2,
                                    contentDescription = "QR Verified Shift",
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "QR Verified",
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = EmeraldSuccess
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Shift Type, Date & Hours Pill
            Surface(
                color = Blue50,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Blue100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, contentDescription = null, tint = Blue800, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = shift.shiftType,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Blue900
                            )
                            Text(
                                text = "${shift.dayOfWeek}, ${shift.dateFormatted} (${shift.startTime} - ${shift.endTime})",
                                fontSize = 10.sp,
                                color = Color(0xFF475569)
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Place, contentDescription = null, tint = Blue800, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = shift.assignedBranch,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Blue900
                        )
                    }
                }
            }

            // Route / Destination if assigned
            if (shift.destination != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Deployment Route: ${shift.destination}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Blue950
                    )
                }
            }

            // Hearse assignment chip
            if (shift.hearseAssigned != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = Color(0xFFEFF6FF),
                    border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Assigned Hearse: ${shift.hearseAssigned}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Blue900
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "• VIP Escort Ready",
                            fontSize = 9.sp,
                            color = Color(0xFF2563EB),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Funeral equipment assigned
            if (shift.equipmentAssigned != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = Color(0xFF0369A1), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Equipment: ${shift.equipmentAssigned}",
                        fontSize = 10.sp,
                        color = Color(0xFF0369A1),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Bereaved Family / Case Reference Tag if linked
            if (shift.caseReference != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Assignment, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Case: ${shift.caseReference} (${shift.familyName ?: "Family Case"})",
                        fontSize = 10.sp,
                        color = Color(0xFF334155),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Notes / Protocol Task
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = shift.notes,
                fontSize = 11.sp,
                color = Color(0xFF334155),
                lineHeight = 15.sp
            )

            // Past Shift debrief / hours logged
            if (shift.shiftPeriod == ShiftPeriod.PAST) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Hours Logged: ${shift.hoursLogged} hrs (${shift.checkInStatus})",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                        }
                        Text(
                            text = "Signed: ${shift.supervisorName}",
                            fontSize = 9.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 0.8.dp)
            Spacer(modifier = Modifier.height(6.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Quick Action: 3CX Phone Contact or Report
                OutlinedButton(
                    onClick = onContactStaff,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, Blue200),
                    modifier = Modifier.testTag("btn_contact_${shift.id}")
                ) {
                    Icon(
                        imageVector = if (shift.shiftPeriod == ShiftPeriod.PAST) Icons.Default.Info else Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = Blue800,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = when (shift.shiftPeriod) {
                            ShiftPeriod.ACTIVE -> "Shift Alert"
                            ShiftPeriod.UPCOMING -> "Send Alert"
                            ShiftPeriod.PAST -> "Details"
                        },
                        fontSize = 11.sp,
                        color = Blue900,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Update Status (Switch to transit, active, or complete)
                    OutlinedButton(
                        onClick = onUpdateStatus,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, Blue200),
                        modifier = Modifier.testTag("btn_status_${shift.id}")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (shift.shiftPeriod == ShiftPeriod.ACTIVE) "Update Status" else if (shift.shiftPeriod == ShiftPeriod.UPCOMING) "Clock In" else "Sign-off",
                            fontSize = 11.sp,
                            color = Blue800,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Reassign / Edit
                    Button(
                        onClick = onEdit,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("btn_reassign_${shift.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reassign", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// 1. ADD / SCHEDULE NEW SHIFT DIALOG
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddShiftDialog(
    allStaff: List<StaffAccount>,
    onDismiss: () -> Unit,
    onSave: (StaffShiftSchedule) -> Unit
) {
    var selectedStaff by remember { mutableStateOf(allStaff.firstOrNull()) }
    var selectedDepartment by remember { mutableStateOf(selectedStaff?.department ?: Department.DRIVERS) }
    var selectedBranch by remember { mutableStateOf(selectedStaff?.branch ?: "Siaya Referral (Opposite Morgue)") }
    var selectedPeriod by remember { mutableStateOf(ShiftPeriod.UPCOMING) }
    var shiftType by remember { mutableStateOf("Morning Cortege Escort (06:00 - 14:00)") }
    var startTime by remember { mutableStateOf("06:00") }
    var endTime by remember { mutableStateOf("14:00") }
    var assignedHearse by remember { mutableStateOf<String?>("KBR 104R") }
    var equipment by remember { mutableStateOf("VIP Church Trolley Bier & Lowering Gear") }
    var destination by remember { mutableStateOf("Siaya Referral -> Bondo Central Cemetery") }
    var caseRef by remember { mutableStateOf("CASE-2026-0920") }
    var familyName by remember { mutableStateOf("Late Elder Family") }
    var notes by remember { mutableStateOf("Escort procession protocol and church vigil assistance.") }

    var staffDropdownExpanded by remember { mutableStateOf(false) }
    var branchDropdownExpanded by remember { mutableStateOf(false) }
    var hearseDropdownExpanded by remember { mutableStateOf(false) }

    val presetShifts = listOf(
        "Morning Cortege Escort (06:00 - 14:00)",
        "Evening Shift & Vigil Setup (14:00 - 22:00)",
        "24/7 Night Deceased Evacuation On-Call",
        "Gravesite Rigging & Lowering Gear (07:00 - 15:00)",
        "Workshop Dome Casket Crafting (06:00 - 14:00)",
        "Family Grief Consultation (08:00 - 17:00)"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Blue800)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Schedule Funeral Personnel Shift", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Blue900)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Select Personnel
                item {
                    Text("Select Funeral Staff Member:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    ExposedDropdownMenuBox(
                        expanded = staffDropdownExpanded,
                        onExpandedChange = { staffDropdownExpanded = !staffDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedStaff?.let { "${it.fullName} (${it.role.title})" } ?: "Select Personnel",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = staffDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .testTag("dropdown_staff_select")
                        )
                        ExposedDropdownMenu(
                            expanded = staffDropdownExpanded,
                            onDismissRequest = { staffDropdownExpanded = false }
                        ) {
                            allStaff.forEach { staff ->
                                DropdownMenuItem(
                                    text = { Text("${staff.fullName} • ${staff.role.title} (${staff.branch})", fontSize = 12.sp) },
                                    onClick = {
                                        selectedStaff = staff
                                        selectedDepartment = staff.department
                                        selectedBranch = staff.branch
                                        staffDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Shift Period (Active vs Upcoming)
                item {
                    Text("Shift Timeline Category:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ShiftPeriod.values().forEach { period ->
                            FilterChip(
                                selected = selectedPeriod == period,
                                onClick = { selectedPeriod = period },
                                label = { Text(period.label, fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Blue800,
                                    selectedLabelColor = Color.White,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                )
                            )
                        }
                    }
                }

                // Branch selector
                item {
                    Text("Assigned Branch:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    ExposedDropdownMenuBox(
                        expanded = branchDropdownExpanded,
                        onExpandedChange = { branchDropdownExpanded = !branchDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedBranch,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = branchDropdownExpanded,
                            onDismissRequest = { branchDropdownExpanded = false }
                        ) {
                            JABIMA_BRANCHES.forEach { b ->
                                DropdownMenuItem(
                                    text = { Text(b, fontSize = 12.sp) },
                                    onClick = {
                                        selectedBranch = b
                                        branchDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Shift Type presets
                item {
                    Text("Shift Duty Type:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        presetShifts.forEach { opt ->
                            FilterChip(
                                selected = shiftType == opt,
                                onClick = { shiftType = opt },
                                label = { Text(opt, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Blue800,
                                    selectedLabelColor = Color.White,
                                    containerColor = Blue50,
                                    labelColor = Blue900
                                )
                            )
                        }
                    }
                }

                // Hearse Fleet selection
                item {
                    Text("Assigned Hearse / Vehicle (Optional):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    ExposedDropdownMenuBox(
                        expanded = hearseDropdownExpanded,
                        onExpandedChange = { hearseDropdownExpanded = !hearseDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = assignedHearse ?: "No Vehicle Assigned",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = hearseDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = hearseDropdownExpanded,
                            onDismissRequest = { hearseDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("None (Stationary Workshop / Office)", fontSize = 12.sp) },
                                onClick = {
                                    assignedHearse = null
                                    hearseDropdownExpanded = false
                                }
                            )
                            JABIMA_FLEET.forEach { v ->
                                DropdownMenuItem(
                                    text = { Text("Fleet $v (Hearse Cortege)", fontSize = 12.sp) },
                                    onClick = {
                                        assignedHearse = v
                                        hearseDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Destination / Route
                item {
                    OutlinedTextField(
                        value = destination,
                        onValueChange = { destination = it },
                        label = { Text("Route / Gravesite Destination", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Equipment
                item {
                    OutlinedTextField(
                        value = equipment,
                        onValueChange = { equipment = it },
                        label = { Text("Equipment (Lowering Gear, Church Trolley)", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Family & Case Ref
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = caseRef,
                            onValueChange = { caseRef = it },
                            label = { Text("Case Ref", fontSize = 10.sp) },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = familyName,
                            onValueChange = { familyName = it },
                            label = { Text("Family Name", fontSize = 10.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Notes
                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Protocol Notes & Instructions", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val staff = selectedStaff ?: allStaff.first()
                    val newShift = StaffShiftSchedule(
                        id = "SH-${UUID.randomUUID().toString().take(6).uppercase()}",
                        staffId = staff.id,
                        staffName = staff.fullName,
                        department = selectedDepartment,
                        assignedBranch = selectedBranch,
                        shiftType = shiftType,
                        dayOfWeek = "Wednesday",
                        dateFormatted = "23 Sep 2026",
                        availabilityStatus = when (selectedPeriod) {
                            ShiftPeriod.ACTIVE -> "On-Duty Active"
                            ShiftPeriod.UPCOMING -> "Scheduled Upcoming"
                            ShiftPeriod.PAST -> "Shift Completed"
                        },
                        hearseAssigned = assignedHearse,
                        notes = notes,
                        shiftPeriod = selectedPeriod,
                        startTime = startTime,
                        endTime = endTime,
                        equipmentAssigned = equipment,
                        caseReference = caseRef,
                        familyName = familyName,
                        destination = destination,
                        supervisorName = "Fredrick Hayoyo (CEO)",
                        hoursLogged = if (selectedPeriod == ShiftPeriod.PAST) 8.0 else 0.0,
                        checkInStatus = if (selectedPeriod == ShiftPeriod.ACTIVE) "On-Site Active" else "Confirmed"
                    )
                    onSave(newShift)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("btn_confirm_add_shift")
            ) {
                Text("Deploy to Roster")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Blue900)
            }
        },
        containerColor = PureWhite,
        shape = RoundedCornerShape(16.dp)
    )
}

// ==========================================
// 2. EDIT / REASSIGN SHIFT DIALOG
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditShiftDialog(
    shift: StaffShiftSchedule,
    onDismiss: () -> Unit,
    onSave: (StaffShiftSchedule) -> Unit
) {
    var shiftType by remember { mutableStateOf(shift.shiftType) }
    var assignedBranch by remember { mutableStateOf(shift.assignedBranch) }
    var availabilityStatus by remember { mutableStateOf(shift.availabilityStatus) }
    var destination by remember { mutableStateOf(shift.destination ?: "") }
    var notes by remember { mutableStateOf(shift.notes) }

    var branchDropdownExpanded by remember { mutableStateOf(false) }

    val statusOptions = listOf(
        "On-Duty Active",
        "In Cortege Transit",
        "On-Call Emergency",
        "Scheduled Upcoming",
        "Shift Completed"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = Blue800)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Reassign Shift for ${shift.staffName}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Blue900)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Department: ${shift.department.displayName}", fontSize = 11.sp, color = Blue700, fontWeight = FontWeight.SemiBold)

                // Branch Dropdown
                ExposedDropdownMenuBox(
                    expanded = branchDropdownExpanded,
                    onExpandedChange = { branchDropdownExpanded = !branchDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = assignedBranch,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Assigned Branch") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchDropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                    )
                    ExposedDropdownMenu(
                        expanded = branchDropdownExpanded,
                        onDismissRequest = { branchDropdownExpanded = false }
                    ) {
                        JABIMA_BRANCHES.forEach { b ->
                            DropdownMenuItem(
                                text = { Text(b) },
                                onClick = {
                                    assignedBranch = b
                                    branchDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Status chip selection
                Text("Availability Status:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(statusOptions) { st ->
                        FilterChip(
                            selected = availabilityStatus == st,
                            onClick = { availabilityStatus = st },
                            label = { Text(st, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = destination,
                    onValueChange = { destination = it },
                    label = { Text("Deployment Route / Destination") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Duty Notes / Assignment Instructions") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updatedPeriod = when (availabilityStatus) {
                        "Shift Completed" -> ShiftPeriod.PAST
                        "Scheduled Upcoming" -> ShiftPeriod.UPCOMING
                        else -> ShiftPeriod.ACTIVE
                    }
                    onSave(
                        shift.copy(
                            shiftType = shiftType,
                            assignedBranch = assignedBranch,
                            availabilityStatus = availabilityStatus,
                            shiftPeriod = updatedPeriod,
                            destination = destination.ifBlank { null },
                            notes = notes
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Blue900)
            }
        },
        containerColor = PureWhite,
        shape = RoundedCornerShape(16.dp)
    )
}

// ==========================================
// 3. STATUS UPDATE DIALOG
// ==========================================
@Composable
fun UpdateShiftStatusDialog(
    shift: StaffShiftSchedule,
    onDismiss: () -> Unit,
    onConfirmStatus: (String, ShiftPeriod) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = Blue800)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Update Shift Status", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Blue900)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Personnel: ${shift.staffName} (${shift.department.displayName})",
                    fontSize = 12.sp,
                    color = Blue950,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Choose live status transition for this shift:",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )

                // 1. On-Duty Active
                OutlinedButton(
                    onClick = { onConfirmStatus("On-Duty Active", ShiftPeriod.ACTIVE) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (shift.availabilityStatus == "On-Duty Active") Color(0xFFECFDF5) else PureWhite
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🟢 On-Duty Active (Base Station)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF047857))
                        Text("Active Now", fontSize = 10.sp, color = Color(0xFF059669))
                    }
                }

                // 2. In Cortege Transit
                OutlinedButton(
                    onClick = { onConfirmStatus("In Cortege Transit", ShiftPeriod.ACTIVE) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (shift.availabilityStatus == "In Cortege Transit") Color(0xFFEFF6FF) else PureWhite
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🚑 In Cortege Transit (On Road)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1D4ED8))
                        Text("En Route", fontSize = 10.sp, color = Color(0xFF2563EB))
                    }
                }

                // 3. 24/7 On-Call Emergency
                OutlinedButton(
                    onClick = { onConfirmStatus("On-Call Emergency", ShiftPeriod.ACTIVE) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚡ 24/7 On-Call Emergency", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                        Text("Standby", fontSize = 10.sp, color = Color(0xFFD97706))
                    }
                }

                // 4. Mark as Shift Completed
                Button(
                    onClick = { onConfirmStatus("Shift Completed", ShiftPeriod.PAST) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155), contentColor = Color.White),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("✓ Mark as Shift Completed (Move to Past)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Sign-Off", fontSize = 10.sp, color = Color(0xFFCBD5E1))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = Blue900)
            }
        },
        containerColor = PureWhite,
        shape = RoundedCornerShape(16.dp)
    )
}

// ==========================================
// 4. SHIFT DETAIL & PROTOCOL REPORT DIALOG
// ==========================================
@Composable
fun ShiftDetailReportDialog(
    shift: StaffShiftSchedule,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, tint = Blue800)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Operational Shift Record", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Blue900)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = Blue50,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Personnel: ${shift.staffName}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Blue950)
                        Text("Department: ${shift.department.displayName} (${shift.department.description})", fontSize = 10.sp, color = Blue700)
                        Text("Assigned Branch: ${shift.assignedBranch}", fontSize = 11.sp, color = Blue900)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Timeline Status:", fontSize = 10.sp, color = Color(0xFF64748B))
                        Text(shift.shiftPeriod.label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Availability:", fontSize = 10.sp, color = Color(0xFF64748B))
                        Text(shift.availabilityStatus, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    }
                }

                HorizontalDivider(color = Color(0xFFE2E8F0))

                Text("Operational Protocol Details:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                Text("• Shift Timing: ${shift.dayOfWeek}, ${shift.dateFormatted} (${shift.startTime} - ${shift.endTime})", fontSize = 11.sp, color = Color(0xFF334155))
                if (shift.hearseAssigned != null) {
                    Text("• Cortege Hearse: ${shift.hearseAssigned} (Inspected & Fuel Checked)", fontSize = 11.sp, color = Color(0xFF334155))
                }
                if (shift.destination != null) {
                    Text("• Route / Cemetery: ${shift.destination}", fontSize = 11.sp, color = Color(0xFF334155))
                }
                if (shift.equipmentAssigned != null) {
                    Text("• Equipment Assigned: ${shift.equipmentAssigned}", fontSize = 11.sp, color = Color(0xFF334155))
                }
                if (shift.caseReference != null) {
                    Text("• Funeral Case: ${shift.caseReference} (${shift.familyName ?: "Bereaved Family"})", fontSize = 11.sp, color = Color(0xFF334155))
                }

                HorizontalDivider(color = Color(0xFFE2E8F0))

                Text("Supervisor Verification & Sign-Off:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                Text("• Supervisor: ${shift.supervisorName}", fontSize = 11.sp, color = Color(0xFF334155))
                Text("• Attendance State: ${shift.checkInStatus}", fontSize = 11.sp, color = Color(0xFF334155))
                Text("• Hours Logged: ${shift.hoursLogged} hours", fontSize = 11.sp, color = Color(0xFF334155))
                if (shift.completionNotes != null) {
                    Text("• Debrief Notes: ${shift.completionNotes}", fontSize = 11.sp, color = Color(0xFF065F46), fontWeight = FontWeight.Medium)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Blue800, contentColor = Color.White),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Acknowledge")
            }
        },
        containerColor = PureWhite,
        shape = RoundedCornerShape(16.dp)
    )
}
