package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BranchStatusBoard
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.Blue100
import com.example.ui.theme.Blue200
import com.example.ui.theme.Blue50
import com.example.ui.theme.Blue700
import com.example.ui.theme.Blue800
import com.example.ui.theme.Blue900
import com.example.ui.theme.Blue950
import com.example.ui.theme.PureWhite

@Composable
fun BranchStatusBoardsScreen(
    viewModel: StaffPortalViewModel,
    modifier: Modifier = Modifier
) {
    val boards by viewModel.branchStatusBoards.collectAsState()
    var selectedBranch by remember { mutableStateOf<String?>(null) }

    val totalCases = boards.sumOf { it.activeCasesCount }
    val totalOccupied = boards.sumOf { it.coldRoomOccupancy }
    val totalCapacity = boards.sumOf { it.coldRoomCapacity }
    val totalOnDutyStaff = boards.sumOf { it.onDutyStaffCount }
    val totalCorteges = boards.sumOf { it.todayCortegeDepartures }

    val displayedBoards = if (selectedBranch == null) {
        boards
    } else {
        boards.filter { it.branchName == selectedBranch }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) {
        // TOP EXECUTIVE STATUS HEADER
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Blue900),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("branch_boards_header_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Business,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Branch Status & Operations Board",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                            Text(
                                text = "Real-time state across 8 funeral home branches",
                                color = Blue100,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // OVERALL KPI SUMMARY GRID
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricCard(
                            title = "Active Cases",
                            value = "$totalCases",
                            subtext = "Across 9 branches",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "Casket Stock",
                            value = "$totalCapacity units",
                            subtext = "Branch showrooms",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "Today Corteges",
                            value = "$totalCorteges",
                            subtext = "$totalOnDutyStaff staff on duty",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // BRANCH SELECTOR CHIPS
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Select Branch Board",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Blue900
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedBranch == null,
                            onClick = { selectedBranch = null },
                            label = { Text("All 8 Branches") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                    items(boards) { board ->
                        FilterChip(
                            selected = selectedBranch == board.branchName,
                            onClick = { selectedBranch = if (selectedBranch == board.branchName) null else board.branchName },
                            label = { Text(board.branchName) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Blue800,
                                selectedLabelColor = Color.White,
                                containerColor = Blue50,
                                labelColor = Blue900
                            )
                        )
                    }
                }
            }
        }

        // BRANCH CARDS
        items(displayedBoards, key = { it.branchName }) { board ->
            BranchBoardCard(board = board)
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtext: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White.copy(alpha = 0.12f),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(text = title, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Blue100)
            Text(text = subtext, fontSize = 8.sp, color = Color(0xFF93C5FD))
        }
    }
}

@Composable
private fun BranchBoardCard(board: BranchStatusBoard) {
    val occupancyRatio = if (board.coldRoomCapacity > 0) {
        board.coldRoomOccupancy.toFloat() / board.coldRoomCapacity.toFloat()
    } else 0f

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, Blue200),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("branch_card_${board.branchName.replace(" ", "_")}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Branch Name & Operational Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = null,
                        tint = Blue800,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = board.branchName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Blue950
                    )
                }

                Box(
                    modifier = Modifier
                        .background(Blue50, RoundedCornerShape(6.dp))
                        .border(1.dp, Blue700.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = board.operationalStatus,
                        color = Blue900,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Lead Supervisor: ${board.leadSupervisor}",
                fontSize = 11.sp,
                color = Blue700,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 4-COLUMN STAT TILES
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BranchStatTile(
                    label = "Active Cases",
                    value = "${board.activeCasesCount}",
                    icon = Icons.Default.Business,
                    modifier = Modifier.weight(1f)
                )
                BranchStatTile(
                    label = "Duty Staff",
                    value = "${board.onDutyStaffCount}",
                    icon = Icons.Default.Groups,
                    modifier = Modifier.weight(1f)
                )
                BranchStatTile(
                    label = "Departures",
                    value = "${board.todayCortegeDepartures}",
                    icon = Icons.Default.DirectionsCar,
                    modifier = Modifier.weight(1f)
                )
                BranchStatTile(
                    label = "Stock Req",
                    value = "${board.pendingStockRequests}",
                    icon = Icons.Default.Inventory,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // COLD ROOM STORAGE METER
            Surface(
                color = Blue50,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Blue100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Inventory, contentDescription = null, tint = Blue800, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Showroom Casket Allocation & Capacity",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Blue900
                            )
                        }
                        Text(
                            text = "${board.coldRoomOccupancy} / ${board.coldRoomCapacity} Showroom Units (${(occupancyRatio * 100).toInt()}%)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Blue900
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { occupancyRatio.coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (occupancyRatio > 0.85f) Color(0xFF1D4ED8) else Blue800,
                        trackColor = Blue200
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // FLEET DEPLOYMENT ROW
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Stationed Hearses:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Blue800)
                    if (board.hearseFleetStationed.isEmpty()) {
                        Text("None on standby", fontSize = 11.sp, color = Color(0xFF64748B))
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            board.hearseFleetStationed.forEach { plate ->
                                Box(
                                    modifier = Modifier
                                        .background(Blue800, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(plate, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("In Transit To/From:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Blue800)
                    if (board.hearseFleetInTransit.isEmpty()) {
                        Text("No movement", fontSize = 11.sp, color = Color(0xFF64748B))
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            board.hearseFleetInTransit.forEach { plate ->
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFDBEAFE), RoundedCornerShape(4.dp))
                                        .border(1.dp, Blue700, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(plate, color = Blue900, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // ACTIVE ADVISORIES & BULLETINS
            if (board.activeAdvisories.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFEFF6FF), RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFF93C5FD), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Campaign, contentDescription = null, tint = Blue800, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Branch Bulletin & Operational Advisories", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue900)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    board.activeAdvisories.forEach { advisory ->
                        Text(
                            text = "• $advisory",
                            fontSize = 10.sp,
                            color = Blue950,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            // CONTACT PHONE FOOTER
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Phone, contentDescription = null, tint = Blue800, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Emergency Duty Line: ${board.contactPhone}", fontSize = 11.sp, color = Blue900, fontWeight = FontWeight.SemiBold)
                }

                Box(
                    modifier = Modifier
                        .background(Blue50, RoundedCornerShape(4.dp))
                        .border(1.dp, Blue200, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text("Verified Active", fontSize = 9.sp, color = Blue800, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun BranchStatTile(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Blue50,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, Blue100),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = Blue800, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Blue950)
            Text(text = label, fontSize = 8.sp, color = Blue700, fontWeight = FontWeight.SemiBold)
        }
    }
}
