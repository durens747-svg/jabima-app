package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BANK_ACCOUNT_NAME
import com.example.model.BANK_ACCOUNT_NUMBER
import com.example.model.BANK_NAME
import com.example.model.BANK_SWIFT_CODE
import com.example.model.MPESA_PAYBILL_NUMBER
import com.example.model.MPESA_STK_NUMBER
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import java.util.Locale

@Composable
fun AccountsFinanceTab(
    viewModel: StaffPortalViewModel
) {
    val customerOrders by viewModel.customerOrders.collectAsState()
    val vendorTransactions by viewModel.vendorTransactions.collectAsState()

    val totalCasketRevenueKes = customerOrders.sumOf { it.totalAmountKes }
    val totalVendorExpensesKes = vendorTransactions.filter { it.transactionType == com.example.model.VendorTransactionType.PAYMENT_SUBMITTED }.sumOf { it.amount }
    val netCashFlowKes = totalCasketRevenueKes - totalVendorExpensesKes

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp)
            .testTag("accounts_finance_tab"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Accounts & Finance Management",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = ObsidianBlack
                )
                Text(
                    text = "Consolidated financial ledgers, revenue flows, statutory compliance & cash analysis",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }
        }

        // METRIC CARDS
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Revenue
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Total Revenue", fontSize = 10.sp, color = Color(0xFF64748B))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "KES ${String.format(Locale.getDefault(), "%,.0f", totalCasketRevenueKes)}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = ObsidianBlack
                        )
                    }
                }

                // Expenses
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Vendor Outflows", fontSize = 10.sp, color = Color(0xFF64748B))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "KES ${String.format(Locale.getDefault(), "%,.0f", totalVendorExpensesKes)}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )
                    }
                }

                // Net Cash Flow
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = RoyalCobaltIce),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF93C5FD)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Net Position", fontSize = 10.sp, color = RoyalCobaltBlue)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "KES ${String.format(Locale.getDefault(), "%,.0f", netCashFlowKes)}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = RoyalCobaltBlue
                        )
                    }
                }
            }
        }

        // BANK & MPESA SETTLEMENT ACCOUNT DETAILS
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianBlack),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "OFFICIAL TREASURY SETTLEMENT CHANNELS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF94A3B8)
                        )
                        Surface(
                            color = Color(0xFF1E293B),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Standard Chartered & Safaricom",
                                fontSize = 9.sp,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Safaricom M-PESA Paybill", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            Text("Paybill #: $MPESA_PAYBILL_NUMBER", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PureWhite)
                            Text("STK Verification: $MPESA_STK_NUMBER", fontSize = 10.sp, color = Color(0xFF34D399))
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("$BANK_NAME", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            Text("Acc #: $BANK_ACCOUNT_NUMBER", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PureWhite)
                            Text("Swift: $BANK_SWIFT_CODE", fontSize = 10.sp, color = Color(0xFF60A5FA))
                        }
                    }
                }
            }
        }

        // RECENT TRANSACTION LEDGER
        item {
            Text(
                text = "Recent Departmental Transactions",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = ObsidianBlack
            )
        }

        items(customerOrders.take(5)) { order ->
            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Order: ${order.orderId}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ObsidianBlack)
                        Text(text = "Client: ${order.clientName} • ${order.branch}", fontSize = 11.sp, color = Color(0xFF64748B))
                        Text(text = "Channel: ${order.paymentMethod} (Ref: ${order.referenceCode})", fontSize = 10.sp, color = EmeraldSuccess)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "+ KES ${String.format(Locale.getDefault(), "%,.0f", order.totalAmountKes)}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess
                        )
                        Text(
                            text = "5% Comm: KES ${String.format(Locale.getDefault(), "%,.0f", order.commissionEarnedKes)}",
                            fontSize = 10.sp,
                            color = RoyalCobaltBlue,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
