package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Department
import com.example.model.StaffAccount
import com.example.model.StaffDailyReport
import com.example.ui.StaffPortalViewModel
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenLight
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DailyReportScreen(
    viewModel: StaffPortalViewModel
) {
    val dailyReports by viewModel.dailyReports.collectAsState()
    val allAccounts by viewModel.allAccounts.collectAsState()
    val currentAccount by viewModel.currentAccount.collectAsState()

    var showSubmitReportDialog by remember { mutableStateOf(false) }

    // Summary calculations requested by user:
    // "summary of reports submitted by staff, Total Tasks done, and Staff who haven’t submitted reports"
    val submittedStaffIds = remember(dailyReports) { dailyReports.map { it.staffId }.toSet() }
    val unsubmittedStaff = remember(allAccounts, submittedStaffIds) {
        allAccounts.filter { !submittedStaffIds.contains(it.id) }
    }
    val totalTasksDone = remember(dailyReports) { dailyReports.sumOf { it.tasksDoneCount } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureWhite)
            .padding(16.dp)
            .testTag("daily_report_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ==========================================
        // 1. HERO SUMMARY CARD (REPORTS SUBMITTED, TASKS DONE, UNREPORTED)
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, StrokeRed.copy(alpha = 0.55f)),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("daily_report_hero_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenLight)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EventNote,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "DAILY REPORTING DASHBOARD",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.5.sp
                                    )
                                    Text(
                                        text = "End-of-day duty verification & task accountability",
                                        color = Color(0xFF93C5FD),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Button(
                                onClick = { showSubmitReportDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_submit_my_daily_report")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Submit Log", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // 3 Key Metrics requested by prompt:
                        // "summary of reports submitted by staff, Total Tasks done, and Staff who haven’t submitted reports"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            DailyMetricBadge(
                                title = "Reports Submitted",
                                value = "${dailyReports.size} / ${allAccounts.size}",
                                subtitle = "Staff on duty today",
                                color = EmeraldLight,
                                modifier = Modifier.weight(1f)
                            )
                            DailyMetricBadge(
                                title = "Total Tasks Done",
                                value = "$totalTasksDone Tasks",
                                subtitle = "Completed operations",
                                color = Color(0xFF60A5FA),
                                modifier = Modifier.weight(1f)
                            )
                            DailyMetricBadge(
                                title = "Pending Reports",
                                value = "${unsubmittedStaff.size} Staff",
                                subtitle = "Not yet submitted",
                                color = Color(0xFFFCA5A5),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // 2. STAFF WHO HAVEN'T SUBMITTED REPORTS SECTION
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("unsubmitted_staff_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PendingActions, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Staff Who Haven't Submitted Reports (${unsubmittedStaff.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Navy900
                            )
                        }

                        Button(
                            onClick = {
                                unsubmittedStaff.forEach { staff ->
                                    viewModel.sendNudgeReminderToStaff(staff)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("btn_nudge_all_unsubmitted")
                        ) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Nudge All via SMS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (unsubmittedStaff.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = EmeraldLight,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("100% compliance! All duty staff have submitted their daily reports.", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = EmeraldSuccess)
                            }
                        }
                    } else {
                        unsubmittedStaff.forEach { staff ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFFEF2F2),
                                border = BorderStroke(1.dp, Color(0xFFFEE2E2)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(Color(staff.avatarColor)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = staff.fullName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(staff.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                                            Text("${staff.role.title} • ${staff.branch}", fontSize = 10.sp, color = TextSecondary)
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.sendNudgeReminderToStaff(staff) },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(30.dp).testTag("nudge_staff_${staff.id}")
                                    ) {
                                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Send SMS Nudge", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 3. SUBMITTED DAILY REPORTS LOG
        // ==========================================
        item {
            Text(
                text = "Submitted Reports Summary (${dailyReports.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Navy900
            )
        }

        items(dailyReports) { report ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("report_card_${report.id}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(report.staffName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Navy900)
                                Text("${report.role.title} • ${report.branch}", fontSize = 11.sp, color = TextSecondary)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = EmeraldLight
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(report.submissionTime, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Tasks Completed Today (${report.tasksDoneCount}):", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Navy900)
                    Spacer(modifier = Modifier.height(4.dp))
                    report.tasksSummary.forEach { task ->
                        Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                            Text("• ", fontSize = 12.sp, color = RoyalCobaltBlue, fontWeight = FontWeight.Bold)
                            Text(task, fontSize = 11.sp, color = Navy900, lineHeight = 15.sp)
                        }
                    }

                    if (report.materialsUsedSummary.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Materials / Fuel / Gear Used: ${report.materialsUsedSummary}", fontSize = 11.sp, color = TextSecondary)
                    }

                    if (report.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Staff Notes: ${report.notes}", fontSize = 11.sp, color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Logged: ${report.hoursLogged} Hours", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                        Text("Status: Verified & Synced with HR", fontSize = 10.sp, color = TextSecondary)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // ==========================================
    // DIALOG: SUBMIT TODAY'S DAILY REPORT
    // ==========================================
    if (showSubmitReportDialog) {
        val user = currentAccount ?: allAccounts.first()
        var task1 by remember { mutableStateOf("") }
        var task2 by remember { mutableStateOf("") }
        var task3 by remember { mutableStateOf("") }
        var materialsUsed by remember { mutableStateOf("") }
        var reportNotes by remember { mutableStateOf("") }
        var hoursStr by remember { mutableStateOf("8.0") }

        AlertDialog(
            onDismissRequest = { showSubmitReportDialog = false },
            title = {
                Text("Submit Daily Activity Report", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Reporting Staff: ${user.fullName} (${user.role.title} • ${user.branch})", fontSize = 12.sp, color = TextSecondary)

                    OutlinedTextField(
                        value = task1,
                        onValueChange = { task1 = it },
                        label = { Text("Task 1 Completed (Required)") },
                        placeholder = { Text("e.g. Assembled Executive casket frame") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = task2,
                        onValueChange = { task2 = it },
                        label = { Text("Task 2 Completed") },
                        placeholder = { Text("e.g. Quilted ivory satin lining") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = task3,
                        onValueChange = { task3 = it },
                        label = { Text("Task 3 Completed") },
                        placeholder = { Text("e.g. Pre-trip hearse inspection & wash") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = materialsUsed,
                        onValueChange = { materialsUsed = it },
                        label = { Text("Materials / Fuel / Spares Used") },
                        placeholder = { Text("e.g. 2 Rolls Satin, 40L Diesel Shell Siaya") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = hoursStr,
                            onValueChange = { hoursStr = it },
                            label = { Text("Hours Logged") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = reportNotes,
                            onValueChange = { reportNotes = it },
                            label = { Text("General Notes") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val tasks = listOfNotNull(
                            task1.ifBlank { null },
                            task2.ifBlank { null },
                            task3.ifBlank { null }
                        ).ifEmpty { listOf("Completed scheduled daily roster assignment") }

                        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
                        val timeNow = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + " EAT"

                        val report = StaffDailyReport(
                            id = "REP-" + (1000..9999).random(),
                            staffId = user.id,
                            staffName = user.fullName,
                            role = user.role,
                            department = user.department,
                            branch = user.branch,
                            date = today,
                            submissionTime = timeNow,
                            tasksDoneCount = tasks.size,
                            tasksSummary = tasks,
                            materialsUsedSummary = materialsUsed,
                            hoursLogged = hoursStr.toDoubleOrNull() ?: 8.0,
                            notes = reportNotes,
                            isSubmitted = true
                        )
                        viewModel.submitDailyReport(report)
                        showSubmitReportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Text("Submit Report")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSubmitReportDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun DailyMetricBadge(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White.copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 10.sp, color = color, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 9.sp, color = Color.White.copy(alpha = 0.7f))
        }
    }
}
