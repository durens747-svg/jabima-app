package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ProductionQuantityLimits
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.InventoryHealthStatus
import com.example.domain.OperationsAnalyticsEngine
import com.example.model.InventoryMaterialItem
import com.example.model.JABIMA_BRANCHES
import com.example.model.JABIMA_CASKET_TYPES
import com.example.model.MaterialCategory
import com.example.model.ProductItem
import com.example.model.StaffRole
import com.example.ui.StaffPortalViewModel
import com.example.ui.components.QrCodeBadge
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.Navy900
import com.example.ui.theme.RoyalCobaltBlue
import com.example.ui.theme.RoyalCobaltIce
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class InventoryTab(val title: String) {
    STOCK_TRACKER("Stock Tracker"),
    OVERVIEW("Overview"),
    PRODUCTS("Products"),
    RAW_MATERIALS("Raw Materials & Store"),
    UPGRADE_DOWNGRADE("Upgrade / Downgrade"),
    MATERIAL_CATEGORIES("Materials Categories")
}

private data class UpgradeDowngradeTarget(
    val storeCategory: String,
    val itemId: String,
    val itemName: String,
    val initialIsUpgrade: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryManagementScreen(
    viewModel: StaffPortalViewModel
) {
    val currentAccount by viewModel.currentAccount.collectAsState()
    val adminImpersonator by viewModel.adminImpersonator.collectAsState()

    val materialCategories by viewModel.materialCategories.collectAsState()
    val materials by viewModel.inventoryMaterials.collectAsState()
    val products by viewModel.inventoryProducts.collectAsState()
    val caskets by viewModel.caskets.collectAsState()
    val casketStockByBranch by viewModel.casketStockByBranch.collectAsState()
    val uploadedStock by viewModel.uploadedStockItems.collectAsState()
    val workshopItems by viewModel.workshopItems.collectAsState()
    val upgradeDowngradeLogs by viewModel.upgradeDowngradeLogs.collectAsState()
    val stockMovements by viewModel.stockMovements.collectAsState()

    val isUserAdminOrCeo = currentAccount?.role == StaffRole.MANAGING_DIRECTOR_CEO ||
        currentAccount?.role == StaffRole.OPERATIONS_ADMIN ||
        currentAccount?.role == StaffRole.INVENTORY_MANAGER ||
        adminImpersonator != null

    var selectedTab by remember { mutableStateOf(InventoryTab.STOCK_TRACKER) }
    var qrPreviewTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var selectedUpgradeCategory by remember { mutableStateOf("Raw Material") }
    var trackerBranchFilter by remember { mutableStateOf("All Branches") }
    var trackerHealthFilter by remember { mutableStateOf(InventoryHealthStatus.ALL) }
    var trackerSearchQuery by remember { mutableStateOf("") }

    // Dialog states
    var showAddProductDialog by remember { mutableStateOf(false) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var categoryToEdit by remember { mutableStateOf<MaterialCategory?>(null) }
    var showPurchaseMaterialDialog by remember { mutableStateOf(false) }
    var materialToIssueWorkshop by remember { mutableStateOf<InventoryMaterialItem?>(null) }
    var upgradeDowngradeTarget by remember { mutableStateOf<UpgradeDowngradeTarget?>(null) }

    val activeWorkshopJobs = remember(workshopItems) { workshopItems.filter { !it.isCompleted } }
    val trackerSummary = remember(
        materials,
        products,
        casketStockByBranch,
        trackerBranchFilter,
        trackerHealthFilter,
        trackerSearchQuery
    ) {
        OperationsAnalyticsEngine.buildInventoryTrackerSummary(
            materials = materials,
            products = products,
            casketStockByBranch = casketStockByBranch,
            branchFilter = trackerBranchFilter,
            healthFilter = trackerHealthFilter,
            searchQuery = trackerSearchQuery
        )
    }

    // Computations for Overview tab
    val totalMaterialsValue = remember(materials) { materials.sumOf { it.totalValueKes } + 1845000.0 }
    val totalMaterialTypes = remember(materials) { materials.size + 24 }
    val totalFinishedProducts = remember(products) { products.sumOf { it.stockCount } + 88 }
    val lowStockItems = remember(materials) { materials.filter { it.isLowStock } }
    val outOfStockItems = remember(materials) { materials.filter { it.isOutOfStock } }
    val pendingProductRequests = remember(stockMovements) { stockMovements.filter { it.status.name.contains("PENDING") } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .testTag("inventory_management_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ==========================================
        // HEADER & HORIZONTAL TABS
        // ==========================================
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, BorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(RoyalCobaltIce),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Inventory, contentDescription = "Inventory", tint = RoyalCobaltBlue)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Inventory & Store Pipeline",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Purchase Materials -> Workshop -> Store -> Sales",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isUserAdminOrCeo) EmeraldLight else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (isUserAdminOrCeo) EmeraldSuccess.copy(alpha = 0.5f) else Color(0xFFCBD5E1))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isUserAdminOrCeo) Icons.Default.Security else Icons.Default.Info,
                                    contentDescription = null,
                                    tint = if (isUserAdminOrCeo) EmeraldSuccess else TextSecondary,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isUserAdminOrCeo) "Admin Access" else "Officer View",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUserAdminOrCeo) EmeraldSuccess else Navy900
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    ScrollableTabRow(
                        selectedTabIndex = selectedTab.ordinal,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        edgePadding = 4.dp,
                        indicator = { tabPositions ->
                            if (selectedTab.ordinal < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                                    color = RoyalCobaltBlue,
                                    height = 3.dp
                                )
                            }
                        },
                        modifier = Modifier.clip(RoundedCornerShape(10.dp))
                    ) {
                        InventoryTab.values().forEach { tab ->
                            Tab(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                text = {
                                    Text(
                                        text = tab.title,
                                        fontSize = 12.sp,
                                        fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium,
                                        color = if (selectedTab == tab) RoyalCobaltBlue else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.testTag("inventory_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // TAB 0: STOCK TRACKER TAB
        // ==========================================
        if (selectedTab == InventoryTab.STOCK_TRACKER) {
            inventoryTrackerItems(
                summary = trackerSummary,
                selectedBranch = trackerBranchFilter,
                selectedHealth = trackerHealthFilter,
                searchQuery = trackerSearchQuery,
                hasActiveWorkshopJobs = activeWorkshopJobs.isNotEmpty(),
                onBranchChange = { trackerBranchFilter = it },
                onHealthChange = { trackerHealthFilter = it },
                onSearchChange = { trackerSearchQuery = it },
                onAdjustQuantity = { item, delta -> viewModel.adjustInventoryMaterialQuantity(item.id, delta) },
                onIssueToWorkshop = { item -> materialToIssueWorkshop = item },
                onOpenPurchaseDialog = { showPurchaseMaterialDialog = true }
            )
        }

        // ==========================================
        // TAB 1: OVERVIEW TAB
        // ==========================================
        if (selectedTab == InventoryTab.OVERVIEW) {
            item {
                Text(
                    text = "Inventory Overview & Valuations",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        InventoryStatCard(
                            title = "Total Materials Value",
                            value = "KES ${String.format("%,.0f", totalMaterialsValue)}",
                            sub = "Raw timber, linings & hardware",
                            color = RoyalCobaltBlue,
                            bgColor = RoyalCobaltIce,
                            modifier = Modifier.weight(1f)
                        )
                        InventoryStatCard(
                            title = "Material Types",
                            value = "$totalMaterialTypes Types",
                            sub = "Active inventory SKUs",
                            color = Color(0xFF0D9488),
                            bgColor = Color(0xFFCCFBF1),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        InventoryStatCard(
                            title = "Finished Products",
                            value = "$totalFinishedProducts Caskets",
                            sub = "Ready across 8 branches",
                            color = EmeraldSuccess,
                            bgColor = EmeraldLight,
                            modifier = Modifier.weight(1f)
                        )
                        InventoryStatCard(
                            title = "Upgrade / Downgrades",
                            value = "${upgradeDowngradeLogs.size} Logs",
                            sub = "Store cost adjustments",
                            color = Color(0xFF7C3AED),
                            bgColor = Color(0xFFEDE9FE),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        InventoryStatCard(
                            title = "Low Stock Items",
                            value = "${lowStockItems.size} Warning",
                            sub = "Under reorder threshold",
                            color = AmberWarning,
                            bgColor = AmberLight,
                            modifier = Modifier.weight(1f)
                        )
                        InventoryStatCard(
                            title = "Pending Requests",
                            value = "${pendingProductRequests.size} Pending",
                            sub = "${outOfStockItems.size} out of stock",
                            color = com.example.ui.theme.StrokeRed,
                            bgColor = com.example.ui.theme.StrokeRedLight,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Low Stock Warnings & Reorder Alerts", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                            }
                            TextButton(onClick = { showPurchaseMaterialDialog = true }) {
                                Text("Restock Raw Material", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        lowStockItems.forEach { item ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFFFFBEB),
                                border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(item.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Navy900)
                                        Text("${item.categoryName} • ${item.branchWarehouse}", fontSize = 10.sp, color = TextSecondary)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("${item.quantity} ${item.unit} left", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = AmberWarning)
                                        Text("Min: ${item.minThreshold}", fontSize = 10.sp, color = TextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (outOfStockItems.isNotEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ProductionQuantityLimits, contentDescription = null, tint = com.example.ui.theme.StrokeRed, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Out of Stock (Zero Units)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                }
                                Text("${outOfStockItems.size} items", fontSize = 11.sp, color = com.example.ui.theme.StrokeRed, fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            outOfStockItems.forEach { item ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = com.example.ui.theme.StrokeRedLight,
                                    border = BorderStroke(1.dp, com.example.ui.theme.StrokeRedBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(item.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = com.example.ui.theme.StrokeRedDark)
                                            Text("${item.categoryName} • Immediate PO Required", fontSize = 10.sp, color = TextSecondary)
                                        }
                                        Surface(
                                            color = com.example.ui.theme.StrokeRed,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text("OUT OF STOCK", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // TAB 2: PRODUCTS TAB (FINISHED STORE)
        // ==========================================
        if (selectedTab == InventoryTab.PRODUCTS) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Finished Store Products (${products.size})",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Workshop completions, caskets & accessories ready for sale",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (isUserAdminOrCeo) {
                        Button(
                            onClick = { showAddProductDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_add_product")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Product", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            items(products, key = { it.id }) { prod ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth().testTag("product_card_${prod.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(RoyalCobaltIce),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Inventory2, contentDescription = null, tint = RoyalCobaltBlue, modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(prod.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("${prod.category} • ${prod.branchWarehouse}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = EmeraldLight
                            ) {
                                Text(
                                    text = "${prod.stockCount} in stock",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Cost Price", fontSize = 10.sp, color = TextSecondary)
                                Text("KES ${String.format("%,.0f", prod.costPriceKes)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Column {
                                Text("Selling Price", fontSize = 10.sp, color = TextSecondary)
                                Text("KES ${String.format("%,.0f", prod.sellingPriceKes)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = RoyalCobaltBlue)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Source", fontSize = 10.sp, color = TextSecondary)
                                Text(prod.addedBy, fontSize = 10.sp, color = TextSecondary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    upgradeDowngradeTarget = UpgradeDowngradeTarget(
                                        storeCategory = "Finished Product",
                                        itemId = prod.id,
                                        itemName = prod.name,
                                        initialIsUpgrade = true
                                    )
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp),
                                modifier = Modifier.weight(1.3f).height(36.dp).testTag("btn_upgrade_downgrade_product_${prod.id}")
                            ) {
                                Icon(Icons.Default.SwapVert, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("Upgrade / Downgrade", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }

                            OutlinedButton(
                                onClick = { qrPreviewTarget = "JFD-PRD-${prod.id}" to prod.name },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp),
                                modifier = Modifier.weight(0.7f).height(36.dp).testTag("btn_qr_tag_${prod.id}")
                            ) {
                                Icon(Icons.Default.QrCode2, contentDescription = "View Casket QR Tag", modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("QR Tag", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // TAB 3: RAW MATERIALS & SEAMLESS WORKSHOP ISSUE
        // ==========================================
        if (selectedTab == InventoryTab.RAW_MATERIALS) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Raw Materials & Store Intake (${materials.size})",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Purchase materials & issue directly to Live Workshop jobs",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { showPurchaseMaterialDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_purchase_raw_material")
                    ) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Purchase Material", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }

            items(materials, key = { it.id }) { mat ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        1.dp,
                        if (mat.isOutOfStock) com.example.ui.theme.StrokeRed else if (mat.isLowStock) AmberWarning else BorderLight
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("raw_material_card_${mat.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(mat.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                Text("${mat.categoryName} • ${mat.branchWarehouse}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${mat.quantity} ${mat.unit}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = if (mat.isOutOfStock) com.example.ui.theme.StrokeRed else if (mat.isLowStock) AmberWarning else EmeraldSuccess
                                )
                                Text(
                                    text = "@ KES ${String.format("%,.0f", mat.unitCostKes)} / ${mat.unit}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                enabled = mat.quantity > 0 && activeWorkshopJobs.isNotEmpty(),
                                onClick = { materialToIssueWorkshop = mat },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f).height(36.dp).testTag("btn_issue_workshop_${mat.id}")
                            ) {
                                Icon(Icons.Default.Handyman, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Issue to Workshop", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }

                            OutlinedButton(
                                onClick = {
                                    upgradeDowngradeTarget = UpgradeDowngradeTarget(
                                        storeCategory = "Raw Material",
                                        itemId = mat.id,
                                        itemName = mat.name,
                                        initialIsUpgrade = true
                                    )
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f).height(36.dp).testTag("btn_upgrade_downgrade_mat_${mat.id}")
                            ) {
                                Icon(Icons.Default.SwapVert, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Upgrade / Downgrade", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // TAB 4: COST OF UPGRADE / DOWNGRADE FOR ALL STORE ITEMS
        // ==========================================
        if (selectedTab == InventoryTab.UPGRADE_DOWNGRADE) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Store Item Upgrade / Downgrade Cost Control",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Apply upgrade enhancements (+) or downgrade adjustments (-) across all store items",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Raw Material", "Finished Product", "Uploaded Stock", "Casket Catalog").forEach { cat ->
                                val isSel = selectedUpgradeCategory == cat
                                FilterChip(
                                    selected = isSel,
                                    onClick = { selectedUpgradeCategory = cat },
                                    label = { Text(cat, fontSize = 11.sp, maxLines = 1, softWrap = false) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = RoyalCobaltBlue,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.testTag("upgrade_cat_${cat.lowercase().replace(" ", "_")}")
                                )
                            }
                        }
                    }
                }
            }

            val normalizedItems: List<Triple<String, String, String>> = when (selectedUpgradeCategory) {
                "Raw Material" -> materials.map { Triple(it.id, it.name, "${it.quantity} ${it.unit} • Cost: KES ${String.format("%,.0f", it.unitCostKes)}") }
                "Finished Product" -> products.map { Triple(it.id, it.name, "${it.stockCount} pcs • Selling: KES ${String.format("%,.0f", it.sellingPriceKes)}") }
                "Uploaded Stock" -> uploadedStock.map { Triple(it.id, it.name, "${it.quantity} units • Selling: KES ${String.format("%,.0f", it.sellingPriceKes)}") }
                else -> caskets.map { Triple(it.id, it.name, "${it.stockCount} pcs • Price: KES ${String.format("%,.0f", it.priceKes)}") }
            }

            if (normalizedItems.isEmpty()) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No store items currently listed in $selectedUpgradeCategory.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(normalizedItems, key = { "${selectedUpgradeCategory}_${it.first}" }) { (itemId, itemName, subtitle) ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(itemName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text("$selectedUpgradeCategory • $subtitle", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        upgradeDowngradeTarget = UpgradeDowngradeTarget(selectedUpgradeCategory, itemId, itemName, true)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f).height(34.dp).testTag("btn_upgrade_${itemId}"),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Upgrade (+)", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }

                                OutlinedButton(
                                    onClick = {
                                        upgradeDowngradeTarget = UpgradeDowngradeTarget(selectedUpgradeCategory, itemId, itemName, false)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f).height(34.dp).testTag("btn_downgrade_${itemId}"),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Downgrade (-)", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                }
                            }
                        }
                    }
                }
            }

            if (upgradeDowngradeLogs.isNotEmpty()) {
                item {
                    Text(
                        text = "Upgrade / Downgrade Cost Ledger (${upgradeDowngradeLogs.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                items(upgradeDowngradeLogs, key = { it.id }) { rec ->
                    val isUp = rec.actionType == "UPGRADE"
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${rec.actionType}: ${rec.itemName}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                Text("${rec.storeCategory} • Qty: ${rec.quantity} • ${rec.reason}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("By ${rec.processedBy} • ${rec.date}", fontSize = 9.sp, color = TextSecondary)
                            }
                            Text(
                                text = "${if (isUp) "+" else "-"}KES ${String.format("%,.0f", rec.totalCostDeltaKes)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp,
                                color = if (isUp) EmeraldSuccess else AmberWarning
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // TAB 5: MATERIALS CATEGORIES TAB
        // ==========================================
        if (selectedTab == InventoryTab.MATERIAL_CATEGORIES) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Materials Categories (${materialCategories.size})",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Viewable by Inventory Officer • Adding & Editing by Admin & CEO",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (isUserAdminOrCeo) {
                        Button(
                            onClick = { showAddCategoryDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_add_material_category")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Category", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Editing: Admin/CEO", fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            items(materialCategories, key = { it.id }) { category ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.fillMaxWidth().testTag("category_card_${category.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFEF3C7)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Category, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(category.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                    Text("Unit: ${category.unitOfMeasure} • Threshold: ${category.lowStockThreshold}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            if (isUserAdminOrCeo) {
                                IconButton(
                                    onClick = { categoryToEdit = category },
                                    modifier = Modifier.size(32.dp).testTag("edit_category_${category.id}")
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit Category", tint = RoyalCobaltBlue, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(category.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${category.itemCount} Material Items", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            Text("Total Valuation: KES ${String.format("%,.0f", category.totalValuationKes)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // ==========================================
    // DIALOG: PURCHASE RAW MATERIAL INTO STORE
    // ==========================================
    if (showPurchaseMaterialDialog) {
        var selectedExisting by remember { mutableStateOf<InventoryMaterialItem?>(null) }
        var matName by remember { mutableStateOf("") }
        var selectedCat by remember { mutableStateOf(materialCategories.firstOrNull()) }
        var qtyStr by remember { mutableStateOf("20") }
        var unitStr by remember { mutableStateOf(selectedCat?.unitOfMeasure ?: "Units") }
        var unitCostStr by remember { mutableStateOf("1800") }
        var thresholdStr by remember { mutableStateOf("10") }
        var selectedBranch by remember { mutableStateOf(JABIMA_BRANCHES.first()) }
        var existingExpanded by remember { mutableStateOf(false) }
        var catExpanded by remember { mutableStateOf(false) }
        var branchExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showPurchaseMaterialDialog = false },
            title = {
                Text("Purchase Raw Material -> Store", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExposedDropdownMenuBox(
                        expanded = existingExpanded,
                        onExpandedChange = { existingExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedExisting?.name ?: "Create / Purchase New Material",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Restock Existing or New") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = existingExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = existingExpanded,
                            onDismissRequest = { existingExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("+ New Material SKU") },
                                onClick = {
                                    selectedExisting = null
                                    matName = ""
                                    existingExpanded = false
                                }
                            )
                            materials.forEach { mat ->
                                DropdownMenuItem(
                                    text = { Text("${mat.name} (Stock: ${mat.quantity} ${mat.unit})") },
                                    onClick = {
                                        selectedExisting = mat
                                        matName = mat.name
                                        unitStr = mat.unit
                                        unitCostStr = mat.unitCostKes.toInt().toString()
                                        thresholdStr = mat.minThreshold.toString()
                                        selectedBranch = mat.branchWarehouse
                                        selectedCat = materialCategories.firstOrNull { it.id == mat.categoryId } ?: selectedCat
                                        existingExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = matName,
                        onValueChange = { matName = it },
                        label = { Text("Material Name *") },
                        placeholder = { Text("e.g. Seasoned Cypress Planks") },
                        modifier = Modifier.fillMaxWidth().testTag("input_purchase_material_name")
                    )

                    ExposedDropdownMenuBox(
                        expanded = catExpanded,
                        onExpandedChange = { catExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedCat?.name ?: "Timber & Wood",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Material Category") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = catExpanded,
                            onDismissRequest = { catExpanded = false }
                        ) {
                            materialCategories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.name) },
                                    onClick = {
                                        selectedCat = cat
                                        unitStr = cat.unitOfMeasure
                                        catExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = qtyStr,
                            onValueChange = { qtyStr = it },
                            label = { Text("Quantity") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = unitStr,
                            onValueChange = { unitStr = it },
                            label = { Text("Unit") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = unitCostStr,
                            onValueChange = { unitCostStr = it },
                            label = { Text("Unit Cost (KES)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = thresholdStr,
                            onValueChange = { thresholdStr = it },
                            label = { Text("Min Alert") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    ExposedDropdownMenuBox(
                        expanded = branchExpanded,
                        onExpandedChange = { branchExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedBranch,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Destination Warehouse") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = branchExpanded,
                            onDismissRequest = { branchExpanded = false }
                        ) {
                            JABIMA_BRANCHES.forEach { br ->
                                DropdownMenuItem(
                                    text = { Text(br) },
                                    onClick = {
                                        selectedBranch = br
                                        branchExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.purchaseRawMaterial(
                            materialId = selectedExisting?.id,
                            name = matName.trim().ifBlank { selectedExisting?.name ?: "Purchased Raw Material" },
                            categoryId = selectedCat?.id ?: "CAT-01",
                            quantity = (qtyStr.toIntOrNull() ?: 10).coerceAtLeast(1),
                            unit = unitStr.ifBlank { "Units" },
                            unitCostKes = unitCostStr.toDoubleOrNull() ?: 1000.0,
                            minThreshold = thresholdStr.toIntOrNull() ?: 10,
                            branch = selectedBranch
                        )
                        showPurchaseMaterialDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    modifier = Modifier.testTag("btn_confirm_purchase_material")
                ) {
                    Text("Save to Store")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPurchaseMaterialDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: ISSUE RAW MATERIAL -> LIVE WORKSHOP JOB
    // ==========================================
    materialToIssueWorkshop?.let { mat ->
        var selectedJob by remember { mutableStateOf(activeWorkshopJobs.firstOrNull()) }
        var qtyStr by remember { mutableStateOf("2") }
        var jobExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { materialToIssueWorkshop = null },
            title = {
                Text("Issue ${mat.name} -> Workshop", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Available Store Stock: ${mat.quantity} ${mat.unit} @ KES ${String.format("%,.0f", mat.unitCostKes)}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    ExposedDropdownMenuBox(
                        expanded = jobExpanded,
                        onExpandedChange = { jobExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedJob?.let { "${it.casketType} (#${it.id} • ${it.assignedCraftsmanName})" } ?: "Select Job",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Target Workshop Job") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = jobExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = jobExpanded,
                            onDismissRequest = { jobExpanded = false }
                        ) {
                            activeWorkshopJobs.forEach { job ->
                                DropdownMenuItem(
                                    text = { Text("${job.casketType} (#${job.id}) • ${job.currentStage.title}") },
                                    onClick = {
                                        selectedJob = job
                                        jobExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = qtyStr,
                        onValueChange = { qtyStr = it },
                        label = { Text("Quantity (${mat.unit})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = selectedJob != null && (qtyStr.toIntOrNull() ?: 0) > 0,
                    onClick = {
                        val job = selectedJob ?: return@Button
                        val qty = qtyStr.toIntOrNull() ?: 1
                        viewModel.allocateMaterialToWorkshopJob(job.id, mat.id, qty)
                        materialToIssueWorkshop = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue),
                    modifier = Modifier.testTag("btn_confirm_issue_to_workshop")
                ) {
                    Text("Issue to Workshop")
                }
            },
            dismissButton = {
                TextButton(onClick = { materialToIssueWorkshop = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: STORE ITEM UPGRADE / DOWNGRADE COST
    // ==========================================
    upgradeDowngradeTarget?.let { target ->
        var isUpgrade by remember { mutableStateOf(target.initialIsUpgrade) }
        var qtyStr by remember { mutableStateOf("1") }
        var costDeltaStr by remember { mutableStateOf("5000") }
        var reasonStr by remember { mutableStateOf("") }

        val qtyVal = (qtyStr.toIntOrNull() ?: 1).coerceAtLeast(1)
        val unitDelta = costDeltaStr.toDoubleOrNull() ?: 0.0
        val totalDelta = qtyVal * unitDelta

        AlertDialog(
            onDismissRequest = { upgradeDowngradeTarget = null },
            title = {
                Text("Store Cost Adjustment (${target.itemName})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Category: ${target.storeCategory}", fontSize = 11.sp, color = TextSecondary)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = isUpgrade,
                            onClick = { isUpgrade = true },
                            label = { Text("Upgrade (+ Cost)", fontSize = 11.sp, maxLines = 1, softWrap = false) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = !isUpgrade,
                            onClick = { isUpgrade = false },
                            label = { Text("Downgrade (- Cost)", fontSize = 11.sp, maxLines = 1, softWrap = false) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = costDeltaStr,
                            onValueChange = { costDeltaStr = it },
                            label = { Text("Cost Delta / Unit (KES)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1.3f)
                        )
                        OutlinedTextField(
                            value = qtyStr,
                            onValueChange = { qtyStr = it },
                            label = { Text("Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.7f)
                        )
                    }

                    OutlinedTextField(
                        value = reasonStr,
                        onValueChange = { reasonStr = it },
                        label = { Text("Upgrade / Downgrade Specification") },
                        placeholder = { Text("e.g. Upgraded satin interior & heavy brass handles") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Surface(
                        color = if (isUpgrade) EmeraldLight else AmberLight,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Total ${if (isUpgrade) "Upgrade (+)" else "Downgrade (-)" } Valuation Delta: KES ${String.format("%,.0f", totalDelta)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isUpgrade) EmeraldSuccess else AmberWarning,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.applyStoreItemUpgradeDowngrade(
                            storeCategory = target.storeCategory,
                            itemId = target.itemId,
                            itemName = target.itemName,
                            isUpgrade = isUpgrade,
                            quantity = qtyVal,
                            costDeltaPerUnitKes = unitDelta,
                            reason = reasonStr.ifBlank { if (isUpgrade) "Quality/specification upgrade" else "Cost-reduction specification downgrade" }
                        )
                        upgradeDowngradeTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isUpgrade) EmeraldSuccess else AmberWarning),
                    modifier = Modifier.testTag("btn_confirm_upgrade_downgrade")
                ) {
                    Text(if (isUpgrade) "Apply Upgrade" else "Apply Downgrade")
                }
            },
            dismissButton = {
                TextButton(onClick = { upgradeDowngradeTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: ADD PRODUCT (ADMIN & CEO ONLY)
    // ==========================================
    if (showAddProductDialog) {
        var prodName by remember { mutableStateOf("") }
        var prodCategory by remember { mutableStateOf("Casket") }
        var selectedCasketType by remember { mutableStateOf(JABIMA_CASKET_TYPES.first()) }
        var costPriceStr by remember { mutableStateOf("") }
        var sellingPriceStr by remember { mutableStateOf("") }
        var stockCountStr by remember { mutableStateOf("5") }
        var selectedWarehouse by remember { mutableStateOf(JABIMA_BRANCHES.first()) }

        var categoryExpanded by remember { mutableStateOf(false) }
        var casketExpanded by remember { mutableStateOf(false) }
        var branchExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddProductDialog = false },
            title = {
                Text("Add New Product (Admin & CEO)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = prodName,
                        onValueChange = { prodName = it },
                        label = { Text("Product Name") },
                        placeholder = { Text("e.g. Modern High Roof Casket") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    ExposedDropdownMenuBox(
                        expanded = categoryExpanded,
                        onExpandedChange = { categoryExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = prodCategory,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Product Category") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = categoryExpanded,
                            onDismissRequest = { categoryExpanded = false }
                        ) {
                            listOf("Casket", "Ceremonial Equipment", "Burial Accessory").forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        prodCategory = cat
                                        categoryExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    if (prodCategory == "Casket") {
                        ExposedDropdownMenuBox(
                            expanded = casketExpanded,
                            onExpandedChange = { casketExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = selectedCasketType,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Casket Type") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = casketExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            )
                            ExposedDropdownMenu(
                                expanded = casketExpanded,
                                onDismissRequest = { casketExpanded = false }
                            ) {
                                JABIMA_CASKET_TYPES.forEach { ct ->
                                    DropdownMenuItem(
                                        text = { Text(ct) },
                                        onClick = {
                                            selectedCasketType = ct
                                            casketExpanded = false
                                            if (prodName.isBlank()) prodName = "$ct Casket"
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = costPriceStr,
                            onValueChange = { costPriceStr = it },
                            label = { Text("Cost (KES)") },
                            placeholder = { Text("45000") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = sellingPriceStr,
                            onValueChange = { sellingPriceStr = it },
                            label = { Text("Selling (KES)") },
                            placeholder = { Text("95000") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = stockCountStr,
                            onValueChange = { stockCountStr = it },
                            label = { Text("Stock Qty") },
                            modifier = Modifier.weight(1f)
                        )
                        ExposedDropdownMenuBox(
                            expanded = branchExpanded,
                            onExpandedChange = { branchExpanded = it },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = selectedWarehouse,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Branch") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchExpanded) },
                                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            )
                            ExposedDropdownMenu(
                                expanded = branchExpanded,
                                onDismissRequest = { branchExpanded = false }
                            ) {
                                JABIMA_BRANCHES.forEach { br ->
                                    DropdownMenuItem(
                                        text = { Text(br) },
                                        onClick = {
                                            selectedWarehouse = br
                                            branchExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
                        val product = ProductItem(
                            id = "PRD-" + (1000..9999).random(),
                            name = if (prodName.isNotBlank()) prodName else "$selectedCasketType Casket",
                            category = prodCategory,
                            casketType = if (prodCategory == "Casket") selectedCasketType else null,
                            stockCount = stockCountStr.toIntOrNull() ?: 5,
                            costPriceKes = costPriceStr.toDoubleOrNull() ?: 45000.0,
                            sellingPriceKes = sellingPriceStr.toDoubleOrNull() ?: 95000.0,
                            branchWarehouse = selectedWarehouse,
                            dateAdded = today,
                            addedBy = currentAccount?.fullName ?: "Fredrick Hayoyo (CEO)"
                        )
                        viewModel.addProductItem(product)
                        showAddProductDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Text("Save Product")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddProductDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: ADD MATERIAL CATEGORY (ADMIN & CEO ONLY)
    // ==========================================
    if (showAddCategoryDialog) {
        var catName by remember { mutableStateOf("") }
        var catDesc by remember { mutableStateOf("") }
        var catUnit by remember { mutableStateOf("Pieces") }
        var thresholdStr by remember { mutableStateOf("10") }

        AlertDialog(
            onDismissRequest = { showAddCategoryDialog = false },
            title = {
                Text("Add Materials Category", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Only Admin & CEO are authorized to add new material categories.", fontSize = 11.sp, color = TextSecondary)
                    OutlinedTextField(
                        value = catName,
                        onValueChange = { catName = it },
                        label = { Text("Category Name") },
                        placeholder = { Text("e.g. Glass & Dome Fittings") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = catDesc,
                        onValueChange = { catDesc = it },
                        label = { Text("Description") },
                        placeholder = { Text("Viewing glass, dome seals and airtight rubber latches") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = catUnit,
                        onValueChange = { catUnit = it },
                        label = { Text("Unit of Measure") },
                        placeholder = { Text("Panels / Pieces / Rolls / Kg") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = thresholdStr,
                        onValueChange = { thresholdStr = it },
                        label = { Text("Low Stock Threshold") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newCat = MaterialCategory(
                            id = "CAT-" + (10..99).random(),
                            name = catName,
                            description = catDesc,
                            unitOfMeasure = catUnit,
                            lowStockThreshold = thresholdStr.toIntOrNull() ?: 10,
                            itemCount = 0,
                            totalValuationKes = 0.0
                        )
                        viewModel.addMaterialCategory(newCat)
                        showAddCategoryDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue)
                ) {
                    Text("Add Category")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCategoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // DIALOG: EDIT MATERIAL CATEGORY (ADMIN & CEO ONLY)
    // ==========================================
    categoryToEdit?.let { cat ->
        var catName by remember { mutableStateOf(cat.name) }
        var catDesc by remember { mutableStateOf(cat.description) }
        var catUnit by remember { mutableStateOf(cat.unitOfMeasure) }
        var thresholdStr by remember { mutableStateOf(cat.lowStockThreshold.toString()) }

        AlertDialog(
            onDismissRequest = { categoryToEdit = null },
            title = {
                Text("Edit Category: ${cat.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Only Admin & CEO may modify category rules and thresholds.", fontSize = 11.sp, color = TextSecondary)
                    OutlinedTextField(
                        value = catName,
                        onValueChange = { catName = it },
                        label = { Text("Category Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = catDesc,
                        onValueChange = { catDesc = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = catUnit,
                        onValueChange = { catUnit = it },
                        label = { Text("Unit of Measure") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = thresholdStr,
                        onValueChange = { thresholdStr = it },
                        label = { Text("Low Stock Threshold") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val updated = cat.copy(
                            name = catName,
                            description = catDesc,
                            unitOfMeasure = catUnit,
                            lowStockThreshold = thresholdStr.toIntOrNull() ?: cat.lowStockThreshold
                        )
                        viewModel.updateMaterialCategory(updated)
                        categoryToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalCobaltBlue)
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { categoryToEdit = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    qrPreviewTarget?.let { (qrCode, label) ->
        AlertDialog(
            onDismissRequest = { qrPreviewTarget = null },
            title = {
                Text("Finished Casket QR Tag", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Navy900)
                    QrCodeBadge(qrData = qrCode, label = label, sizeDp = 160.dp)
                    Text(
                        "Scan this tag in Company Assets -> QR Custody to check caskets/gear out to a hearse or burial site.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            },
            confirmButton = {
                Button(onClick = { qrPreviewTarget = null }) {
                    Text("Done")
                }
            }
        )
    }
}

@Composable
private fun InventoryStatCard(
    title: String,
    value: String,
    sub: String,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 10.sp, color = color, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = sub, fontSize = 9.sp, color = color.copy(alpha = 0.8f))
        }
    }
}
