package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AirportShuttle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Church
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldGreenIce
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.PlusJakartaSansFontFamily
import com.example.ui.theme.PureWhite
import com.example.ui.theme.StrokeRed
import com.example.ui.theme.StrokeRedBorder
import com.example.ui.theme.StrokeRedDark
import com.example.ui.theme.StrokeRedLight
import java.util.Locale

data class FuneralPackage(
    val title: String,
    val price: String,
    val basePriceKes: Double,
    val subtitle: String,
    val features: List<String>,
    val isPopular: Boolean = false,
    val badge: String? = null
)

private data class ServiceAddonOption(
    val id: String,
    val name: String,
    val priceKes: Double
)

@Composable
fun ServicesScreen(
    onNavigateToStaffPortal: () -> Unit,
    isStaffLoggedIn: Boolean = false,
    staffName: String? = null
) {
    val cornerDp = 14.dp

    val packages = remember {
        listOf(
            FuneralPackage(
                title = "Executive State Honors",
                price = "KES 380,000",
                basePriceKes = 380000.0,
                subtitle = "Comprehensive luxury tribute for dignified farewell",
                features = listOf(
                    "Handcrafted Mahogany Casket with solid brass swing handles",
                    "Executive Mercedes Hearse with VIP cortege escort",
                    "Private Chapel Vigil at Lee Memorial Hall (audio & livestreaming)",
                    "Full embalming & preservation with cosmetologist preparation",
                    "Deluxe gravesite lowering gear, green turf & VIP canopies",
                    "Floral wreath arrangements & personalized memorial programs"
                ),
                isPopular = true,
                badge = "SIGNATURE TIER"
            ),
            FuneralPackage(
                title = "Dignity Gold Tier",
                price = "KES 220,000",
                basePriceKes = 220000.0,
                subtitle = "Distinguished care and full ceremonial transit",
                features = listOf(
                    "Polished Teakwood Casket with velvet interior lining",
                    "Long-distance hearse transport (up to 300km included)",
                    "Complete mortuary preparation and preservation",
                    "Gravesite setup: lowering gear, mobile church trolley & tent",
                    "Dedicated Funeral Director coordination on ceremony day"
                ),
                badge = "MOST REQUESTED"
            ),
            FuneralPackage(
                title = "Classic Silver Memorial",
                price = "KES 135,000",
                basePriceKes = 135000.0,
                subtitle = "Affordable, respectful, and complete family funeral care",
                features = listOf(
                    "Hardwood veneered dome casket with metal fittings",
                    "Hearse transport to family burial site",
                    "Mortuary preservation and family viewing setup",
                    "Gravesite lowering equipment and basic canopy"
                )
            ),
            FuneralPackage(
                title = "Heritage & Repatriation",
                price = "Custom Quote",
                basePriceKes = 450000.0,
                subtitle = "Cross-border and international dignified transit",
                features = listOf(
                    "Air cargo booking & consular embassy clearance",
                    "Hermetic zinc sealing & statutory health certification",
                    "Airport tarmac transfer & customs clearance escort"
                ),
                badge = "INTERNATIONAL"
            )
        )
    }

    val addons = remember {
        listOf(
            ServiceAddonOption("ADD-LIVE", "HD Chapel Livestreaming", 18000.0),
            ServiceAddonOption("ADD-FLORAL", "Deep Cypress & Rose Wreaths", 15000.0),
            ServiceAddonOption("ADD-CHOIR", "Tribute PA & Choir Acoustics", 12000.0),
            ServiceAddonOption("ADD-TENT", "Warm Alabaster VIP Canopy", 22000.0)
        )
    }

    var selectedPkgTitle by remember { mutableStateOf(packages.first().title) }
    var expandedPkgTitle by remember { mutableStateOf<String?>(packages.first().title) }
    val selectedAddons = remember { mutableStateListOf("ADD-FLORAL") }

    val selectedPackage = packages.firstOrNull { it.title == selectedPkgTitle } ?: packages.first()
    val addonTotal = addons.filter { selectedAddons.contains(it.id) }.sumOf { it.priceKes }
    val estimatedEstimateKes = selectedPackage.basePriceKes + addonTotal

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp)
            .testTag("services_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))

            // 24/7 BEREAVEMENT HOTLINE BANNER (Forest Green + Pure White + Stroke of Red)
            Card(
                shape = RoundedCornerShape(cornerDp + 2.dp),
                colors = CardDefaults.cardColors(containerColor = ForestGreenDark),
                border = BorderStroke(1.5.dp, StrokeRed.copy(alpha = 0.7f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(ForestGreenDark, ForestGreenPrimary, ForestGreenDark)
                            )
                        )
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(StrokeRed)
                            .border(1.5.dp, PureWhite.copy(alpha = 0.85f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneInTalk,
                            contentDescription = "Helpline",
                            tint = PureWhite,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "24/7 BEREAVEMENT CARE DESK",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = StrokeRedLight,
                            letterSpacing = 0.6.sp
                        )
                        Text(
                            text = "+254 700 123 456 / +254 722 000 888",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = PureWhite
                        )
                        Text(
                            text = "Immediate ambulance & mortuary hearse dispatch",
                            fontSize = 10.sp,
                            color = PureWhite.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }

        // INTERACTIVE STAFF PORTAL CALLOUT CARD
        item {
            Card(
                shape = RoundedCornerShape(cornerDp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("services_staff_portal_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                                    MaterialTheme.colorScheme.surface
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "STAFF OPERATIONS PORTAL",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = if (isStaffLoggedIn) "Signed in as $staffName" else "Field Operations & Payroll System",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.secondary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Surface(
                            color = if (isStaffLoggedIn) EmeraldLight else StrokeRedLight,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (isStaffLoggedIn) "ACTIVE" else "STAFF TAB",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isStaffLoggedIn) EmeraldSuccess else MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Access assigned duties, record case activities, check accrued task allowances, and withdraw earnings directly to M-PESA.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onNavigateToStaffPortal,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .testTag("services_enter_staff_portal_button")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isStaffLoggedIn) "Open Staff Operations Portal" else "Switch to Staff Operations Tab",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // INTERACTIVE PACKAGE ESTIMATOR SUMMARY
        item {
            Card(
                shape = RoundedCornerShape(cornerDp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth().testTag("services_interactive_estimator")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Interactive Ceremony Quote Estimator",
                        fontFamily = PlusJakartaSansFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Select a dignified tier below and toggle ceremonial enhancements for an instant family estimate.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        addons.forEach { addon ->
                            val selected = selectedAddons.contains(addon.id)
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    if (selected) selectedAddons.remove(addon.id) else selectedAddons.add(addon.id)
                                },
                                label = {
                                    Text(
                                        text = "${addon.name} (+${(addon.priceKes / 1000).toInt()}k)",
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.secondary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onSecondary
                                ),
                                modifier = Modifier.testTag("service_addon_${addon.id.lowercase()}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = ForestGreenPrimary,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "SELECTED ESTIMATE • ${selectedPackage.title.uppercase()}",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = EmeraldGreenIce
                                )
                                Text(
                                    text = "KES ${String.format(Locale.US, "%,.0f", estimatedEstimateKes)}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PureWhite
                                )
                            }
                            Surface(
                                color = StrokeRed,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "${selectedAddons.size} Add-ons",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PureWhite,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // SECTION HEADER: DIGNIFIED PACKAGES
        item {
            Column {
                Text(
                    text = "Dignified Funeral Packages",
                    fontFamily = PlusJakartaSansFontFamily,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Tap any package to select it for the estimator or inspect complete inclusions",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(packages, key = { it.title }) { pkg ->
            val isSelected = pkg.title == selectedPkgTitle
            val isExpanded = pkg.title == expandedPkgTitle
            Card(
                shape = RoundedCornerShape(cornerDp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f)
                    else MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(
                    if (isSelected) 2.dp else 1.dp,
                    if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(cornerDp))
                    .clickable {
                        selectedPkgTitle = pkg.title
                        expandedPkgTitle = if (isExpanded) null else pkg.title
                    }
                    .testTag("service_package_${pkg.title.lowercase().replace(" ", "_")}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Selected Tier",
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(
                                text = pkg.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (pkg.badge != null) {
                                Surface(
                                    color = if (pkg.isPopular) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = pkg.badge,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (pkg.isPopular) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Toggle details",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Text(
                        text = pkg.subtitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = pkg.price,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    AnimatedVisibility(visible = isExpanded) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(8.dp))
                            pkg.features.forEach { feature ->
                                Row(
                                    modifier = Modifier.padding(vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = null,
                                        tint = EmeraldSuccess,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = feature,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // SPECIALIZED SERVICES TILES
        item {
            Text(
                text = "Specialized Facilities & Support",
                fontFamily = PlusJakartaSansFontFamily,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FacilityTile(
                    icon = Icons.Default.AirportShuttle,
                    title = "Hearse Fleet",
                    desc = "Executive cortege vehicles",
                    modifier = Modifier.weight(1f)
                )
                FacilityTile(
                    icon = Icons.Default.Handyman,
                    title = "Casket Works",
                    desc = "Handcrafted custom fittings",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FacilityTile(
                    icon = Icons.Default.Church,
                    title = "Memorial Chapel",
                    desc = "Private family vigils",
                    modifier = Modifier.weight(1f)
                )
                FacilityTile(
                    icon = Icons.Default.MedicalServices,
                    title = "Mortuary Center",
                    desc = "Modern preservation vaults",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // BRANCH LOCATIONS
        item {
            Card(
                shape = RoundedCornerShape(cornerDp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Jabima Funeral Depots & Branches",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Nairobi Headquarters: Lee Memorial Lane / Ngong Rd", fontSize = 11.sp)
                    Text("• Nakuru Memorial Branch: George Morara Highway", fontSize = 11.sp)
                    Text("• Kisumu Transit Hub: Oginga Odinga Street", fontSize = 11.sp)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun FacilityTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    modifier: Modifier = Modifier
) {
    val cornerDp = 14.dp
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(cornerDp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(text = desc, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
