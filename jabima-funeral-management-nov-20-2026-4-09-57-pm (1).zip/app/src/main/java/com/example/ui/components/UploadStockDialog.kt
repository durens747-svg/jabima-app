package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.JABIMA_BRANCHES
import com.example.model.StockCategory
import com.example.model.StockUploadItem
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ForestGreenDark
import com.example.ui.theme.ForestGreenPrimary
import com.example.ui.theme.Navy900
import com.example.ui.theme.PureWhite

enum class StockUploadViewMode(val label: String) {
    EXCEL_UPLOAD("Upload via Excel"),
    UPLOAD_FORM("Manual Entry"),
    BATCH_PRESETS("Consignment Batches"),
    INVENTORY_CATALOG("Stock Log")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadStockDialog(
    uploadedStockList: List<StockUploadItem>,
    onDismiss: () -> Unit,
    onUploadItem: (
        name: String,
        category: StockCategory,
        sku: String,
        description: String,
        quantity: Int,
        reorderThreshold: Int,
        costPriceKes: Double,
        sellingPriceKes: Double,
        branchWarehouse: String,
        supplierName: String,
        invoiceOrBatch: String
    ) -> Unit,
    onUploadPresetBatch: (presetName: String) -> Unit,
    onBatchUpload: (items: List<StockUploadItem>) -> Unit = {},
    onDeleteStockItem: (itemId: String) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var viewMode by remember { mutableStateOf(StockUploadViewMode.EXCEL_UPLOAD) }

    // Excel import state
    val excelParsedItems = remember { mutableStateListOf<StockUploadItem>() }
    var selectedExcelFileName by remember { mutableStateOf<String?>(null) }
    var isExcelLoading by remember { mutableStateOf(false) }
    var excelPasteInput by remember { mutableStateOf("") }
    var showPasteBox by remember { mutableStateOf(false) }
    var excelStatusMessage by remember { mutableStateOf<String?>(null) }

    // Launcher for picking Excel (.xlsx, .xls, .csv) files from device storage
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            isExcelLoading = true
            try {
                val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "stock_consignment.xlsx"
                selectedExcelFileName = fileName
                val stream = context.contentResolver.openInputStream(uri)
                if (stream != null) {
                    val parsed = stream.use {
                        ExcelStockHelper.parseExcelOrCsvStream(it, fileName)
                    }
                    excelParsedItems.clear()
                    excelParsedItems.addAll(parsed)
                    excelStatusMessage = "Extracted ${parsed.size} stock items from '$fileName'."
                    Toast.makeText(context, "Parsed ${parsed.size} items from Excel file", Toast.LENGTH_SHORT).show()
                } else {
                    excelStatusMessage = "Could not open selected file."
                }
            } catch (e: Exception) {
                e.printStackTrace()
                excelStatusMessage = "Error parsing file: ${e.localizedMessage ?: "Invalid Excel format"}"
            } finally {
                isExcelLoading = false
            }
        }
    }

    // Manual Form inputs
    var itemName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(StockCategory.CASKET) }
    var skuCode by remember { mutableStateOf("CSK-${(100..999).random()}") }
    var description by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("5") }
    var reorderThresholdText by remember { mutableStateOf("2") }
    var costPriceText by remember { mutableStateOf("80000") }
    var sellingPriceText by remember { mutableStateOf("140000") }
    var selectedBranch by remember { mutableStateOf(JABIMA_BRANCHES.first()) }
    var supplierName by remember { mutableStateOf("Internal Workshop / Consignment") }
    var invoiceBatchNumber by remember { mutableStateOf("LOT-2026-${(10..99).random()}") }

    var categoryMenuExpanded by remember { mutableStateOf(false) }
    var branchMenuExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .height(680.dp)
                .padding(vertical = 4.dp)
                .testTag("upload_stock_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header with Microsoft Excel branding
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF107C41)), // Microsoft Excel green
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TableChart,
                                contentDescription = "Microsoft Excel",
                                tint = PureWhite,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Stock Intake & Inventory Upload",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Microsoft Excel (.xlsx / .csv) & ERP Consignments",
                                fontSize = 11.sp,
                                color = Color(0xFF107C41),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Mode Tabs
                ScrollableTabRow(
                    selectedTabIndex = viewMode.ordinal,
                    edgePadding = 0.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    StockUploadViewMode.entries.forEach { mode ->
                        Tab(
                            selected = viewMode == mode,
                            onClick = { viewMode = mode },
                            text = {
                                Text(
                                    text = if (mode == StockUploadViewMode.INVENTORY_CATALOG) "${mode.label} (${uploadedStockList.size})" else mode.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (viewMode == mode) FontWeight.Bold else FontWeight.Normal,
                                    color = if (viewMode == mode && mode == StockUploadViewMode.EXCEL_UPLOAD) Color(0xFF107C41) else MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // =====================================================================
                // VIEW 1: MICROSOFT EXCEL IMPORT (.xlsx / .csv)
                // =====================================================================
                when (viewMode) {
                    StockUploadViewMode.EXCEL_UPLOAD -> {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Excel Upload Banner Card
                            Surface(
                                color = Color(0xFFF0FDF4),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(Color(0xFF107C41), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.FileUpload,
                                                contentDescription = null,
                                                tint = PureWhite,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Microsoft Excel Stock Intake",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = Color(0xFF166534)
                                            )
                                            Text(
                                                text = "Import stock lists from Microsoft Excel spreadsheets (.xlsx, .xls, .csv)",
                                                fontSize = 10.sp,
                                                color = Color(0xFF15803D)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Action buttons row: Select File, Sample Template, Paste
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                filePickerLauncher.launch("*/*")
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            modifier = Modifier
                                                .weight(1.2f)
                                                .height(36.dp)
                                                .testTag("btn_select_excel_file")
                                        ) {
                                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Choose File", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                val sampleItems = ExcelStockHelper.getSampleExcelConsignmentItems()
                                                excelParsedItems.clear()
                                                excelParsedItems.addAll(sampleItems)
                                                selectedExcelFileName = "Jabima_Consignment_Excel_Q4.xlsx"
                                                excelStatusMessage = "Loaded ${sampleItems.size} verified items from Jabima Excel Consignment Template."
                                                Toast.makeText(context, "Loaded sample Excel spreadsheet records", Toast.LENGTH_SHORT).show()
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            modifier = Modifier
                                                .weight(1.4f)
                                                .height(36.dp)
                                                .testTag("btn_load_sample_excel")
                                        ) {
                                            Icon(Icons.Default.TableChart, contentDescription = null, tint = Color(0xFF107C41), modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Sample Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF107C41))
                                        }

                                        OutlinedButton(
                                            onClick = { showPasteBox = !showPasteBox },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(36.dp)
                                        ) {
                                            Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(if (showPasteBox) "Hide" else "Paste", fontSize = 11.sp)
                                        }
                                    }

                                    // Expandable Paste Box
                                    if (showPasteBox) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = excelPasteInput,
                                            onValueChange = { excelPasteInput = it },
                                            label = { Text("Paste Excel Tab-Separated or CSV Rows") },
                                            placeholder = { Text("SKU\tItem Name\tCategory\tQty\tCost\tPrice\tBranch...") },
                                            modifier = Modifier.fillMaxWidth(),
                                            minLines = 3,
                                            maxLines = 6
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Button(
                                            onClick = {
                                                if (excelPasteInput.isNotBlank()) {
                                                    val parsed = ExcelStockHelper.parsePastedExcelText(excelPasteInput)
                                                    excelParsedItems.clear()
                                                    excelParsedItems.addAll(parsed)
                                                    selectedExcelFileName = "Pasted_Excel_Data"
                                                    excelStatusMessage = "Parsed ${parsed.size} items from clipboard."
                                                    showPasteBox = false
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.fillMaxWidth().height(34.dp)
                                        ) {
                                            Text("Parse & Load Pasted Rows", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            // Status / Feedback message
                            excelStatusMessage?.let { msg ->
                                Surface(
                                    color = EmeraldLight,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(msg, fontSize = 11.sp, color = Color(0xFF065F46), fontWeight = FontWeight.Medium)
                                    }
                                }
                            }

                            // Parsed Rows Table Preview & Commit Action
                            if (excelParsedItems.isNotEmpty()) {
                                val totalUnits = excelParsedItems.sumOf { it.quantity }
                                val totalCostKes = excelParsedItems.sumOf { it.costPriceKes * it.quantity }
                                val totalSellingKes = excelParsedItems.sumOf { it.sellingPriceKes * it.quantity }

                                // Metrics Summary Card
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = "EXCEL PREVIEW: ${excelParsedItems.size} ITEMS READY",
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 11.sp,
                                                    color = CyanPrimary
                                                )
                                                Text(
                                                    text = "Source: ${selectedExcelFileName ?: "Microsoft Excel"}",
                                                    fontSize = 10.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            Surface(
                                                color = Color(0xFF107C41).copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = "$totalUnits Units Total",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF107C41),
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "Cost Valuation: KES ${String.format("%,.0f", totalCostKes)}",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = "Retail Valuation: KES ${String.format("%,.0f", totalSellingKes)}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = EmeraldSuccess
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Commit Button
                                        Button(
                                            onClick = {
                                                if (onBatchUpload != null) {
                                                    onBatchUpload(excelParsedItems.toList())
                                                } else {
                                                    excelParsedItems.forEach { item ->
                                                        onUploadItem(
                                                            item.name,
                                                            item.category,
                                                            item.sku,
                                                            item.description,
                                                            item.quantity,
                                                            item.reorderThreshold,
                                                            item.costPriceKes,
                                                            item.sellingPriceKes,
                                                            item.branchWarehouse,
                                                            item.supplierName,
                                                            item.invoiceOrBatchNumber
                                                        )
                                                    }
                                                }
                                                Toast.makeText(
                                                    context,
                                                    "Successfully imported ${excelParsedItems.size} items from Excel!",
                                                    Toast.LENGTH_LONG
                                                ).show()
                                                excelParsedItems.clear()
                                                selectedExcelFileName = null
                                                excelStatusMessage = null
                                                viewMode = StockUploadViewMode.INVENTORY_CATALOG
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(44.dp)
                                                .testTag("btn_import_excel_to_inventory")
                                        ) {
                                            Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                "Import All ${excelParsedItems.size} Excel Items to Warehouse Stock",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                }

                                // List of parsed items
                                Text(
                                    text = "Preview of parsed items (${excelParsedItems.size}):",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                excelParsedItems.forEachIndexed { index, item ->
                                    ParsedExcelRowCard(
                                        item = item,
                                        onRemove = {
                                            excelParsedItems.removeAt(index)
                                        }
                                    )
                                }
                            } else {
                                // Instructions when empty
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Description,
                                            contentDescription = null,
                                            tint = Color.Gray,
                                            modifier = Modifier.size(36.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "No Excel File Loaded Yet",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Tap 'Choose File' to select a .xlsx or .csv spreadsheet from your device, or click 'Sample Excel' to test consignment import with verified funeral supplies.",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        OutlinedButton(
                                            onClick = {
                                                val templateCsv = ExcelStockHelper.generateBlankExcelTemplate()
                                                clipboardManager.setText(AnnotatedString(templateCsv))
                                                Toast.makeText(context, "Copied Excel CSV template header to clipboard", Toast.LENGTH_SHORT).show()
                                            },
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Copy Blank Excel Template", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // =====================================================================
                    // VIEW 2: MANUAL FORM ENTRY
                    // =====================================================================
                    StockUploadViewMode.UPLOAD_FORM -> {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState())
                        ) {
                            // Category Dropdown
                            ExposedDropdownMenuBox(
                                expanded = categoryMenuExpanded,
                                onExpandedChange = { categoryMenuExpanded = it }
                            ) {
                                OutlinedTextField(
                                    value = selectedCategory.label,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Stock Item Category") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryMenuExpanded) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                        .testTag("stock_category_dropdown")
                                )
                                ExposedDropdownMenu(
                                    expanded = categoryMenuExpanded,
                                    onDismissRequest = { categoryMenuExpanded = false }
                                ) {
                                    StockCategory.entries.forEach { cat ->
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(10.dp)
                                                            .background(Color(cat.badgeColorHex), CircleShape)
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(cat.label, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                                }
                                            },
                                            onClick = {
                                                selectedCategory = cat
                                                skuCode = when (cat) {
                                                    StockCategory.CASKET -> "CSK-${(100..999).random()}"
                                                    StockCategory.MORTUARY_CHEMICALS -> "CHM-${(100..999).random()}"
                                                    StockCategory.BURIAL_APPAREL -> "APP-${(100..999).random()}"
                                                    StockCategory.CEREMONIAL_EQUIPMENT -> "EQP-${(100..999).random()}"
                                                    StockCategory.CHAPEL_VIGIL -> "VGL-${(100..999).random()}"
                                                    StockCategory.BRASS_HARDWARE -> "HWR-${(100..999).random()}"
                                                    StockCategory.FLEET_SPARES -> "FLT-${(100..999).random()}"
                                                }
                                                categoryMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = itemName,
                                    onValueChange = { itemName = it },
                                    label = { Text("Item Name") },
                                    placeholder = { Text("e.g. Imperial Teak Casket") },
                                    modifier = Modifier
                                        .weight(1.5f)
                                        .testTag("stock_name_input")
                                )

                                OutlinedTextField(
                                    value = skuCode,
                                    onValueChange = { skuCode = it },
                                    label = { Text("SKU / Code") },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = description,
                                onValueChange = { description = it },
                                label = { Text("Specifications & Description") },
                                placeholder = { Text("Material, wood finish, interior lining, dimensions...") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Quantity & Threshold
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = quantityText,
                                    onValueChange = { quantityText = it },
                                    label = { Text("Quantity Received") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("stock_quantity_input")
                                )

                                OutlinedTextField(
                                    value = reorderThresholdText,
                                    onValueChange = { reorderThresholdText = it },
                                    label = { Text("Reorder Alert Level") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Cost Price & Selling Price
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = costPriceText,
                                    onValueChange = { costPriceText = it },
                                    label = { Text("Unit Cost Price (KES)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedTextField(
                                    value = sellingPriceText,
                                    onValueChange = { sellingPriceText = it },
                                    label = { Text("Retail Selling Price (KES)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("stock_selling_price_input")
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Warehouse destination
                            ExposedDropdownMenuBox(
                                expanded = branchMenuExpanded,
                                onExpandedChange = { branchMenuExpanded = it }
                            ) {
                                OutlinedTextField(
                                    value = selectedBranch,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Destination Warehouse / Branch") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchMenuExpanded) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                )
                                ExposedDropdownMenu(
                                    expanded = branchMenuExpanded,
                                    onDismissRequest = { branchMenuExpanded = false }
                                ) {
                                    JABIMA_BRANCHES.forEach { b ->
                                        DropdownMenuItem(
                                            text = { Text(b, fontSize = 12.sp) },
                                            onClick = {
                                                selectedBranch = b
                                                branchMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = supplierName,
                                    onValueChange = { supplierName = it },
                                    label = { Text("Supplier / Workshop") },
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedTextField(
                                    value = invoiceBatchNumber,
                                    onValueChange = { invoiceBatchNumber = it },
                                    label = { Text("Batch / Lot #") },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = {
                                    if (itemName.isNotBlank()) {
                                        val qty = quantityText.toIntOrNull() ?: 1
                                        val threshold = reorderThresholdText.toIntOrNull() ?: 2
                                        val cost = costPriceText.toDoubleOrNull() ?: 0.0
                                        val selling = sellingPriceText.toDoubleOrNull() ?: cost * 1.5

                                        onUploadItem(
                                            itemName,
                                            selectedCategory,
                                            skuCode,
                                            description.ifBlank { "Standard ${selectedCategory.label} consignments" },
                                            qty,
                                            threshold,
                                            cost,
                                            selling,
                                            selectedBranch,
                                            supplierName,
                                            invoiceBatchNumber
                                        )
                                        // Reset fields
                                        itemName = ""
                                        description = ""
                                        viewMode = StockUploadViewMode.INVENTORY_CATALOG
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("submit_upload_stock_button")
                            ) {
                                Icon(imageVector = Icons.Default.Upload, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Upload Stock to Warehouse Inventory", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // =====================================================================
                    // VIEW 3: SHIPMENT BATCH PRESETS
                    // =====================================================================
                    StockUploadViewMode.BATCH_PRESETS -> {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Fast-track stock upload using verified supplier consignment presets:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            PresetBatchCard(
                                title = "Central Workshop Caskets Consignment",
                                subtitle = "10 Solid Hardwood Caskets (Teak & Gloss Walnut)",
                                category = "Caskets & Coffins",
                                destination = "Bama Central & Siaya Referral",
                                onUploadClick = {
                                    onUploadPresetBatch("CASKETS_WORKSHOP_BATCH")
                                    viewMode = StockUploadViewMode.INVENTORY_CATALOG
                                }
                            )

                            PresetBatchCard(
                                title = "Apex Medical Mortuary & PPE Consignment",
                                subtitle = "74 Units: Embalming Fluids & Heavy-Duty Shrouds",
                                category = "Mortuary & Chemicals",
                                destination = "Siaya Referral & Bama Branch",
                                onUploadClick = {
                                    onUploadPresetBatch("MORTUARY_PPE_BATCH")
                                    viewMode = StockUploadViewMode.INVENTORY_CATALOG
                                }
                            )

                            PresetBatchCard(
                                title = "ProAudio Vigil & Chapel Equipment Consignment",
                                subtitle = "5 Units: Dual Wireless Microphone & Receiver Sets",
                                category = "Chapel & Vigil Supplies",
                                destination = "Siaya opposite Shell Petrol",
                                onUploadClick = {
                                    onUploadPresetBatch("VIGIL_AUDIO_BATCH")
                                    viewMode = StockUploadViewMode.INVENTORY_CATALOG
                                }
                            )
                        }
                    }

                    // =====================================================================
                    // VIEW 4: INVENTORY CATALOG (LOG OF UPLOADED ITEMS)
                    // =====================================================================
                    StockUploadViewMode.INVENTORY_CATALOG -> {
                        Column(modifier = Modifier.weight(1f)) {
                            // Top action bar in Stock Log: Export to Excel button
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Catalogued Consignments (${uploadedStockList.size})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                OutlinedButton(
                                    onClick = {
                                        if (uploadedStockList.isNotEmpty()) {
                                            val csvData = ExcelStockHelper.exportToExcelCsv(uploadedStockList)
                                            val sendIntent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                putExtra(Intent.EXTRA_TEXT, csvData)
                                                putExtra(Intent.EXTRA_SUBJECT, "Jabima_Stock_Inventory_Export.csv")
                                                type = "text/csv"
                                            }
                                            val shareIntent = Intent.createChooser(sendIntent, "Export Stock to Microsoft Excel")
                                            context.startActivity(shareIntent)
                                        } else {
                                            Toast.makeText(context, "No stock items to export", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.FileDownload, contentDescription = null, tint = Color(0xFF107C41), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Export to Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF107C41))
                                }
                            }

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (uploadedStockList.isEmpty()) {
                                    item {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(32.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(Icons.Default.Inventory, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(32.dp))
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text("No stock items uploaded yet.", color = Color.Gray, fontSize = 12.sp)
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text("Use 'Upload via Excel' tab to import spreadsheet records.", color = Color.Gray, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                } else {
                                    items(uploadedStockList, key = { it.id }) { item ->
                                        StockUploadItemRow(
                                            item = item,
                                            onDelete = { onDeleteStockItem(item.id) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Warehouse Inventory Sync Active",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Done / Close", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ParsedExcelRowCard(
    item: StockUploadItem,
    onRemove: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Color(item.category.badgeColorHex), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Navy900
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${item.sku} • ${item.category.label} • ${item.branchWarehouse}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Supplier: ${item.supplierName} | Batch: ${item.invoiceOrBatchNumber}",
                    fontSize = 9.sp,
                    color = Color.Gray
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    color = EmeraldLight,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "${item.quantity} pcs",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldSuccess,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "KES ${String.format("%,.0f", item.sellingPriceKes)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanPrimary
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = onRemove,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove row",
                    tint = com.example.ui.theme.StrokeRed,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
private fun PresetBatchCard(
    title: String,
    subtitle: String,
    category: String,
    destination: String,
    onUploadClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(subtitle, fontSize = 11.sp, color = CyanPrimary, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(2.dp))
                Text("Destination: $destination", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Button(
                onClick = onUploadClick,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.height(34.dp)
            ) {
                Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Load Batch", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StockUploadItemRow(
    item: StockUploadItem,
    onDelete: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Color(item.category.badgeColorHex), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Text(
                    text = "${item.sku} • ${item.category.label} • ${item.branchWarehouse}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Supplier: ${item.supplierName} • Batch: ${item.invoiceOrBatchNumber}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    color = EmeraldLight,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "${item.quantity} units",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldSuccess,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "KES ${String.format("%,.0f", item.sellingPriceKes)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanPrimary
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = com.example.ui.theme.StrokeRed,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
