package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.PreferencesManager
import com.example.data.StaffPortalRepository
import com.example.data.firebase.CloudSyncState
import com.example.data.firebase.FirestoreAdminEntry
import com.example.data.firebase.FirestoreErrorHandler
import com.example.data.firebase.FirestoreSyncRepository
import com.example.domain.CasketProductionCostModel
import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.BranchStatusBoard
import com.example.model.CaseDocumentRecord
import com.example.model.CaseDocumentType
import com.example.utils.PasswordSecurityHelper
import com.example.model.MainAppTab
import com.example.model.NavTab
import com.example.model.PaymentStatus
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.StaffRole
import com.example.model.StaffShiftSchedule
import com.example.model.ShiftPeriod
import com.example.model.StaffWalletSummary
import com.example.model.StockMovementRecord
import com.example.model.StockMovementStatus
import com.example.model.TransactionType
import com.example.model.VendorProfile
import com.example.model.VendorTransaction
import com.example.model.VendorTransactionType
import com.example.model.WalletTransaction
import com.example.model.CasketExchangeRecord
import com.example.model.CasketItem
import com.example.model.CompanyAsset
import com.example.model.CustodyStatus
import com.example.model.CustomerOrderRecord
import com.example.model.LeaveRequest
import com.example.model.SalesServiceItem
import com.example.model.VoipExtension
import com.example.model.VoipCallLog
import com.example.model.BulkSmsMessage
import com.example.model.PerformanceIncentive
import com.example.model.IncentiveCategory
import com.example.model.StaffExpenseClaim
import com.example.model.ExpenseCategory
import com.example.model.ExpenseStatus
import com.example.model.Department
import com.example.model.PriceEditItem
import com.example.model.StockCategory
import com.example.model.StockUploadItem
import com.example.model.PriceUpdateRecord
import com.example.model.IntegrationPlatform
import com.example.model.SyncStatus
import com.example.model.PlatformIntegrationConfig
import com.example.model.IntegrationSyncLog
import com.example.model.FleetGpsVehicle
import com.example.model.GeofenceZone
import com.example.model.GeofenceCheckinEvent
import com.example.model.FleetInspectionRecord
import com.example.model.FleetFuelLogRecord
import com.example.model.MpesaB2cReceipt
import com.example.model.CasketStockByBranchRow
import com.example.model.DashboardDailyKpis
import com.example.model.WorkshopProductionStage
import com.example.model.WorkshopProductionItem
import com.example.model.MaterialCategory
import com.example.model.InventoryMaterialItem
import com.example.model.ProductItem
import com.example.model.StaffDailyReport
import com.example.model.BurialScheduleEvent
import com.example.model.BurialServiceTiming
import com.example.model.ServiceReminderLog
import com.example.model.FuneralArrangementStage
import com.example.model.OrderPackageItem
import com.example.model.OrderAddonItem
import com.example.model.StaffBreakageRecord
import com.example.model.OperatorWageAllocation
import com.example.model.StoreUpgradeDowngradeRecord
import com.example.model.StaffAlertNotification
import com.example.domain.PayrollRulesEngine
import com.example.domain.StaffQrIdentityCodec
import com.example.domain.StaffQrParseResult
import com.example.model.AssetCustodyLog
import com.example.model.FamilyCortegeMilestone
import com.example.model.MarginStatus
import com.example.model.OfflineActionType
import com.example.model.OfflineQueuedAction
import com.example.model.ShiftAttendanceAction
import com.example.model.ShiftAttendanceRecord
import com.example.model.ShiftVehicleHandover
import com.example.model.TaskPriority
import com.example.network.ExternalGatewayStatus
import com.example.network.ExternalServiceBridge
import com.example.ui.screens.GoogleCloudAuthHelper
import com.example.utils.NetworkConnectivityObserver
import com.google.firebase.auth.FirebaseUser
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StaffPortalViewModel(
    private val repository: StaffPortalRepository = StaffPortalRepository(),
    private val preferencesManager: PreferencesManager? = null,
    private val firestoreSyncRepository: FirestoreSyncRepository? = null,
    private val externalServiceBridge: ExternalServiceBridge = ExternalServiceBridge(),
    private val connectivityObserver: NetworkConnectivityObserver? = null
) : ViewModel() {

    private val _mainAppTab = MutableStateFlow(MainAppTab.STAFF_OPERATIONS)
    val mainAppTab: StateFlow<MainAppTab> = _mainAppTab.asStateFlow()

    private val _currentAccount = MutableStateFlow<StaffAccount?>(null)
    val currentAccount: StateFlow<StaffAccount?> = _currentAccount.asStateFlow()

    // When admin is impersonating a staff member to access their account
    private val _adminImpersonator = MutableStateFlow<StaffAccount?>(null)
    val adminImpersonator: StateFlow<StaffAccount?> = _adminImpersonator.asStateFlow()

    private val _currentTab = MutableStateFlow(NavTab.OVERVIEW)
    val currentTab: StateFlow<NavTab> = _currentTab.asStateFlow()

    val preSelectedOrderCasketName = MutableStateFlow<String?>(null)

    // Filters for activities
    val activitySearchQuery = MutableStateFlow("")
    val activityStatusFilter = MutableStateFlow<ActivityStatus?>(null)
    val activityCategoryFilter = MutableStateFlow<ActivityCategory?>(null)

    // Filters for transactions
    val transactionFilter = MutableStateFlow("ALL") // "ALL", "CREDITS", "WITHDRAWALS"

    val allAccounts: StateFlow<List<StaffAccount>> = repository.accounts
    val allActivities: StateFlow<List<StaffActivity>> = repository.activities
    val allTransactions: StateFlow<List<WalletTransaction>> = repository.transactions

    // Inter-branch stock movement, status boards, vendors, and visual shifts
    val stockMovements: StateFlow<List<StockMovementRecord>> = repository.stockMovements
    val branchStatusBoards: StateFlow<List<BranchStatusBoard>> = repository.branchStatusBoards
    val vendors: StateFlow<List<VendorProfile>> = repository.vendors
    val vendorTransactions: StateFlow<List<VendorTransaction>> = repository.vendorTransactions
    val staffShiftSchedules: StateFlow<List<StaffShiftSchedule>> = repository.staffShiftSchedules

    // Caskets, exchanges, sales services, customer orders, assets, leaves, 3CX, and SMS
    val caskets: StateFlow<List<CasketItem>> = repository.caskets
    val casketExchanges: StateFlow<List<CasketExchangeRecord>> = repository.casketExchanges
    val salesServices: StateFlow<List<SalesServiceItem>> = repository.salesServices
    val customerOrders: StateFlow<List<CustomerOrderRecord>> = repository.customerOrders
    val companyAssets: StateFlow<List<CompanyAsset>> = repository.companyAssets
    val leaveRequests: StateFlow<List<LeaveRequest>> = repository.leaveRequests
    val voipExtensions: StateFlow<List<VoipExtension>> = repository.voipExtensions
    val voipCallLogs: StateFlow<List<VoipCallLog>> = repository.voipCallLogs
    val bulkSmsMessages: StateFlow<List<BulkSmsMessage>> = repository.bulkSmsMessages
    val fleetGpsVehicles: StateFlow<List<FleetGpsVehicle>> = repository.fleetGpsVehicles
    val geofenceZones: StateFlow<List<GeofenceZone>> = repository.geofenceZones
    val geofenceCheckinEvents: StateFlow<List<GeofenceCheckinEvent>> = repository.geofenceCheckinEvents
    val fleetInspections: StateFlow<List<FleetInspectionRecord>> = repository.fleetInspections
    val fleetFuelLogs: StateFlow<List<FleetFuelLogRecord>> = repository.fleetFuelLogs

    val dashboardDailyKpis: StateFlow<DashboardDailyKpis> = repository.dashboardDailyKpis
    val casketStockByBranch: StateFlow<List<CasketStockByBranchRow>> = repository.casketStockByBranch
    val workshopItems: StateFlow<List<WorkshopProductionItem>> = repository.workshopItems
    val materialCategories: StateFlow<List<MaterialCategory>> = repository.materialCategories
    val inventoryMaterials: StateFlow<List<InventoryMaterialItem>> = repository.inventoryMaterials
    val inventoryProducts: StateFlow<List<ProductItem>> = repository.inventoryProducts
    val dailyReports: StateFlow<List<StaffDailyReport>> = repository.dailyReports
    val burialSchedules: StateFlow<List<BurialScheduleEvent>> = repository.burialSchedules
    val serviceReminderLogs: StateFlow<List<ServiceReminderLog>> = repository.serviceReminderLogs
    val orderPackages: StateFlow<List<OrderPackageItem>> = repository.orderPackages
    val orderAddons: StateFlow<List<OrderAddonItem>> = repository.orderAddons
    val upgradeDowngradeLogs: StateFlow<List<StoreUpgradeDowngradeRecord>> = repository.upgradeDowngradeLogs
    val staffAlerts: StateFlow<List<StaffAlertNotification>> = repository.staffAlerts
    val breakageRecords: StateFlow<List<StaffBreakageRecord>> = repository.breakageRecords
    val operatorWageAllocations: StateFlow<List<OperatorWageAllocation>> = repository.operatorWageAllocations
    val assetCustodyLogs: StateFlow<List<AssetCustodyLog>> = repository.assetCustodyLogs
    val shiftHandovers: StateFlow<List<ShiftVehicleHandover>> = repository.shiftHandovers
    val shiftAttendanceLogs: StateFlow<List<ShiftAttendanceRecord>> = repository.shiftAttendanceLogs
    val caseDocuments: StateFlow<List<CaseDocumentRecord>> = repository.caseDocuments

    // Forced first-login password rotation state
    val requiresPasswordRotation = MutableStateFlow<StaffAccount?>(null)

    val selectedFleetVehicle = MutableStateFlow<FleetGpsVehicle?>(null)
    val latestMpesaReceipt = MutableStateFlow<MpesaB2cReceipt?>(null)
    val showMpesaB2cDialog = MutableStateFlow(false)
    val showFleetInspectionDialog = MutableStateFlow(false)
    val showFuelLogDialog = MutableStateFlow(false)

    fun selectFleetVehicle(vehicle: FleetGpsVehicle?) {
        selectedFleetVehicle.value = vehicle
    }

    fun triggerGeofenceAutoCheckin(vehicleReg: String, zoneName: String? = null) {
        val event = repository.triggerSimulatedGeofenceAutoCheckin(vehicleReg, zoneName)
        actionFeedbackMessage.value = "📍 Geofence Auto-Checkin: ${event.vehicleReg} at ${event.zoneName} (${event.eventType})"
    }

    fun submitFleetInspection(record: FleetInspectionRecord) {
        repository.submitFleetInspection(record)
        actionFeedbackMessage.value = "✅ Pre-cortege inspection submitted for ${record.vehicleReg} (Passed)."
    }

    fun recordFuelLog(record: FleetFuelLogRecord) {
        repository.recordFuelLog(record)
        actionFeedbackMessage.value = "⛽ Fuel log recorded for ${record.vehicleReg} (${record.litersPumped}L @ KES ${String.format("%,.0f", record.totalAmountKes)})."
    }

    fun executeInstantMpesaB2cPayout(
        staffId: String,
        amount: Double,
        phone: String,
        category: String,
        reason: String
    ): MpesaB2cReceipt {
        val receipt = repository.disburseInstantMpesaB2c(staffId, amount, phone, category, reason)
        latestMpesaReceipt.value = receipt
        actionFeedbackMessage.value = "⚡ M-PESA B2C Disbursed! Ref: ${receipt.transactionId} (${receipt.recipientName} - KES ${String.format("%,.0f", amount)})"
        return receipt
    }

    fun refreshFleetTelemetry() {
        repository.refreshFleetTelemetry()
        if (cloudUserEmail.value != null) {
            val isAdminUser = canWriteVerifiedCloudActivity()
            viewModelScope.launch {
                repository.fleetGpsVehicles.value.forEach { vehicle ->
                    firestoreSyncRepository?.upsertFleetVehicle(vehicle, isAdminUser = isAdminUser)
                }
            }
        }
        actionFeedbackMessage.value = "Fleet GPS Telemetry refreshed. All ${repository.fleetGpsVehicles.value.size} hearse transponders active."
    }

    fun simulateFleetStepMovement() {
        repository.simulateFleetStepMovement()
    }

    fun recordCasketExchange(exchange: CasketExchangeRecord) {
        repository.recordCasketExchange(exchange)
        actionFeedbackMessage.value = "Casket exchange record #${exchange.id} saved for ${exchange.clientFamily}."
    }

    fun submitCustomerOrder(order: CustomerOrderRecord) {
        repository.submitCustomerOrder(order)
        val agentId = repository.accounts.value
            .firstOrNull { it.fullName.contains(order.salesAgentName, ignoreCase = true) }
            ?.id ?: ""
        viewModelScope.launch {
            if (order.paymentMethod.equals("M-PESA", ignoreCase = true)) {
                val stkResult = externalServiceBridge.dispatchMpesaStkPush(
                    phoneNumber = order.clientPhone,
                    amountKes = order.totalAmountKes,
                    accountReference = order.orderId,
                    description = "Jabima Funeral ${order.orderId}"
                )
                actionFeedbackMessage.value = "Order #${order.orderId} recorded • ${stkResult.summaryMessage}"
            } else {
                actionFeedbackMessage.value = "Order #${order.orderId} placed successfully. Ref: ${order.referenceCode}."
            }
            if (cloudUserEmail.value != null) {
                firestoreSyncRepository?.createCustomerOrder(order, agentId)
            }
        }
    }

    fun updateCustomerOrderPaymentStatus(
        orderId: String,
        newStatus: String,
        updatedRef: String? = null
    ) {
        val ok = repository.updateCustomerOrderPaymentStatus(orderId, newStatus, updatedRef)
        if (ok) {
            actionFeedbackMessage.value = "Order #$orderId payment status updated to $newStatus."
        }
    }

    fun updateAssetStatus(assetId: String, newCondition: String) {
        repository.updateAssetStatus(assetId, newCondition)
        val updated = repository.companyAssets.value.firstOrNull { it.id == assetId }
        if (updated != null && cloudUserEmail.value != null) {
            val isAdminUser = canWriteVerifiedCloudActivity()
            viewModelScope.launch {
                firestoreSyncRepository?.upsertCompanyAsset(updated, isAdminUser = isAdminUser)
            }
        }
        actionFeedbackMessage.value = "Asset $assetId condition updated to $newCondition."
    }

    fun submitLeaveRequest(request: LeaveRequest) {
        if (!isDeviceOnline.value) {
            enqueueOfflineAction(
                type = OfflineActionType.LEAVE_REQUEST,
                title = "Time-Off Request: ${request.staffName}",
                summary = "${request.leaveType} • ${request.daysCount} days (${request.startDate} - ${request.endDate})",
                payloadObj = request
            )
            actionFeedbackMessage.value = "Queued offline: Leave request for ${request.staffName} will sync on signal."
            return
        }
        repository.submitLeaveRequest(request)
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.createLeaveRequest(request)
            }
        }
        actionFeedbackMessage.value = "Leave request submitted for ${request.staffName} (${request.daysCount} days)."
    }

    fun approveLeaveRequest(requestId: String, approvedBy: String) {
        repository.approveLeaveRequest(requestId, approvedBy)
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch {
                firestoreSyncRepository?.adminUpdateLeaveStatus(requestId, "Approved", approvedBy)
            }
        }
        actionFeedbackMessage.value = "Leave request #$requestId approved by $approvedBy."
    }

    fun rejectLeaveRequest(requestId: String, rejectedBy: String) {
        repository.rejectLeaveRequest(requestId, rejectedBy)
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch {
                firestoreSyncRepository?.adminUpdateLeaveStatus(requestId, "Declined", rejectedBy)
            }
        }
        actionFeedbackMessage.value = "Leave request #$requestId declined by $rejectedBy."
    }

    fun recordVoipCall(
        callType: String,
        contactName: String,
        numberOrExt: String,
        durationText: String = "01:15 min"
    ) {
        val newCall = VoipCallLog(
            id = "CDR-${(100..999).random()}",
            callType = callType,
            contactName = contactName,
            numberOrExt = numberOrExt,
            durationText = durationText,
            timestamp = "Just now",
            status = "Connected HD (Opus)",
            recordingAvailable = true
        )
        repository.recordVoipCall(newCall)
        actionFeedbackMessage.value = "3CX Call logged: $callType call to $contactName ($numberOrExt)."
    }

    fun sendBulkSms(
        recipientType: String,
        recipients: String,
        body: String,
        senderId: String = "JABIMA_LTD",
        units: Int = 1
    ) {
        repository.sendBulkSms(recipientType, recipients, body, senderId, units)
        viewModelScope.launch {
            val res = externalServiceBridge.dispatchBulkSms(recipients, body, senderId)
            actionFeedbackMessage.value = if (res.isLiveApiCall) {
                "Bulk SMS ($senderId) -> $recipients: ${res.summaryMessage}"
            } else {
                "Bulk SMS broadcast ($units unit) logged via $senderId • ${res.summaryMessage}"
            }
        }
    }

    // Filtered activities for current staff member's independent portal
    val currentStaffActivities: StateFlow<List<StaffActivity>> = combine(
        repository.activities,
        _currentAccount,
        activitySearchQuery,
        activityStatusFilter,
        activityCategoryFilter
    ) { acts, account, query, status, cat ->
        if (account == null) return@combine emptyList()
        val staffList = acts.filter { it.staffId == account.id }

        staffList.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.title.contains(query, ignoreCase = true) ||
                    item.caseReference.contains(query, ignoreCase = true) ||
                    item.clientFamily.contains(query, ignoreCase = true) ||
                    item.location.contains(query, ignoreCase = true)

            val matchesStatus = status == null || item.status == status
            val matchesCat = cat == null || item.category == cat

            matchesQuery && matchesStatus && matchesCat
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Wallet summary for current staff
    val currentWalletSummary: StateFlow<StaffWalletSummary> = combine(
        repository.transactions,
        _currentAccount
    ) { _, account ->
        if (account == null) {
            StaffWalletSummary("", 0.0, 0.0, 0.0, 0.0)
        } else {
            repository.getWalletSummary(account.id)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StaffWalletSummary("", 0.0, 0.0, 0.0, 0.0))

    // All staff wallet summaries for Admin Console portal directory
    val allStaffWalletSummaries: StateFlow<Map<String, StaffWalletSummary>> = combine(
        repository.accounts,
        repository.transactions
    ) { _, _ ->
        repository.getAllWalletSummaries()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // Transactions strictly scoped to current staff member's independent wallet
    val currentStaffTransactions: StateFlow<List<WalletTransaction>> = combine(
        repository.transactions,
        _currentAccount,
        transactionFilter
    ) { txns, account, filter ->
        if (account == null) return@combine emptyList()
        val staffList = txns.filter { it.staffId == account.id }

        when (filter) {
            "CREDITS" -> staffList.filter { it.amount > 0 }
            "WITHDRAWALS" -> staffList.filter { it.amount < 0 }
            "PENDING" -> staffList.filter { it.status == PaymentStatus.PENDING_APPROVAL || it.status == PaymentStatus.PROCESSING }
            "COMMISSIONS" -> staffList.filter { it.type == TransactionType.COMMISSION || it.type == TransactionType.PERFORMANCE_INCENTIVE }
            "SERVICE_PAYOUTS" -> staffList.filter {
                it.type == TransactionType.ACTIVITY_ALLOWANCE ||
                    it.type == TransactionType.OVERTIME_BONUS ||
                    it.type == TransactionType.OPERATOR_TRANSPORT_FEE ||
                    it.type == TransactionType.OPERATOR_DAILY_WAGE ||
                    it.type == TransactionType.PER_DIEM
            }
            else -> staffList
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Performance incentives strictly scoped to current staff member's independent portal
    val allIncentives: StateFlow<List<PerformanceIncentive>> = repository.incentives
    val currentStaffIncentives: StateFlow<List<PerformanceIncentive>> = combine(
        repository.incentives,
        _currentAccount
    ) { incs, account ->
        if (account == null) emptyList()
        else incs.filter { it.staffId == account.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Field expense claims strictly scoped to current staff member's independent portal
    val allExpenses: StateFlow<List<StaffExpenseClaim>> = repository.expenses
    val currentStaffExpenses: StateFlow<List<StaffExpenseClaim>> = combine(
        repository.expenses,
        _currentAccount
    ) { exps, account ->
        if (account == null) emptyList()
        else exps.filter { it.staffId == account.id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Price updates and stock uploads
    val priceUpdateHistory: StateFlow<List<PriceUpdateRecord>> = repository.priceUpdateHistory
    val uploadedStockItems: StateFlow<List<StockUploadItem>> = repository.uploadedStockItems

    // Enterprise Platform Integrations (Zoho One, Freshsales, Zuri Platform, HubSpot)
    val integrationConfigs: StateFlow<List<PlatformIntegrationConfig>> = repository.integrationConfigs
    val integrationSyncLogs: StateFlow<List<IntegrationSyncLog>> = repository.integrationSyncLogs
    val showConfigureIntegrationDialog = MutableStateFlow<PlatformIntegrationConfig?>(null)

    // UI Dialog States
    val showLogActivityDialog = MutableStateFlow(false)
    val showRequestPayoutDialog = MutableStateFlow(false)
    val showSubmitExpenseDialog = MutableStateFlow(false)
    val showAwardIncentiveDialog = MutableStateFlow(false)
    val showChangePasswordDialog = MutableStateFlow(false)
    val showAdminCreditDialog = MutableStateFlow(false)
    val showEditStaffDialog = MutableStateFlow<StaffAccount?>(null)
    val showPriceEditorDialog = MutableStateFlow(false)
    val showUploadStockDialog = MutableStateFlow(false)
    val showUniversalExcelImportDialog = MutableStateFlow(false)
    val selectedExcelImportDataset = MutableStateFlow(com.example.model.ExcelDatasetType.INVENTORY_STOCK)
    val showExportManifestDialog = MutableStateFlow(false)
    val showSpotlightSearchDialog = MutableStateFlow(false)
    val isOutdoorHighContrastMode = MutableStateFlow(false)
    val isDarkMode = MutableStateFlow(false)
    val autoNightShiftScheduled = MutableStateFlow(false)
    val nightShiftEyeProtection = MutableStateFlow(true)

    val selectedStaffForAdmin = MutableStateFlow<StaffAccount?>(null)
    val selectedActivityForDetail = MutableStateFlow<StaffActivity?>(null)
    val selectedTransactionForReceipt = MutableStateFlow<WalletTransaction?>(null)

    // Login error message
    val authErrorMessage = MutableStateFlow<String?>(null)
    val actionFeedbackMessage = MutableStateFlow<String?>(null)

    // Biometric Security States (Locked on entry point by default for 24/7 staff verification)
    val showBiometricDialog = MutableStateFlow(false)
    val biometricTargetStaff = MutableStateFlow<StaffAccount?>(null)
    val isPortalBiometricLocked = MutableStateFlow(true)

    // Cloud Sync & External Gateway States
    val cloudUserEmail = MutableStateFlow<String?>(null)
    val cloudUserUid = MutableStateFlow<String?>(null)
    val cloudAdmins = MutableStateFlow<List<FirestoreAdminEntry>>(emptyList())
    val cloudSyncState = MutableStateFlow<CloudSyncState>(CloudSyncState.SignedOut)
    val externalGatewayStatus: StateFlow<ExternalGatewayStatus> = MutableStateFlow(externalServiceBridge.inspectGatewayStatus()).asStateFlow()
    private var cloudSyncJobs: List<Job> = emptyList()

    // Statutory Payroll Payslip Toggle & Offline Rural Burial Queue
    private val gson = Gson()
    val applyStatutoryOnPayslip = MutableStateFlow(true)
    val showOfflineSyncDialog = MutableStateFlow(false)
    val showShiftAlertCenterDialog = MutableStateFlow(false)
    val prefilledAlertStaffId = MutableStateFlow<String?>(null)
    val prefilledAlertShiftId = MutableStateFlow<String?>(null)
    val simulatedOfflineOverride = MutableStateFlow(false)
    private val rawNetworkOnlineFlow = connectivityObserver?.isOnline ?: MutableStateFlow(true)
    val isDeviceOnline: StateFlow<Boolean> = combine(
        rawNetworkOnlineFlow,
        simulatedOfflineOverride
    ) { rawOnline, simOffline ->
        rawOnline && !simOffline
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val offlineQueue = MutableStateFlow<List<OfflineQueuedAction>>(emptyList())
    val isSyncingOfflineQueue = MutableStateFlow(false)

    init {
        // Default target profile for Biometric Entry Gate (user must verify via fingerprint/face or password)
        val defaultStaff = repository.accounts.value.firstOrNull { it.id == "CEO-001" } ?: repository.accounts.value.firstOrNull()
        _currentAccount.value = defaultStaff
        biometricTargetStaff.value = defaultStaff

        // Restore persisted DataStore preferences, offline queue & rotated password hashes
        preferencesManager?.let { pm ->
            viewModelScope.launch {
                val initialPrefs = pm.preferencesFlow.first()
                runCatching {
                    val pwType = object : TypeToken<Map<String, String>>() {}.type
                    val savedHashes: Map<String, String> = gson.fromJson(initialPrefs.rotatedPasswordsJson, pwType) ?: emptyMap()
                    repository.applyPersistedPasswordHashes(savedHashes)
                    val refreshedCurrent = _currentAccount.value?.id?.let { id ->
                        repository.accounts.value.firstOrNull { it.id == id }
                    }
                    if (refreshedCurrent != null) {
                        _currentAccount.value = refreshedCurrent
                        biometricTargetStaff.value = refreshedCurrent
                    }
                }
                runCatching {
                    val type = object : TypeToken<List<OfflineQueuedAction>>() {}.type
                    val restored: List<OfflineQueuedAction> = gson.fromJson(initialPrefs.offlineQueueJson, type) ?: emptyList()
                    offlineQueue.value = restored
                    if (restored.any { !it.synced } && isDeviceOnline.value) {
                        syncPendingOfflineQueue()
                    }
                }
                pm.preferencesFlow.collect { prefs ->
                    isDarkMode.value = prefs.isDarkMode
                    autoNightShiftScheduled.value = prefs.autoNightShiftScheduled
                    nightShiftEyeProtection.value = prefs.nightShiftEyeProtection
                    isOutdoorHighContrastMode.value = prefs.isOutdoorHighContrastMode
                    val savedStaff = repository.accounts.value.firstOrNull { it.id == prefs.lastLinkedStaffId }
                    if (savedStaff != null && isPortalBiometricLocked.value) {
                        biometricTargetStaff.value = savedStaff
                    }
                }
            }
        }
        repository.evaluateAndDispatchOperationalAlerts()

        // Auto-flush offline queue when device returns online
        viewModelScope.launch {
            isDeviceOnline.collect { online ->
                if (online && offlineQueue.value.any { !it.synced }) {
                    syncPendingOfflineQueue()
                }
            }
        }

        // Auth-gated Firestore snapshot listeners
        if (firestoreSyncRepository != null) {
            viewModelScope.launch {
                GoogleCloudAuthHelper.observeAuthUser().collect { user ->
                    if (user != null) {
                        cloudUserEmail.value = user.email ?: user.uid
                        cloudUserUid.value = user.uid
                        startCloudListeners(user)
                    } else {
                        stopCloudListeners()
                        cloudUserEmail.value = null
                        cloudUserUid.value = null
                        cloudAdmins.value = emptyList()
                        cloudSyncState.value = CloudSyncState.SignedOut
                    }
                }
            }
        }
    }

    fun canWriteVerifiedCloudActivity(): Boolean {
        val uid = cloudUserUid.value ?: firestoreSyncRepository?.currentUid()
        return cloudUserEmail.value.equals(FirestoreSyncRepository.BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true) ||
            (uid != null && cloudAdmins.value.any { it.id == uid })
    }

    private fun markCloudSynced() {
        val timeLabel = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val totalCount = repository.transactions.value.size +
            repository.customerOrders.value.size +
            repository.activities.value.size +
            repository.shiftAttendanceLogs.value.size +
            repository.burialSchedules.value.size +
            repository.workshopItems.value.size +
            repository.inventoryMaterials.value.size +
            repository.caskets.value.size +
            repository.caseDocuments.value.size +
            repository.branchStatusBoards.value.size +
            repository.leaveRequests.value.size +
            repository.fleetGpsVehicles.value.size +
            repository.companyAssets.value.size
        cloudSyncState.value = CloudSyncState.Synced(timeLabel, totalCount)
    }

    private fun startCloudListeners(user: FirebaseUser) {
        stopCloudListeners()
        val repo = firestoreSyncRepository ?: return
        cloudSyncState.value = CloudSyncState.Syncing

        val coordinatorJob = viewModelScope.launch {
            val isCloudAdmin = repo.checkIsCloudAdmin(user.uid, user.email)
            if (user.email.equals(FirestoreSyncRepository.BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true)) {
                repo.seedAdminCloudRole(
                    uid = user.uid,
                    email = user.email ?: FirestoreSyncRepository.BOOTSTRAP_ADMIN_EMAIL,
                    branch = "All Branches",
                    role = "BOOTSTRAP_ADMIN"
                )
            }

            // Restore cloud preferences (linked staff identity & dark mode) before upserting profile
            val existingProfile = repo.getUserProfile(user.uid).getOrNull()
            var resolvedStaff = _currentAccount.value
            if (existingProfile != null) {
                if (existingProfile.linkedStaffId.isNotBlank()) {
                    val matchedAcc = repository.accounts.value.firstOrNull {
                        it.id.equals(existingProfile.linkedStaffId, ignoreCase = true)
                    }
                    if (matchedAcc != null) {
                        if (isPortalBiometricLocked.value || _currentAccount.value?.id == "CEO-001") {
                            biometricTargetStaff.value = matchedAcc
                            if (isPortalBiometricLocked.value) {
                                _currentAccount.value = matchedAcc
                            }
                            resolvedStaff = matchedAcc
                        }
                        preferencesManager?.setLastLinkedStaffId(matchedAcc.id)
                    }
                }
                if (existingProfile.darkModeEnabled != isDarkMode.value) {
                    isDarkMode.value = existingProfile.darkModeEnabled
                    preferencesManager?.setDarkMode(existingProfile.darkModeEnabled)
                }
            }

            repo.upsertUserProfile(
                displayName = user.displayName ?: resolvedStaff?.fullName ?: "Jabima Staff",
                email = user.email ?: resolvedStaff?.email ?: "",
                linkedStaffId = resolvedStaff?.id ?: "CEO-001",
                linkedBranch = resolvedStaff?.branch ?: "Bama Branch",
                darkModeEnabled = isDarkMode.value
            )

            // Attach snapshot listeners across all 7 synced collections
            val subJobs = mutableListOf<Job>()
            subJobs += launch {
                repo.observeWalletTransactions(isCloudAdmin)
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                        val mapped = FirestoreErrorHandler.mapException(e)
                        cloudSyncState.value = CloudSyncState.Error(mapped.userMessage, mapped.isRetryable)
                    }
                    .collect { cloudList ->
                        val mapped = cloudList.map { f ->
                            WalletTransaction(
                                id = f.id,
                                staffId = f.staffId,
                                type = runCatching { TransactionType.valueOf(f.type) }.getOrDefault(TransactionType.ACTIVITY_ALLOWANCE),
                                title = f.title,
                                referenceNumber = f.referenceNumber,
                                amount = f.amount,
                                date = f.dateLabel,
                                status = runCatching { PaymentStatus.valueOf(f.status) }.getOrDefault(PaymentStatus.DISBURSED),
                                notes = f.notes,
                                payoutMethod = f.payoutMethod.ifBlank { null },
                                payoutDestination = f.payoutDestination.ifBlank { null },
                                timestamp = (f.updatedAt?.seconds ?: System.currentTimeMillis() / 1000L) * 1000L
                            )
                        }
                        repository.mergeCloudTransactions(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeCustomerOrders(isCloudAdmin)
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudOrders ->
                        val mapped = cloudOrders.map { f ->
                            CustomerOrderRecord(
                                orderId = f.orderNumber.ifBlank { f.id },
                                clientName = f.clientName,
                                clientPhone = f.clientPhone,
                                deceasedName = f.deceasedName,
                                selectedPackage = f.selectedPackage,
                                selectedCasket = f.selectedCasket,
                                selectedAddons = emptyList(),
                                totalAmountKes = f.totalAmountKes,
                                totalAmountUsd = f.totalAmountKes / 130.0,
                                paymentMethod = f.paymentMethod,
                                paymentTerms = "Cloud Synced",
                                paymentStatus = f.paymentStatus,
                                referenceCode = f.referenceCode,
                                orderDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
                                branch = f.branch,
                                salesAgentName = f.salesAgentName,
                                commissionEarnedKes = f.commissionEarnedKes
                            )
                        }
                        repository.mergeCloudOrders(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeStaffActivities(isCloudAdmin)
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudActs ->
                        val mapped = cloudActs.map { f ->
                            StaffActivity(
                                id = f.id,
                                staffId = f.staffId,
                                staffName = f.staffName.ifBlank { "Jabima Staff" },
                                department = runCatching { Department.valueOf(f.department) }.getOrDefault(Department.OPERATORS),
                                category = runCatching { ActivityCategory.valueOf(f.category) }.getOrDefault(ActivityCategory.CASE_HANDLING),
                                title = f.title,
                                caseReference = f.caseReference,
                                clientFamily = "Cloud Case Record",
                                location = f.location,
                                date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(
                                    Date((f.updatedAt?.seconds ?: (System.currentTimeMillis() / 1000L)) * 1000L)
                                ),
                                time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(
                                    Date((f.updatedAt?.seconds ?: (System.currentTimeMillis() / 1000L)) * 1000L)
                                ),
                                durationMinutes = 30,
                                status = runCatching { ActivityStatus.valueOf(f.status) }.getOrDefault(ActivityStatus.SCHEDULED),
                                allowanceEarned = f.allowanceEarned,
                                verifiedByAdmin = f.verifiedByAdmin,
                                timestamp = (f.updatedAt?.seconds ?: (System.currentTimeMillis() / 1000L)) * 1000L
                            )
                        }
                        repository.mergeCloudActivities(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeBreakageRecords(isCloudAdmin)
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudBreakages ->
                        val mapped = cloudBreakages.map { f ->
                            val staffDept = repository.accounts.value
                                .firstOrNull { it.id == f.staffId }?.department ?: Department.OPERATORS
                            StaffBreakageRecord(
                                id = f.id,
                                staffId = f.staffId,
                                staffName = f.staffName.ifBlank { "Staff Member" },
                                department = staffDept,
                                itemBroken = f.itemBroken,
                                description = f.description,
                                breakageCostKes = f.breakageCostKes,
                                date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(
                                    Date((f.createdAt?.seconds ?: (System.currentTimeMillis() / 1000L)) * 1000L)
                                ),
                                loggedBy = f.loggedBy.ifBlank { "Cloud Admin" },
                                isDeducted = f.isDeducted
                            )
                        }
                        repository.mergeCloudBreakages(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeShiftAttendanceLogs(isCloudAdmin)
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudAttendance ->
                        val mapped = cloudAttendance.map { f ->
                            ShiftAttendanceRecord(
                                id = f.id,
                                staffId = f.staffId,
                                staffName = f.staffName,
                                roleTitle = f.roleTitle.ifBlank { "Staff Member" },
                                department = runCatching { Department.valueOf(f.department) }.getOrDefault(Department.OPERATORS),
                                branch = f.branch.ifBlank { "Bama Branch" },
                                scannedQrPayload = f.scannedQrPayload,
                                shiftId = f.shiftId.ifBlank { null },
                                shiftWindowLabel = f.shiftWindowLabel.ifBlank { "24/7 Shift Window" },
                                action = runCatching { ShiftAttendanceAction.valueOf(f.action) }.getOrDefault(ShiftAttendanceAction.CHECK_IN),
                                checkpointLocation = f.checkpointLocation.ifBlank { "Main Gate" },
                                verifiedByStaffId = f.verifiedByStaffId,
                                verifiedByName = f.verifiedByName.ifBlank { "Supervisor" },
                                timestampFormatted = f.timestampFormatted.ifBlank { "Synced" },
                                dateFormatted = f.dateFormatted.ifBlank { "Synced" },
                                notes = f.notes,
                                timestampMillis = if (f.timestampMillis > 0L) f.timestampMillis else System.currentTimeMillis()
                            )
                        }
                        repository.mergeCloudShiftAttendance(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeBurialSchedules(isCloudAdmin)
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudSchedules ->
                        val mapped = cloudSchedules.map { f ->
                            BurialScheduleEvent(
                                id = f.id,
                                caseReference = f.caseReference,
                                deceasedName = f.deceasedName,
                                familyRepresentative = f.familyRepresentative,
                                familyPhone = f.familyPhone,
                                burialDate = f.burialDate,
                                casketModel = f.casketModel,
                                churchVenue = f.churchVenue,
                                gravesiteLocation = f.gravesiteLocation,
                                assignedHearseReg = f.assignedHearseReg,
                                assignedDriverName = f.assignedDriverName,
                                assignedOperators = emptyList(),
                                assignedDirector = f.assignedDirector,
                                timings = emptyList(),
                                status = f.status.ifBlank { "Confirmed & Roster Synced" },
                                isRosterSynced = f.rosterSynced,
                                currentMilestone = runCatching {
                                    FamilyCortegeMilestone.valueOf(f.currentMilestone)
                                }.getOrDefault(FamilyCortegeMilestone.PREPARATION_COMPLETE),
                                milestoneUpdatedAt = f.milestoneUpdatedAt.ifBlank { "Cloud Synced" }
                            )
                        }
                        repository.mergeCloudBurialSchedules(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeWorkshopJobs(isCloudAdmin)
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudJobs ->
                        val mapped = cloudJobs.map { f ->
                            val stage = runCatching {
                                WorkshopProductionStage.valueOf(f.currentStage)
                            }.getOrDefault(WorkshopProductionStage.FRAME_AND_ASSEMBLY)
                            val done = stage == WorkshopProductionStage.GLASS_FITTING && f.completionPercentage >= 100
                            WorkshopProductionItem(
                                id = f.id,
                                casketType = f.casketType,
                                currentStage = stage,
                                percentageDone = f.completionPercentage,
                                assignedCraftsmanId = f.assignedCraftsmanId,
                                assignedCraftsmanName = f.assignedCraftsmanName.ifBlank { "Workshop Artisan" },
                                isDoneForDay = done,
                                isCompleted = done,
                                startedDate = "Cloud Synced",
                                targetCompletionDate = "Scheduled",
                                notes = f.notes,
                                sellingPriceKes = f.sellingPriceKes,
                                materialCostKes = f.materialCostKes,
                                laborCostKes = f.laborCostKes,
                                finishingCostKes = f.finishingCostKes
                            )
                        }
                        repository.mergeCloudWorkshopJobs(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeInventoryMaterials()
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudMaterials ->
                        val mapped = cloudMaterials.map { f ->
                            InventoryMaterialItem(
                                id = f.materialId.ifBlank { f.id },
                                name = f.name,
                                categoryId = f.categoryId.ifBlank { "CAT-TIMBER" },
                                categoryName = f.categoryName.ifBlank { "Raw Material" },
                                quantity = f.quantity,
                                unit = f.unit.ifBlank { "Units" },
                                unitCostKes = f.unitCostKes,
                                minThreshold = f.minThreshold,
                                branchWarehouse = f.branchWarehouse.ifBlank { "Bama Branch" },
                                status = f.status.ifBlank { "IN_STOCK" }
                            )
                        }
                        repository.mergeCloudInventoryMaterials(mapped)
                        repository.evaluateAndDispatchOperationalAlerts()
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeCasketCatalog()
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudCaskets ->
                        val mapped = cloudCaskets.map { f ->
                            CasketItem(
                                id = f.casketId.ifBlank { f.id },
                                name = f.name,
                                woodType = f.woodType,
                                finish = f.finish,
                                interiorLining = f.interiorLining,
                                tier = f.tier.ifBlank { "Standard" },
                                priceKes = f.priceKes,
                                priceUsd = f.priceUsd,
                                inStock = f.inStock,
                                stockCount = f.stockCount,
                                features = f.features
                            )
                        }
                        repository.mergeCloudCaskets(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeCaseDocuments()
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudDocs ->
                        val mapped = cloudDocs.map { f ->
                            CaseDocumentRecord(
                                id = f.id,
                                caseReference = f.caseReference,
                                deceasedName = f.deceasedName,
                                documentType = runCatching {
                                    CaseDocumentType.valueOf(f.documentType)
                                }.getOrDefault(CaseDocumentType.BURIAL_PERMIT),
                                title = f.title,
                                notes = f.notes,
                                fileName = f.fileName,
                                mimeType = f.mimeType,
                                thumbnailBase64 = f.thumbnailBase64,
                                uploadedByStaffId = f.uploadedByStaffId,
                                uploadedByStaffName = f.uploadedByStaffName,
                                uploadedAt = f.uploadedAt.ifBlank { "Synced" },
                                verifiedByAdmin = f.verifiedByAdmin,
                                timestampMillis = if (f.timestampMillis > 0L) f.timestampMillis else System.currentTimeMillis()
                            )
                        }
                        repository.mergeCloudCaseDocuments(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeStaffDirectory()
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudStaff ->
                        repository.mergeCloudStaffDirectory(cloudStaff)
                        val refreshed = _currentAccount.value?.id?.let { id ->
                            repository.accounts.value.firstOrNull { it.id == id }
                        }
                        if (refreshed != null) {
                            _currentAccount.value = refreshed
                            if (!refreshed.isActive) {
                                signOut()
                                authErrorMessage.value = "Account ${refreshed.id} was deactivated by Admin."
                            }
                        }
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeBranchBoards()
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudBoards ->
                        val mapped = cloudBoards.map { f ->
                            BranchStatusBoard(
                                branchName = f.branchName.ifBlank { f.id },
                                operationalStatus = f.operationalStatus,
                                activeCasesCount = f.activeCasesCount,
                                coldRoomCapacity = f.coldRoomCapacity,
                                coldRoomOccupancy = f.coldRoomOccupancy,
                                hearseFleetStationed = f.hearseFleetStationed,
                                hearseFleetInTransit = f.hearseFleetInTransit,
                                onDutyStaffCount = f.onDutyStaffCount,
                                todayCortegeDepartures = f.todayCortegeDepartures,
                                pendingStockRequests = f.pendingStockRequests,
                                contactPhone = f.contactPhone,
                                leadSupervisor = f.leadSupervisor,
                                activeAdvisories = f.activeAdvisories
                            )
                        }
                        repository.mergeCloudBranchBoards(mapped)
                        repository.evaluateAndDispatchOperationalAlerts()
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeLeaveRequests(isCloudAdmin)
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudLeaves ->
                        val mapped = cloudLeaves.map { f ->
                            LeaveRequest(
                                id = f.leaveId.ifBlank { f.id },
                                staffId = f.staffId,
                                staffName = f.staffName,
                                department = runCatching { Department.valueOf(f.departmentName) }.getOrDefault(Department.OPERATORS),
                                leaveType = f.leaveType,
                                startDate = f.startDate,
                                endDate = f.endDate,
                                daysCount = f.daysCount,
                                reason = f.reason,
                                status = f.status,
                                approvedBy = f.approvedBy.ifBlank { null }
                            )
                        }
                        repository.mergeCloudLeaveRequests(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeFleetVehicles()
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudFleet ->
                        val mapped = cloudFleet.map { f ->
                            FleetGpsVehicle(
                                registration = f.registration.ifBlank { f.id },
                                model = f.model,
                                driverName = f.driverName,
                                driverPhone = f.driverPhone,
                                latitude = f.latitude,
                                longitude = f.longitude,
                                speedKmh = f.speedKmh,
                                headingDegrees = f.headingDegrees.toFloat(),
                                statusLabel = f.statusLabel,
                                isMoving = f.moving,
                                fuelPercent = f.fuelPercent,
                                engineRunning = f.engineRunning,
                                activeCaseRef = f.activeCaseRef,
                                destination = f.destination,
                                eta = f.eta,
                                currentStreet = f.currentStreet,
                                lastPingSecondsAgo = f.lastPingSecondsAgo
                            )
                        }
                        repository.mergeCloudFleetVehicles(mapped)
                        markCloudSynced()
                    }
            }
            subJobs += launch {
                repo.observeCompanyAssets()
                    .catch { e ->
                        if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                    }
                    .collect { cloudAssets ->
                        val mapped = cloudAssets.map { f ->
                            CompanyAsset(
                                id = f.assetId.ifBlank { f.id },
                                name = f.name,
                                category = f.category,
                                registrationOrTag = f.registrationOrTag,
                                branchAssigned = f.branchAssigned,
                                condition = f.condition,
                                lastInspected = f.lastInspected,
                                custodianStaffName = f.custodianStaffName,
                                qrTagCode = f.qrTagCode.ifBlank { "JFD-AST-${f.assetId}" },
                                custodyStatus = runCatching { CustodyStatus.valueOf(f.custodyStatus) }.getOrDefault(CustodyStatus.IN_DEPOT),
                                checkedOutCaseRef = f.checkedOutCaseRef.ifBlank { null }
                            )
                        }
                        repository.mergeCloudCompanyAssets(mapped)
                        markCloudSynced()
                    }
            }
            if (isCloudAdmin) {
                subJobs += launch {
                    repo.observeCloudAdmins()
                        .catch { e ->
                            if (FirestoreErrorHandler.isCancellationWithoutFirestoreError(e)) throw e
                        }
                        .collect { admins ->
                            cloudAdmins.value = admins
                        }
                }
            }
            cloudSyncJobs = cloudSyncJobs + subJobs
        }
        cloudSyncJobs = listOf(coordinatorJob)
    }

    private fun stopCloudListeners() {
        cloudSyncJobs.forEach { it.cancel() }
        cloudSyncJobs = emptyList()
    }

    fun onCloudSignedIn(user: FirebaseUser) {
        cloudUserEmail.value = user.email ?: user.uid
        cloudUserUid.value = user.uid
        startCloudListeners(user)
        actionFeedbackMessage.value = "Google Cloud Sync connected (${user.email})."
    }

    fun onCloudSignedOut() {
        stopCloudListeners()
        cloudUserEmail.value = null
        cloudUserUid.value = null
        cloudAdmins.value = emptyList()
        cloudSyncState.value = CloudSyncState.SignedOut
        actionFeedbackMessage.value = "Disconnected from Google Cloud Sync. Offline records preserved."
    }

    fun authorizeCloudBranchAdmin(targetUid: String, email: String, branch: String) {
        val repo = firestoreSyncRepository
        val cleanUid = targetUid.trim()
        val cleanEmail = email.trim()
        if (repo == null || cloudUserEmail.value == null) {
            actionFeedbackMessage.value = "Connect Google Cloud Sync as Admin first."
            return
        }
        if (cleanUid.length < 4 || cleanEmail.isBlank()) {
            actionFeedbackMessage.value = "Enter a valid Firebase UID and Google email for the branch admin."
            return
        }
        viewModelScope.launch {
            val res = repo.seedAdminCloudRole(
                uid = cleanUid,
                email = cleanEmail,
                branch = branch.ifBlank { "All Branches" },
                role = "BRANCH_ADMIN"
            )
            res.onSuccess {
                actionFeedbackMessage.value = "Authorized $cleanEmail as multi-device Cloud Branch Admin ($branch)."
            }.onFailure { err ->
                val mapped = FirestoreErrorHandler.mapException(err)
                actionFeedbackMessage.value = "Could not authorize branch admin: ${mapped.userMessage}"
            }
        }
    }

    fun revokeCloudBranchAdmin(targetUid: String) {
        val repo = firestoreSyncRepository ?: return
        if (targetUid == cloudUserUid.value) {
            actionFeedbackMessage.value = "Cannot revoke your currently active admin session."
            return
        }
        viewModelScope.launch {
            val res = repo.revokeAdminCloudRole(targetUid)
            res.onSuccess {
                actionFeedbackMessage.value = "Revoked cloud admin access for UID $targetUid."
            }.onFailure { err ->
                val mapped = FirestoreErrorHandler.mapException(err)
                actionFeedbackMessage.value = "Could not revoke branch admin: ${mapped.userMessage}"
            }
        }
    }

    fun triggerManualCloudSync() {
        val repo = firestoreSyncRepository
        val acc = _currentAccount.value
        if (repo == null || cloudUserEmail.value == null) {
            actionFeedbackMessage.value = "Sign in with Google first to synchronize records to Firestore."
            return
        }
        val allowVerified = canWriteVerifiedCloudActivity()
        cloudSyncState.value = CloudSyncState.Syncing
        viewModelScope.launch {
            var uploadedCount = 0
            repository.transactions.value.take(25).forEach { txn ->
                val staffName = repository.accounts.value.firstOrNull { it.id == txn.staffId }?.fullName ?: "Staff Member"
                if (repo.createWalletTransaction(txn, staffName).isSuccess) uploadedCount++
            }
            repository.customerOrders.value.take(20).forEach { ord ->
                val agentId = repository.accounts.value.firstOrNull { it.fullName.contains(ord.salesAgentName, ignoreCase = true) }?.id ?: ""
                if (repo.createCustomerOrder(ord, agentId).isSuccess) uploadedCount++
            }
            repository.activities.value.take(25).forEach { act ->
                if (repo.createStaffActivity(act, allowVerifiedFlag = allowVerified).isSuccess) uploadedCount++
            }
            repository.breakageRecords.value.take(20).forEach { brk ->
                if (repo.createBreakageRecord(brk).isSuccess) uploadedCount++
            }
            repository.shiftAttendanceLogs.value.take(25).forEach { att ->
                if (repo.createShiftAttendanceRecord(att).isSuccess) uploadedCount++
            }
            repository.burialSchedules.value.take(20).forEach { ev ->
                if (repo.upsertBurialSchedule(ev).isSuccess) uploadedCount++
            }
            repository.workshopItems.value.take(20).forEach { job ->
                if (repo.upsertWorkshopJob(job).isSuccess) uploadedCount++
            }
            repository.caseDocuments.value.take(25).forEach { doc ->
                if (repo.upsertCaseDocument(doc).isSuccess) uploadedCount++
            }
            repository.leaveRequests.value.take(25).forEach { lv ->
                if (repo.createLeaveRequest(lv).isSuccess) uploadedCount++
            }
            if (allowVerified) {
                repository.accounts.value.take(50).forEach { staffAcc ->
                    if (repo.upsertStaffDirectoryEntry(staffAcc).isSuccess) uploadedCount++
                }
                repository.branchStatusBoards.value.take(15).forEach { board ->
                    if (repo.upsertBranchBoard(board, isAdminUser = true).isSuccess) uploadedCount++
                }
                repository.fleetGpsVehicles.value.take(20).forEach { vehicle ->
                    if (repo.upsertFleetVehicle(vehicle, isAdminUser = true).isSuccess) uploadedCount++
                }
                repository.companyAssets.value.take(40).forEach { asset ->
                    if (repo.upsertCompanyAsset(asset, isAdminUser = true).isSuccess) uploadedCount++
                }
                repository.inventoryMaterials.value.take(40).forEach { mat ->
                    if (repo.upsertInventoryMaterial(mat, isAdminUser = true).isSuccess) uploadedCount++
                }
                repository.caskets.value.take(30).forEach { casket ->
                    if (repo.upsertCasketCatalogItem(casket).isSuccess) uploadedCount++
                }
            }
            if (acc != null) {
                repo.upsertUserProfile(
                    displayName = acc.fullName,
                    email = cloudUserEmail.value ?: acc.email,
                    linkedStaffId = acc.id,
                    linkedBranch = acc.branch,
                    darkModeEnabled = isDarkMode.value
                )
            }
            val timeLabel = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            cloudSyncState.value = CloudSyncState.Synced(timeLabel, uploadedCount)
            actionFeedbackMessage.value = "Cloud sync complete: $uploadedCount records verified & synchronized across all branch ledgers."
        }
    }

    fun setMainAppTab(tab: MainAppTab) {
        _mainAppTab.value = tab
    }

    fun setTab(tab: NavTab) {
        _currentTab.value = tab
    }

    private fun syncLinkedProfileToCloud(account: StaffAccount) {
        val repo = firestoreSyncRepository ?: return
        val email = cloudUserEmail.value ?: return
        viewModelScope.launch {
            preferencesManager?.setLastLinkedStaffId(account.id)
            repo.upsertUserProfile(
                displayName = account.fullName,
                email = email,
                linkedStaffId = account.id,
                linkedBranch = account.branch,
                darkModeEnabled = isDarkMode.value
            )
        }
    }

    fun signIn(identifier: String, pass: String): Boolean {
        authErrorMessage.value = null
        val account = repository.authenticate(identifier, pass)
        return when {
            account == null -> {
                authErrorMessage.value = "Invalid Staff ID / Email or Password. Please check credentials."
                false
            }
            !account.isActive -> {
                authErrorMessage.value = "Account ${account.id} (${account.fullName}) is deactivated. Contact Operations Admin or CEO."
                false
            }
            else -> {
                _currentAccount.value = account
                biometricTargetStaff.value = account
                isPortalBiometricLocked.value = false
                _adminImpersonator.value = null
                _currentTab.value = NavTab.OVERVIEW
                _mainAppTab.value = MainAppTab.STAFF_OPERATIONS
                requiresPasswordRotation.value = if (account.mustRotatePassword) account else null
                viewModelScope.launch { preferencesManager?.setLastLinkedStaffId(account.id) }
                syncLinkedProfileToCloud(account)
                true
            }
        }
    }

    fun quickSignIn(account: StaffAccount) {
        if (!account.isActive) {
            authErrorMessage.value = "Account ${account.id} (${account.fullName}) is deactivated by Admin."
            actionFeedbackMessage.value = "Account ${account.fullName} is currently deactivated."
            return
        }
        _currentAccount.value = account
        biometricTargetStaff.value = account
        isPortalBiometricLocked.value = false
        _adminImpersonator.value = null
        _currentTab.value = NavTab.OVERVIEW
        viewModelScope.launch { preferencesManager?.setLastLinkedStaffId(account.id) }
        syncLinkedProfileToCloud(account)
        actionFeedbackMessage.value = "Switched to ${account.fullName} (${account.role.title})"
    }

    fun triggerBiometricAuth(targetStaff: StaffAccount? = null) {
        val candidate = targetStaff ?: _currentAccount.value ?: allAccounts.value.firstOrNull()
        if (candidate != null && !candidate.isActive) {
            authErrorMessage.value = "Account ${candidate.id} (${candidate.fullName}) is deactivated. Biometric entry denied."
            actionFeedbackMessage.value = "Biometric entry blocked: ${candidate.fullName} is deactivated."
            showBiometricDialog.value = false
            return
        }
        biometricTargetStaff.value = candidate
        showBiometricDialog.value = true
    }

    fun dismissBiometricDialog() {
        showBiometricDialog.value = false
    }

    fun onBiometricSuccess() {
        val target = biometricTargetStaff.value ?: allAccounts.value.firstOrNull()
        if (target != null && !target.isActive) {
            authErrorMessage.value = "Account ${target.id} is deactivated. Biometric entry denied."
            actionFeedbackMessage.value = "Biometric entry blocked: ${target.fullName} is deactivated."
            showBiometricDialog.value = false
            return
        }
        if (target != null) {
            _currentAccount.value = target
            _adminImpersonator.value = null
            _currentTab.value = NavTab.OVERVIEW
            _mainAppTab.value = MainAppTab.STAFF_OPERATIONS
            isPortalBiometricLocked.value = false
            syncLinkedProfileToCloud(target)
            actionFeedbackMessage.value = "Biometric authentication verified. Welcome, ${target.fullName}."
        }
        showBiometricDialog.value = false
    }

    fun lockPortalWithBiometrics() {
        isPortalBiometricLocked.value = true
        actionFeedbackMessage.value = "Staff Operations Portal locked with Biometric Protection."
    }

    fun unlockPortalWithBiometrics() {
        isPortalBiometricLocked.value = false
        actionFeedbackMessage.value = "Staff Operations Portal unlocked."
    }

    fun toggleStaffBiometric(enabled: Boolean) {
        val current = _currentAccount.value ?: return
        val updated = current.copy(isBiometricEnabled = enabled)
        _currentAccount.value = updated
        repository.updateAccount(updated)
        actionFeedbackMessage.value = if (enabled) "Biometric login & payment security enabled." else "Biometric verification disabled."
    }

    fun signOut() {
        _currentAccount.value = null
        _adminImpersonator.value = null
        _currentTab.value = NavTab.OVERVIEW
        isPortalBiometricLocked.value = true
    }

    // CEO, Inventory Manager, and Admin access any staff member's independent portal directly
    fun adminAccessStaffAccount(
        targetStaff: StaffAccount,
        initialTab: NavTab = NavTab.OVERVIEW,
        stayOnWalletTab: Boolean = false
    ) {
        val current = _currentAccount.value
        val isAuthorized = current?.role == StaffRole.MANAGING_DIRECTOR_CEO ||
                current?.role == StaffRole.INVENTORY_MANAGER ||
                current?.role == StaffRole.OPERATIONS_ADMIN ||
                _adminImpersonator.value != null
        if (isAuthorized) {
            if (_adminImpersonator.value == null && current != null && current.id != targetStaff.id) {
                _adminImpersonator.value = current
            }
            _currentAccount.value = targetStaff
            biometricTargetStaff.value = targetStaff
            isPortalBiometricLocked.value = false
            _currentTab.value = initialTab
            _mainAppTab.value = if (stayOnWalletTab) MainAppTab.STAFF_WALLET else MainAppTab.STAFF_OPERATIONS
            actionFeedbackMessage.value = "Admin Portal Access: Viewing independent portal of ${targetStaff.fullName} (${targetStaff.role.title})"
        }
    }

    // Return back to main admin account and Admin Console
    fun returnToAdminAccount() {
        _adminImpersonator.value?.let { admin ->
            _currentAccount.value = admin
            biometricTargetStaff.value = admin
            _adminImpersonator.value = null
            _currentTab.value = NavTab.ADMIN_CONSOLE
            _mainAppTab.value = MainAppTab.ADMIN_CONSOLE
            actionFeedbackMessage.value = "Returned to Main Admin Console (${admin.fullName})"
        }
    }

    fun registerStaff(
        fullName: String,
        email: String,
        phone: String,
        role: StaffRole,
        desiredPassword: String,
        nationalId: String,
        branch: String,
        defaultMpesaNumber: String
    ) {
        val newAcc = repository.registerStaff(
            fullName = fullName,
            email = email,
            phone = phone,
            role = role,
            desiredPassword = desiredPassword,
            nationalId = nationalId,
            branch = branch,
            defaultMpesaNumber = defaultMpesaNumber
        )
        _currentAccount.value = newAcc
        biometricTargetStaff.value = newAcc
        isPortalBiometricLocked.value = false
        _currentTab.value = NavTab.OVERVIEW
        syncLinkedProfileToCloud(newAcc)
        actionFeedbackMessage.value = "Welcome to Jabima Funeral, ${newAcc.fullName}! Your Staff ID is ${newAcc.id}"
    }

    private fun persistRotatedHashesToStore() {
        val pm = preferencesManager ?: return
        val rotatedMap = repository.accounts.value
            .filter { !it.mustRotatePassword && it.passwordHash.isNotBlank() }
            .associate { it.id to it.passwordHash }
        viewModelScope.launch {
            pm.saveRotatedPasswordsJson(gson.toJson(rotatedMap))
        }
    }

    fun completeForcedPasswordRotation(newPassword: String): String? {
        val target = requiresPasswordRotation.value ?: _currentAccount.value ?: return "No active staff session."
        if (PasswordSecurityHelper.isDefaultOrWeakPassword(newPassword)) {
            return "Choose a stronger personal password (min 6 characters and not a default factory password)."
        }
        val ok = repository.updatePassword(target.id, newPassword, forceRotateOnNextLogin = false)
        if (!ok) return "Could not update password."
        val updatedAcc = repository.accounts.value.firstOrNull { it.id == target.id }
        if (updatedAcc != null) {
            _currentAccount.value = updatedAcc
            biometricTargetStaff.value = updatedAcc
        }
        requiresPasswordRotation.value = null
        persistRotatedHashesToStore()
        actionFeedbackMessage.value = "Security rotation complete. Your personal password is now hashed and saved."
        return null
    }

    // Staff updating their desired password
    fun updateDesiredPassword(newPassword: String): Boolean {
        val acc = _currentAccount.value ?: return false
        val isWeak = PasswordSecurityHelper.isDefaultOrWeakPassword(newPassword)
        val success = repository.updatePassword(acc.id, newPassword, forceRotateOnNextLogin = isWeak)
        if (success) {
            val refreshed = repository.accounts.value.firstOrNull { it.id == acc.id } ?: acc
            _currentAccount.value = refreshed
            biometricTargetStaff.value = refreshed
            persistRotatedHashesToStore()
            actionFeedbackMessage.value = "Your password hash has been updated securely."
        }
        return success
    }

    // Admin updating/resetting any staff password
    fun adminResetStaffPassword(staffId: String, newPassword: String): Boolean {
        val forceNext = PasswordSecurityHelper.isDefaultOrWeakPassword(newPassword)
        val success = repository.updatePassword(staffId, newPassword, forceRotateOnNextLogin = forceNext)
        if (success) {
            persistRotatedHashesToStore()
            actionFeedbackMessage.value = "Password hash updated for staff ID $staffId."
        }
        return success
    }

    fun logActivity(
        category: ActivityCategory,
        title: String,
        caseReference: String,
        clientFamily: String,
        location: String,
        date: String,
        time: String,
        durationMinutes: Int,
        notes: String,
        allowanceEarned: Double
    ) {
        val acc = _currentAccount.value ?: return
        val created = repository.logActivity(
            staffId = acc.id,
            category = category,
            title = title,
            caseReference = caseReference,
            clientFamily = clientFamily,
            location = location,
            date = date,
            time = time,
            durationMinutes = durationMinutes,
            notes = notes,
            allowanceEarned = allowanceEarned
        )
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.createStaffActivity(created, allowVerifiedFlag = false)
            }
        }
        actionFeedbackMessage.value = "Activity '$title' logged successfully."
    }

    fun updateActivityStatus(activityId: String, status: ActivityStatus, notes: String? = null) {
        val currentAcc = _currentAccount.value
        val activity = repository.activities.value.firstOrNull { it.id == activityId }
        if (activity != null && currentAcc != null) {
            val isManagement = currentAcc.role == StaffRole.OPERATIONS_ADMIN || currentAcc.role == StaffRole.MANAGING_DIRECTOR_CEO
            if (!isManagement && activity.staffId != currentAcc.id) {
                actionFeedbackMessage.value = "Access Denied: '${activity.title}' is assigned to ${activity.staffName} (${activity.department.displayName}). Staff are restricted to their directly assigned duties."
                return
            }
        }
        repository.updateActivityStatus(activityId, status, notes)
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.updateStaffActivityStatus(activityId, status)
            }
        }
        actionFeedbackMessage.value = "Activity status updated to ${status.label}."
    }

    fun recordFuneralArrangementTask(activity: StaffActivity) {
        repository.recordFuneralArrangementTask(activity)
        if (cloudUserEmail.value != null) {
            val allowVerified = canWriteVerifiedCloudActivity()
            viewModelScope.launch {
                firestoreSyncRepository?.createStaffActivity(activity, allowVerifiedFlag = allowVerified)
            }
        }
        actionFeedbackMessage.value = "Funeral task recorded: ${activity.title} (${activity.caseReference})"
    }

    fun toggleChecklistItem(activityId: String, item: String) {
        repository.toggleActivityChecklistItem(activityId, item)
    }

    fun requestPayout(
        amount: Double,
        method: String,
        destination: String,
        notes: String
    ) {
        val acc = _currentAccount.value ?: return
        val created = repository.requestPayout(
            staffId = acc.id,
            amount = amount,
            method = method,
            destination = destination,
            notes = notes
        )
        viewModelScope.launch {
            if (cloudUserEmail.value != null) {
                firestoreSyncRepository?.createWalletTransaction(created, acc.fullName)
            }
        }
        actionFeedbackMessage.value = "Payout request of KES ${String.format("%,.0f", amount)} submitted for Admin approval."
    }

    fun runBatchMonthlyPayroll(periodLabel: String = "October 2026") {
        val exec = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        val result = repository.runBatchMonthlyPayroll(periodLabel, exec)
        viewModelScope.launch {
            if (cloudUserEmail.value != null) {
                result.items.forEach { item ->
                    firestoreSyncRepository?.createWalletTransaction(item.generatedTransaction, item.staffName)
                }
            }
        }
        actionFeedbackMessage.value = if (result.processedCount > 0) {
            "Payroll Run ($periodLabel): ${result.processedCount} staff credited • Total Net KES ${String.format("%,.0f", result.totalNetDisbursedKes)}."
        } else {
            "Payroll Run ($periodLabel): All ${result.skippedDuplicateCount} active staff already processed."
        }
    }

    fun adminApprovePayout(transactionId: String) {
        repository.adminApprovePayout(transactionId)
        val updated = repository.transactions.value.firstOrNull { it.id == transactionId }
        if (cloudUserEmail.value != null && updated != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.adminUpdateTransactionStatus(
                    txnId = transactionId,
                    status = updated.status.name,
                    notes = updated.notes
                )
            }
        }
        actionFeedbackMessage.value = "Payout request approved and marked disbursed."
    }

    fun adminRejectPayout(transactionId: String, reason: String) {
        repository.adminRejectPayout(transactionId, reason)
        val updated = repository.transactions.value.firstOrNull { it.id == transactionId }
        if (cloudUserEmail.value != null && updated != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.adminUpdateTransactionStatus(
                    txnId = transactionId,
                    status = updated.status.name,
                    notes = updated.notes
                )
            }
        }
        actionFeedbackMessage.value = "Payout request rejected: $reason"
    }

    fun adminCreditStaffWallet(
        staffId: String,
        amount: Double,
        title: String,
        type: TransactionType,
        notes: String
    ) {
        val created = repository.adminCreditStaffWallet(staffId, amount, title, type, notes)
        val staffName = repository.accounts.value.firstOrNull { it.id == staffId }?.fullName ?: "Staff Member"
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.createWalletTransaction(created, staffName)
            }
        }
        actionFeedbackMessage.value = "Credited KES ${String.format("%,.0f", amount)} to staff wallet."
    }

    fun submitExpenseClaim(
        category: ExpenseCategory,
        title: String,
        amount: Double,
        caseReference: String,
        receiptNumber: String,
        vehiclePlate: String?,
        notes: String,
        reimbursementMethod: String
    ) {
        val acc = _currentAccount.value ?: return
        repository.submitExpenseClaim(
            staffId = acc.id,
            category = category,
            title = title,
            amount = amount,
            date = "",
            caseReference = caseReference,
            receiptNumber = receiptNumber,
            vehiclePlate = vehiclePlate,
            notes = notes,
            reimbursementMethod = reimbursementMethod
        )
        actionFeedbackMessage.value = "Expense claim #${receiptNumber} of KES ${String.format("%,.0f", amount)} submitted for verification."
    }

    fun approveExpenseClaim(claimId: String) {
        val approver = _currentAccount.value?.fullName ?: "Management & Accounts"
        repository.approveExpenseClaim(claimId, approver)
        actionFeedbackMessage.value = "Expense claim approved and reimbursed to staff wallet!"
    }

    fun rejectExpenseClaim(claimId: String, reason: String) {
        repository.rejectExpenseClaim(claimId, reason)
        actionFeedbackMessage.value = "Expense claim rejected: $reason"
    }

    fun awardPerformanceIncentive(
        staffId: String,
        category: IncentiveCategory,
        title: String,
        amount: Double,
        caseReference: String?,
        awardedBy: String,
        rationale: String
    ) {
        repository.awardPerformanceIncentive(
            staffId = staffId,
            category = category,
            title = title,
            amount = amount,
            caseReference = caseReference,
            awardedBy = awardedBy,
            rationale = rationale
        )
        actionFeedbackMessage.value = "Awarded incentive of KES ${String.format("%,.0f", amount)} (${category.label}) and credited to recipient wallet!"
    }

    fun exportPaymentStatement(period: String = "September 2026") {
        actionFeedbackMessage.value = "Payment Statement for $period exported successfully (PDF/CSV)."
    }

    fun clearFeedback() {
        actionFeedbackMessage.value = null
    }

    // ==========================================
    // CEO & INVENTORY MANAGER AUTHORITY & STOCK MOVEMENT
    // ==========================================
    fun isAuthorizedForAdminChanges(): Boolean {
        val account = _currentAccount.value ?: return false
        return account.role == StaffRole.MANAGING_DIRECTOR_CEO ||
                account.role == StaffRole.INVENTORY_MANAGER ||
                account.role == StaffRole.OPERATIONS_ADMIN ||
                _adminImpersonator.value != null ||
                account.id == "CEO-001" ||
                account.id == "INV-001" ||
                account.fullName.contains("Fredrick Hayoyo", ignoreCase = true) ||
                account.fullName.contains("Silas", ignoreCase = true)
    }

    fun isInventoryManagerAuthorized(): Boolean {
        val account = _currentAccount.value ?: return false
        return account.role == StaffRole.MANAGING_DIRECTOR_CEO ||
                account.role == StaffRole.INVENTORY_MANAGER ||
                account.role == StaffRole.OPERATIONS_ADMIN ||
                account.id == "CEO-001" ||
                account.id == "INV-001" ||
                account.fullName.contains("Silas", ignoreCase = true) ||
                account.fullName.contains("Fredrick Hayoyo", ignoreCase = true) ||
                account.fullName.contains("Brian Adoche", ignoreCase = true) ||
                (account.department == com.example.model.Department.WORKSHOP && account.fullName.contains("Brian", ignoreCase = true))
    }

    fun authorizeStockMovement(recordId: String) {
        val account = _currentAccount.value
        val managerName = if (account != null) "${account.fullName} (Inventory Authority)" else "Silas Hayoyo (Inventory Manager)"
        val isAuth = isInventoryManagerAuthorized()
        val result = repository.authorizeStockMovement(recordId, managerName, isAuth)
        if (result.isSuccess) {
            actionFeedbackMessage.value = "Stock transfer authorized successfully by Inventory Manager (Silas)."
        } else {
            actionFeedbackMessage.value = result.exceptionOrNull()?.message ?: "Authorization failed."
        }
    }

    val showFleetManagerDialog = MutableStateFlow(false)
    val selectedVehicleForEdit = MutableStateFlow<FleetGpsVehicle?>(null)

    fun updateFleetVehicle(
        oldReg: String,
        newReg: String,
        model: String,
        driver: String,
        phone: String,
        dest: String
    ) {
        val res = repository.updateFleetVehicle(oldReg, newReg, model, driver, phone, dest)
        if (res.isSuccess) {
            actionFeedbackMessage.value = "Vehicle $newReg ($model) updated in system by Admin."
            showFleetManagerDialog.value = false
            selectedVehicleForEdit.value = null
        } else {
            actionFeedbackMessage.value = "Failed to update vehicle record."
        }
    }

    fun rejectStockMovement(recordId: String) {
        val account = _currentAccount.value
        val managerName = if (account != null) "${account.fullName} (Inventory Authority)" else "Brian Adoche (Chief Inventory Manager)"
        val isAuth = isInventoryManagerAuthorized()
        val result = repository.rejectStockMovement(recordId, managerName, isAuth)
        if (result.isSuccess) {
            actionFeedbackMessage.value = "Stock transfer rejected by Inventory Manager."
        } else {
            actionFeedbackMessage.value = result.exceptionOrNull()?.message ?: "Action failed."
        }
    }

    fun markStockInTransit(recordId: String) {
        repository.markStockInTransit(recordId)
        actionFeedbackMessage.value = "Stock transfer marked In Transit."
    }

    fun markStockDelivered(recordId: String) {
        repository.markStockDelivered(recordId)
        actionFeedbackMessage.value = "Stock received and marked Delivered."
    }

    fun requestStockMovement(
        itemName: String,
        category: String,
        quantity: Int,
        sourceBranch: String,
        destinationBranch: String,
        assignedVehicle: String,
        assignedDriverName: String,
        urgency: String,
        notes: String
    ) {
        val account = _currentAccount.value
        val staffId = account?.id ?: "STAFF-001"
        val staffName = account?.fullName ?: "Staff Counselor"
        repository.requestStockMovement(
            itemName = itemName,
            category = category,
            quantity = quantity,
            sourceBranch = sourceBranch,
            destinationBranch = destinationBranch,
            staffId = staffId,
            staffName = staffName,
            assignedVehicle = assignedVehicle,
            assignedDriverName = assignedDriverName,
            urgency = urgency,
            notes = notes
        )
        actionFeedbackMessage.value = "Stock movement requested. Awaiting Inventory Manager sole authorization."
    }

    // ==========================================
    // VENDOR MANAGEMENT ACTIONS
    // ==========================================
    fun recordVendorTransaction(
        vendorId: String,
        transactionType: VendorTransactionType,
        amount: Double,
        description: String,
        invoiceNumber: String,
        paymentMethod: String,
        mpesaOrBankRef: String
    ) {
        val account = _currentAccount.value
        val authorizedBy = if (account != null) "${account.fullName} (${account.role.title})" else "Authorized Officer"
        repository.recordVendorTransaction(
            vendorId = vendorId,
            transactionType = transactionType,
            amount = amount,
            description = description,
            invoiceNumber = invoiceNumber,
            paymentMethod = paymentMethod,
            mpesaOrBankRef = mpesaOrBankRef,
            authorizedBy = authorizedBy
        )
        val actionWord = if (transactionType == VendorTransactionType.PAYMENT_SUBMITTED) "Payment submitted to" else "Payment received from"
        actionFeedbackMessage.value = "$actionWord vendor recorded successfully."
    }

    fun updateShiftSchedule(shift: StaffShiftSchedule) {
        repository.updateShiftSchedule(shift)
        actionFeedbackMessage.value = "Shift roster updated for ${shift.staffName}."
    }

    fun addShiftSchedule(shift: StaffShiftSchedule) {
        repository.addShiftSchedule(shift)
        actionFeedbackMessage.value = "New shift scheduled for ${shift.staffName}."
    }

    fun deleteShiftSchedule(shiftId: String) {
        repository.deleteShiftSchedule(shiftId)
        actionFeedbackMessage.value = "Shift removed from roster."
    }

    fun setShiftStatus(shiftId: String, newAvailability: String, newPeriod: ShiftPeriod? = null) {
        repository.setShiftStatus(shiftId, newAvailability, newPeriod)
        actionFeedbackMessage.value = "Shift status updated to '$newAvailability'."
    }

    // ==========================================
    // ADMIN / CEO EDIT VALUES & ROLES OF STAFF
    // ==========================================
    fun adminUpdateStaffRoleAndValues(
        staffId: String,
        fullName: String,
        phone: String,
        email: String,
        role: StaffRole,
        department: Department,
        branch: String,
        nationalId: String,
        assignedVehicle: String?,
        baseSalaryKes: Double,
        allowanceKes: Double,
        commissionRatePercent: Double,
        defaultMpesa: String,
        defaultBank: String,
        isActive: Boolean,
        notes: String
    ) {
        val success = repository.updateStaffDetailsAndRole(
            staffId = staffId,
            fullName = fullName,
            phone = phone,
            email = email,
            role = role,
            department = department,
            branch = branch,
            nationalId = nationalId,
            assignedVehicle = assignedVehicle,
            defaultMpesa = defaultMpesa,
            defaultBank = defaultBank,
            isActive = isActive,
            baseSalaryKes = baseSalaryKes,
            allowanceKes = allowanceKes,
            commissionRatePercent = commissionRatePercent,
            notes = notes
        )
        if (success) {
            val updatedAcc = repository.accounts.value.firstOrNull { it.id == staffId }
            if (updatedAcc != null && cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
                viewModelScope.launch {
                    firestoreSyncRepository?.upsertStaffDirectoryEntry(updatedAcc)
                }
            }
            actionFeedbackMessage.value = "Staff credentials, role (${role.title}), and compensation values updated successfully."
            if (_currentAccount.value?.id == staffId) {
                _currentAccount.value = updatedAcc
            }
        }
    }

    // ==========================================
    // ADMIN / CEO PRICE MANAGEMENT
    // ==========================================
    fun updateCasketPrice(
        casketId: String,
        newPriceKes: Double,
        newPriceUsd: Double? = null,
        newStockCount: Int? = null,
        inStock: Boolean? = null,
        notes: String = ""
    ) {
        val adminName = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        repository.updateCasketPriceAndStock(
            casketId = casketId,
            newPriceKes = newPriceKes,
            newPriceUsd = newPriceUsd,
            newStockCount = newStockCount,
            inStock = inStock,
            updatedBy = adminName,
            notes = notes
        )
        val updated = repository.caskets.value.firstOrNull { it.id == casketId }
        if (updated != null && cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch {
                firestoreSyncRepository?.upsertCasketCatalogItem(updated)
            }
        }
        actionFeedbackMessage.value = "Casket price updated to KES ${String.format("%,.0f", newPriceKes)}."
    }

    fun updateSalesServicePrice(
        serviceId: String,
        newPriceKes: Double,
        notes: String = ""
    ) {
        val adminName = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        repository.updateSalesServicePrice(
            serviceId = serviceId,
            newPriceKes = newPriceKes,
            updatedBy = adminName,
            notes = notes
        )
        actionFeedbackMessage.value = "Service tariff updated to KES ${String.format("%,.0f", newPriceKes)}."
    }

    // ==========================================
    // ADMIN / CEO STOCK ITEM UPLOAD MODULE
    // ==========================================
    fun uploadStockItem(
        name: String,
        category: StockCategory,
        sku: String,
        description: String,
        quantity: Int,
        reorderThreshold: Int,
        costPriceKes: Double,
        sellingPriceKes: Double,
        branchWarehouse: String,
        supplierName: String,
        invoiceOrBatchNumber: String
    ) {
        val adminName = _currentAccount.value?.let { "${it.fullName} (${it.role.title})" } ?: "Fredrick Hayoyo (CEO)"
        val today = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        val newItem = StockUploadItem(
            id = "STK-UPL-" + java.util.UUID.randomUUID().toString().take(6).uppercase(),
            name = name.trim(),
            category = category,
            sku = sku.trim().ifBlank { "SKU-" + (1000..9999).random() },
            description = description.trim(),
            quantity = quantity,
            reorderThreshold = reorderThreshold,
            costPriceKes = costPriceKes,
            sellingPriceKes = sellingPriceKes,
            branchWarehouse = branchWarehouse.trim(),
            supplierName = supplierName.trim().ifBlank { "Direct Consignment" },
            invoiceOrBatchNumber = invoiceOrBatchNumber.trim().ifBlank { "BATCH-" + (100..999).random() },
            dateUploaded = today,
            uploadedByStaffName = adminName
        )
        repository.uploadStockItem(newItem)
        actionFeedbackMessage.value = "Stock item '$name' ($quantity units) successfully uploaded & inventoried."
    }

    fun uploadStockBatchPreset(presetName: String) {
        val adminName = _currentAccount.value?.let { "${it.fullName} (${it.role.title})" } ?: "Fredrick Hayoyo (CEO)"
        val today = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        val batchItems = when (presetName) {
            "CASKETS_WORKSHOP_BATCH" -> listOf(
                StockUploadItem(
                    id = "STK-" + (1000..9999).random(),
                    name = "Imperial Double-Lid Cedar Casket",
                    category = StockCategory.CASKET,
                    sku = "CSK-CEDAR-10",
                    description = "Aromatic Highland Cedar with Hand-Carved Corner Pillars & Velvet Crepe",
                    quantity = 6,
                    costPriceKes = 85000.0,
                    sellingPriceKes = 145000.0,
                    branchWarehouse = "Bama Branch",
                    supplierName = "Bama Central Carpentry Guild",
                    invoiceOrBatchNumber = "LOT-BAMA-SEP26",
                    dateUploaded = today,
                    uploadedByStaffName = adminName
                ),
                StockUploadItem(
                    id = "STK-" + (1000..9999).random(),
                    name = "Presidential Gloss Walnut Heritage",
                    category = StockCategory.CASKET,
                    sku = "CSK-WALNUT-11",
                    description = "Luxury American Walnut, High Gloss Polish, Heavy Chrome Swing Bar Handles",
                    quantity = 4,
                    costPriceKes = 110000.0,
                    sellingPriceKes = 195000.0,
                    branchWarehouse = "Siaya Referral (Opposite Morgue)",
                    supplierName = "Bama Central Carpentry Guild",
                    invoiceOrBatchNumber = "LOT-BAMA-SEP26",
                    dateUploaded = today,
                    uploadedByStaffName = adminName
                )
            )
            "MORTUARY_PPE_BATCH" -> listOf(
                StockUploadItem(
                    id = "STK-" + (1000..9999).random(),
                    name = "Cavity Chemical Treatment Fluid (24 x 1L)",
                    category = StockCategory.MORTUARY_CHEMICALS,
                    sku = "CHM-CAV-24",
                    description = "Ultra-penetrating deep tissue preservation cavity fluid",
                    quantity = 24,
                    costPriceKes = 3800.0,
                    sellingPriceKes = 6200.0,
                    branchWarehouse = "Siaya Referral (Opposite Morgue)",
                    supplierName = "MedTech Mortuary Supplies",
                    invoiceOrBatchNumber = "INV-MT-8841",
                    dateUploaded = today,
                    uploadedByStaffName = adminName
                ),
                StockUploadItem(
                    id = "STK-" + (1000..9999).random(),
                    name = "Heavy-Duty Vinyl Body Shrouds & Pouches",
                    category = StockCategory.MORTUARY_CHEMICALS,
                    sku = "MOR-SHR-50",
                    description = "Reinforced leakproof curved zipper disaster & transit pouches",
                    quantity = 50,
                    costPriceKes = 1200.0,
                    sellingPriceKes = 2500.0,
                    branchWarehouse = "Bama Branch",
                    supplierName = "MedTech Mortuary Supplies",
                    invoiceOrBatchNumber = "INV-MT-8841",
                    dateUploaded = today,
                    uploadedByStaffName = adminName
                )
            )
            else -> listOf(
                StockUploadItem(
                    id = "STK-" + (1000..9999).random(),
                    name = "Vigil LED Sound & PA Wireless Microphone Kit",
                    category = StockCategory.CHAPEL_VIGIL,
                    sku = "VGL-MIC-02",
                    description = "Dual VHF wireless microphone set with rechargeable receiver for home vigils",
                    quantity = 5,
                    costPriceKes = 8500.0,
                    sellingPriceKes = 14000.0,
                    branchWarehouse = "Siaya opposite Shell Petrol",
                    supplierName = "ProAudio Systems Kisumu",
                    invoiceOrBatchNumber = "INV-PA-772",
                    dateUploaded = today,
                    uploadedByStaffName = adminName
                )
            )
        }
        repository.batchUploadStockItems(batchItems)
        actionFeedbackMessage.value = "Preset batch '${presetName}' (${batchItems.size} items) uploaded to inventory."
    }

    fun batchUploadStockItems(items: List<StockUploadItem>) {
        repository.batchUploadStockItems(items)
        actionFeedbackMessage.value = "Imported ${items.size} stock items from Microsoft Excel into warehouse inventory."
    }

    fun openExcelImportHub(dataset: com.example.model.ExcelDatasetType = com.example.model.ExcelDatasetType.INVENTORY_STOCK) {
        selectedExcelImportDataset.value = dataset
        showUniversalExcelImportDialog.value = true
    }

    fun batchImportBurialSchedules(events: List<com.example.model.BurialScheduleEvent>) {
        events.forEach { repository.addBurialSchedule(it) }
        actionFeedbackMessage.value = "Imported ${events.size} burial schedule cases from Microsoft Excel."
    }

    fun batchImportCustomerOrders(orders: List<com.example.model.CustomerOrderRecord>) {
        orders.forEach { repository.addOrReplaceCustomerOrder(it) }
        actionFeedbackMessage.value = "Imported ${orders.size} customer orders from Microsoft Excel."
    }

    fun batchImportStaffAccounts(accounts: List<com.example.model.StaffAccount>) {
        accounts.forEach { repository.addOrReplaceStaffAccount(it) }
        actionFeedbackMessage.value = "Imported ${accounts.size} staff member accounts from Microsoft Excel."
    }

    fun batchImportFleetVehicles(vehicles: List<com.example.model.FleetGpsVehicle>) {
        vehicles.forEach { repository.addOrReplaceFleetVehicle(it) }
        actionFeedbackMessage.value = "Imported ${vehicles.size} fleet vehicles from Microsoft Excel."
    }

    fun batchImportWorkshopJobs(jobs: List<com.example.model.WorkshopProductionItem>) {
        jobs.forEach { repository.addOrReplaceWorkshopItem(it) }
        actionFeedbackMessage.value = "Imported ${jobs.size} workshop production jobs from Microsoft Excel."
    }

    fun openExportManifestDialog() {
        showExportManifestDialog.value = true
    }

    fun openSpotlightSearch() {
        showSpotlightSearchDialog.value = true
    }

    fun toggleOutdoorHighContrastMode() {
        val next = !isOutdoorHighContrastMode.value
        isOutdoorHighContrastMode.value = next
        viewModelScope.launch { preferencesManager?.setOutdoorHighContrastMode(next) }
        actionFeedbackMessage.value = if (next) {
            "☀️ Outdoor Sunlight / Night Vigil High-Contrast Mode Enabled"
        } else {
            "🌙 Standard Executive Portal Mode Active"
        }
    }

    fun setDarkMode(enabled: Boolean) {
        isDarkMode.value = enabled
        viewModelScope.launch {
            preferencesManager?.setDarkMode(enabled)
            if (cloudUserEmail.value != null) {
                firestoreSyncRepository?.updateCloudDarkModePreference(enabled)
            }
        }
        actionFeedbackMessage.value = if (enabled) {
            "🌙 24/7 Operations Dark Mode Activated — Blue Light & Screen Glare Reduced"
        } else {
            "☀️ Daytime Natural Mode Restored"
        }
    }

    fun toggleDarkMode() {
        setDarkMode(!isDarkMode.value)
    }

    fun setAutoNightShiftScheduled(enabled: Boolean) {
        autoNightShiftScheduled.value = enabled
        viewModelScope.launch { preferencesManager?.setAutoNightShiftScheduled(enabled) }
        if (enabled) {
            val currentHour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            val isNightTime = currentHour >= 18 || currentHour < 6
            isDarkMode.value = isNightTime
            viewModelScope.launch { preferencesManager?.setDarkMode(isNightTime) }
            actionFeedbackMessage.value = if (isNightTime) {
                "🕒 24/7 Auto Schedule: Night Shift Detected (6PM - 6AM) — Dark Mode Activated"
            } else {
                "🕒 24/7 Auto Schedule: Day Shift Active — Auto Dark Mode will engage at 6:00 PM"
            }
        } else {
            actionFeedbackMessage.value = "🕒 Auto Night-Shift Schedule Disabled"
        }
    }

    fun setNightShiftEyeProtection(enabled: Boolean) {
        nightShiftEyeProtection.value = enabled
        viewModelScope.launch { preferencesManager?.setNightShiftEyeProtection(enabled) }
        actionFeedbackMessage.value = if (enabled) {
            "👁️ Anti-Glare & Circadian Eye Fatigue Filter Active"
        } else {
            "👁️ Standard Contrast Profile Restored"
        }
    }

    fun deleteUploadedStockItem(itemId: String) {
        repository.deleteUploadedStockItem(itemId)
        actionFeedbackMessage.value = "Stock item deleted from catalog."
    }

    // ==========================================
    // ENTERPRISE PLATFORM INTEGRATIONS (ZOHO ONE, FRESHSALES, ZURI, HUBSPOT)
    // ==========================================
    fun triggerPlatformSync(platform: IntegrationPlatform) {
        val log = repository.triggerPlatformSync(platform)
        actionFeedbackMessage.value = "${platform.displayName} synchronized: ${log.recordSummary}"
    }

    fun syncAllIntegrationPlatforms() {
        IntegrationPlatform.entries.forEach { platform ->
            repository.triggerPlatformSync(platform)
        }
        actionFeedbackMessage.value = "All 4 Enterprise Platforms (Zoho One, Freshsales, Zuri Platform, HubSpot) synchronized successfully."
    }

    fun updatePlatformConfig(
        platform: IntegrationPlatform,
        isEnabled: Boolean,
        apiEndpoint: String,
        organizationId: String,
        autoSyncInterval: Int = 15
    ) {
        repository.updatePlatformConfig(platform, isEnabled, apiEndpoint, organizationId, autoSyncInterval)
        actionFeedbackMessage.value = "${platform.displayName} connection parameters saved."
    }

    // ==========================================
    // WORKSHOP PRODUCTION & STAGES
    // ==========================================
    fun updateWorkshopStage(
        itemId: String,
        nextStage: WorkshopProductionStage,
        percentage: Int,
        stageCostAddKes: Double = 0.0
    ) {
        val by = _currentAccount.value?.fullName ?: "Workshop Lead"
        val bomNote = repository.updateWorkshopStage(itemId, nextStage, percentage, stageCostAddKes, by)
        val updated = repository.workshopItems.value.firstOrNull { it.id == itemId }
        if (cloudUserEmail.value != null && updated != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.upsertWorkshopJob(updated)
            }
        }
        val suffix = if (nextStage == WorkshopProductionStage.GLASS_FITTING && percentage >= 100) {
            " • Synced to Finished Store"
        } else ""
        actionFeedbackMessage.value = "Workshop $itemId -> ${nextStage.title} ($percentage%) • $bomNote$suffix"
    }

    fun addWorkshopProductionStageCost(itemId: String, laborAddKes: Double, finishingAddKes: Double) {
        repository.addWorkshopProductionStageCost(itemId, laborAddKes, finishingAddKes)
        actionFeedbackMessage.value = "Production stage cost logged for $itemId."
    }

    fun allocateMaterialToWorkshopJob(jobId: String, materialId: String, quantity: Int): Boolean {
        val by = _currentAccount.value?.fullName ?: "Workshop Lead"
        val ok = repository.allocateMaterialToWorkshopJob(jobId, materialId, quantity, by)
        actionFeedbackMessage.value = if (ok) {
            "Allocated $quantity units from Raw Material Store to workshop job $jobId."
        } else {
            "Insufficient raw material stock for allocation."
        }
        return ok
    }

    fun completeWorkshopJobToStore(itemId: String) {
        if (repository.completeWorkshopJobToStore(itemId)) {
            val updated = repository.workshopItems.value.firstOrNull { it.id == itemId }
            if (cloudUserEmail.value != null && updated != null) {
                viewModelScope.launch {
                    firestoreSyncRepository?.upsertWorkshopJob(updated)
                }
            }
            actionFeedbackMessage.value = "Job $itemId completed, inventoried into Store & synced to Casket Sales."
        }
    }

    fun assignCraftsmanToWorkshopItem(itemId: String, craftsmanId: String, craftsmanName: String) {
        repository.assignCraftsmanToWorkshopItem(itemId, craftsmanId, craftsmanName)
        actionFeedbackMessage.value = "Assigned craftsman $craftsmanName to production job $itemId (Alert sent)"
    }

    fun markWorkshopItemDoneForDay(itemId: String, isDone: Boolean) {
        repository.markWorkshopItemDoneForDay(itemId, isDone)
        actionFeedbackMessage.value = if (isDone) "Marked job $itemId as Done for the day." else "Job $itemId kept in production."
    }

    fun createWorkshopItem(
        casketType: String,
        craftsmanId: String,
        craftsmanName: String,
        initialStage: WorkshopProductionStage = WorkshopProductionStage.FRAME_AND_ASSEMBLY,
        notes: String = "",
        sellingPriceKes: Double = 95000.0,
        materialCostKes: Double = 25000.0,
        laborCostKes: Double = 8000.0,
        finishingCostKes: Double = 4000.0
    ) {
        repository.createWorkshopItem(
            casketType = casketType,
            craftsmanId = craftsmanId,
            craftsmanName = craftsmanName,
            initialStage = initialStage,
            notes = notes,
            sellingPriceKes = sellingPriceKes,
            materialCostKes = materialCostKes,
            laborCostKes = laborCostKes,
            finishingCostKes = finishingCostKes
        )
        val created = repository.workshopItems.value.firstOrNull()
        if (cloudUserEmail.value != null && created != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.upsertWorkshopJob(created)
            }
        }
        actionFeedbackMessage.value = "New production job created: $casketType assigned to $craftsmanName"
    }

    fun openOrderWithCasketGuide(casketModelName: String) {
        val matched = caskets.value.firstOrNull {
            it.name.contains(casketModelName, ignoreCase = true) ||
                casketModelName.contains(it.name, ignoreCase = true)
        }
        preSelectedOrderCasketName.value = matched?.name ?: casketModelName
        _mainAppTab.value = MainAppTab.ORDERS_PAYMENTS
        actionFeedbackMessage.value = "Loaded Order Price Guide for $casketModelName."
    }

    fun startWorkshopJobFromCosting(
        model: CasketProductionCostModel,
        sellingPriceOverrideKes: Double? = null
    ) {
        val craft = allAccounts.value.firstOrNull {
            it.department == com.example.model.Department.WORKSHOP ||
                it.role.name.contains("WORKSHOP") ||
                it.role.name.contains("ARTISAN")
        } ?: allAccounts.value.first()

        val finishAndPaintCost = model.finishingMaterialCostKes + model.paintAndAbrasivesCostKes
        val targetSell = sellingPriceOverrideKes ?: model.recommendedOrderPriceKes
        createWorkshopItem(
            casketType = model.matchedBranchCasketTypes.firstOrNull() ?: model.modelName,
            craftsmanId = craft.id,
            craftsmanName = craft.fullName,
            initialStage = WorkshopProductionStage.FRAME_AND_ASSEMBLY,
            notes = "PDF BOM Spec: ${model.modelName} (${model.sizeSpec}). Direct Mat KES ${model.directMaterialCostKes.toLong()}, Crew: ${model.matchedWorkshopTeam}.",
            sellingPriceKes = targetSell,
            materialCostKes = model.baseBodyMaterialCostKes,
            laborCostKes = model.crewLaborCostKes,
            finishingCostKes = finishAndPaintCost
        )
        _mainAppTab.value = MainAppTab.WORKSHOP_PRODUCTION
    }

    fun createCustomProductionCasketType(
        name: String,
        woodType: String,
        tier: String,
        finish: String,
        interiorLining: String,
        sellingPriceKes: Double,
        materialCostKes: Double,
        laborCostKes: Double,
        finishingCostKes: Double,
        craftsmanId: String,
        craftsmanName: String,
        branch: String = "Bama Branch",
        notes: String = ""
    ) {
        val job = repository.createCustomProductionCasketType(
            name = name,
            woodType = woodType,
            tier = tier,
            finish = finish,
            interiorLining = interiorLining,
            sellingPriceKes = sellingPriceKes,
            materialCostKes = materialCostKes,
            laborCostKes = laborCostKes,
            finishingCostKes = finishingCostKes,
            craftsmanId = craftsmanId,
            craftsmanName = craftsmanName,
            branch = branch,
            notes = notes
        )
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.upsertWorkshopJob(job)
            }
        }
        val eval = PayrollRulesEngine.evaluateBomMargin(sellingPriceKes, materialCostKes, laborCostKes, finishingCostKes)
        if (eval.status != MarginStatus.HEALTHY && eval.warningMessage != null) {
            repository.raiseMarginGuardAlert(name, eval.warningMessage, job.id)
            actionFeedbackMessage.value = "Custom casket '$name' queued (${eval.status.label}: ${eval.marginPercent}% margin — Admin Alert raised)."
        } else {
            actionFeedbackMessage.value = "Custom casket '$name' (KES ${String.format("%,.0f", sellingPriceKes)} • ${eval.marginPercent}% margin) queued in Production & Catalog."
        }
    }

    // ==========================================
    // INVENTORY MANAGEMENT (ADMIN & CEO GATED ACTIONS)
    // ==========================================
    fun addMaterialCategory(category: MaterialCategory) {
        repository.addMaterialCategory(category)
        actionFeedbackMessage.value = "Category '${category.name}' added successfully."
    }

    fun updateMaterialCategory(category: MaterialCategory) {
        repository.updateMaterialCategory(category)
        actionFeedbackMessage.value = "Category '${category.name}' updated."
    }

    fun addProductItem(product: ProductItem) {
        repository.addProductItem(product)
        actionFeedbackMessage.value = "Product '${product.name}' added to inventory catalog."
    }

    fun purchaseRawMaterial(
        materialId: String?,
        name: String,
        categoryId: String,
        quantity: Int,
        unit: String,
        unitCostKes: Double,
        minThreshold: Int,
        branch: String
    ) {
        val by = _currentAccount.value?.fullName ?: "Procurement Officer"
        val item = repository.purchaseRawMaterial(materialId, name, categoryId, quantity, unit, unitCostKes, minThreshold, branch, by)
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.upsertInventoryMaterial(item, isAdminUser = canWriteVerifiedCloudActivity())
            }
        }
        actionFeedbackMessage.value = "Purchased $quantity $unit of '$name' into Central Store."
    }

    fun adjustInventoryMaterialQuantity(materialId: String, delta: Int) {
        val updated = repository.adjustInventoryMaterialQuantity(materialId, delta)
        if (updated != null) {
            val newAlerts = repository.evaluateAndDispatchOperationalAlerts()
            if (cloudUserEmail.value != null) {
                viewModelScope.launch {
                    firestoreSyncRepository?.adjustInventoryStockLevel(updated.id, updated.quantity, updated.status)
                }
            }
            val actionLabel = if (delta >= 0) "+$delta" else "$delta"
            actionFeedbackMessage.value = "${updated.name}: adjusted $actionLabel ${updated.unit} (Now ${updated.quantity} ${updated.unit})." +
                if (newAlerts > 0) " Urgent Low-Stock alert sent to Admin." else ""
        }
    }

    fun applyStoreItemUpgradeDowngrade(
        storeCategory: String,
        itemId: String,
        itemName: String,
        isUpgrade: Boolean,
        quantity: Int,
        costDeltaPerUnitKes: Double,
        reason: String
    ) {
        val by = _currentAccount.value?.fullName ?: "Admin"
        val rec = repository.applyStoreItemUpgradeDowngrade(
            storeCategory = storeCategory,
            itemId = itemId,
            itemName = itemName,
            isUpgrade = isUpgrade,
            quantity = quantity,
            costDeltaPerUnitKes = costDeltaPerUnitKes,
            reason = reason,
            processedBy = by
        )
        actionFeedbackMessage.value = "${rec.actionType} recorded for ${rec.itemName}: Delta KES ${String.format("%,.0f", rec.totalCostDeltaKes)}."
    }

    // ==========================================
    // DAILY REPORTS
    // ==========================================
    fun submitDailyReport(report: StaffDailyReport) {
        repository.submitDailyReport(report)
        actionFeedbackMessage.value = "Daily report submitted successfully for ${report.staffName}."
    }

    fun sendNudgeReminderToStaff(staffAccount: StaffAccount) {
        actionFeedbackMessage.value = "Daily report reminder SMS sent to ${staffAccount.fullName} (${staffAccount.phone})."
    }

    // ==========================================
    // DYNAMIC BURIAL SCHEDULING & ROSTER SYNC
    // ==========================================
    fun addBurialSchedule(event: BurialScheduleEvent) {
        repository.addBurialSchedule(event)
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.upsertBurialSchedule(event)
            }
        }
        actionFeedbackMessage.value = "Burial service scheduled for ${event.deceasedName} and synced with duty roster."
    }

    fun sendBurialServiceReminder(
        burialScheduleId: String,
        timingStage: FuneralArrangementStage,
        customMessage: String = ""
    ) {
        val log = repository.sendBurialServiceReminder(burialScheduleId, timingStage, customMessage)
        actionFeedbackMessage.value = "Service reminder SMS dispatched to ${log.recipients.size} assigned staff members."
    }

    // ==========================================
    // ADMIN MASTER DATA MANAGEMENT (ADD, EDIT, REPLACE, DELETE)
    // ==========================================
    fun deleteStaffAccount(staffId: String): Boolean {
        val success = repository.deleteStaffAccount(staffId)
        if (success) {
            if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
                viewModelScope.launch {
                    firestoreSyncRepository?.deleteStaffDirectoryEntry(staffId)
                }
            }
            actionFeedbackMessage.value = "Staff account $staffId deleted successfully."
        } else {
            actionFeedbackMessage.value = "Primary CEO account cannot be deleted."
        }
        return success
    }

    fun addOrReplaceStaffAccount(account: StaffAccount) {
        repository.addOrReplaceStaffAccount(account)
        val savedAcc = repository.accounts.value.firstOrNull { it.id == account.id } ?: account
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch {
                firestoreSyncRepository?.upsertStaffDirectoryEntry(savedAcc)
            }
        }
        actionFeedbackMessage.value = "Staff account '${account.fullName}' (${account.id}) saved."
    }

    fun deleteCasketItem(casketId: String) {
        repository.deleteCasketItem(casketId)
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch { firestoreSyncRepository?.deleteCasketCatalogItem(casketId) }
        }
        actionFeedbackMessage.value = "Casket model $casketId deleted from catalog and inventory."
    }

    fun addOrReplaceCasketItem(item: com.example.model.CasketItem) {
        repository.addOrReplaceCasketItem(item)
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch { firestoreSyncRepository?.upsertCasketCatalogItem(item) }
        }
        actionFeedbackMessage.value = "Casket model '${item.name}' saved."
    }

    fun deleteInventoryMaterial(materialId: String) {
        repository.deleteInventoryMaterial(materialId)
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch { firestoreSyncRepository?.deleteInventoryMaterialCloud(materialId) }
        }
        actionFeedbackMessage.value = "Inventory material $materialId deleted."
    }

    fun addOrReplaceInventoryMaterial(item: InventoryMaterialItem) {
        repository.addOrReplaceInventoryMaterial(item)
        repository.evaluateAndDispatchOperationalAlerts()
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.upsertInventoryMaterial(item, isAdminUser = canWriteVerifiedCloudActivity())
            }
        }
        actionFeedbackMessage.value = "Material item '${item.name}' saved."
    }

    // ==========================================
    // CASE PAPERWORK & PERMIT CLOUD VAULT
    // ==========================================
    fun uploadCaseDocument(
        caseReference: String,
        deceasedName: String,
        documentType: CaseDocumentType,
        title: String,
        notes: String,
        fileName: String,
        mimeType: String,
        thumbnailBase64: String
    ) {
        val uploader = _currentAccount.value
        val nowStr = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date()) + " EAT"
        val doc = CaseDocumentRecord(
            id = "DOC-" + (1000 + repository.caseDocuments.value.size + (1..99).random()),
            caseReference = caseReference.trim().ifBlank { "GENERAL-CASE" },
            deceasedName = deceasedName.trim().ifBlank { "Family Case File" },
            documentType = documentType,
            title = title.trim().ifBlank { documentType.label },
            notes = notes.trim(),
            fileName = fileName.trim(),
            mimeType = mimeType.trim().ifBlank { "image/jpeg" },
            thumbnailBase64 = thumbnailBase64,
            uploadedByStaffId = uploader?.id ?: "STAFF",
            uploadedByStaffName = uploader?.fullName ?: "Jabima Staff",
            uploadedAt = nowStr,
            verifiedByAdmin = canWriteVerifiedCloudActivity(),
            timestampMillis = System.currentTimeMillis()
        )
        repository.addOrReplaceCaseDocument(doc)
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.upsertCaseDocument(doc)
            }
        }
        actionFeedbackMessage.value = "Case document '${doc.title}' saved to Vault${if (cloudUserEmail.value != null) " & Cloud Synced" else ""}."
    }

    fun verifyCaseDocument(docId: String, verified: Boolean = true) {
        repository.verifyCaseDocument(docId, verified)
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch {
                firestoreSyncRepository?.adminVerifyCaseDocument(docId, verified)
            }
        }
        actionFeedbackMessage.value = if (verified) "Case permit/document $docId marked Verified." else "Verification removed for $docId."
    }

    fun deleteCaseDocument(docId: String) {
        repository.deleteCaseDocument(docId)
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch {
                firestoreSyncRepository?.deleteCaseDocument(docId)
            }
        }
        actionFeedbackMessage.value = "Case document $docId removed from vault."
    }

    fun deleteWorkshopItem(itemId: String) {
        repository.deleteWorkshopItem(itemId)
        actionFeedbackMessage.value = "Workshop production item $itemId deleted."
    }

    fun addOrReplaceWorkshopItem(item: WorkshopProductionItem) {
        repository.addOrReplaceWorkshopItem(item)
        actionFeedbackMessage.value = "Workshop job '${item.casketType}' saved."
    }

    fun deleteActivity(activityId: String) {
        repository.deleteActivity(activityId)
        actionFeedbackMessage.value = "Activity record $activityId deleted."
    }

    fun addOrReplaceActivity(activity: StaffActivity) {
        repository.addOrReplaceActivity(activity)
        actionFeedbackMessage.value = "Activity record '${activity.title}' saved."
    }

    fun deleteFleetVehicle(registration: String) {
        repository.deleteFleetVehicle(registration)
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch { firestoreSyncRepository?.deleteFleetVehicle(registration) }
        }
        actionFeedbackMessage.value = "Fleet vehicle $registration deleted."
    }

    fun addOrReplaceFleetVehicle(vehicle: com.example.model.FleetGpsVehicle) {
        repository.addOrReplaceFleetVehicle(vehicle)
        if (cloudUserEmail.value != null) {
            val isAdminUser = canWriteVerifiedCloudActivity()
            viewModelScope.launch { firestoreSyncRepository?.upsertFleetVehicle(vehicle, isAdminUser = isAdminUser) }
        }
        actionFeedbackMessage.value = "Fleet vehicle ${vehicle.registration} saved."
    }

    fun deleteCustomerOrder(orderId: String) {
        repository.deleteCustomerOrder(orderId)
        actionFeedbackMessage.value = "Customer order $orderId deleted."
    }

    fun addOrReplaceCustomerOrder(order: com.example.model.CustomerOrderRecord) {
        repository.addOrReplaceCustomerOrder(order)
        actionFeedbackMessage.value = "Customer order ${order.orderId} saved."
    }

    fun deleteBranchStatusBoard(branchName: String) {
        repository.deleteBranchStatusBoard(branchName)
        if (cloudUserEmail.value != null && canWriteVerifiedCloudActivity()) {
            viewModelScope.launch { firestoreSyncRepository?.deleteBranchBoard(branchName) }
        }
        actionFeedbackMessage.value = "Branch board $branchName deleted."
    }

    fun addOrReplaceBranchStatusBoard(board: com.example.model.BranchStatusBoard) {
        repository.addOrReplaceBranchStatusBoard(board)
        repository.evaluateAndDispatchOperationalAlerts()
        if (cloudUserEmail.value != null) {
            val isAdminUser = canWriteVerifiedCloudActivity()
            viewModelScope.launch { firestoreSyncRepository?.upsertBranchBoard(board, isAdminUser = isAdminUser) }
        }
        actionFeedbackMessage.value = "Branch status board '${board.branchName}' saved."
    }

    // ==========================================
    // PACKAGES, ADD-ONS, ALERTS, TASK PRICING, BREAKAGES & OPERATOR WAGES
    // ==========================================
    fun updateOrderPackagePrice(packageId: String, newPriceKes: Double) {
        val adminName = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        repository.updateOrderPackagePrice(packageId, newPriceKes, adminName)
        actionFeedbackMessage.value = "Package price updated to KES ${String.format("%,.0f", newPriceKes)}."
    }

    fun updateOrderAddonPrice(addonId: String, newPriceKes: Double) {
        val adminName = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        repository.updateOrderAddonPrice(addonId, newPriceKes, adminName)
        actionFeedbackMessage.value = "Add-on price updated to KES ${String.format("%,.0f", newPriceKes)}."
    }

    fun markStaffAlertRead(alertId: String) {
        repository.acknowledgeShiftAlert(alertId)
    }

    fun openShiftAlertCenter(staffId: String? = null, shiftId: String? = null) {
        prefilledAlertStaffId.value = staffId
        prefilledAlertShiftId.value = shiftId
        showShiftAlertCenterDialog.value = true
    }

    fun closeShiftAlertCenter() {
        showShiftAlertCenterDialog.value = false
        prefilledAlertStaffId.value = null
        prefilledAlertShiftId.value = null
    }

    fun dispatchShiftAlert(
        recipientStaffId: String,
        title: String,
        message: String,
        priority: TaskPriority = TaskPriority.HIGH,
        shiftId: String? = null,
        scheduledTimeLabel: String? = null,
        branch: String? = null,
        relatedEntityId: String? = null,
        sendSmsAlso: Boolean = true
    ) {
        val staff = repository.accounts.value.firstOrNull { it.id == recipientStaffId }
        val staffName = staff?.fullName ?: "Assigned Crew"
        val alert = repository.dispatchShiftAlert(
            recipientStaffId = recipientStaffId,
            recipientName = staffName,
            title = title.trim(),
            message = message.trim(),
            priority = priority,
            shiftId = shiftId,
            scheduledTimeLabel = scheduledTimeLabel,
            branch = branch ?: staff?.branch,
            relatedEntityId = relatedEntityId,
            smsDispatched = sendSmsAlso
        )
        if (sendSmsAlso && staff != null) {
            repository.sendBulkSms(
                recipientType = "Shift Alert (${priority.label})",
                recipients = "${staff.fullName} (${staff.phone})",
                body = "${alert.title}: ${alert.message}",
                senderId = "JABIMA_OPS",
                units = 1
            )
            viewModelScope.launch {
                externalServiceBridge.dispatchBulkSms(
                    staff.phone,
                    "[JABIMA SHIFT ALERT] ${alert.title} - ${alert.message}",
                    "JABIMA_OPS"
                )
            }
        }
        actionFeedbackMessage.value = "Shift Alert sent to $staffName (${priority.label})${if (sendSmsAlso) " + SMS queued" else ""}."
    }

    fun dispatchShiftAlertForTask(activity: StaffActivity, sendSmsAlso: Boolean = true) {
        dispatchShiftAlert(
            recipientStaffId = activity.staffId,
            title = "Task Readiness Alert (${activity.time}): ${activity.title}",
            message = "${activity.status.label} • ${activity.caseReference} (${activity.clientFamily}) at ${activity.location}.",
            priority = activity.priority,
            shiftId = "TASK-${activity.id}",
            scheduledTimeLabel = activity.time,
            branch = activity.location,
            relatedEntityId = activity.id,
            sendSmsAlso = sendSmsAlso
        )
    }

    fun triggerDueShiftAlertsScan(targetDate: String = "23 Sep 2026"): Int {
        val count = repository.scanAndTriggerDueShiftAlerts(targetDate)
        actionFeedbackMessage.value = if (count > 0) {
            "Shift Alert Engine generated $count due shift & task readiness alert(s)."
        } else {
            "All scheduled shifts and active tasks for $targetDate already have active alerts."
        }
        return count
    }

    fun acknowledgeShiftAlert(alertId: String) {
        repository.acknowledgeShiftAlert(alertId)
        actionFeedbackMessage.value = "Shift alert acknowledged."
    }

    fun markAllShiftAlertsRead() {
        repository.markAllShiftAlertsRead()
        actionFeedbackMessage.value = "All shift & operational alerts marked as acknowledged."
    }

    fun dismissShiftAlert(alertId: String) {
        repository.dismissShiftAlert(alertId)
    }

    fun autoAssignAndAlertTask(
        category: ActivityCategory,
        title: String,
        caseReference: String,
        clientFamily: String,
        location: String,
        priority: TaskPriority,
        paymentPriceKes: Double,
        notes: String
    ) {
        val (act, staff) = repository.autoAssignAndAlertTask(
            category, title, caseReference, clientFamily, location, priority, paymentPriceKes, notes
        )
        if (cloudUserEmail.value != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.createStaffActivity(act, allowVerifiedFlag = false)
            }
        }
        actionFeedbackMessage.value = "Auto-assigned '${act.title}' to ${staff.fullName} (${staff.role.title}) • Pay KES ${String.format("%,.0f", paymentPriceKes)}. Alert sent!"
    }

    fun adminAssessAndPriceActivity(
        activityId: String,
        paymentPriceKes: Double,
        approveAndCredit: Boolean,
        assessmentNotes: String
    ) {
        val adminName = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        repository.adminAssessAndPriceActivity(activityId, paymentPriceKes, approveAndCredit, assessmentNotes, adminName)
        if (cloudUserEmail.value != null) {
            val updatedAct = repository.activities.value.firstOrNull { it.id == activityId }
            val newTxn = repository.transactions.value.firstOrNull { it.referenceNumber == "ASSESS-$activityId" }
            viewModelScope.launch {
                if (updatedAct != null) {
                    firestoreSyncRepository?.adminVerifyAndPriceActivity(
                        activityId = activityId,
                        allowanceEarned = paymentPriceKes,
                        status = updatedAct.status
                    )
                }
                if (newTxn != null) {
                    val staffName = repository.accounts.value.firstOrNull { it.id == newTxn.staffId }?.fullName ?: "Staff Member"
                    firestoreSyncRepository?.createWalletTransaction(newTxn, staffName)
                }
            }
        }
        actionFeedbackMessage.value = "Task payment priced at KES ${String.format("%,.0f", paymentPriceKes)}${if (approveAndCredit) " & credited to wallet" else ""}."
    }

    fun recordAndDeductBreakage(
        staffId: String,
        itemBroken: String,
        description: String,
        costKes: Double,
        deductImmediately: Boolean
    ) {
        val adminName = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        val rec = repository.recordAndDeductBreakage(staffId, itemBroken, description, costKes, deductImmediately, adminName)
        if (cloudUserEmail.value != null) {
            val brkTxn = rec.walletTransactionId?.let { txId ->
                repository.transactions.value.firstOrNull { it.id == txId }
            }
            viewModelScope.launch {
                firestoreSyncRepository?.createBreakageRecord(rec)
                if (brkTxn != null) {
                    firestoreSyncRepository?.createWalletTransaction(brkTxn, rec.staffName)
                }
            }
        }
        actionFeedbackMessage.value = if (deductImmediately) {
            "Breakage deduction of KES ${String.format("%,.0f", rec.breakageCostKes)} executed on ${rec.staffName}'s wallet."
        } else {
            "Breakage logged for ${rec.staffName} (Pending deduction)."
        }
    }

    fun executePendingBreakageDeduction(breakageId: String) {
        val adminName = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        if (repository.executePendingBreakageDeduction(breakageId, adminName)) {
            if (cloudUserEmail.value != null) {
                val updated = repository.breakageRecords.value.firstOrNull { it.id == breakageId }
                val brkTxn = updated?.walletTransactionId?.let { txId ->
                    repository.transactions.value.firstOrNull { it.id == txId }
                }
                viewModelScope.launch {
                    firestoreSyncRepository?.adminMarkBreakageDeducted(breakageId)
                    if (brkTxn != null && updated != null) {
                        firestoreSyncRepository?.createWalletTransaction(brkTxn, updated.staffName)
                    }
                }
            }
            actionFeedbackMessage.value = "Breakage cost deducted from staff wallet & alert dispatched."
        }
    }

    fun allocateOperatorTransportAndWage(
        staffId: String,
        transportFeeKes: Double,
        dailyWageKes: Double,
        dutyAssignment: String,
        disburseNow: Boolean
    ) {
        val adminName = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        val rec = repository.allocateOperatorTransportAndWage(
            staffId, transportFeeKes, dailyWageKes, dutyAssignment, disburseNow, adminName
        )
        if (_currentAccount.value?.id == staffId) {
            _currentAccount.value = repository.accounts.value.firstOrNull { it.id == staffId }
        }
        actionFeedbackMessage.value = "Allocated Transport KES ${String.format("%,.0f", rec.transportFeeKes)} + Daily Wage KES ${String.format("%,.0f", rec.dailyWageKes)} to ${rec.staffName}."
    }

    fun disburseOperatorWageAllocation(allocationId: String) {
        val adminName = _currentAccount.value?.fullName ?: "Fredrick Hayoyo (CEO)"
        if (repository.disburseOperatorWageAllocation(allocationId, adminName)) {
            actionFeedbackMessage.value = "Operator transport & daily wage disbursed to wallet."
        }
    }

    fun getWalletSummaryForStaff(staffId: String): StaffWalletSummary = repository.getWalletSummary(staffId)

    // ==========================================
    // 6 NEW OPERATIONAL WORKFLOWS (CUSTODY, MILESTONES, MARGIN GUARD, HANDOVER, STATUTORY, OFFLINE QUEUE)
    // ==========================================
    fun toggleStatutoryPayslipMode(enabled: Boolean) {
        applyStatutoryOnPayslip.value = enabled
        actionFeedbackMessage.value = if (enabled) {
            "Kenyan Statutory Deductions (PAYE, NSSF, SHIF & AHL) enabled on Payslip."
        } else {
            "Switched Payslip to Gross / Contract view."
        }
    }

    fun raiseCustomMarginAlertIfNeeded(
        casketName: String,
        sellingPriceKes: Double,
        materialCostKes: Double,
        laborCostKes: Double = 8000.0,
        finishingCostKes: Double = 4000.0
    ) {
        val eval = PayrollRulesEngine.evaluateBomMargin(
            sellingPriceKes = sellingPriceKes,
            materialCostKes = materialCostKes,
            laborCostKes = laborCostKes,
            finishingCostKes = finishingCostKes
        )
        if (eval.status != MarginStatus.HEALTHY && eval.warningMessage != null) {
            repository.raiseMarginGuardAlert(casketName, eval.warningMessage, null)
        }
    }

    private fun enqueueOfflineAction(
        type: OfflineActionType,
        title: String,
        summary: String,
        payloadObj: Any
    ) {
        val staffName = _currentAccount.value?.fullName ?: "Field Operator"
        val nowStr = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date())
        val queued = OfflineQueuedAction(
            id = "OFF-" + (1000..9999).random(),
            actionType = type,
            title = title,
            summary = summary,
            payloadJson = gson.toJson(payloadObj),
            createdAtLabel = nowStr,
            staffName = staffName,
            synced = false
        )
        val updated = listOf(queued) + offlineQueue.value
        offlineQueue.value = updated
        persistOfflineQueue(updated)
    }

    private fun persistOfflineQueue(list: List<OfflineQueuedAction>) {
        preferencesManager?.let { pm ->
            viewModelScope.launch {
                pm.saveOfflineQueueJson(gson.toJson(list))
            }
        }
    }

    fun toggleSimulatedOfflineMode() {
        val next = !simulatedOfflineOverride.value
        simulatedOfflineOverride.value = next
        actionFeedbackMessage.value = if (next) {
            "Rural Field Offline Mode enabled — actions will queue locally for sync."
        } else {
            "Connectivity restored — checking pending rural field queue."
        }
        if (!next && offlineQueue.value.any { !it.synced }) {
            syncPendingOfflineQueue()
        }
    }

    fun logRuralFieldCheckIn(locationLabel: String, notes: String) {
        val acc = _currentAccount.value
        val staffId = acc?.id ?: "OPR-001"
        val staffName = acc?.fullName ?: "Field Crew"
        val payload = mapOf("staffId" to staffId, "staffName" to staffName, "location" to locationLabel, "notes" to notes)

        if (!isDeviceOnline.value) {
            enqueueOfflineAction(
                type = OfflineActionType.FIELD_CHECKIN,
                title = "Rural Check-In: $locationLabel",
                summary = "$staffName • $notes",
                payloadObj = payload
            )
            actionFeedbackMessage.value = "Queued offline: Rural check-in at $locationLabel."
        } else {
            val created = repository.logActivity(
                staffId = staffId,
                category = ActivityCategory.GRAVESITE_SETUP,
                title = "Field Site Check-In: $locationLabel",
                caseReference = "FIELD-SYNC",
                clientFamily = "Rural Burial Operations",
                location = locationLabel,
                date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
                time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                durationMinutes = 30,
                notes = notes,
                allowanceEarned = 0.0
            )
            if (cloudUserEmail.value != null) {
                viewModelScope.launch {
                    firestoreSyncRepository?.createStaffActivity(created, allowVerifiedFlag = false)
                }
            }
            actionFeedbackMessage.value = "Field check-in synced for $locationLabel."
        }
    }

    fun scanAssetCustody(
        qrOrTag: String,
        actionCheckOut: Boolean,
        caseReference: String,
        isDamagedOrMissing: Boolean,
        conditionNotes: String,
        breakageCostKes: Double = 2500.0
    ) {
        val staff = _currentAccount.value
        val staffId = staff?.id ?: "OPR-001"
        val staffName = staff?.fullName ?: "Grounds Operator"

        if (!isDeviceOnline.value) {
            enqueueOfflineAction(
                type = OfflineActionType.CUSTODY_SCAN,
                title = "QR Custody: $qrOrTag (${if (actionCheckOut) "OUT" else "IN"})",
                summary = "Case $caseReference • ${if (isDamagedOrMissing) "Damaged/Missing Flag" else "OK"}",
                payloadObj = mapOf(
                    "qrOrTag" to qrOrTag,
                    "actionCheckOut" to actionCheckOut,
                    "caseReference" to caseReference,
                    "staffId" to staffId,
                    "staffName" to staffName,
                    "isDamagedOrMissing" to isDamagedOrMissing,
                    "conditionNotes" to conditionNotes,
                    "breakageCostKes" to breakageCostKes
                )
            )
            actionFeedbackMessage.value = "Queued offline: QR scan $qrOrTag stored locally until signal returns."
            return
        }

        val log = repository.scanAssetCustody(
            qrOrTag = qrOrTag,
            actionCheckOut = actionCheckOut,
            caseReference = caseReference,
            staffId = staffId,
            staffName = staffName,
            isDamagedOrMissing = isDamagedOrMissing,
            conditionNotes = conditionNotes,
            breakageCostKes = breakageCostKes
        )
        if (cloudUserEmail.value != null) {
            val matchedAsset = log?.let { entry ->
                repository.companyAssets.value.firstOrNull { it.id == entry.assetId }
            }
            val isAdminUser = canWriteVerifiedCloudActivity()
            viewModelScope.launch {
                if (matchedAsset != null) {
                    firestoreSyncRepository?.upsertCompanyAsset(matchedAsset, isAdminUser = isAdminUser)
                }
                if (log?.breakageRecordId != null) {
                    val brk = repository.breakageRecords.value.firstOrNull { it.id == log.breakageRecordId }
                    val brkTxn = brk?.walletTransactionId?.let { txId ->
                        repository.transactions.value.firstOrNull { it.id == txId }
                    }
                    if (brk != null) firestoreSyncRepository?.createBreakageRecord(brk)
                    if (brkTxn != null && brk != null) {
                        firestoreSyncRepository?.createWalletTransaction(brkTxn, brk.staffName)
                    }
                }
            }
        }
        actionFeedbackMessage.value = if (log?.breakageRecordId != null) {
            "⚠️ ${log.assetName} flagged ${log.custodyStatus.label} — Breakage #${log.breakageRecordId} deducted!"
        } else {
            "✅ QR Custody updated: ${log?.assetName ?: qrOrTag} -> ${log?.custodyStatus?.label}"
        }
    }

    fun updateCortegeMilestone(
        burialScheduleId: String,
        milestone: FamilyCortegeMilestone,
        notifyFamilySms: Boolean = false
    ) {
        if (!isDeviceOnline.value) {
            enqueueOfflineAction(
                type = OfflineActionType.CORTEGE_MILESTONE,
                title = "Cortege Milestone: ${milestone.label}",
                summary = "Schedule $burialScheduleId • Family SMS=$notifyFamilySms",
                payloadObj = mapOf(
                    "burialScheduleId" to burialScheduleId,
                    "milestone" to milestone.name,
                    "notifyFamilySms" to notifyFamilySms
                )
            )
            actionFeedbackMessage.value = "Queued offline: Milestone '${milestone.label}' will dispatch on signal."
            return
        }

        val updated = repository.advanceCortegeMilestone(burialScheduleId, milestone)
        if (cloudUserEmail.value != null && updated != null) {
            viewModelScope.launch {
                firestoreSyncRepository?.updateBurialMilestone(
                    scheduleId = updated.id,
                    milestone = milestone,
                    updatedAtLabel = updated.milestoneUpdatedAt,
                    status = updated.status
                )
            }
        }
        if (updated != null && notifyFamilySms) {
            val smsBody = "Jabima Funeral Update (${updated.caseReference} - ${updated.deceasedName}): Stage '${milestone.label}'. ${milestone.familySmsNotice} Hotline: +254793553434."
            sendBulkSms(
                recipientType = "Client Family",
                recipients = updated.familyPhone,
                body = smsBody
            )
        } else {
            actionFeedbackMessage.value = "Cortege milestone updated to '${milestone.label}' for ${updated?.deceasedName ?: burialScheduleId}."
        }
    }

    fun submitShiftHandover(handover: ShiftVehicleHandover) {
        if (!isDeviceOnline.value) {
            enqueueOfflineAction(
                type = OfflineActionType.SHIFT_HANDOVER,
                title = "Biometric Handover: ${handover.vehicleReg}",
                summary = "${handover.outgoingStaffName} -> ${handover.incomingStaffName} (${handover.fuelPercent}% fuel)",
                payloadObj = handover
            )
            actionFeedbackMessage.value = "Queued offline: Biometric shift handover for ${handover.vehicleReg}."
            return
        }
        repository.recordShiftHandover(handover)
        actionFeedbackMessage.value = "✅ Biometric shift handover signed & logged for ${handover.vehicleReg}."
    }

    fun canCurrentUserVerifyShiftAttendance(): Boolean {
        val activeActor = _adminImpersonator.value ?: _currentAccount.value
        return StaffQrIdentityCodec.canVerifyShiftAttendance(activeActor?.role)
    }

    fun verifyStaffShiftAttendanceByQr(
        scannedCode: String,
        action: ShiftAttendanceAction,
        checkpointLocation: String,
        shiftId: String? = null,
        shiftWindowLabel: String = StaffQrIdentityCodec.resolve24HourShiftWindow(
            java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        ),
        notes: String = ""
    ): Result<ShiftAttendanceRecord> {
        val verifier = _adminImpersonator.value ?: _currentAccount.value
        if (verifier == null || !StaffQrIdentityCodec.canVerifyShiftAttendance(verifier.role)) {
            val msg = "Only managers or shift supervisors can scan & verify staff shift attendance."
            actionFeedbackMessage.value = msg
            return Result.failure(SecurityException(msg))
        }

        val parseResult = StaffQrIdentityCodec.parseScannedStaffCode(scannedCode, allAccounts.value)
        if (parseResult is StaffQrParseResult.NotFound) {
            actionFeedbackMessage.value = parseResult.reason
            return Result.failure(IllegalArgumentException(parseResult.reason))
        }

        val matched = parseResult as StaffQrParseResult.Matched
        val staff = matched.staff
        val normalizedCheckpoint = checkpointLocation.ifBlank { "${staff.branch} 24/7 Desk" }

        if (!isDeviceOnline.value) {
            enqueueOfflineAction(
                type = OfflineActionType.SHIFT_ATTENDANCE,
                title = "${action.label}: ${staff.fullName} (${staff.id})",
                summary = "$shiftWindowLabel • $normalizedCheckpoint • By ${verifier.fullName}",
                payloadObj = mapOf(
                    "staffId" to staff.id,
                    "scannedQrPayload" to matched.encodedPayload,
                    "action" to action.name,
                    "checkpointLocation" to normalizedCheckpoint,
                    "shiftId" to (shiftId ?: ""),
                    "shiftWindowLabel" to shiftWindowLabel,
                    "verifiedByStaffId" to verifier.id,
                    "verifiedByName" to verifier.fullName,
                    "notes" to notes
                )
            )
            actionFeedbackMessage.value = "Queued offline: ${action.label} for ${staff.fullName} will sync when signal returns."
            return Result.success(
                ShiftAttendanceRecord(
                    id = "ATT-QUEUED",
                    staffId = staff.id,
                    staffName = staff.fullName,
                    roleTitle = staff.role.title,
                    department = staff.department,
                    branch = staff.branch,
                    scannedQrPayload = matched.encodedPayload,
                    shiftId = shiftId,
                    shiftWindowLabel = shiftWindowLabel,
                    action = action,
                    checkpointLocation = normalizedCheckpoint,
                    verifiedByStaffId = verifier.id,
                    verifiedByName = verifier.fullName,
                    timestampFormatted = "Queued Offline",
                    dateFormatted = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
                    notes = notes
                )
            )
        }

        val record = repository.verifyStaffShiftAttendance(
            staff = staff,
            scannedQrPayload = matched.encodedPayload,
            action = action,
            checkpointLocation = normalizedCheckpoint,
            shiftId = shiftId,
            shiftWindowLabel = shiftWindowLabel,
            verifiedByStaffId = verifier.id,
            verifiedByName = verifier.fullName,
            notes = notes
        )
        if (cloudUserEmail.value != null) {
            val autoAct = repository.activities.value.firstOrNull { it.caseReference == record.id }
            val allowVerified = canWriteVerifiedCloudActivity()
            viewModelScope.launch {
                firestoreSyncRepository?.createShiftAttendanceRecord(record)
                if (autoAct != null) {
                    firestoreSyncRepository?.createStaffActivity(autoAct, allowVerifiedFlag = allowVerified)
                }
            }
        }
        actionFeedbackMessage.value = "✅ ${action.label} verified for ${staff.fullName} (${staff.id}) • $shiftWindowLabel"
        return Result.success(record)
    }

    fun syncPendingOfflineQueue() {
        val pending = offlineQueue.value.filter { !it.synced }
        if (pending.isEmpty()) {
            actionFeedbackMessage.value = "All rural field actions are already synced."
            return
        }
        if (!isDeviceOnline.value) {
            actionFeedbackMessage.value = "Device still offline — ${pending.size} actions remain safely queued."
            return
        }
        val isCloudConnected = cloudUserEmail.value != null
        val allowVerified = canWriteVerifiedCloudActivity()
        viewModelScope.launch {
            isSyncingOfflineQueue.value = true
            var flushed = 0
            pending.reversed().forEach { item ->
                runCatching {
                    when (item.actionType) {
                        OfflineActionType.CUSTODY_SCAN -> {
                            val mapType = object : TypeToken<Map<String, Any>>() {}.type
                            val m: Map<String, Any> = gson.fromJson(item.payloadJson, mapType)
                            val log = repository.scanAssetCustody(
                                qrOrTag = m["qrOrTag"]?.toString() ?: "",
                                actionCheckOut = (m["actionCheckOut"] as? Boolean) ?: false,
                                caseReference = m["caseReference"]?.toString() ?: "OFFLINE",
                                staffId = m["staffId"]?.toString() ?: "OPR-001",
                                staffName = m["staffName"]?.toString() ?: item.staffName,
                                isDamagedOrMissing = (m["isDamagedOrMissing"] as? Boolean) ?: false,
                                conditionNotes = m["conditionNotes"]?.toString() ?: "Synced from offline queue",
                                breakageCostKes = (m["breakageCostKes"] as? Number)?.toDouble() ?: 2500.0
                            )
                            if (isCloudConnected && log?.breakageRecordId != null) {
                                val brk = repository.breakageRecords.value.firstOrNull { it.id == log.breakageRecordId }
                                if (brk != null) firestoreSyncRepository?.createBreakageRecord(brk)
                            }
                        }
                        OfflineActionType.CORTEGE_MILESTONE -> {
                            val mapType = object : TypeToken<Map<String, Any>>() {}.type
                            val m: Map<String, Any> = gson.fromJson(item.payloadJson, mapType)
                            val ms = runCatching {
                                FamilyCortegeMilestone.valueOf(m["milestone"]?.toString() ?: "")
                            }.getOrDefault(FamilyCortegeMilestone.HEARSE_DISPATCHED)
                            val ev = repository.advanceCortegeMilestone(m["burialScheduleId"]?.toString() ?: "", ms)
                            if (isCloudConnected && ev != null) {
                                firestoreSyncRepository?.updateBurialMilestone(
                                    scheduleId = ev.id,
                                    milestone = ms,
                                    updatedAtLabel = ev.milestoneUpdatedAt,
                                    status = ev.status
                                )
                            }
                            val sendSms = (m["notifyFamilySms"] as? Boolean) ?: false
                            if (ev != null && sendSms) {
                                externalServiceBridge.dispatchBulkSms(
                                    recipients = ev.familyPhone,
                                    message = "Jabima Update (${ev.deceasedName}): ${ms.label}. ${ms.familySmsNotice}",
                                    senderId = "JABIMA"
                                )
                            }
                        }
                        OfflineActionType.SHIFT_HANDOVER -> {
                            val handover = gson.fromJson(item.payloadJson, ShiftVehicleHandover::class.java)
                            repository.recordShiftHandover(handover)
                        }
                        OfflineActionType.FIELD_CHECKIN -> {
                            val mapType = object : TypeToken<Map<String, Any>>() {}.type
                            val m: Map<String, Any> = gson.fromJson(item.payloadJson, mapType)
                            val created = repository.logActivity(
                                staffId = m["staffId"]?.toString() ?: "OPR-001",
                                category = ActivityCategory.GRAVESITE_SETUP,
                                title = item.title,
                                caseReference = "RURAL-SYNC",
                                clientFamily = "Rural Burial Site",
                                location = m["location"]?.toString() ?: "Rural Site",
                                date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
                                time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                                durationMinutes = 30,
                                notes = m["notes"]?.toString() ?: item.summary,
                                allowanceEarned = 0.0
                            )
                            if (isCloudConnected) {
                                firestoreSyncRepository?.createStaffActivity(created, allowVerifiedFlag = false)
                            }
                        }
                        OfflineActionType.SHIFT_ATTENDANCE -> {
                            val mapType = object : TypeToken<Map<String, Any>>() {}.type
                            val m: Map<String, Any> = gson.fromJson(item.payloadJson, mapType)
                            val staffId = m["staffId"]?.toString() ?: ""
                            val staff = allAccounts.value.firstOrNull { it.id.equals(staffId, ignoreCase = true) }
                            if (staff != null) {
                                val parsedAction = runCatching {
                                    ShiftAttendanceAction.valueOf(m["action"]?.toString() ?: "")
                                }.getOrDefault(ShiftAttendanceAction.CHECK_IN)
                                val record = repository.verifyStaffShiftAttendance(
                                    staff = staff,
                                    scannedQrPayload = m["scannedQrPayload"]?.toString()
                                        ?: StaffQrIdentityCodec.encodeStaffQrPayload(staff),
                                    action = parsedAction,
                                    checkpointLocation = m["checkpointLocation"]?.toString() ?: "${staff.branch} Checkpoint",
                                    shiftId = m["shiftId"]?.toString()?.takeIf { it.isNotBlank() },
                                    shiftWindowLabel = m["shiftWindowLabel"]?.toString() ?: "24/7 Shift Window",
                                    verifiedByStaffId = m["verifiedByStaffId"]?.toString() ?: "CEO-001",
                                    verifiedByName = m["verifiedByName"]?.toString() ?: item.staffName,
                                    notes = m["notes"]?.toString() ?: "Synced offline QR shift scan"
                                )
                                if (isCloudConnected) {
                                    firestoreSyncRepository?.createShiftAttendanceRecord(record)
                                    val autoAct = repository.activities.value.firstOrNull { it.caseReference == record.id }
                                    if (autoAct != null) {
                                        firestoreSyncRepository?.createStaffActivity(autoAct, allowVerifiedFlag = allowVerified)
                                    }
                                }
                            }
                        }
                        OfflineActionType.CASH_PAYMENT -> Unit
                        OfflineActionType.LEAVE_REQUEST -> {
                            val req = gson.fromJson(item.payloadJson, LeaveRequest::class.java)
                            repository.submitLeaveRequest(req)
                            if (isCloudConnected) {
                                firestoreSyncRepository?.createLeaveRequest(req)
                            }
                        }
                    }
                    flushed++
                }
            }
            offlineQueue.value = emptyList()
            persistOfflineQueue(emptyList())
            isSyncingOfflineQueue.value = false
            actionFeedbackMessage.value = "☁️ Synced $flushed offline field action(s) to operations ledger."
        }
    }
}
