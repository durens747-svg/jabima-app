package com.example.data.firebase

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class FirestoreUserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val linkedStaffId: String = "",
    val linkedBranch: String = "",
    val darkModeEnabled: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreAdminEntry(
    @DocumentId val id: String = "",
    val email: String = "",
    val role: String = "BRANCH_ADMIN",
    val branch: String = "All Branches",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreWalletTransaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val staffId: String = "",
    val staffName: String = "",
    val type: String = "",
    val title: String = "",
    val referenceNumber: String = "",
    val amount: Double = 0.0,
    val dateLabel: String = "",
    val status: String = "DISBURSED",
    val notes: String = "",
    val payoutMethod: String = "",
    val payoutDestination: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreCustomerOrder(
    @DocumentId val id: String = "",
    val userId: String = "",
    val orderNumber: String = "",
    val clientName: String = "",
    val clientPhone: String = "",
    val deceasedName: String = "",
    val selectedPackage: String = "",
    val selectedCasket: String = "",
    val totalAmountKes: Double = 0.0,
    val paymentMethod: String = "M-PESA",
    val paymentStatus: String = "CONFIRMED_PAID",
    val referenceCode: String = "",
    val branch: String = "",
    val salesAgentId: String = "",
    val salesAgentName: String = "",
    val commissionEarnedKes: Double = 0.0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreStaffActivity(
    @DocumentId val id: String = "",
    val userId: String = "",
    val staffId: String = "",
    val staffName: String = "",
    val department: String = "",
    val category: String = "",
    val title: String = "",
    val caseReference: String = "",
    val location: String = "",
    val status: String = "SCHEDULED",
    val allowanceEarned: Double = 0.0,
    val verifiedByAdmin: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreBreakageRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val staffId: String = "",
    val staffName: String = "",
    val itemBroken: String = "",
    val description: String = "",
    val breakageCostKes: Double = 0.0,
    @get:PropertyName("isDeducted")
    @set:PropertyName("isDeducted")
    var isDeducted: Boolean = false,
    val loggedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreShiftAttendanceRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val staffId: String = "",
    val staffName: String = "",
    val roleTitle: String = "",
    val department: String = "",
    val branch: String = "",
    val scannedQrPayload: String = "",
    val shiftId: String = "",
    val shiftWindowLabel: String = "",
    val action: String = "CHECK_IN",
    val checkpointLocation: String = "",
    val verifiedByStaffId: String = "",
    val verifiedByName: String = "",
    val timestampFormatted: String = "",
    val dateFormatted: String = "",
    val notes: String = "",
    val timestampMillis: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreBurialSchedule(
    @DocumentId val id: String = "",
    val userId: String = "",
    val caseReference: String = "",
    val deceasedName: String = "",
    val familyRepresentative: String = "",
    val familyPhone: String = "",
    val burialDate: String = "",
    val casketModel: String = "",
    val churchVenue: String = "",
    val gravesiteLocation: String = "",
    val assignedHearseReg: String = "",
    val assignedDriverName: String = "",
    val assignedDirector: String = "",
    val status: String = "Confirmed & Roster Synced",
    val currentMilestone: String = "PREPARATION_COMPLETE",
    val milestoneUpdatedAt: String = "",
    val rosterSynced: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreWorkshopJob(
    @DocumentId val id: String = "",
    val userId: String = "",
    val casketType: String = "",
    val assignedCraftsmanId: String = "",
    val assignedCraftsmanName: String = "",
    val currentStage: String = "FRAME_AND_ASSEMBLY",
    val completionPercentage: Int = 20,
    val notes: String = "",
    val sellingPriceKes: Double = 0.0,
    val materialCostKes: Double = 0.0,
    val laborCostKes: Double = 0.0,
    val finishingCostKes: Double = 0.0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreInventoryMaterial(
    @DocumentId val id: String = "",
    val userId: String = "",
    val materialId: String = "",
    val name: String = "",
    val categoryId: String = "",
    val categoryName: String = "",
    val quantity: Int = 0,
    val unit: String = "",
    val unitCostKes: Double = 0.0,
    val minThreshold: Int = 5,
    val branchWarehouse: String = "Bama Branch",
    val status: String = "IN_STOCK",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreCasketCatalogItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val casketId: String = "",
    val name: String = "",
    val woodType: String = "",
    val finish: String = "",
    val interiorLining: String = "",
    val tier: String = "",
    val priceKes: Double = 0.0,
    val priceUsd: Double = 0.0,
    val inStock: Boolean = true,
    val stockCount: Int = 0,
    val features: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreCaseDocument(
    @DocumentId val id: String = "",
    val userId: String = "",
    val caseReference: String = "",
    val deceasedName: String = "",
    val documentType: String = "BURIAL_PERMIT",
    val title: String = "",
    val notes: String = "",
    val fileName: String = "",
    val mimeType: String = "image/jpeg",
    val thumbnailBase64: String = "",
    val uploadedByStaffId: String = "",
    val uploadedByStaffName: String = "",
    val uploadedAt: String = "",
    val verifiedByAdmin: Boolean = false,
    val timestampMillis: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreStaffDirectoryEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val staffId: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val roleName: String = "OPERATOR",
    val departmentName: String = "OPERATORS",
    val branch: String = "Bama Branch",
    val assignedVehicle: String = "",
    val active: Boolean = true,
    val baseSalaryKes: Double = 0.0,
    val allowanceKes: Double = 0.0,
    val commissionRatePercent: Double = 0.0,
    val defaultMpesaNumber: String = "",
    val defaultBankDetails: String = "",
    val mustRotatePassword: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreBranchBoard(
    @DocumentId val id: String = "",
    val userId: String = "",
    val branchName: String = "",
    val operationalStatus: String = "24/7 Active & Full Standby",
    val activeCasesCount: Int = 0,
    val coldRoomCapacity: Int = 10,
    val coldRoomOccupancy: Int = 0,
    val onDutyStaffCount: Int = 0,
    val todayCortegeDepartures: Int = 0,
    val pendingStockRequests: Int = 0,
    val contactPhone: String = "",
    val leadSupervisor: String = "",
    val hearseFleetStationed: List<String> = emptyList(),
    val hearseFleetInTransit: List<String> = emptyList(),
    val activeAdvisories: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreLeaveRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val leaveId: String = "",
    val staffId: String = "",
    val staffName: String = "",
    val departmentName: String = "OPERATORS",
    val leaveType: String = "Annual Leave",
    val startDate: String = "",
    val endDate: String = "",
    val daysCount: Int = 1,
    val reason: String = "",
    val status: String = "Pending",
    val approvedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreFleetVehicle(
    @DocumentId val id: String = "",
    val userId: String = "",
    val registration: String = "",
    val model: String = "",
    val driverName: String = "",
    val driverPhone: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val speedKmh: Int = 0,
    val headingDegrees: Double = 0.0,
    val statusLabel: String = "Standby at Branch",
    val moving: Boolean = false,
    val fuelPercent: Int = 80,
    val engineRunning: Boolean = false,
    val activeCaseRef: String = "",
    val destination: String = "",
    val eta: String = "",
    val currentStreet: String = "",
    val lastPingSecondsAgo: Int = 10,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FirestoreCompanyAsset(
    @DocumentId val id: String = "",
    val userId: String = "",
    val assetId: String = "",
    val name: String = "",
    val category: String = "",
    val registrationOrTag: String = "",
    val branchAssigned: String = "Bama Branch",
    val condition: String = "Operational",
    val lastInspected: String = "",
    val custodianStaffName: String = "",
    val qrTagCode: String = "",
    val custodyStatus: String = "IN_DEPOT",
    val checkedOutCaseRef: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

