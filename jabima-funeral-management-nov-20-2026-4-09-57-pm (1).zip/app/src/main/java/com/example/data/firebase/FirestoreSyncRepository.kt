package com.example.data.firebase

import android.content.Context
import com.example.R
import com.example.model.ActivityStatus
import com.example.model.BranchStatusBoard
import com.example.model.BurialScheduleEvent
import com.example.model.CaseDocumentRecord
import com.example.model.CasketItem
import com.example.model.CompanyAsset
import com.example.model.CustomerOrderRecord
import com.example.model.FamilyCortegeMilestone
import com.example.model.FleetGpsVehicle
import com.example.model.InventoryMaterialItem
import com.example.model.LeaveRequest
import com.example.model.ShiftAttendanceRecord
import com.example.model.StaffAccount
import com.example.model.StaffActivity
import com.example.model.StaffBreakageRecord
import com.example.model.WalletTransaction
import com.example.model.WorkshopProductionItem
import com.example.model.WorkshopProductionStage
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.Locale

sealed class CloudSyncState {
    data object SignedOut : CloudSyncState()
    data object Syncing : CloudSyncState()
    data class Synced(val lastSyncedLabel: String, val recordCount: Int) : CloudSyncState()
    data class Error(val message: String, val retryable: Boolean) : CloudSyncState()
}

class FirestoreSyncRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth
) {
    companion object {
        const val COLLECTION_USERS = "users"
        const val COLLECTION_WALLET_TRANSACTIONS = "wallet_transactions"
        const val COLLECTION_CUSTOMER_ORDERS = "customer_orders"
        const val COLLECTION_STAFF_ACTIVITIES = "staff_activities"
        const val COLLECTION_BREAKAGE_RECORDS = "breakage_records"
        const val COLLECTION_SHIFT_ATTENDANCE = "shift_attendance_logs"
        const val COLLECTION_BURIAL_SCHEDULES = "burial_schedules"
        const val COLLECTION_WORKSHOP_JOBS = "workshop_jobs"
        const val COLLECTION_INVENTORY_MATERIALS = "inventory_materials"
        const val COLLECTION_CASKET_CATALOG = "casket_catalog"
        const val COLLECTION_CASE_DOCUMENTS = "case_documents"
        const val COLLECTION_STAFF_DIRECTORY = "staff_directory"
        const val COLLECTION_BRANCH_BOARDS = "branch_boards"
        const val COLLECTION_LEAVE_REQUESTS = "leave_requests"
        const val COLLECTION_FLEET_VEHICLES = "fleet_vehicles"
        const val COLLECTION_COMPANY_ASSETS = "company_assets"
        const val COLLECTION_ADMINS = "admins"
        const val BOOTSTRAP_ADMIN_EMAIL = "durens747@gmail.com"

        fun create(context: Context): FirestoreSyncRepository {
            val databaseId = context.getString(R.string.firestore_database_id)
            val firestore = FirebaseFirestore.getInstance(databaseId)
            return FirestoreSyncRepository(firestore, Firebase.auth)
        }
    }

    fun currentUid(): String? = auth.currentUser?.uid

    fun sanitizeDocId(raw: String): String {
        val cleaned = raw.trim().replace(Regex("[^a-zA-Z0-9_\\-]"), "-")
        return cleaned.ifBlank { "DOC-${System.currentTimeMillis()}" }.take(120)
    }

    private fun rethrowIfCancellation(t: Throwable) {
        if (t is CancellationException && FirestoreErrorHandler.unwrapFirestoreException(t) == null) {
            throw t
        }
    }

    // =========================================================================
    // USER PROFILES (/users/{userId})
    // =========================================================================
    suspend fun getUserProfile(uid: String): Result<FirestoreUserProfile?> {
        val current = auth.currentUser ?: return Result.failure(IllegalStateException("Not signed in"))
        val safeUid = sanitizeDocId(uid.ifBlank { current.uid })
        return try {
            val snap = db.collection(COLLECTION_USERS).document(safeUid).get().await()
            if (!snap.exists()) {
                Result.success(null)
            } else {
                Result.success(snap.toObject(FirestoreUserProfile::class.java))
            }
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun upsertUserProfile(
        displayName: String,
        email: String,
        linkedStaffId: String,
        linkedBranch: String,
        darkModeEnabled: Boolean
    ): Result<Unit> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Sign in required"))
        val safeUid = sanitizeDocId(user.uid)
        val docRef = db.collection(COLLECTION_USERS).document(safeUid)
        return try {
            val existingSnap = docRef.get().await()
            if (!existingSnap.exists()) {
                val newProfile = FirestoreUserProfile(
                    userId = user.uid,
                    displayName = displayName.trim().ifBlank { "Jabima Staff Member" }.take(120),
                    email = email.trim().take(180),
                    linkedStaffId = linkedStaffId.take(64),
                    linkedBranch = linkedBranch.take(120),
                    darkModeEnabled = darkModeEnabled
                )
                docRef.set(newProfile).await()
            } else {
                docRef.update(
                    mapOf(
                        "displayName" to displayName.trim().ifBlank { "Jabima Staff Member" }.take(120),
                        "linkedStaffId" to linkedStaffId.take(64),
                        "linkedBranch" to linkedBranch.take(120),
                        "darkModeEnabled" to darkModeEnabled,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun updateCloudDarkModePreference(darkModeEnabled: Boolean): Result<Unit> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Sign in required"))
        val docRef = db.collection(COLLECTION_USERS).document(sanitizeDocId(user.uid))
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(
                    mapOf(
                        "darkModeEnabled" to darkModeEnabled,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun deleteUserProfile(uid: String): Result<Unit> {
        val safeUid = sanitizeDocId(uid)
        return try {
            db.collection(COLLECTION_USERS).document(safeUid).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // WALLET TRANSACTIONS (/wallet_transactions/{txnId})
    // =========================================================================
    fun observeWalletTransactions(isAdmin: Boolean): Flow<List<FirestoreWalletTransaction>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            close(IllegalStateException("Unauthenticated wallet listener"))
            awaitClose { }
            return@callbackFlow
        }
        val baseQuery: Query = if (isAdmin) {
            db.collection(COLLECTION_WALLET_TRANSACTIONS)
                .orderBy("createdAt", Query.Direction.DESCENDING)
        } else {
            db.collection(COLLECTION_WALLET_TRANSACTIONS)
                .whereEqualTo("userId", uid)
        }
        val registration = baseQuery.addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            val list = snap?.documents?.mapNotNull { doc ->
                doc.toObjectWithEstimate<FirestoreWalletTransaction>()
            }?.sortedByDescending { it.createdAt?.seconds ?: 0L }.orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    suspend fun createWalletTransaction(
        txn: WalletTransaction,
        staffName: String
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(txn.id)
        val docRef = db.collection(COLLECTION_WALLET_TRANSACTIONS).document(docId)
        val payload = FirestoreWalletTransaction(
            userId = uid,
            staffId = txn.staffId.take(64),
            staffName = staffName.take(120),
            type = txn.type.name.take(64),
            title = txn.title.take(200),
            referenceNumber = txn.referenceNumber.take(80),
            amount = txn.amount.coerceIn(-10_000_000.0, 10_000_000.0),
            dateLabel = txn.date.take(64),
            status = txn.status.name,
            notes = txn.notes.take(500),
            payoutMethod = (txn.payoutMethod ?: "").take(120),
            payoutDestination = (txn.payoutDestination ?: "").take(120)
        )
        return try {
            if (!docRef.get().await().exists()) {
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun updatePendingPayoutNotes(
        txnId: String,
        newNotes: String,
        newDestination: String
    ): Result<Unit> {
        val docId = sanitizeDocId(txnId)
        return try {
            db.collection(COLLECTION_WALLET_TRANSACTIONS).document(docId).update(
                mapOf(
                    "notes" to newNotes.take(500),
                    "payoutDestination" to newDestination.take(120),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun adminUpdateTransactionStatus(
        txnId: String,
        status: String,
        notes: String
    ): Result<Unit> {
        val docId = sanitizeDocId(txnId)
        return try {
            db.collection(COLLECTION_WALLET_TRANSACTIONS).document(docId).update(
                mapOf(
                    "status" to status,
                    "notes" to notes.take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun deleteWalletTransaction(txnId: String): Result<Unit> {
        val docId = sanitizeDocId(txnId)
        return try {
            db.collection(COLLECTION_WALLET_TRANSACTIONS).document(docId).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // CUSTOMER ORDERS (/customer_orders/{orderId})
    // =========================================================================
    fun observeCustomerOrders(isAdmin: Boolean): Flow<List<FirestoreCustomerOrder>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            close(IllegalStateException("Unauthenticated orders listener"))
            awaitClose { }
            return@callbackFlow
        }
        val query: Query = if (isAdmin) {
            db.collection(COLLECTION_CUSTOMER_ORDERS)
                .orderBy("createdAt", Query.Direction.DESCENDING)
        } else {
            db.collection(COLLECTION_CUSTOMER_ORDERS)
                .whereEqualTo("userId", uid)
        }
        val registration = query.addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreCustomerOrder>() }
                ?.sortedByDescending { it.createdAt?.seconds ?: 0L }.orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    suspend fun createCustomerOrder(
        order: CustomerOrderRecord,
        salesAgentId: String
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(order.orderId)
        val docRef = db.collection(COLLECTION_CUSTOMER_ORDERS).document(docId)
        val payload = FirestoreCustomerOrder(
            userId = uid,
            orderNumber = order.orderId.take(64),
            clientName = order.clientName.take(120),
            clientPhone = order.clientPhone.take(40),
            deceasedName = order.deceasedName.take(120),
            selectedPackage = order.selectedPackage.take(120),
            selectedCasket = order.selectedCasket.take(160),
            totalAmountKes = order.totalAmountKes.coerceIn(0.0, 50_000_000.0),
            paymentMethod = order.paymentMethod.take(64),
            paymentStatus = order.paymentStatus.take(80),
            referenceCode = order.referenceCode.take(80),
            branch = order.branch.take(120),
            salesAgentId = salesAgentId.take(64),
            salesAgentName = order.salesAgentName.take(120),
            commissionEarnedKes = order.commissionEarnedKes.coerceIn(0.0, 5_000_000.0)
        )
        return try {
            if (!docRef.get().await().exists()) {
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun updateOrderContactDetails(
        orderId: String,
        clientPhone: String,
        deceasedName: String,
        referenceCode: String
    ): Result<Unit> {
        val docId = sanitizeDocId(orderId)
        return try {
            db.collection(COLLECTION_CUSTOMER_ORDERS).document(docId).update(
                mapOf(
                    "clientPhone" to clientPhone.take(40),
                    "deceasedName" to deceasedName.take(120),
                    "referenceCode" to referenceCode.take(80),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun deleteCustomerOrder(orderId: String): Result<Unit> {
        val docId = sanitizeDocId(orderId)
        return try {
            db.collection(COLLECTION_CUSTOMER_ORDERS).document(docId).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // STAFF ACTIVITIES (/staff_activities/{activityId})
    // =========================================================================
    fun observeStaffActivities(isAdmin: Boolean): Flow<List<FirestoreStaffActivity>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            close(IllegalStateException("Unauthenticated activities listener"))
            awaitClose { }
            return@callbackFlow
        }
        val query: Query = if (isAdmin) {
            db.collection(COLLECTION_STAFF_ACTIVITIES)
                .orderBy("createdAt", Query.Direction.DESCENDING)
        } else {
            db.collection(COLLECTION_STAFF_ACTIVITIES)
                .whereEqualTo("userId", uid)
        }
        val registration = query.addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreStaffActivity>() }
                ?.sortedByDescending { it.createdAt?.seconds ?: 0L }.orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    suspend fun createStaffActivity(
        activity: StaffActivity,
        allowVerifiedFlag: Boolean = false
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(activity.id)
        val docRef = db.collection(COLLECTION_STAFF_ACTIVITIES).document(docId)
        val payload = FirestoreStaffActivity(
            userId = uid,
            staffId = activity.staffId.take(64),
            staffName = activity.staffName.take(120),
            department = activity.department.name.take(64),
            category = activity.category.name.take(64),
            title = activity.title.take(200),
            caseReference = activity.caseReference.take(64),
            location = activity.location.take(160),
            status = activity.status.name,
            allowanceEarned = activity.allowanceEarned.coerceIn(0.0, 1_000_000.0),
            verifiedByAdmin = allowVerifiedFlag && activity.verifiedByAdmin
        )
        return try {
            if (!docRef.get().await().exists()) {
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun updateStaffActivityStatus(
        activityId: String,
        newStatus: ActivityStatus
    ): Result<Unit> {
        val docId = sanitizeDocId(activityId)
        return try {
            db.collection(COLLECTION_STAFF_ACTIVITIES).document(docId).update(
                mapOf(
                    "status" to newStatus.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun adminVerifyAndPriceActivity(
        activityId: String,
        allowanceEarned: Double,
        status: ActivityStatus
    ): Result<Unit> {
        val docId = sanitizeDocId(activityId)
        return try {
            db.collection(COLLECTION_STAFF_ACTIVITIES).document(docId).update(
                mapOf(
                    "allowanceEarned" to allowanceEarned.coerceIn(0.0, 1_000_000.0),
                    "verifiedByAdmin" to true,
                    "status" to status.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // BREAKAGE RECORDS (/breakage_records/{breakageId})
    // =========================================================================
    fun observeBreakageRecords(isAdmin: Boolean): Flow<List<FirestoreBreakageRecord>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            close(IllegalStateException("Unauthenticated breakage listener"))
            awaitClose { }
            return@callbackFlow
        }
        val query: Query = if (isAdmin) {
            db.collection(COLLECTION_BREAKAGE_RECORDS)
                .orderBy("createdAt", Query.Direction.DESCENDING)
        } else {
            db.collection(COLLECTION_BREAKAGE_RECORDS)
                .whereEqualTo("userId", uid)
        }
        val registration = query.addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreBreakageRecord>() }
                ?.sortedByDescending { it.createdAt?.seconds ?: 0L }.orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    suspend fun createBreakageRecord(record: StaffBreakageRecord): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(record.id)
        val docRef = db.collection(COLLECTION_BREAKAGE_RECORDS).document(docId)
        val payload = FirestoreBreakageRecord(
            userId = uid,
            staffId = record.staffId.take(64),
            staffName = record.staffName.take(120),
            itemBroken = record.itemBroken.take(180),
            description = record.description.take(400),
            breakageCostKes = record.breakageCostKes.coerceIn(0.0, 5_000_000.0),
            isDeducted = record.isDeducted,
            loggedBy = record.loggedBy.take(120)
        )
        return try {
            if (!docRef.get().await().exists()) {
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun updateBreakageDescription(
        breakageId: String,
        newDescription: String
    ): Result<Unit> {
        val docId = sanitizeDocId(breakageId)
        return try {
            db.collection(COLLECTION_BREAKAGE_RECORDS).document(docId).update(
                mapOf(
                    "description" to newDescription.take(400),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun adminMarkBreakageDeducted(breakageId: String): Result<Unit> {
        val docId = sanitizeDocId(breakageId)
        return try {
            db.collection(COLLECTION_BREAKAGE_RECORDS).document(docId).update(
                mapOf(
                    "isDeducted" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // 24/7 QR SHIFT ATTENDANCE LOGS (/shift_attendance_logs/{attendanceId})
    // =========================================================================
    fun observeShiftAttendanceLogs(isAdmin: Boolean): Flow<List<FirestoreShiftAttendanceRecord>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            close(IllegalStateException("Unauthenticated shift attendance listener"))
            awaitClose { }
            return@callbackFlow
        }
        val query: Query = if (isAdmin) {
            db.collection(COLLECTION_SHIFT_ATTENDANCE)
                .orderBy("createdAt", Query.Direction.DESCENDING)
        } else {
            db.collection(COLLECTION_SHIFT_ATTENDANCE)
                .whereEqualTo("userId", uid)
        }
        val registration = query.addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreShiftAttendanceRecord>() }
                ?.sortedByDescending { it.timestampMillis }.orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    suspend fun createShiftAttendanceRecord(record: ShiftAttendanceRecord): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(record.id)
        val docRef = db.collection(COLLECTION_SHIFT_ATTENDANCE).document(docId)
        val payload = FirestoreShiftAttendanceRecord(
            userId = uid,
            staffId = record.staffId.take(64),
            staffName = record.staffName.take(120),
            roleTitle = record.roleTitle.take(120),
            department = record.department.name.take(64),
            branch = record.branch.take(120),
            scannedQrPayload = record.scannedQrPayload.take(240),
            shiftId = (record.shiftId ?: "").take(64),
            shiftWindowLabel = record.shiftWindowLabel.take(120),
            action = record.action.name,
            checkpointLocation = record.checkpointLocation.take(160),
            verifiedByStaffId = record.verifiedByStaffId.take(64),
            verifiedByName = record.verifiedByName.take(120),
            timestampFormatted = record.timestampFormatted.take(80),
            dateFormatted = record.dateFormatted.take(64),
            notes = record.notes.take(400),
            timestampMillis = record.timestampMillis
        )
        return try {
            if (!docRef.get().await().exists()) {
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // BURIAL SCHEDULES (/burial_schedules/{scheduleId})
    // =========================================================================
    fun observeBurialSchedules(isAdmin: Boolean): Flow<List<FirestoreBurialSchedule>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            close(IllegalStateException("Unauthenticated burial schedule listener"))
            awaitClose { }
            return@callbackFlow
        }
        val query: Query = if (isAdmin) {
            db.collection(COLLECTION_BURIAL_SCHEDULES)
                .orderBy("createdAt", Query.Direction.DESCENDING)
        } else {
            db.collection(COLLECTION_BURIAL_SCHEDULES)
                .whereEqualTo("userId", uid)
        }
        val registration = query.addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreBurialSchedule>() }
                ?.sortedByDescending { it.createdAt?.seconds ?: 0L }.orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    suspend fun upsertBurialSchedule(event: BurialScheduleEvent): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(event.id)
        val docRef = db.collection(COLLECTION_BURIAL_SCHEDULES).document(docId)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = FirestoreBurialSchedule(
                    userId = uid,
                    caseReference = event.caseReference.take(64),
                    deceasedName = event.deceasedName.take(120),
                    familyRepresentative = event.familyRepresentative.take(120),
                    familyPhone = event.familyPhone.take(40),
                    burialDate = event.burialDate.take(64),
                    casketModel = event.casketModel.take(160),
                    churchVenue = event.churchVenue.take(160),
                    gravesiteLocation = event.gravesiteLocation.take(160),
                    assignedHearseReg = event.assignedHearseReg.take(64),
                    assignedDriverName = event.assignedDriverName.take(120),
                    assignedDirector = event.assignedDirector.take(120),
                    status = event.status.take(100),
                    currentMilestone = event.currentMilestone.name,
                    milestoneUpdatedAt = event.milestoneUpdatedAt.take(120),
                    rosterSynced = event.isRosterSynced
                )
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "currentMilestone" to event.currentMilestone.name,
                        "milestoneUpdatedAt" to event.milestoneUpdatedAt.take(120),
                        "status" to event.status.take(100),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun updateBurialMilestone(
        scheduleId: String,
        milestone: FamilyCortegeMilestone,
        updatedAtLabel: String,
        status: String
    ): Result<Unit> {
        val docId = sanitizeDocId(scheduleId)
        return try {
            db.collection(COLLECTION_BURIAL_SCHEDULES).document(docId).update(
                mapOf(
                    "currentMilestone" to milestone.name,
                    "milestoneUpdatedAt" to updatedAtLabel.take(120),
                    "status" to status.take(100),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // WORKSHOP PRODUCTION JOBS (/workshop_jobs/{jobId})
    // =========================================================================
    fun observeWorkshopJobs(isAdmin: Boolean): Flow<List<FirestoreWorkshopJob>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            close(IllegalStateException("Unauthenticated workshop listener"))
            awaitClose { }
            return@callbackFlow
        }
        val query: Query = if (isAdmin) {
            db.collection(COLLECTION_WORKSHOP_JOBS)
                .orderBy("createdAt", Query.Direction.DESCENDING)
        } else {
            db.collection(COLLECTION_WORKSHOP_JOBS)
                .whereEqualTo("userId", uid)
        }
        val registration = query.addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreWorkshopJob>() }
                ?.sortedByDescending { it.createdAt?.seconds ?: 0L }.orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    suspend fun upsertWorkshopJob(job: WorkshopProductionItem): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(job.id)
        val docRef = db.collection(COLLECTION_WORKSHOP_JOBS).document(docId)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = FirestoreWorkshopJob(
                    userId = uid,
                    casketType = job.casketType.take(160),
                    assignedCraftsmanId = job.assignedCraftsmanId.take(64),
                    assignedCraftsmanName = job.assignedCraftsmanName.take(120),
                    currentStage = job.currentStage.name,
                    completionPercentage = job.percentageDone.coerceIn(0, 100),
                    notes = job.notes.take(400),
                    sellingPriceKes = job.sellingPriceKes.coerceIn(0.0, 5_000_000.0),
                    materialCostKes = job.materialCostKes.coerceIn(0.0, 5_000_000.0),
                    laborCostKes = job.laborCostKes.coerceIn(0.0, 5_000_000.0),
                    finishingCostKes = job.finishingCostKes.coerceIn(0.0, 5_000_000.0)
                )
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "currentStage" to job.currentStage.name,
                        "completionPercentage" to job.percentageDone.coerceIn(0, 100),
                        "notes" to job.notes.take(400),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun updateWorkshopJobStage(
        jobId: String,
        stage: WorkshopProductionStage,
        percentage: Int,
        notes: String
    ): Result<Unit> {
        val docId = sanitizeDocId(jobId)
        return try {
            db.collection(COLLECTION_WORKSHOP_JOBS).document(docId).update(
                mapOf(
                    "currentStage" to stage.name,
                    "completionPercentage" to percentage.coerceIn(0, 100),
                    "notes" to notes.take(400),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // MULTI-DEVICE BRANCH ADMINS (/admins/{adminUid})
    // =========================================================================
    suspend fun checkIsCloudAdmin(uid: String, email: String?): Boolean {
        if (email.equals(BOOTSTRAP_ADMIN_EMAIL, ignoreCase = true)) {
            return true
        }
        return try {
            val snap = db.collection(COLLECTION_ADMINS).document(sanitizeDocId(uid)).get().await()
            snap.exists()
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            false
        }
    }

    fun observeCloudAdmins(): Flow<List<FirestoreAdminEntry>> = callbackFlow {
        if (auth.currentUser == null) {
            close(IllegalStateException("Unauthenticated admin listener"))
            awaitClose { }
            return@callbackFlow
        }
        val registration = db.collection(COLLECTION_ADMINS)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreAdminEntry>() }.orEmpty()
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    suspend fun seedAdminCloudRole(
        uid: String,
        email: String,
        branch: String = "All Branches",
        role: String = "BRANCH_ADMIN"
    ): Result<Unit> {
        val safeUid = sanitizeDocId(uid)
        return try {
            db.collection(COLLECTION_ADMINS).document(safeUid).set(
                mapOf(
                    "email" to email.trim().lowercase(Locale.US),
                    "role" to role.trim().ifBlank { "BRANCH_ADMIN" },
                    "branch" to branch.trim().ifBlank { "All Branches" },
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun revokeAdminCloudRole(uid: String): Result<Unit> {
        val safeUid = sanitizeDocId(uid)
        return try {
            db.collection(COLLECTION_ADMINS).document(safeUid).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // LIVE INVENTORY MATERIALS (/inventory_materials/{materialId})
    // =========================================================================
    fun observeInventoryMaterials(): Flow<List<FirestoreInventoryMaterial>> = callbackFlow {
        if (auth.currentUser == null) {
            close(IllegalStateException("Unauthenticated inventory listener"))
            awaitClose { }
            return@callbackFlow
        }
        val registration = db.collection(COLLECTION_INVENTORY_MATERIALS)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreInventoryMaterial>() }
                    .orEmpty()
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    suspend fun upsertInventoryMaterial(item: InventoryMaterialItem, isAdminUser: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(item.id)
        val docRef = db.collection(COLLECTION_INVENTORY_MATERIALS).document(docId)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                if (!isAdminUser) {
                    return Result.failure(IllegalStateException("Admin permission required to register new cloud inventory items"))
                }
                val payload = FirestoreInventoryMaterial(
                    userId = uid,
                    materialId = item.id.take(64),
                    name = item.name.take(160),
                    categoryId = item.categoryId.take(64),
                    categoryName = item.categoryName.take(120),
                    quantity = item.quantity.coerceIn(0, 100_000),
                    unit = item.unit.take(40),
                    unitCostKes = item.unitCostKes.coerceIn(0.0, 5_000_000.0),
                    minThreshold = item.minThreshold.coerceIn(0, 10_000),
                    branchWarehouse = item.branchWarehouse.take(120),
                    status = item.status.ifBlank { "IN_STOCK" }
                )
                docRef.set(payload).await()
            } else if (isAdminUser) {
                docRef.update(
                    mapOf(
                        "name" to item.name.take(160),
                        "categoryId" to item.categoryId.take(64),
                        "categoryName" to item.categoryName.take(120),
                        "quantity" to item.quantity.coerceIn(0, 100_000),
                        "unit" to item.unit.take(40),
                        "unitCostKes" to item.unitCostKes.coerceIn(0.0, 5_000_000.0),
                        "minThreshold" to item.minThreshold.coerceIn(0, 10_000),
                        "branchWarehouse" to item.branchWarehouse.take(120),
                        "status" to item.status.ifBlank { "IN_STOCK" },
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "quantity" to item.quantity.coerceIn(0, 100_000),
                        "status" to item.status.ifBlank { "IN_STOCK" },
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun adjustInventoryStockLevel(materialId: String, newQuantity: Int, newStatus: String): Result<Unit> {
        if (auth.currentUser == null) return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(materialId)
        val docRef = db.collection(COLLECTION_INVENTORY_MATERIALS).document(docId)
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(
                    mapOf(
                        "quantity" to newQuantity.coerceIn(0, 100_000),
                        "status" to newStatus.ifBlank { "IN_STOCK" },
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun deleteInventoryMaterialCloud(materialId: String): Result<Unit> {
        val docId = sanitizeDocId(materialId)
        return try {
            db.collection(COLLECTION_INVENTORY_MATERIALS).document(docId).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // LIVE CASKET CATALOG (/casket_catalog/{casketId})
    // =========================================================================
    fun observeCasketCatalog(): Flow<List<FirestoreCasketCatalogItem>> = callbackFlow {
        if (auth.currentUser == null) {
            close(IllegalStateException("Unauthenticated casket catalog listener"))
            awaitClose { }
            return@callbackFlow
        }
        val registration = db.collection(COLLECTION_CASKET_CATALOG)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreCasketCatalogItem>() }
                    .orEmpty()
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    suspend fun upsertCasketCatalogItem(item: CasketItem): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(item.id)
        val docRef = db.collection(COLLECTION_CASKET_CATALOG).document(docId)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = FirestoreCasketCatalogItem(
                    userId = uid,
                    casketId = item.id.take(64),
                    name = item.name.take(160),
                    woodType = item.woodType.take(120),
                    finish = item.finish.take(120),
                    interiorLining = item.interiorLining.take(120),
                    tier = item.tier.take(64),
                    priceKes = item.priceKes.coerceIn(0.0, 10_000_000.0),
                    priceUsd = item.priceUsd.coerceIn(0.0, 100_000.0),
                    inStock = item.inStock,
                    stockCount = item.stockCount.coerceIn(0, 10_000),
                    features = item.features.take(20)
                )
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "name" to item.name.take(160),
                        "woodType" to item.woodType.take(120),
                        "finish" to item.finish.take(120),
                        "interiorLining" to item.interiorLining.take(120),
                        "tier" to item.tier.take(64),
                        "priceKes" to item.priceKes.coerceIn(0.0, 10_000_000.0),
                        "priceUsd" to item.priceUsd.coerceIn(0.0, 100_000.0),
                        "inStock" to item.inStock,
                        "stockCount" to item.stockCount.coerceIn(0, 10_000),
                        "features" to item.features.take(20),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun deleteCasketCatalogItem(casketId: String): Result<Unit> {
        val docId = sanitizeDocId(casketId)
        return try {
            db.collection(COLLECTION_CASKET_CATALOG).document(docId).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // CASE PAPERWORK & PERMIT CLOUD VAULT (/case_documents/{docId})
    // =========================================================================
    fun observeCaseDocuments(): Flow<List<FirestoreCaseDocument>> = callbackFlow {
        if (auth.currentUser == null) {
            close(IllegalStateException("Unauthenticated case vault listener"))
            awaitClose { }
            return@callbackFlow
        }
        val registration = db.collection(COLLECTION_CASE_DOCUMENTS)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreCaseDocument>() }
                    ?.sortedByDescending { it.timestampMillis }.orEmpty()
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    suspend fun upsertCaseDocument(doc: CaseDocumentRecord): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(doc.id)
        val docRef = db.collection(COLLECTION_CASE_DOCUMENTS).document(docId)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = FirestoreCaseDocument(
                    userId = uid,
                    caseReference = doc.caseReference.take(64),
                    deceasedName = doc.deceasedName.take(120),
                    documentType = doc.documentType.name,
                    title = doc.title.take(180),
                    notes = doc.notes.take(500),
                    fileName = doc.fileName.take(160),
                    mimeType = doc.mimeType.take(80),
                    thumbnailBase64 = doc.thumbnailBase64.take(350_000),
                    uploadedByStaffId = doc.uploadedByStaffId.take(64),
                    uploadedByStaffName = doc.uploadedByStaffName.take(120),
                    uploadedAt = doc.uploadedAt.take(80),
                    verifiedByAdmin = doc.verifiedByAdmin,
                    timestampMillis = doc.timestampMillis
                )
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "title" to doc.title.take(180),
                        "notes" to doc.notes.take(500),
                        "fileName" to doc.fileName.take(160),
                        "mimeType" to doc.mimeType.take(80),
                        "thumbnailBase64" to doc.thumbnailBase64.take(350_000),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun adminVerifyCaseDocument(docId: String, verified: Boolean): Result<Unit> {
        val safeId = sanitizeDocId(docId)
        return try {
            db.collection(COLLECTION_CASE_DOCUMENTS).document(safeId).update(
                mapOf(
                    "verifiedByAdmin" to verified,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun deleteCaseDocument(docId: String): Result<Unit> {
        val safeId = sanitizeDocId(docId)
        return try {
            db.collection(COLLECTION_CASE_DOCUMENTS).document(safeId).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // STAFF DIRECTORY (/staff_directory/{staffId}) — NON-SECRET FIELDS ONLY
    // =========================================================================
    fun observeStaffDirectory(): Flow<List<FirestoreStaffDirectoryEntry>> = callbackFlow {
        if (auth.currentUser == null) {
            close(IllegalStateException("Unauthenticated staff directory listener"))
            awaitClose { }
            return@callbackFlow
        }
        val registration = db.collection(COLLECTION_STAFF_DIRECTORY)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreStaffDirectoryEntry>() }
                    .orEmpty()
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    suspend fun upsertStaffDirectoryEntry(account: StaffAccount): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(account.id)
        val docRef = db.collection(COLLECTION_STAFF_DIRECTORY).document(docId)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = FirestoreStaffDirectoryEntry(
                    userId = uid,
                    staffId = account.id.take(64),
                    fullName = account.fullName.take(120),
                    email = account.email.take(180),
                    phone = account.phone.take(40),
                    roleName = account.role.name,
                    departmentName = account.department.name,
                    branch = account.branch.ifBlank { "Bama Branch" }.take(120),
                    assignedVehicle = (account.assignedVehicle ?: "").take(64),
                    active = account.isActive,
                    baseSalaryKes = account.baseSalaryKes.coerceIn(0.0, 5_000_000.0),
                    allowanceKes = account.allowanceKes.coerceIn(0.0, 5_000_000.0),
                    commissionRatePercent = account.commissionRatePercent.coerceIn(0.0, 100.0),
                    defaultMpesaNumber = account.defaultMpesaNumber.take(40),
                    defaultBankDetails = account.defaultBankDetails.take(160),
                    mustRotatePassword = account.mustRotatePassword
                )
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "fullName" to account.fullName.take(120),
                        "email" to account.email.take(180),
                        "phone" to account.phone.take(40),
                        "roleName" to account.role.name,
                        "departmentName" to account.department.name,
                        "branch" to account.branch.ifBlank { "Bama Branch" }.take(120),
                        "assignedVehicle" to (account.assignedVehicle ?: "").take(64),
                        "active" to account.isActive,
                        "baseSalaryKes" to account.baseSalaryKes.coerceIn(0.0, 5_000_000.0),
                        "allowanceKes" to account.allowanceKes.coerceIn(0.0, 5_000_000.0),
                        "commissionRatePercent" to account.commissionRatePercent.coerceIn(0.0, 100.0),
                        "defaultMpesaNumber" to account.defaultMpesaNumber.take(40),
                        "defaultBankDetails" to account.defaultBankDetails.take(160),
                        "mustRotatePassword" to account.mustRotatePassword,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun deleteStaffDirectoryEntry(staffId: String): Result<Unit> {
        val docId = sanitizeDocId(staffId)
        return try {
            db.collection(COLLECTION_STAFF_DIRECTORY).document(docId).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // BRANCH STATUS BOARDS (/branch_boards/{boardId})
    // =========================================================================
    fun observeBranchBoards(): Flow<List<FirestoreBranchBoard>> = callbackFlow {
        if (auth.currentUser == null) {
            close(IllegalStateException("Unauthenticated branch boards listener"))
            awaitClose { }
            return@callbackFlow
        }
        val registration = db.collection(COLLECTION_BRANCH_BOARDS)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreBranchBoard>() }
                    .orEmpty()
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    suspend fun upsertBranchBoard(board: BranchStatusBoard, isAdminUser: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(board.branchName)
        val docRef = db.collection(COLLECTION_BRANCH_BOARDS).document(docId)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                if (!isAdminUser) {
                    return Result.failure(IllegalStateException("Admin permission required to register branch board"))
                }
                val payload = FirestoreBranchBoard(
                    userId = uid,
                    branchName = board.branchName.take(120),
                    operationalStatus = board.operationalStatus.take(100),
                    activeCasesCount = board.activeCasesCount.coerceIn(0, 10_000),
                    coldRoomCapacity = board.coldRoomCapacity.coerceIn(1, 5_000),
                    coldRoomOccupancy = board.coldRoomOccupancy.coerceIn(0, 5_000),
                    onDutyStaffCount = board.onDutyStaffCount.coerceIn(0, 1_000),
                    todayCortegeDepartures = board.todayCortegeDepartures.coerceIn(0, 500),
                    pendingStockRequests = board.pendingStockRequests.coerceIn(0, 500),
                    contactPhone = board.contactPhone.take(40),
                    leadSupervisor = board.leadSupervisor.take(120),
                    hearseFleetStationed = board.hearseFleetStationed.take(30),
                    hearseFleetInTransit = board.hearseFleetInTransit.take(30),
                    activeAdvisories = board.activeAdvisories.take(20)
                )
                docRef.set(payload).await()
            } else if (isAdminUser) {
                docRef.update(
                    mapOf(
                        "operationalStatus" to board.operationalStatus.take(100),
                        "activeCasesCount" to board.activeCasesCount.coerceIn(0, 10_000),
                        "coldRoomCapacity" to board.coldRoomCapacity.coerceIn(1, 5_000),
                        "coldRoomOccupancy" to board.coldRoomOccupancy.coerceIn(0, 5_000),
                        "onDutyStaffCount" to board.onDutyStaffCount.coerceIn(0, 1_000),
                        "todayCortegeDepartures" to board.todayCortegeDepartures.coerceIn(0, 500),
                        "pendingStockRequests" to board.pendingStockRequests.coerceIn(0, 500),
                        "contactPhone" to board.contactPhone.take(40),
                        "leadSupervisor" to board.leadSupervisor.take(120),
                        "hearseFleetStationed" to board.hearseFleetStationed.take(30),
                        "hearseFleetInTransit" to board.hearseFleetInTransit.take(30),
                        "activeAdvisories" to board.activeAdvisories.take(20),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "operationalStatus" to board.operationalStatus.take(100),
                        "activeCasesCount" to board.activeCasesCount.coerceIn(0, 10_000),
                        "coldRoomOccupancy" to board.coldRoomOccupancy.coerceIn(0, 5_000),
                        "onDutyStaffCount" to board.onDutyStaffCount.coerceIn(0, 1_000),
                        "todayCortegeDepartures" to board.todayCortegeDepartures.coerceIn(0, 500),
                        "pendingStockRequests" to board.pendingStockRequests.coerceIn(0, 500),
                        "activeAdvisories" to board.activeAdvisories.take(20),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun deleteBranchBoard(branchName: String): Result<Unit> {
        val docId = sanitizeDocId(branchName)
        return try {
            db.collection(COLLECTION_BRANCH_BOARDS).document(docId).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // LEAVE REQUESTS (/leave_requests/{leaveId})
    // =========================================================================
    fun observeLeaveRequests(isAdmin: Boolean): Flow<List<FirestoreLeaveRequest>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            close(IllegalStateException("Unauthenticated leave listener"))
            awaitClose { }
            return@callbackFlow
        }
        val query: Query = if (isAdmin) {
            db.collection(COLLECTION_LEAVE_REQUESTS).orderBy("createdAt", Query.Direction.DESCENDING)
        } else {
            db.collection(COLLECTION_LEAVE_REQUESTS).whereEqualTo("userId", uid)
        }
        val registration = query.addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
            if (err != null) {
                close(err)
                return@addSnapshotListener
            }
            val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreLeaveRequest>() }
                ?.sortedByDescending { it.createdAt?.seconds ?: 0L }.orEmpty()
            trySend(list)
        }
        awaitClose { registration.remove() }
    }

    suspend fun createLeaveRequest(request: LeaveRequest): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(request.id)
        val docRef = db.collection(COLLECTION_LEAVE_REQUESTS).document(docId)
        val payload = FirestoreLeaveRequest(
            userId = uid,
            leaveId = request.id.take(64),
            staffId = request.staffId.take(64),
            staffName = request.staffName.take(120),
            departmentName = request.department.name,
            leaveType = request.leaveType.take(80),
            startDate = request.startDate.take(40),
            endDate = request.endDate.take(40),
            daysCount = request.daysCount.coerceIn(1, 365),
            reason = request.reason.take(400),
            status = "Pending",
            approvedBy = ""
        )
        return try {
            if (!docRef.get().await().exists()) {
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun adminUpdateLeaveStatus(leaveId: String, status: String, approvedBy: String): Result<Unit> {
        val docId = sanitizeDocId(leaveId)
        return try {
            db.collection(COLLECTION_LEAVE_REQUESTS).document(docId).update(
                mapOf(
                    "status" to if (status == "Approved" || status == "Declined") status else "Pending",
                    "approvedBy" to approvedBy.take(120),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // FLEET GPS VEHICLES (/fleet_vehicles/{vehicleId})
    // =========================================================================
    fun observeFleetVehicles(): Flow<List<FirestoreFleetVehicle>> = callbackFlow {
        if (auth.currentUser == null) {
            close(IllegalStateException("Unauthenticated fleet listener"))
            awaitClose { }
            return@callbackFlow
        }
        val registration = db.collection(COLLECTION_FLEET_VEHICLES)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreFleetVehicle>() }
                    .orEmpty()
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    suspend fun upsertFleetVehicle(vehicle: FleetGpsVehicle, isAdminUser: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(vehicle.registration)
        val docRef = db.collection(COLLECTION_FLEET_VEHICLES).document(docId)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                if (!isAdminUser) {
                    return Result.failure(IllegalStateException("Admin permission required to register fleet vehicles"))
                }
                val payload = FirestoreFleetVehicle(
                    userId = uid,
                    registration = vehicle.registration.take(40),
                    model = vehicle.model.take(120),
                    driverName = vehicle.driverName.take(120),
                    driverPhone = vehicle.driverPhone.take(40),
                    latitude = vehicle.latitude.coerceIn(-90.0, 90.0),
                    longitude = vehicle.longitude.coerceIn(-180.0, 180.0),
                    speedKmh = vehicle.speedKmh.coerceIn(0, 240),
                    headingDegrees = vehicle.headingDegrees.toDouble().coerceIn(0.0, 360.0),
                    statusLabel = vehicle.statusLabel.take(120),
                    moving = vehicle.isMoving,
                    fuelPercent = vehicle.fuelPercent.coerceIn(0, 100),
                    engineRunning = vehicle.engineRunning,
                    activeCaseRef = vehicle.activeCaseRef.take(64),
                    destination = vehicle.destination.take(160),
                    eta = vehicle.eta.take(64),
                    currentStreet = vehicle.currentStreet.take(160),
                    lastPingSecondsAgo = vehicle.lastPingSecondsAgo.coerceIn(0, 864_000)
                )
                docRef.set(payload).await()
            } else if (isAdminUser) {
                docRef.update(
                    mapOf(
                        "model" to vehicle.model.take(120),
                        "driverName" to vehicle.driverName.take(120),
                        "driverPhone" to vehicle.driverPhone.take(40),
                        "latitude" to vehicle.latitude.coerceIn(-90.0, 90.0),
                        "longitude" to vehicle.longitude.coerceIn(-180.0, 180.0),
                        "speedKmh" to vehicle.speedKmh.coerceIn(0, 240),
                        "headingDegrees" to vehicle.headingDegrees.toDouble().coerceIn(0.0, 360.0),
                        "statusLabel" to vehicle.statusLabel.take(120),
                        "moving" to vehicle.isMoving,
                        "fuelPercent" to vehicle.fuelPercent.coerceIn(0, 100),
                        "engineRunning" to vehicle.engineRunning,
                        "activeCaseRef" to vehicle.activeCaseRef.take(64),
                        "destination" to vehicle.destination.take(160),
                        "eta" to vehicle.eta.take(64),
                        "currentStreet" to vehicle.currentStreet.take(160),
                        "lastPingSecondsAgo" to vehicle.lastPingSecondsAgo.coerceIn(0, 864_000),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "latitude" to vehicle.latitude.coerceIn(-90.0, 90.0),
                        "longitude" to vehicle.longitude.coerceIn(-180.0, 180.0),
                        "speedKmh" to vehicle.speedKmh.coerceIn(0, 240),
                        "headingDegrees" to vehicle.headingDegrees.toDouble().coerceIn(0.0, 360.0),
                        "statusLabel" to vehicle.statusLabel.take(120),
                        "moving" to vehicle.isMoving,
                        "fuelPercent" to vehicle.fuelPercent.coerceIn(0, 100),
                        "engineRunning" to vehicle.engineRunning,
                        "currentStreet" to vehicle.currentStreet.take(160),
                        "destination" to vehicle.destination.take(160),
                        "eta" to vehicle.eta.take(64),
                        "lastPingSecondsAgo" to vehicle.lastPingSecondsAgo.coerceIn(0, 864_000),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    suspend fun deleteFleetVehicle(registration: String): Result<Unit> {
        val docId = sanitizeDocId(registration)
        return try {
            db.collection(COLLECTION_FLEET_VEHICLES).document(docId).delete().await()
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    // =========================================================================
    // COMPANY ASSETS & CUSTODY (/company_assets/{assetId})
    // =========================================================================
    fun observeCompanyAssets(): Flow<List<FirestoreCompanyAsset>> = callbackFlow {
        if (auth.currentUser == null) {
            close(IllegalStateException("Unauthenticated company assets listener"))
            awaitClose { }
            return@callbackFlow
        }
        val registration = db.collection(COLLECTION_COMPANY_ASSETS)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { it.toObjectWithEstimate<FirestoreCompanyAsset>() }
                    .orEmpty()
                trySend(list)
            }
        awaitClose { registration.remove() }
    }

    suspend fun upsertCompanyAsset(asset: CompanyAsset, isAdminUser: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Sign in required"))
        val docId = sanitizeDocId(asset.id)
        val docRef = db.collection(COLLECTION_COMPANY_ASSETS).document(docId)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                if (!isAdminUser) {
                    return Result.failure(IllegalStateException("Admin permission required to register company assets"))
                }
                val payload = FirestoreCompanyAsset(
                    userId = uid,
                    assetId = asset.id.take(64),
                    name = asset.name.take(160),
                    category = asset.category.take(80),
                    registrationOrTag = asset.registrationOrTag.take(80),
                    branchAssigned = asset.branchAssigned.take(120),
                    condition = asset.condition.take(80),
                    lastInspected = asset.lastInspected.take(64),
                    custodianStaffName = asset.custodianStaffName.take(120),
                    qrTagCode = asset.qrTagCode.take(100),
                    custodyStatus = asset.custodyStatus.name,
                    checkedOutCaseRef = (asset.checkedOutCaseRef ?: "").take(64)
                )
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "condition" to asset.condition.take(80),
                        "lastInspected" to asset.lastInspected.take(64),
                        "custodianStaffName" to asset.custodianStaffName.take(120),
                        "custodyStatus" to asset.custodyStatus.name,
                        "checkedOutCaseRef" to (asset.checkedOutCaseRef ?: "").take(64),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            rethrowIfCancellation(t)
            Result.failure(t)
        }
    }

    private inline fun <reified T> DocumentSnapshot.toObjectWithEstimate(): T? {
        return toObject(T::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
    }
}

