package com.example.domain

import com.example.model.CasketStockByBranchRow
import com.example.model.CustomerOrderRecord
import com.example.model.ExpenseStatus
import com.example.model.InventoryMaterialItem
import com.example.model.MarginEvaluation
import com.example.model.ProductItem
import com.example.model.StaffExpenseClaim
import com.example.model.VendorTransaction
import com.example.model.VendorTransactionType
import com.example.model.WorkshopProductionItem
import kotlin.math.abs
import kotlin.math.roundToInt

// =========================================================================
// 1. INVENTORY TRACKER ANALYTICS
// =========================================================================
enum class InventoryHealthStatus(val label: String) {
    ALL("All Stock"),
    OUT_OF_STOCK("Out of Stock"),
    LOW_STOCK("Low Stock"),
    HEALTHY("Healthy Stock")
}

data class InventoryCategoryMetric(
    val categoryName: String,
    val skuCount: Int,
    val totalUnits: Int,
    val valuationKes: Double,
    val lowOrOutCount: Int
)

data class InventoryBranchMetric(
    val branchName: String,
    val casketUnitsTotal: Int,
    val branchValueKes: Double,
    val depletedModelsCount: Int
)

data class InventoryTrackerSummary(
    val totalMaterialSkus: Int,
    val totalMaterialUnits: Int,
    val totalMaterialValuationKes: Double,
    val outOfStockCount: Int,
    val lowStockCount: Int,
    val healthyStockCount: Int,
    val estimatedReorderCostKes: Double,
    val finishedProductsCount: Int,
    val casketBranchUnitsTotal: Int,
    val categoryMetrics: List<InventoryCategoryMetric>,
    val branchCasketMetrics: List<InventoryBranchMetric>,
    val prioritizedMaterials: List<InventoryMaterialItem>
)

// =========================================================================
// 2. ORDER DASHBOARD ANALYTICS
// =========================================================================
enum class OrderStatusFilter(val label: String) {
    ALL("All Orders"),
    CONFIRMED("Confirmed"),
    INSTALLMENT("Installments"),
    PENDING("Pending")
}

data class PaymentChannelMetric(
    val channelLabel: String,
    val orderCount: Int,
    val totalKes: Double,
    val sharePercent: Double,
    val colorHex: Long
)

data class BranchOrderMetric(
    val branchName: String,
    val orderCount: Int,
    val revenueKes: Double,
    val commissionKes: Double
)

data class CasketModelSalesMetric(
    val casketModel: String,
    val unitsSold: Int,
    val revenueKes: Double
)

data class OrderDashboardSummary(
    val totalOrders: Int,
    val confirmedOrders: Int,
    val installmentOrders: Int,
    val pendingOrders: Int,
    val totalRevenueKes: Double,
    val totalRevenueUsd: Double,
    val confirmedRevenueKes: Double,
    val collectionRatePercent: Double,
    val averageOrderValueKes: Double,
    val totalCommissionPoolKes: Double,
    val channelMetrics: List<PaymentChannelMetric>,
    val branchMetrics: List<BranchOrderMetric>,
    val topCasketModels: List<CasketModelSalesMetric>,
    val filteredOrders: List<CustomerOrderRecord>
)

// =========================================================================
// 3. COST ANALYTICS ENGINE
// =========================================================================
data class CostPoolSlice(
    val label: String,
    val amountKes: Double,
    val sharePercent: Double,
    val colorHex: Long
)

data class WorkshopJobCostVariance(
    val jobId: String,
    val casketType: String,
    val stageLabel: String,
    val craftsmanName: String,
    val actualCostKes: Double,
    val benchmarkBomCostKes: Double,
    val varianceKes: Double, // Positive = Over Budget, Negative = Under Budget Saving
    val sellingPriceKes: Double,
    val realizedMarginPercent: Double,
    val isOverBudget: Boolean
)

data class OrderProfitabilityItem(
    val orderId: String,
    val clientName: String,
    val casketLabel: String,
    val matchedBomModelName: String,
    val orderRevenueKes: Double,
    val estimatedProductionCostKes: Double,
    val salesCommissionKes: Double,
    val netProfitKes: Double,
    val netMarginPercent: Double,
    val marginEvaluation: MarginEvaluation
)

data class CostAnalyticsSummary(
    val totalInventoryAssetCostKes: Double,
    val totalWorkshopSpendKes: Double,
    val totalWorkshopBenchmarkKes: Double,
    val workshopNetVarianceKes: Double,
    val realizedOrderRevenueKes: Double,
    val estimatedOrderCogsKes: Double,
    val totalAgentCommissionsKes: Double,
    val vendorOutflowsKes: Double,
    val staffFieldExpensesKes: Double,
    val netOperatingProfitKes: Double,
    val netOperatingMarginPercent: Double,
    val monthlyBulkGlueSavingsPotentialKes: Double,
    val costPoolSlices: List<CostPoolSlice>,
    val workshopVariances: List<WorkshopJobCostVariance>,
    val orderProfitabilities: List<OrderProfitabilityItem>,
    val modelUnitEconomics: List<CasketProductionCostModel>
)

object OperationsAnalyticsEngine {

    fun buildInventoryTrackerSummary(
        materials: List<InventoryMaterialItem>,
        products: List<ProductItem>,
        casketStockByBranch: List<CasketStockByBranchRow>,
        branchFilter: String = "All Branches",
        healthFilter: InventoryHealthStatus = InventoryHealthStatus.ALL,
        searchQuery: String = ""
    ): InventoryTrackerSummary {
        val branchScoped = if (branchFilter == "All Branches") {
            materials
        } else {
            materials.filter {
                it.branchWarehouse.equals(branchFilter, ignoreCase = true) ||
                    it.branchWarehouse.contains(branchFilter, ignoreCase = true)
            }
        }

        val query = searchQuery.trim().lowercase()
        val searched = if (query.isEmpty()) {
            branchScoped
        } else {
            branchScoped.filter {
                it.name.lowercase().contains(query) ||
                    it.categoryName.lowercase().contains(query) ||
                    it.branchWarehouse.lowercase().contains(query)
            }
        }

        val healthFiltered = when (healthFilter) {
            InventoryHealthStatus.ALL -> searched
            InventoryHealthStatus.OUT_OF_STOCK -> searched.filter { it.quantity == 0 }
            InventoryHealthStatus.LOW_STOCK -> searched.filter { it.quantity in 1..it.minThreshold }
            InventoryHealthStatus.HEALTHY -> searched.filter { it.quantity > it.minThreshold }
        }.sortedWith(
            compareBy<InventoryMaterialItem> {
                when {
                    it.quantity == 0 -> 0
                    it.quantity <= it.minThreshold -> 1
                    else -> 2
                }
            }.thenBy { it.quantity }
        )

        val outCount = branchScoped.count { it.quantity == 0 }
        val lowCount = branchScoped.count { it.quantity in 1..it.minThreshold }
        val healthyCount = branchScoped.count { it.quantity > it.minThreshold }

        // Estimate cost to replenish out/low items up to 2x minimum threshold
        val reorderEstimate = branchScoped.sumOf { mat ->
            val targetLevel = (mat.minThreshold * 2).coerceAtLeast(1)
            if (mat.quantity <= mat.minThreshold) {
                (targetLevel - mat.quantity).coerceAtLeast(0) * mat.unitCostKes
            } else {
                0.0
            }
        }

        val categoryMetrics = branchScoped
            .groupBy { it.categoryName }
            .map { (catName, items) ->
                InventoryCategoryMetric(
                    categoryName = catName,
                    skuCount = items.size,
                    totalUnits = items.sumOf { it.quantity },
                    valuationKes = items.sumOf { it.totalValueKes },
                    lowOrOutCount = items.count { it.quantity <= it.minThreshold }
                )
            }
            .sortedByDescending { it.valuationKes }

        val branchMap = mutableMapOf<String, Triple<Int, Double, Int>>()
        casketStockByBranch.forEach { row ->
            row.branchStockMap.forEach { (branch, qty) ->
                val cur = branchMap[branch] ?: Triple(0, 0.0, 0)
                val depletedInc = if (qty == 0) 1 else 0
                branchMap[branch] = Triple(
                    cur.first + qty,
                    cur.second + (qty * row.priceKes),
                    cur.third + depletedInc
                )
            }
        }
        val branchCasketMetrics = branchMap.map { (branch, triple) ->
            InventoryBranchMetric(
                branchName = branch,
                casketUnitsTotal = triple.first,
                branchValueKes = triple.second,
                depletedModelsCount = triple.third
            )
        }.sortedByDescending { it.casketUnitsTotal }

        return InventoryTrackerSummary(
            totalMaterialSkus = branchScoped.size,
            totalMaterialUnits = branchScoped.sumOf { it.quantity },
            totalMaterialValuationKes = branchScoped.sumOf { it.totalValueKes },
            outOfStockCount = outCount,
            lowStockCount = lowCount,
            healthyStockCount = healthyCount,
            estimatedReorderCostKes = reorderEstimate,
            finishedProductsCount = products.sumOf { it.stockCount },
            casketBranchUnitsTotal = casketStockByBranch.sumOf { it.totalStock },
            categoryMetrics = categoryMetrics,
            branchCasketMetrics = branchCasketMetrics,
            prioritizedMaterials = healthFiltered
        )
    }

    fun buildOrderDashboardSummary(
        orders: List<CustomerOrderRecord>,
        branchFilter: String = "All Branches",
        statusFilter: OrderStatusFilter = OrderStatusFilter.ALL,
        searchQuery: String = ""
    ): OrderDashboardSummary {
        val branchOrders = if (branchFilter == "All Branches") {
            orders
        } else {
            orders.filter {
                it.branch.equals(branchFilter, ignoreCase = true) ||
                    it.branch.contains(branchFilter, ignoreCase = true)
            }
        }

        val query = searchQuery.trim().lowercase()
        val searched = if (query.isEmpty()) {
            branchOrders
        } else {
            branchOrders.filter {
                it.orderId.lowercase().contains(query) ||
                    it.clientName.lowercase().contains(query) ||
                    it.deceasedName.lowercase().contains(query) ||
                    it.selectedCasket.lowercase().contains(query) ||
                    it.salesAgentName.lowercase().contains(query) ||
                    it.referenceCode.lowercase().contains(query)
            }
        }

        val filtered = when (statusFilter) {
            OrderStatusFilter.ALL -> searched
            OrderStatusFilter.CONFIRMED -> searched.filter { isOrderConfirmed(it) }
            OrderStatusFilter.INSTALLMENT -> searched.filter { isOrderInstallment(it) }
            OrderStatusFilter.PENDING -> searched.filter { !isOrderConfirmed(it) && !isOrderInstallment(it) }
        }

        val confirmedCount = branchOrders.count { isOrderConfirmed(it) }
        val installmentCount = branchOrders.count { isOrderInstallment(it) }
        val pendingCount = branchOrders.count { !isOrderConfirmed(it) && !isOrderInstallment(it) }

        val totalRevKes = branchOrders.sumOf { it.totalAmountKes }
        val confirmedRevKes = branchOrders.filter { isOrderConfirmed(it) }.sumOf { it.totalAmountKes }
        val collectionRate = if (totalRevKes > 0.0) {
            ((confirmedRevKes / totalRevKes) * 1000.0).roundToInt() / 10.0
        } else 0.0

        val avgOrder = if (branchOrders.isNotEmpty()) totalRevKes / branchOrders.size else 0.0

        val channelMetrics = branchOrders
            .groupBy { normalizePaymentMethod(it.paymentMethod) }
            .map { (channel, group) ->
                val sumKes = group.sumOf { it.totalAmountKes }
                val pct = if (totalRevKes > 0.0) ((sumKes / totalRevKes) * 1000.0).roundToInt() / 10.0 else 0.0
                val color = when {
                    channel.contains("M-PESA", ignoreCase = true) -> 0xFF059669L
                    channel.contains("BANK", ignoreCase = true) -> 0xFF2563EBL
                    else -> 0xFFD97706L
                }
                PaymentChannelMetric(
                    channelLabel = channel,
                    orderCount = group.size,
                    totalKes = sumKes,
                    sharePercent = pct,
                    colorHex = color
                )
            }
            .sortedByDescending { it.totalKes }

        val branchMetrics = branchOrders
            .groupBy { it.branch.ifBlank { "Main Branch" } }
            .map { (branch, group) ->
                BranchOrderMetric(
                    branchName = branch,
                    orderCount = group.size,
                    revenueKes = group.sumOf { it.totalAmountKes },
                    commissionKes = group.sumOf { it.commissionEarnedKes }
                )
            }
            .sortedByDescending { it.revenueKes }

        val topCasketModels = branchOrders
            .groupBy { it.selectedCasket.substringBefore(" (").trim().ifBlank { "Standard Casket" } }
            .map { (modelName, group) ->
                CasketModelSalesMetric(
                    casketModel = modelName,
                    unitsSold = group.size,
                    revenueKes = group.sumOf { it.totalAmountKes }
                )
            }
            .sortedByDescending { it.revenueKes }

        return OrderDashboardSummary(
            totalOrders = branchOrders.size,
            confirmedOrders = confirmedCount,
            installmentOrders = installmentCount,
            pendingOrders = pendingCount,
            totalRevenueKes = totalRevKes,
            totalRevenueUsd = totalRevKes / 130.0,
            confirmedRevenueKes = confirmedRevKes,
            collectionRatePercent = collectionRate,
            averageOrderValueKes = avgOrder,
            totalCommissionPoolKes = branchOrders.sumOf { it.commissionEarnedKes },
            channelMetrics = channelMetrics,
            branchMetrics = branchMetrics,
            topCasketModels = topCasketModels,
            filteredOrders = filtered
        )
    }

    fun buildCostAnalyticsSummary(
        materials: List<InventoryMaterialItem>,
        workshopJobs: List<WorkshopProductionItem>,
        orders: List<CustomerOrderRecord>,
        vendorTransactions: List<VendorTransaction>,
        expenseClaims: List<StaffExpenseClaim>
    ): CostAnalyticsSummary {
        val inventoryAssetCost = materials.sumOf { it.totalValueKes }

        var workshopMaterialSpend = 0.0
        var workshopFinishingSpend = 0.0
        var workshopLaborSpend = 0.0
        var workshopBenchmarkTotal = 0.0

        val workshopVariances = workshopJobs.map { job ->
            val matchedBom = CasketCostingEngine.findModelForCasketName(job.casketType)
                ?: CasketCostingEngine.casketProductionModels.first()
            val actualCost = job.totalProductionCostKes
            val benchmarkCost = matchedBom.totalProductionCostKes
            val variance = actualCost - benchmarkCost

            workshopMaterialSpend += job.materialCostKes
            workshopFinishingSpend += job.finishingCostKes
            workshopLaborSpend += job.laborCostKes
            workshopBenchmarkTotal += benchmarkCost

            val realizedMarginPct = if (job.sellingPriceKes > 0.0) {
                (((job.sellingPriceKes - actualCost) / job.sellingPriceKes) * 1000.0).roundToInt() / 10.0
            } else 0.0

            WorkshopJobCostVariance(
                jobId = job.id,
                casketType = job.casketType,
                stageLabel = job.currentStage.title,
                craftsmanName = job.assignedCraftsmanName,
                actualCostKes = actualCost,
                benchmarkBomCostKes = benchmarkCost,
                varianceKes = variance,
                sellingPriceKes = job.sellingPriceKes,
                realizedMarginPercent = realizedMarginPct,
                isOverBudget = variance > 500.0
            )
        }.sortedByDescending { abs(it.varianceKes) }

        val workshopSpend = workshopMaterialSpend + workshopFinishingSpend + workshopLaborSpend
        val workshopNetVariance = workshopSpend - workshopBenchmarkTotal

        val orderProfitabilities = orders.map { order ->
            val cleanCasket = order.selectedCasket.substringBefore(" (").trim()
            val matchedModel = CasketCostingEngine.findModelForCasketName(cleanCasket)
                ?: CasketCostingEngine.findModelForCasketName(order.selectedPackage)
                ?: CasketCostingEngine.casketProductionModels.first()

            val estCogs = matchedModel.totalProductionCostKes
            val netProfit = order.totalAmountKes - estCogs - order.commissionEarnedKes
            val netMarginPct = if (order.totalAmountKes > 0.0) {
                ((netProfit / order.totalAmountKes) * 1000.0).roundToInt() / 10.0
            } else 0.0

            val marginEval = PayrollRulesEngine.evaluateBomMargin(
                sellingPriceKes = order.totalAmountKes,
                materialCostKes = matchedModel.baseBodyMaterialCostKes + matchedModel.paintAndAbrasivesCostKes,
                laborCostKes = matchedModel.crewLaborCostKes,
                finishingCostKes = matchedModel.finishingMaterialCostKes + order.commissionEarnedKes,
                minTargetMarginPercent = 20.0
            )

            OrderProfitabilityItem(
                orderId = order.orderId,
                clientName = order.clientName,
                casketLabel = cleanCasket,
                matchedBomModelName = matchedModel.modelName,
                orderRevenueKes = order.totalAmountKes,
                estimatedProductionCostKes = estCogs,
                salesCommissionKes = order.commissionEarnedKes,
                netProfitKes = netProfit,
                netMarginPercent = netMarginPct,
                marginEvaluation = marginEval
            )
        }.sortedByDescending { it.netProfitKes }

        val realizedOrderRevenue = orders.sumOf { it.totalAmountKes }
        val estimatedOrderCogs = orderProfitabilities.sumOf { it.estimatedProductionCostKes }
        val totalCommissions = orders.sumOf { it.commissionEarnedKes }

        val vendorOutflows = vendorTransactions
            .filter { it.transactionType == VendorTransactionType.PAYMENT_SUBMITTED }
            .sumOf { it.amount }

        val fieldExpenses = expenseClaims
            .filter { it.status != ExpenseStatus.REJECTED }
            .sumOf { it.amount }

        val totalAllOutflows = estimatedOrderCogs + totalCommissions + vendorOutflows + fieldExpenses
        val netOperatingProfit = realizedOrderRevenue - totalAllOutflows
        val netOperatingMarginPct = if (realizedOrderRevenue > 0.0) {
            ((netOperatingProfit / realizedOrderRevenue) * 1000.0).roundToInt() / 10.0
        } else 0.0

        // Calculate Bulk Glue savings across active workshop pipeline + monthly run rate baseline (18 units/mo avg 1.75L)
        val bulkGlueSavingsFromJobs = workshopJobs.sumOf { job ->
            val baseModel = CasketCostingEngine.findModelForCasketName(job.casketType)
                ?: CasketCostingEngine.casketProductionModels.first()
            val bulkModel = CasketCostingEngine.calculateModelWithOptions(
                modelId = baseModel.id,
                useBulkGlue = true
            )
            (baseModel.totalProductionCostKes - bulkModel.totalProductionCostKes).coerceAtLeast(0.0)
        }
        val monthlyBulkGlueSavings = maxOf(bulkGlueSavingsFromJobs, 3150.0)

        val totalPoolDenominator = (workshopMaterialSpend + workshopFinishingSpend + workshopLaborSpend + vendorOutflows + fieldExpenses + totalCommissions)
            .coerceAtLeast(1.0)

        val rawSlices = listOf(
            Triple("Body & Paint Materials", workshopMaterialSpend, 0xFF1D4ED8L),
            Triple("Hardware & Finishing", workshopFinishingSpend, 0xFF7C3AEDL),
            Triple("Craft Crew Labor", workshopLaborSpend, 0xFF059669L),
            Triple("Vendor Supply Spend", vendorOutflows, 0xFFD97706L),
            Triple("Field Ops & Commissions", fieldExpenses + totalCommissions, 0xFFDC2626L)
        ).filter { it.second > 0.0 }

        val slices = rawSlices.map { (label, amt, color) ->
            CostPoolSlice(
                label = label,
                amountKes = amt,
                sharePercent = ((amt / totalPoolDenominator) * 1000.0).roundToInt() / 10.0,
                colorHex = color
            )
        }

        return CostAnalyticsSummary(
            totalInventoryAssetCostKes = inventoryAssetCost,
            totalWorkshopSpendKes = workshopSpend,
            totalWorkshopBenchmarkKes = workshopBenchmarkTotal,
            workshopNetVarianceKes = workshopNetVariance,
            realizedOrderRevenueKes = realizedOrderRevenue,
            estimatedOrderCogsKes = estimatedOrderCogs,
            totalAgentCommissionsKes = totalCommissions,
            vendorOutflowsKes = vendorOutflows,
            staffFieldExpensesKes = fieldExpenses,
            netOperatingProfitKes = netOperatingProfit,
            netOperatingMarginPercent = netOperatingMarginPct,
            monthlyBulkGlueSavingsPotentialKes = monthlyBulkGlueSavings,
            costPoolSlices = slices,
            workshopVariances = workshopVariances,
            orderProfitabilities = orderProfitabilities,
            modelUnitEconomics = CasketCostingEngine.casketProductionModels.sortedByDescending { it.grossMarginPercent }
        )
    }

    private fun isOrderConfirmed(order: CustomerOrderRecord): Boolean {
        val statusLower = order.paymentStatus.lowercase()
        return statusLower.contains("confirmed") || statusLower.contains("paid in full") || statusLower.contains("settled")
    }

    private fun isOrderInstallment(order: CustomerOrderRecord): Boolean {
        val statusLower = order.paymentStatus.lowercase()
        val termsLower = order.paymentTerms.lowercase()
        return !isOrderConfirmed(order) && (statusLower.contains("installment") || termsLower.contains("lipa pole pole"))
    }

    private fun normalizePaymentMethod(raw: String): String {
        val upper = raw.uppercase()
        return when {
            upper.contains("MPESA") || upper.contains("M-PESA") -> "M-PESA / STK"
            upper.contains("BANK") || upper.contains("RTGS") || upper.contains("EFT") -> "Bank Transfer"
            upper.contains("CASH") -> "Cash Desk"
            else -> raw.ifBlank { "Other" }
        }
    }
}
