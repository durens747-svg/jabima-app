package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

data class PickedCaseMediaPayload(
    val fileName: String,
    val mimeType: String,
    val thumbnailBase64: String
)

/**
 * Zero-permission ContentResolver helper for Android Photo Picker (PickVisualMedia)
 * and Document Picker (OpenDocument). Scales photos down to lightweight compressed JPEGs
 * so Case Paperwork & Permit previews sync cleanly through Firestore without storage permissions.
 */
object CaseDocumentMediaHelper {
    private const val MAX_DIMENSION_PX = 720
    private const val MAX_BASE64_LENGTH = 280_000

    fun extractPayloadFromUri(context: Context, uri: Uri): PickedCaseMediaPayload {
        val resolver = context.contentResolver
        val mimeType = resolver.getType(uri) ?: "application/octet-stream"
        val fileName = resolveDisplayName(context, uri)
            ?: ("DOC_${System.currentTimeMillis() % 100_000}." + if (mimeType.startsWith("image/")) "jpg" else "pdf")

        val base64Thumb = if (mimeType.startsWith("image/")) {
            compressImageUriToBase64(context, uri)
        } else {
            ""
        }

        return PickedCaseMediaPayload(
            fileName = fileName.take(120),
            mimeType = mimeType.take(80),
            thumbnailBase64 = base64Thumb
        )
    }

    private fun resolveDisplayName(context: Context, uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        }.getOrNull()
    }

    private fun compressImageUriToBase64(context: Context, uri: Uri): String {
        return runCatching {
            val resolver = context.contentResolver
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOpts)
            }

            val maxDim = max(boundsOpts.outWidth, boundsOpts.outHeight)
            var sampleSize = 1
            if (maxDim > MAX_DIMENSION_PX) {
                while ((maxDim / sampleSize) > MAX_DIMENSION_PX * 2) {
                    sampleSize *= 2
                }
            }

            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: return@runCatching ""

            val scaleRatio = if (max(decoded.width, decoded.height) > MAX_DIMENSION_PX) {
                MAX_DIMENSION_PX.toFloat() / max(decoded.width, decoded.height).toFloat()
            } else {
                1f
            }

            val scaled = if (scaleRatio < 1f) {
                val targetW = (decoded.width * scaleRatio).roundToInt().coerceAtLeast(1)
                val targetH = (decoded.height * scaleRatio).roundToInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(decoded, targetW, targetH, true).also {
                    if (it !== decoded) decoded.recycle()
                }
            } else {
                decoded
            }

            var quality = 65
            var encoded = ""
            while (quality >= 25) {
                val baos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
                val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                if (b64.length <= MAX_BASE64_LENGTH || quality == 25) {
                    encoded = b64.take(MAX_BASE64_LENGTH)
                    break
                }
                quality -= 15
            }
            scaled.recycle()
            encoded
        }.getOrDefault("")
    }

    fun decodeBase64Bitmap(base64: String): Bitmap? {
        if (base64.isBlank()) return null
        return runCatching {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }.getOrNull()
    }
}
