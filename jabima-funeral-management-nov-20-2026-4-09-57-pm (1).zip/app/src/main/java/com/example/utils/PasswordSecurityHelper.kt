package com.example.utils

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Provides salted SHA-256 hashing and constant-time verification for local staff
 * accounts so plaintext passwords (such as factory defaults) do not persist in
 * memory or UI screens once initialized or rotated.
 */
object PasswordSecurityHelper {
    private const val PREFIX = "sha256$"
    private val DEFAULT_PASSWORDS = setOf("password123", "admin", "admin123", "1234", "123456")

    private fun toHex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            val hex = Integer.toHexString(v)
            if (hex.length == 1) sb.append('0')
            sb.append(hex)
        }
        return sb.toString()
    }

    private fun fromHex(hex: String): ByteArray? {
        if (hex.length % 2 != 0) return null
        val out = ByteArray(hex.length / 2)
        for (i in out.indices) {
            val hi = Character.digit(hex[i * 2], 16)
            val lo = Character.digit(hex[i * 2 + 1], 16)
            if (hi < 0 || lo < 0) return null
            out[i] = ((hi shl 4) or lo).toByte()
        }
        return out
    }

    fun generateSaltHex(numBytes: Int = 16): String {
        val bytes = ByteArray(numBytes)
        SecureRandom().nextBytes(bytes)
        return toHex(bytes)
    }

    fun deterministicSaltForStaff(staffId: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(("jabima-seed-salt:" + staffId.trim()).toByteArray(StandardCharsets.UTF_8))
        return toHex(digest.copyOf(16))
    }

    fun hashPassword(rawPassword: String, saltHex: String = generateSaltHex()): String {
        val clean = rawPassword.trim()
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("$saltHex:$clean".toByteArray(StandardCharsets.UTF_8))
        return "$PREFIX$saltHex$${toHex(digest)}"
    }

    fun verifyPassword(
        rawInput: String,
        storedHash: String,
        legacyPlaintextFallback: String = ""
    ): Boolean {
        val cleanInput = rawInput.trim()
        if (cleanInput.isEmpty()) return false

        if (storedHash.startsWith(PREFIX)) {
            val parts = storedHash.removePrefix(PREFIX).split("$")
            if (parts.size == 2) {
                val saltHex = parts[0]
                val expectedDigestBytes = fromHex(parts[1]) ?: return false
                val actualDigestBytes = MessageDigest.getInstance("SHA-256")
                    .digest("$saltHex:$cleanInput".toByteArray(StandardCharsets.UTF_8))
                return MessageDigest.isEqual(expectedDigestBytes, actualDigestBytes)
            }
        }

        if (legacyPlaintextFallback.isNotEmpty()) {
            val expectedBytes = legacyPlaintextFallback.trim().toByteArray(StandardCharsets.UTF_8)
            val actualBytes = cleanInput.toByteArray(StandardCharsets.UTF_8)
            return MessageDigest.isEqual(expectedBytes, actualBytes)
        }
        return false
    }

    fun isDefaultOrWeakPassword(rawPassword: String): Boolean {
        val clean = rawPassword.trim()
        return clean.length < 6 || clean.lowercase() in DEFAULT_PASSWORDS
    }
}
