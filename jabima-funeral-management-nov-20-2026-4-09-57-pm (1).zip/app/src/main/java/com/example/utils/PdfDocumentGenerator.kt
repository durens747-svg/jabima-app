package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.domain.PayrollRulesEngine
import com.example.model.BurialScheduleEvent
import com.example.model.CustomerOrderRecord
import com.example.model.PosReceipt
import com.example.model.StaffAccount
import com.example.model.StaffWalletSummary
import com.example.model.WalletTransaction
import com.example.ui.components.QrCodeBitmapHelper
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfDocumentGenerator {

    private const val PAGE_WIDTH = 595 // A4 width in PostScript points
    private const val PAGE_HEIGHT = 842 // A4 height in PostScript points

    fun generateStaffPayslipPdf(
        context: Context,
        staff: StaffAccount,
        summary: StaffWalletSummary,
        transactions: List<WalletTransaction>,
        periodLabel: String,
        includeKenyanStatutory: Boolean = true
    ): File {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val headerBg = Paint().apply { color = Color.rgb(20, 90, 50) } // Executive Forest Green
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val subtitlePaint = Paint().apply {
            color = Color.rgb(220, 252, 231)
            textSize = 10f
            isAntiAlias = true
        }
        val sectionPaint = Paint().apply {
            color = Color.rgb(29, 78, 123) // Corporate Sapphire Blue
            textSize = 12.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val bodyPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10f
            isAntiAlias = true
        }
        val boldBodyPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val dividerPaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }

        // Top Corporate Header
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), 96f, headerBg)
        canvas.drawText("JABIMA FUNERAL DIRECTORS LTD", 32f, 38f, titlePaint)
        canvas.drawText("OFFICIAL STAFF DIGITAL WALLET PAYSLIP • $periodLabel", 32f, 58f, subtitlePaint)
        canvas.drawText("Headquarters: Bama Branch, Siaya • Hotline: +254 793 553 434", 32f, 76f, subtitlePaint)

        var y = 122f
        canvas.drawText("STAFF DETAILS", 32f, y, sectionPaint)
        y += 16f
        canvas.drawText("Full Name: ${staff.fullName} (${staff.id})", 32f, y, boldBodyPaint)
        canvas.drawText("Role: ${staff.role.title}", 320f, y, bodyPaint)
        y += 15f
        canvas.drawText("Department: ${staff.department.displayName}", 32f, y, bodyPaint)
        canvas.drawText("Branch: ${staff.branch}", 320f, y, bodyPaint)
        y += 15f
        canvas.drawText("M-PESA Account: ${staff.defaultMpesaNumber.ifBlank { staff.phone }}", 32f, y, bodyPaint)
        canvas.drawText("Bank Settlement: ${staff.defaultBankDetails}", 320f, y, bodyPaint)

        y += 14f
        canvas.drawLine(32f, y, PAGE_WIDTH - 32f, y, dividerPaint)
        y += 18f

        canvas.drawText("COMPENSATION & WALLET SUMMARY (KES)", 32f, y, sectionPaint)
        y += 16f
        drawKeyValueRow(canvas, "Monthly Base Retainer + Allowance", staff.baseSalaryKes + staff.allowanceKes, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "Earned Casket Commissions", summary.casketCommissionTotal, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "Funeral Service Payouts & Allowances", summary.servicePayoutsTotal, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "Breakage Cost Deductions", -summary.breakageDeductionsTotal, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "Withdrawn / Disbursed Payouts", -summary.totalWithdrawn, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "NET AVAILABLE WALLET BALANCE", summary.availableBalance, 32f, y, boldBodyPaint, boldBodyPaint); y += 16f

        val cycleGrossPay = (staff.baseSalaryKes + staff.allowanceKes + summary.casketCommissionTotal + summary.servicePayoutsTotal)
            .coerceAtLeast(staff.baseSalaryKes + staff.allowanceKes)
        val statutory = PayrollRulesEngine.computeKenyanStatutoryBreakdown(cycleGrossPay, applyStatutory = includeKenyanStatutory)
        val netTakeHomeAfterBreakage = (statutory.netTakeHomeBeforeBreakageKes - summary.breakageDeductionsTotal).coerceAtLeast(0.0)

        canvas.drawLine(32f, y, PAGE_WIDTH - 32f, y, dividerPaint); y += 18f
        canvas.drawText(
            if (includeKenyanStatutory) "KENYAN STATUTORY DEDUCTIONS (PAYE, NSSF, SHIF & AHL)" else "STATUTORY DEDUCTIONS (EXEMPT / CONTRACT MODE)",
            32f,
            y,
            sectionPaint
        )
        y += 16f
        drawKeyValueRow(canvas, "Gross Cycle Remuneration", statutory.grossPayKes, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "SHIF (Social Health Insurance - 2.75%)", -statutory.shifDeductionKes, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "NSSF Pension Contribution (Tier I & II)", -statutory.nssfDeductionKes, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "Affordable Housing Levy (AHL - 1.5%)", -statutory.housingLevyKes, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "KRA PAYE Tax (Net of KES 2,400 Relief)", -statutory.netPayeKes, 32f, y, bodyPaint, boldBodyPaint); y += 14f
        drawKeyValueRow(canvas, "Total Statutory + Breakage Deductions", -(statutory.totalStatutoryDeductionsKes + summary.breakageDeductionsTotal), 32f, y, bodyPaint, boldBodyPaint); y += 15f
        canvas.drawLine(32f, y, PAGE_WIDTH - 32f, y, dividerPaint); y += 16f
        drawKeyValueRow(canvas, "NET STATUTORY TAKE-HOME PAY (KES)", netTakeHomeAfterBreakage, 32f, y, boldBodyPaint, boldBodyPaint)

        y += 22f
        canvas.drawText("RECENT LEDGER ENTRIES (LATEST 12)", 32f, y, sectionPaint)
        y += 16f
        transactions.take(12).forEach { txn ->
            if (y < PAGE_HEIGHT - 48) {
                val sign = if (txn.amount >= 0) "+" else "-"
                val line = "${txn.date.take(12)} | ${txn.referenceNumber.take(14)} | ${txn.title.take(36)}"
                canvas.drawText(line, 32f, y, bodyPaint)
                canvas.drawText("$sign KES ${String.format(Locale.US, "%,.0f", kotlin.math.abs(txn.amount))}", 450f, y, boldBodyPaint)
                y += 14f
            }
        }

        val generatedAt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.US).format(Date())
        canvas.drawText("Generated electronically by Jabima Funeral Operations • KRA P9/PAYE Compliant • $generatedAt", 32f, PAGE_HEIGHT - 24f, bodyPaint)

        doc.finishPage(page)
        val outDir = File(context.cacheDir, "pdfs").apply { mkdirs() }
        val file = File(outDir, "jabima_payslip_${staff.id}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun generateMemorialProgramPdf(
        context: Context,
        schedule: BurialScheduleEvent,
        directorHotline: String = "+254 793 553 434"
    ): File {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val headerBg = Paint().apply { color = Color.rgb(15, 23, 42) } // Executive Navy
        val accentStrip = Paint().apply { color = Color.rgb(20, 90, 50) } // Forest Green accent
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val subtitlePaint = Paint().apply {
            color = Color.rgb(187, 247, 208)
            textSize = 10.5f
            isAntiAlias = true
        }
        val sectionPaint = Paint().apply {
            color = Color.rgb(20, 90, 50)
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val bodyPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 11f
            isAntiAlias = true
        }
        val boldPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val dividerPaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }

        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), 108f, headerBg)
        canvas.drawRect(0f, 102f, PAGE_WIDTH.toFloat(), 108f, accentStrip)
        canvas.drawText("MEMORIAL SERVICE PROGRAM & FAMILY CASE CARD", 32f, 40f, titlePaint)
        canvas.drawText("IN LOVING MEMORY OF ${schedule.deceasedName.uppercase(Locale.US)}", 32f, 62f, subtitlePaint)
        canvas.drawText("Jabima Funeral Directors Ltd • Case #${schedule.caseReference} • ${schedule.burialDate}", 32f, 82f, subtitlePaint)

        // Draw Verification QR Code in top-right below header
        val qrBitmap = QrCodeBitmapHelper.generateQrBitmap(
            "JFD-CASE:${schedule.caseReference}|ETIMS:${schedule.etimsReceiptRef}|DECEASED:${schedule.deceasedName}",
            110
        )
        canvas.drawBitmap(qrBitmap, PAGE_WIDTH - 142f, 124f, null)

        var y = 136f
        canvas.drawText("FAMILY & CORTEGE DISPATCH DETAILS", 32f, y, sectionPaint); y += 20f
        canvas.drawText("Deceased: ${schedule.deceasedName}", 32f, y, boldPaint); y += 16f
        canvas.drawText("Family Representative: ${schedule.familyRepresentative}", 32f, y, bodyPaint); y += 16f
        canvas.drawText("Selected Casket: ${schedule.casketModel}", 32f, y, bodyPaint); y += 16f
        canvas.drawText("Chapel / Church Venue: ${schedule.churchVenue}", 32f, y, bodyPaint); y += 16f
        canvas.drawText("Gravesite Location: ${schedule.gravesiteLocation}", 32f, y, bodyPaint); y += 16f
        canvas.drawText("Assigned Hearse & Driver: ${schedule.assignedHearseReg} • ${schedule.assignedDriverName}", 32f, y, boldPaint); y += 16f
        canvas.drawText("Funeral Director: ${schedule.assignedDirector} ($directorHotline)", 32f, y, bodyPaint); y += 16f
        canvas.drawText("eTIMS Receipt Ref: ${schedule.etimsReceiptRef}", 32f, y, bodyPaint); y += 20f

        canvas.drawLine(32f, y, PAGE_WIDTH - 32f, y, dividerPaint); y += 22f
        canvas.drawText("LIVE CORTEGE MILESTONE: ${schedule.currentMilestone.label.uppercase(Locale.US)}", 32f, y, sectionPaint); y += 16f
        canvas.drawText("Last Update: ${schedule.milestoneUpdatedAt}", 32f, y, bodyPaint); y += 22f

        canvas.drawLine(32f, y, PAGE_WIDTH - 32f, y, dividerPaint); y += 22f
        canvas.drawText("ORDER OF FUNERAL SERVICE & CORTEGE TIMELINE", 32f, y, sectionPaint); y += 20f
        schedule.timings.forEach { timing ->
            if (y < PAGE_HEIGHT - 120) {
                canvas.drawText("${timing.timeFormatted} — ${timing.stage.label}", 32f, y, boldPaint); y += 15f
                canvas.drawText("Venue: ${timing.venue} • Crew: ${timing.assignedStaffNames.joinToString(", ")}", 44f, y, bodyPaint); y += 18f
            }
        }

        y += 10f
        canvas.drawLine(32f, y, PAGE_WIDTH - 32f, y, dividerPaint); y += 20f
        canvas.drawText("24/7 CARE & DIGNITY ASSURANCE", 32f, y, sectionPaint); y += 16f
        canvas.drawText("For real-time family assistance or escort coordination, call $directorHotline.", 32f, y, bodyPaint)

        canvas.drawText("Jabima Funeral Directors Ltd • Bama Branch, Siaya • Rest in Eternal Peace", 32f, PAGE_HEIGHT - 28f, bodyPaint)

        doc.finishPage(page)
        val outDir = File(context.cacheDir, "pdfs").apply { mkdirs() }
        val file = File(outDir, "jabima_memorial_program_${schedule.caseReference}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun generateOrderTaxReceiptPdf(
        context: Context,
        order: CustomerOrderRecord
    ): File {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val headerBg = Paint().apply { color = Color.rgb(29, 78, 123) } // Corporate Sapphire Blue
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val subtitlePaint = Paint().apply {
            color = Color.rgb(219, 234, 254)
            textSize = 10f
            isAntiAlias = true
        }
        val sectionPaint = Paint().apply {
            color = Color.rgb(20, 90, 50)
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val bodyPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11f
            isAntiAlias = true
        }
        val boldBodyPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val dividerPaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }

        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), 96f, headerBg)
        canvas.drawText("JABIMA FUNERAL DIRECTORS LTD", 32f, 38f, titlePaint)
        canvas.drawText("OFFICIAL TAX INVOICE & PAYMENT RECEIPT • PIN: P051928192X", 32f, 58f, subtitlePaint)
        canvas.drawText("Branch: ${order.branch} • 24/7 Dispatch Hotline: +254 793 553 434", 32f, 76f, subtitlePaint)

        var y = 128f
        canvas.drawText("ORDER & CLIENT SUMMARY", 32f, y, sectionPaint); y += 20f
        canvas.drawText("Invoice Number: ${order.orderId}", 32f, y, boldBodyPaint)
        canvas.drawText("Order Date: ${order.orderDate}", 320f, y, bodyPaint); y += 18f
        canvas.drawText("Client Family: ${order.clientName}", 32f, y, bodyPaint)
        canvas.drawText("Phone: ${order.clientPhone}", 320f, y, bodyPaint); y += 18f
        canvas.drawText("Deceased Name: ${order.deceasedName}", 32f, y, boldBodyPaint)
        canvas.drawText("Sales Counselor: ${order.salesAgentName}", 320f, y, bodyPaint); y += 20f

        canvas.drawLine(32f, y, PAGE_WIDTH - 32f, y, dividerPaint); y += 22f
        canvas.drawText("ITEMIZED FUNERAL SERVICES & CASKET", 32f, y, sectionPaint); y += 20f
        canvas.drawText("• Selected Package: ${order.selectedPackage}", 32f, y, bodyPaint); y += 18f
        canvas.drawText("• Casket Specification: ${order.selectedCasket}", 32f, y, bodyPaint); y += 18f
        if (order.selectedAddons.isNotEmpty()) {
            order.selectedAddons.forEach { addon ->
                if (y < PAGE_HEIGHT - 160) {
                    canvas.drawText("• Add-On: $addon", 32f, y, bodyPaint)
                    y += 16f
                }
            }
        } else {
            canvas.drawText("• Add-Ons: Standard package inclusions", 32f, y, bodyPaint); y += 18f
        }

        y += 10f
        canvas.drawLine(32f, y, PAGE_WIDTH - 32f, y, dividerPaint); y += 24f
        drawKeyValueRow(canvas, "TOTAL INVOICED AMOUNT (KES)", order.totalAmountKes, 32f, y, boldBodyPaint, boldBodyPaint); y += 18f
        canvas.drawText("USD Equivalent: $${String.format(Locale.US, "%,.0f", order.totalAmountUsd)}", 32f, y, bodyPaint); y += 18f
        canvas.drawText("Payment Method: ${order.paymentMethod} • Ref: ${order.referenceCode}", 32f, y, boldBodyPaint); y += 16f
        canvas.drawText("Payment Terms: ${order.paymentTerms}", 32f, y, bodyPaint); y += 16f
        canvas.drawText("Status: ${order.paymentStatus}", 32f, y, boldBodyPaint)

        canvas.drawText("Thank you for trusting Jabima Funeral Directors Ltd. KRA eTIMS Compliant.", 32f, PAGE_HEIGHT - 28f, bodyPaint)

        doc.finishPage(page)
        val outDir = File(context.cacheDir, "pdfs").apply { mkdirs() }
        val file = File(outDir, "jabima_receipt_${order.orderId}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun generateThermalPosReceiptPdf(
        context: Context,
        receipt: PosReceipt
    ): File {
        val doc = PdfDocument()
        val pageWidth = 340
        val lineHeight = 16
        val estimatedHeight = (420 + (receipt.items.size * 22)).coerceAtLeast(520)
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, estimatedHeight, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val headerPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 13f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            isAntiAlias = true
        }
        val subPaint = Paint().apply {
            color = Color.rgb(51, 65, 85)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            isAntiAlias = true
        }
        val boldMono = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            isAntiAlias = true
        }
        val divider = Paint().apply {
            color = Color.rgb(148, 163, 184)
            strokeWidth = 1f
        }

        var y = 28f
        canvas.drawText("JABIMA FUNERAL DIRECTORS LTD", 20f, y, headerPaint); y += 16f
        canvas.drawText("Branch: ${receipt.branch}", 20f, y, subPaint); y += 14f
        canvas.drawText("KRA PIN: P051283921Q | ETR: ${receipt.etrNumber}", 20f, y, subPaint); y += 14f
        canvas.drawText("M-PESA STK: ${receipt.mpesaStkNumber}", 20f, y, boldMono); y += 10f
        canvas.drawLine(20f, y, pageWidth - 20f, y, divider); y += 16f

        canvas.drawText("RECEIPT: ${receipt.receiptNumber}", 20f, y, boldMono); y += 14f
        canvas.drawText("DATE: ${receipt.date} ${receipt.time}", 20f, y, subPaint); y += 14f
        canvas.drawText("CLIENT: ${receipt.customerFamily.take(30)}", 20f, y, subPaint); y += 14f
        canvas.drawText("CASE: ${receipt.caseReference}", 20f, y, boldMono); y += 14f
        canvas.drawText("CASHIER: ${receipt.cashierStaffName.take(24)} (${receipt.cashierStaffId})", 20f, y, subPaint); y += 10f
        canvas.drawLine(20f, y, pageWidth - 20f, y, divider); y += 16f

        receipt.items.forEach { cartItem ->
            val lineTotal = cartItem.item.price * cartItem.quantity
            canvas.drawText("${cartItem.quantity}x ${cartItem.item.name.take(22)}", 20f, y, subPaint)
            canvas.drawText(String.format(Locale.US, "KES %,.0f", lineTotal), 220f, y, boldMono)
            y += lineHeight
        }

        y += 4f
        canvas.drawLine(20f, y, pageWidth - 20f, y, divider); y += 16f
        canvas.drawText("SUBTOTAL:", 20f, y, subPaint)
        canvas.drawText(String.format(Locale.US, "KES %,.0f", receipt.subtotal), 210f, y, subPaint); y += 14f
        canvas.drawText("VAT (16% INCL):", 20f, y, subPaint)
        canvas.drawText(String.format(Locale.US, "KES %,.0f", receipt.taxVat), 210f, y, subPaint); y += 16f
        canvas.drawText("TOTAL PAID:", 20f, y, headerPaint)
        canvas.drawText(String.format(Locale.US, "KES %,.0f", receipt.totalAmount), 195f, y, headerPaint); y += 18f

        canvas.drawText("METHOD: ${receipt.paymentMethod}", 20f, y, boldMono); y += 14f
        canvas.drawText("TERMS: ${receipt.paymentTerms.take(30)}", 20f, y, subPaint); y += 14f
        if (!receipt.mpesaRef.isNullOrBlank()) {
            canvas.drawText("M-PESA REF: ${receipt.mpesaRef}", 20f, y, boldMono); y += 14f
        }
        y += 8f
        canvas.drawLine(20f, y, pageWidth - 20f, y, divider); y += 16f
        canvas.drawText("THANK YOU FOR CHOOSING JABIMA", 20f, y, boldMono); y += 14f
        canvas.drawText("May their soul rest in eternal peace", 20f, y, subPaint)

        doc.finishPage(page)
        val outDir = File(context.cacheDir, "pdfs").apply { mkdirs() }
        val safeReceipt = receipt.receiptNumber.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        val file = File(outDir, "jabima_pos_${safeReceipt}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun sharePdfFile(context: Context, pdfFile: File, title: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching {
            context.startActivity(chooser)
        }.onFailure {
            android.widget.Toast.makeText(
                context,
                "PDF saved to ${pdfFile.name}. No share app found on device.",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun drawKeyValueRow(
        canvas: android.graphics.Canvas,
        label: String,
        amountKes: Double,
        x: Float,
        y: Float,
        labelPaint: Paint,
        valuePaint: Paint
    ) {
        canvas.drawText(label, x, y, labelPaint)
        val formatted = if (amountKes < 0) {
            "- KES ${String.format(Locale.US, "%,.2f", kotlin.math.abs(amountKes))}"
        } else {
            "KES ${String.format(Locale.US, "%,.2f", amountKes)}"
        }
        canvas.drawText(formatted, 430f, y, valuePaint)
    }
}
