package com.example.data.firebase

import com.example.base.FirestoreEmulatorTestBase
import com.example.model.ActivityCategory
import com.example.model.ActivityStatus
import com.example.model.CustomerOrderRecord
import com.example.model.Department
import com.example.model.PaymentStatus
import com.example.model.StaffActivity
import com.example.model.StaffBreakageRecord
import com.example.model.TransactionType
import com.example.model.WalletTransaction
import com.google.common.truth.Truth.assertThat
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Test
import java.util.UUID
import kotlin.test.assertFailsWith

class FirestoreRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun observeWalletTransactions_unauthenticated_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = FirestoreSyncRepository(firestore, auth)

        val ex = assertFailsWith<Exception> {
            withTimeout(FLOW_TIMEOUT_MS) { repo.observeWalletTransactions(isAdmin = false).first() }
        }
        // Close happens either immediately (IllegalStateException in repo guard) or via Firestore PERMISSION_DENIED
        val isPermissionOrAuthGuard = ex is IllegalStateException ||
            ex.unwrapFirestoreException()?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED
        assertThat(isPermissionOrAuthGuard).isTrue()
    }

    @Test
    fun directFirestoreRead_unauthenticated_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val exception = assertFailsWith<Exception> {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection(FirestoreSyncRepository.COLLECTION_WALLET_TRANSACTIONS)
                    .whereEqualTo("userId", "alice_uid")
                    .addSnapshotListener { _, _ -> }
                    .let { reg ->
                        try {
                            FirestoreSyncRepository(firestore, auth).apply {
                                // Trigger a direct rule-checked get via FirebaseFirestore when signed out
                            }
                        } finally {
                            reg.remove()
                        }
                    }
                val snapTask = firestore.collection(FirestoreSyncRepository.COLLECTION_WALLET_TRANSACTIONS)
                    .document("nonexistent-doc")
                    .get()
                com.google.android.gms.tasks.Tasks.await(snapTask)
            }
        }
        val fsEx = checkNotNull(exception.unwrapFirestoreException()) { "Expected FirebaseFirestoreException, got $exception" }
        assertThat(fsEx.code).isEqualTo(FirebaseFirestoreException.Code.PERMISSION_DENIED)
    }

    @Test
    fun userProfile_ownerCreateReadUpdate_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = FirestoreSyncRepository(firestore, auth)

        val createRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.upsertUserProfile(
                displayName = "Alice Staff",
                email = ALICE_EMAIL,
                linkedStaffId = "SLS-001",
                linkedBranch = "Bama Branch",
                darkModeEnabled = true
            )
        }
        assertThat(createRes.isSuccess).isTrue()

        val readRes = withTimeout(DEFAULT_TIMEOUT_MS) { repo.getUserProfile(uid) }
        assertThat(readRes.isSuccess).isTrue()
        val profile = checkNotNull(readRes.getOrNull())
        assertThat(profile.userId).isEqualTo(uid)
        assertThat(profile.linkedStaffId).isEqualTo("SLS-001")
        assertThat(profile.darkModeEnabled).isTrue()

        val updateRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.upsertUserProfile(
                displayName = "Alice Updated",
                email = ALICE_EMAIL,
                linkedStaffId = "SLS-002",
                linkedBranch = "Siaya Depot",
                darkModeEnabled = false
            )
        }
        assertThat(updateRes.isSuccess).isTrue()
    }

    @Test
    fun walletTransaction_ownerCreateAndObserve_succeeds_crossUserUpdate_denied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = FirestoreSyncRepository(firestore, auth)
        val txnId = "TXN-${UUID.randomUUID().toString().take(8)}"

        val pendingPayout = WalletTransaction(
            id = txnId,
            staffId = "SLS-001",
            type = TransactionType.PAYOUT_WITHDRAWAL,
            title = "M-PESA Withdrawal",
            referenceNumber = "WD-$txnId",
            amount = -5000.0,
            date = "14 Nov 2026",
            status = PaymentStatus.PENDING_APPROVAL,
            notes = "Initial note",
            payoutMethod = "M-PESA",
            payoutDestination = "+254711111111"
        )

        val createRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createWalletTransaction(pendingPayout, "Alice Staff")
        }
        assertThat(createRes.isSuccess).isTrue()

        val emitted = withTimeout(FLOW_TIMEOUT_MS) {
            aliceRepo.observeWalletTransactions(isAdmin = false).first { list ->
                list.any { it.id == txnId && it.userId == aliceUid }
            }
        }
        assertThat(emitted.map { it.id }).contains(txnId)

        val updateRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.updatePendingPayoutNotes(txnId, "Updated M-PESA note", "+254722000111")
        }
        assertThat(updateRes.isSuccess).isTrue()

        // Non-admin Bob must not update or delete Alice's transaction
        signInTestUser(BOB_EMAIL)
        val bobRepo = FirestoreSyncRepository(firestore, auth)
        val bobUpdateEx = assertFailsWith<FirebaseFirestoreException> {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                bobRepo.updatePendingPayoutNotes(txnId, "Tamper", "+254799999999").getOrThrow()
            }
        }
        assertThat(bobUpdateEx.code).isEqualTo(FirebaseFirestoreException.Code.PERMISSION_DENIED)
    }

    @Test
    fun customerOrder_ownerCreateAndObserve_succeeds() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repo = FirestoreSyncRepository(firestore, auth)
        val orderId = "ORD-${UUID.randomUUID().toString().take(8)}"

        val order = CustomerOrderRecord(
            orderId = orderId,
            clientName = "Family Otieno",
            clientPhone = "+254733333333",
            deceasedName = "Late Mary Otieno",
            selectedPackage = "Executive Package",
            selectedCasket = "Oak Elite (KES 120,000)",
            selectedAddons = emptyList(),
            totalAmountKes = 120_000.0,
            totalAmountUsd = 923.0,
            paymentMethod = "M-PESA",
            paymentTerms = "Full payment",
            paymentStatus = "PENDING_INSTALLMENT",
            referenceCode = "REF-$orderId",
            orderDate = "14 Nov 2026",
            branch = "Bama Branch",
            salesAgentName = "Alice Staff",
            commissionEarnedKes = 6000.0
        )

        val createRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.createCustomerOrder(order, "SLS-001")
        }
        assertThat(createRes.isSuccess).isTrue()

        val orders = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeCustomerOrders(isAdmin = false).first { list ->
                list.any { it.id == orderId }
            }
        }
        assertThat(orders.first { it.id == orderId }.clientName).isEqualTo("Family Otieno")
    }

    @Test
    fun staffActivity_nonAdminSelfVerification_failsWithPermissionDenied() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repo = FirestoreSyncRepository(firestore, auth)
        val actId = "ACT-${UUID.randomUUID().toString().take(8)}"

        val activity = StaffActivity(
            id = actId,
            staffId = "DRV-001",
            staffName = "Alice Driver",
            department = Department.DRIVERS,
            category = ActivityCategory.FLEET_TRANSPORT,
            title = "Cortege Transport Escort",
            caseReference = "CASE-881",
            clientFamily = "Family Kamau",
            location = "Siaya",
            date = "14 Nov 2026",
            time = "09:00",
            durationMinutes = 120,
            status = ActivityStatus.IN_PROGRESS,
            allowanceEarned = 0.0
        )

        val createRes = withTimeout(DEFAULT_TIMEOUT_MS) { repo.createStaffActivity(activity) }
        assertThat(createRes.isSuccess).isTrue()

        val statusUpdate = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.updateStaffActivityStatus(actId, ActivityStatus.COMPLETED)
        }
        assertThat(statusUpdate.isSuccess).isTrue()

        // Non-admin user must be denied from setting verifiedByAdmin=true and allowanceEarned
        val selfVerifyEx = assertFailsWith<FirebaseFirestoreException> {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                repo.adminVerifyAndPriceActivity(actId, 9500.0, ActivityStatus.VERIFIED_BY_ADMIN).getOrThrow()
            }
        }
        assertThat(selfVerifyEx.code).isEqualTo(FirebaseFirestoreException.Code.PERMISSION_DENIED)
    }

    @Test
    fun breakageRecord_kotlinPropertyMappingAndNonAdminDeductionGuard() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repo = FirestoreSyncRepository(firestore, auth)
        val brkId = "BRK-${UUID.randomUUID().toString().take(8)}"

        val record = StaffBreakageRecord(
            id = brkId,
            staffId = "WRK-001",
            staffName = "Workshop Artisan",
            department = Department.WORKSHOP,
            itemBroken = "Carved Brass Handle",
            description = "Damaged during transit",
            breakageCostKes = 4500.0,
            date = "14 Nov 2026",
            loggedBy = "Alice Staff",
            isDeducted = false
        )

        val createRes = withTimeout(DEFAULT_TIMEOUT_MS) { repo.createBreakageRecord(record) }
        assertThat(createRes.isSuccess).isTrue()

        val updateDescRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.updateBreakageDescription(brkId, "Updated transit note")
        }
        assertThat(updateDescRes.isSuccess).isTrue()

        val deductEx = assertFailsWith<FirebaseFirestoreException> {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                repo.adminMarkBreakageDeducted(brkId).getOrThrow()
            }
        }
        assertThat(deductEx.code).isEqualTo(FirebaseFirestoreException.Code.PERMISSION_DENIED)
    }

    private companion object {
        const val ALICE_EMAIL = "alice.staff@jabima.test"
        const val BOB_EMAIL = "bob.staff@jabima.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
