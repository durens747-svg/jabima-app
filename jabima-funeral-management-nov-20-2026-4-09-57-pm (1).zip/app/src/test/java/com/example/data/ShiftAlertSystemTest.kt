package com.example.data

import com.example.model.ActivityStatus
import com.example.model.TaskPriority
import com.google.common.truth.Truth.assertThat
import org.junit.Before
import org.junit.Test

class ShiftAlertSystemTest {

    private lateinit var repository: StaffPortalRepository

    @Before
    fun setUp() {
        repository = StaffPortalRepository()
    }

    @Test
    fun initialAlertsContainActiveShiftReadinessAlerts() {
        val alerts = repository.staffAlerts.value
        val shiftAlerts = alerts.filter { it.category == "SHIFT_ALERT" }

        assertThat(shiftAlerts).isNotEmpty()
        assertThat(shiftAlerts.any { !it.isRead }).isTrue()
    }

    @Test
    fun dispatchShiftAlert_prependsAlertWithPriorityAndSmsFlag() {
        val created = repository.dispatchShiftAlert(
            recipientStaffId = "DRV-002",
            recipientName = "Joseph Ouma",
            title = "Urgent First-Call Van Readiness",
            message = "Report at Siaya Referral bay immediately.",
            priority = TaskPriority.URGENT,
            shiftId = "SH-TEST-01",
            scheduledTimeLabel = "09:45 AM",
            branch = "Bondo",
            smsDispatched = true
        )

        val topAlert = repository.staffAlerts.value.first()
        assertThat(topAlert.id).isEqualTo(created.id)
        assertThat(topAlert.category).isEqualTo("SHIFT_ALERT")
        assertThat(topAlert.priority).isEqualTo(TaskPriority.URGENT)
        assertThat(topAlert.smsDispatched).isTrue()
        assertThat(topAlert.shiftId).isEqualTo("SH-TEST-01")
    }

    @Test
    fun scanAndTriggerDueShiftAlerts_createsAlertsAndIsIdempotent() {
        val initialSize = repository.staffAlerts.value.size

        val firstScanCount = repository.scanAndTriggerDueShiftAlerts("23 Sep 2026")
        assertThat(firstScanCount).isGreaterThan(0)
        assertThat(repository.staffAlerts.value.size).isEqualTo(initialSize + firstScanCount)

        val secondScanCount = repository.scanAndTriggerDueShiftAlerts("23 Sep 2026")
        assertThat(secondScanCount).isEqualTo(0)
        assertThat(repository.staffAlerts.value.size).isEqualTo(initialSize + firstScanCount)
    }

    @Test
    fun acknowledgeAndMarkAllAndDismiss_updateAlertStatesCorrectly() {
        val targetAlert = repository.dispatchShiftAlert(
            recipientStaffId = "WRK-001",
            recipientName = "Brian Adoche",
            title = "Morning Workshop Shift",
            message = "Inspect mahogany curing bay."
        )
        assertThat(repository.staffAlerts.value.first { it.id == targetAlert.id }.isRead).isFalse()

        repository.acknowledgeShiftAlert(targetAlert.id)
        val acknowledged = repository.staffAlerts.value.first { it.id == targetAlert.id }
        assertThat(acknowledged.isRead).isTrue()
        assertThat(acknowledged.acknowledgedAt).isNotNull()

        repository.markAllShiftAlertsRead()
        assertThat(repository.staffAlerts.value.all { it.isRead }).isTrue()

        repository.dismissShiftAlert(targetAlert.id)
        assertThat(repository.staffAlerts.value.none { it.id == targetAlert.id }).isTrue()
    }

    @Test
    fun updateActivityStatus_persistsNotesAndCreditsAllowanceOnCompletion() {
        val scheduledTask = repository.activities.value.first { it.status == ActivityStatus.SCHEDULED }
        val initialTxns = repository.transactions.value.size

        repository.updateActivityStatus(
            activityId = scheduledTask.id,
            newStatus = ActivityStatus.COMPLETED,
            completionNotes = "Setup finished 15 min ahead of schedule"
        )

        val updated = repository.activities.value.first { it.id == scheduledTask.id }
        assertThat(updated.status).isEqualTo(ActivityStatus.COMPLETED)
        assertThat(updated.notes).contains("Setup finished 15 min ahead of schedule")
        assertThat(repository.transactions.value.size).isGreaterThan(initialTxns)
    }

    @Test
    fun evaluateAndDispatchOperationalAlerts_triggersOnceForLowStockAndHighColdRoom() {
        val targetMaterial = repository.inventoryMaterials.value.first()
        repository.addOrReplaceInventoryMaterial(targetMaterial.copy(quantity = targetMaterial.minThreshold))
        val targetBranch = repository.branchStatusBoards.value.first()
        repository.addOrReplaceBranchStatusBoard(
            targetBranch.copy(coldRoomCapacity = 20, coldRoomOccupancy = 18)
        )

        val dispatchedFirst = repository.evaluateAndDispatchOperationalAlerts()
        assertThat(dispatchedFirst).isAtLeast(2)
        assertThat(
            repository.staffAlerts.value.any {
                it.category == "LOW_STOCK_ALERT" && it.relatedEntityId == targetMaterial.id
            }
        ).isTrue()
        assertThat(
            repository.staffAlerts.value.any {
                it.category == "COLD_ROOM_CAPACITY" && it.relatedEntityId == targetBranch.branchName
            }
        ).isTrue()

        val countBeforeRepeat = repository.staffAlerts.value.size
        val dispatchedRepeat = repository.evaluateAndDispatchOperationalAlerts()
        assertThat(dispatchedRepeat).isEqualTo(0)
        assertThat(repository.staffAlerts.value.size).isEqualTo(countBeforeRepeat)
    }
}

